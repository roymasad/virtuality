(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const l of document.querySelectorAll('link[rel="modulepreload"]'))s(l);new MutationObserver(l=>{for(const c of l)if(c.type==="childList")for(const f of c.addedNodes)f.tagName==="LINK"&&f.rel==="modulepreload"&&s(f)}).observe(document,{childList:!0,subtree:!0});function i(l){const c={};return l.integrity&&(c.integrity=l.integrity),l.referrerPolicy&&(c.referrerPolicy=l.referrerPolicy),l.crossOrigin==="use-credentials"?c.credentials="include":l.crossOrigin==="anonymous"?c.credentials="omit":c.credentials="same-origin",c}function s(l){if(l.ep)return;l.ep=!0;const c=i(l);fetch(l.href,c)}})();function c_(r){return r&&r.__esModule&&Object.prototype.hasOwnProperty.call(r,"default")?r.default:r}var ph={exports:{}},ko={};var em;function u_(){if(em)return ko;em=1;var r=Symbol.for("react.transitional.element"),t=Symbol.for("react.fragment");function i(s,l,c){var f=null;if(c!==void 0&&(f=""+c),l.key!==void 0&&(f=""+l.key),"key"in l){c={};for(var T in l)T!=="key"&&(c[T]=l[T])}else c=l;return l=c.ref,{$$typeof:r,type:s,key:f,ref:l!==void 0?l:null,props:c}}return ko.Fragment=t,ko.jsx=i,ko.jsxs=i,ko}var nm;function f_(){return nm||(nm=1,ph.exports=u_()),ph.exports}var jc=f_(),Th={exports:{}},ae={};var im;function h_(){if(im)return ae;im=1;var r=Symbol.for("react.transitional.element"),t=Symbol.for("react.portal"),i=Symbol.for("react.fragment"),s=Symbol.for("react.strict_mode"),l=Symbol.for("react.profiler"),c=Symbol.for("react.consumer"),f=Symbol.for("react.context"),T=Symbol.for("react.forward_ref"),p=Symbol.for("react.suspense"),h=Symbol.for("react.memo"),m=Symbol.for("react.lazy"),E=Symbol.for("react.activity"),S=Symbol.iterator;function g(O){return O===null||typeof O!="object"?null:(O=S&&O[S]||O["@@iterator"],typeof O=="function"?O:null)}var A={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},M=Object.assign,x={};function v(O,V,dt){this.props=O,this.context=V,this.refs=x,this.updater=dt||A}v.prototype.isReactComponent={},v.prototype.setState=function(O,V){if(typeof O!="object"&&typeof O!="function"&&O!=null)throw Error("takes an object of state variables to update or a function which returns an object of state variables.");this.updater.enqueueSetState(this,O,V,"setState")},v.prototype.forceUpdate=function(O){this.updater.enqueueForceUpdate(this,O,"forceUpdate")};function D(){}D.prototype=v.prototype;function I(O,V,dt){this.props=O,this.context=V,this.refs=x,this.updater=dt||A}var U=I.prototype=new D;U.constructor=I,M(U,v.prototype),U.isPureReactComponent=!0;var Y=Array.isArray;function F(){}var B={H:null,A:null,T:null,S:null},R=Object.prototype.hasOwnProperty;function w(O,V,dt){var gt=dt.ref;return{$$typeof:r,type:O,key:V,ref:gt!==void 0?gt:null,props:dt}}function Z(O,V){return w(O.type,V,O.props)}function H(O){return typeof O=="object"&&O!==null&&O.$$typeof===r}function $(O){var V={"=":"=0",":":"=2"};return"$"+O.replace(/[=:]/g,function(dt){return V[dt]})}var ct=/\/+/g;function lt(O,V){return typeof O=="object"&&O!==null&&O.key!=null?$(""+O.key):V.toString(36)}function W(O){switch(O.status){case"fulfilled":return O.value;case"rejected":throw O.reason;default:switch(typeof O.status=="string"?O.then(F,F):(O.status="pending",O.then(function(V){O.status==="pending"&&(O.status="fulfilled",O.value=V)},function(V){O.status==="pending"&&(O.status="rejected",O.reason=V)})),O.status){case"fulfilled":return O.value;case"rejected":throw O.reason}}throw O}function L(O,V,dt,gt,Mt){var rt=typeof O;(rt==="undefined"||rt==="boolean")&&(O=null);var vt=!1;if(O===null)vt=!0;else switch(rt){case"bigint":case"string":case"number":vt=!0;break;case"object":switch(O.$$typeof){case r:case t:vt=!0;break;case m:return vt=O._init,L(vt(O._payload),V,dt,gt,Mt)}}if(vt)return Mt=Mt(O),vt=gt===""?"."+lt(O,0):gt,Y(Mt)?(dt="",vt!=null&&(dt=vt.replace(ct,"$&/")+"/"),L(Mt,V,dt,"",function(Jt){return Jt})):Mt!=null&&(H(Mt)&&(Mt=Z(Mt,dt+(Mt.key==null||O&&O.key===Mt.key?"":(""+Mt.key).replace(ct,"$&/")+"/")+vt)),V.push(Mt)),1;vt=0;var Nt=gt===""?".":gt+":";if(Y(O))for(var Pt=0;Pt<O.length;Pt++)gt=O[Pt],rt=Nt+lt(gt,Pt),vt+=L(gt,V,dt,rt,Mt);else if(Pt=g(O),typeof Pt=="function")for(O=Pt.call(O),Pt=0;!(gt=O.next()).done;)gt=gt.value,rt=Nt+lt(gt,Pt++),vt+=L(gt,V,dt,rt,Mt);else if(rt==="object"){if(typeof O.then=="function")return L(W(O),V,dt,gt,Mt);throw V=String(O),Error("Objects are not valid as a React child (found: "+(V==="[object Object]"?"object with keys {"+Object.keys(O).join(", ")+"}":V)+"). If you meant to render a collection of children, use an array instead.")}return vt}function P(O,V,dt){if(O==null)return O;var gt=[],Mt=0;return L(O,gt,"","",function(rt){return V.call(dt,rt,Mt++)}),gt}function it(O){if(O._status===-1){var V=O._result;V=V(),V.then(function(dt){(O._status===0||O._status===-1)&&(O._status=1,O._result=dt)},function(dt){(O._status===0||O._status===-1)&&(O._status=2,O._result=dt)}),O._status===-1&&(O._status=0,O._result=V)}if(O._status===1)return O._result.default;throw O._result}var mt=typeof reportError=="function"?reportError:function(O){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var V=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof O=="object"&&O!==null&&typeof O.message=="string"?String(O.message):String(O),error:O});if(!window.dispatchEvent(V))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",O);return}console.error(O)},ft={map:P,forEach:function(O,V,dt){P(O,function(){V.apply(this,arguments)},dt)},count:function(O){var V=0;return P(O,function(){V++}),V},toArray:function(O){return P(O,function(V){return V})||[]},only:function(O){if(!H(O))throw Error("React.Children.only expected to receive a single React element child.");return O}};return ae.Activity=E,ae.Children=ft,ae.Component=v,ae.Fragment=i,ae.Profiler=l,ae.PureComponent=I,ae.StrictMode=s,ae.Suspense=p,ae.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=B,ae.__COMPILER_RUNTIME={__proto__:null,c:function(O){return B.H.useMemoCache(O)}},ae.cache=function(O){return function(){return O.apply(null,arguments)}},ae.cacheSignal=function(){return null},ae.cloneElement=function(O,V,dt){if(O==null)throw Error("The argument must be a React element, but you passed "+O+".");var gt=M({},O.props),Mt=O.key;if(V!=null)for(rt in V.key!==void 0&&(Mt=""+V.key),V)!R.call(V,rt)||rt==="key"||rt==="__self"||rt==="__source"||rt==="ref"&&V.ref===void 0||(gt[rt]=V[rt]);var rt=arguments.length-2;if(rt===1)gt.children=dt;else if(1<rt){for(var vt=Array(rt),Nt=0;Nt<rt;Nt++)vt[Nt]=arguments[Nt+2];gt.children=vt}return w(O.type,Mt,gt)},ae.createContext=function(O){return O={$$typeof:f,_currentValue:O,_currentValue2:O,_threadCount:0,Provider:null,Consumer:null},O.Provider=O,O.Consumer={$$typeof:c,_context:O},O},ae.createElement=function(O,V,dt){var gt,Mt={},rt=null;if(V!=null)for(gt in V.key!==void 0&&(rt=""+V.key),V)R.call(V,gt)&&gt!=="key"&&gt!=="__self"&&gt!=="__source"&&(Mt[gt]=V[gt]);var vt=arguments.length-2;if(vt===1)Mt.children=dt;else if(1<vt){for(var Nt=Array(vt),Pt=0;Pt<vt;Pt++)Nt[Pt]=arguments[Pt+2];Mt.children=Nt}if(O&&O.defaultProps)for(gt in vt=O.defaultProps,vt)Mt[gt]===void 0&&(Mt[gt]=vt[gt]);return w(O,rt,Mt)},ae.createRef=function(){return{current:null}},ae.forwardRef=function(O){return{$$typeof:T,render:O}},ae.isValidElement=H,ae.lazy=function(O){return{$$typeof:m,_payload:{_status:-1,_result:O},_init:it}},ae.memo=function(O,V){return{$$typeof:h,type:O,compare:V===void 0?null:V}},ae.startTransition=function(O){var V=B.T,dt={};B.T=dt;try{var gt=O(),Mt=B.S;Mt!==null&&Mt(dt,gt),typeof gt=="object"&&gt!==null&&typeof gt.then=="function"&&gt.then(F,mt)}catch(rt){mt(rt)}finally{V!==null&&dt.types!==null&&(V.types=dt.types),B.T=V}},ae.unstable_useCacheRefresh=function(){return B.H.useCacheRefresh()},ae.use=function(O){return B.H.use(O)},ae.useActionState=function(O,V,dt){return B.H.useActionState(O,V,dt)},ae.useCallback=function(O,V){return B.H.useCallback(O,V)},ae.useContext=function(O){return B.H.useContext(O)},ae.useDebugValue=function(){},ae.useDeferredValue=function(O,V){return B.H.useDeferredValue(O,V)},ae.useEffect=function(O,V){return B.H.useEffect(O,V)},ae.useEffectEvent=function(O){return B.H.useEffectEvent(O)},ae.useId=function(){return B.H.useId()},ae.useImperativeHandle=function(O,V,dt){return B.H.useImperativeHandle(O,V,dt)},ae.useInsertionEffect=function(O,V){return B.H.useInsertionEffect(O,V)},ae.useLayoutEffect=function(O,V){return B.H.useLayoutEffect(O,V)},ae.useMemo=function(O,V){return B.H.useMemo(O,V)},ae.useOptimistic=function(O,V){return B.H.useOptimistic(O,V)},ae.useReducer=function(O,V,dt){return B.H.useReducer(O,V,dt)},ae.useRef=function(O){return B.H.useRef(O)},ae.useState=function(O){return B.H.useState(O)},ae.useSyncExternalStore=function(O,V,dt){return B.H.useSyncExternalStore(O,V,dt)},ae.useTransition=function(){return B.H.useTransition()},ae.version="19.2.6",ae}var am;function e0(){return am||(am=1,Th.exports=h_()),Th.exports}var bn=e0();const hR=c_(bn);var mh={exports:{}},Ko={},Eh={exports:{}},Sh={};var sm;function d_(){return sm||(sm=1,(function(r){function t(L,P){var it=L.length;L.push(P);t:for(;0<it;){var mt=it-1>>>1,ft=L[mt];if(0<l(ft,P))L[mt]=P,L[it]=ft,it=mt;else break t}}function i(L){return L.length===0?null:L[0]}function s(L){if(L.length===0)return null;var P=L[0],it=L.pop();if(it!==P){L[0]=it;t:for(var mt=0,ft=L.length,O=ft>>>1;mt<O;){var V=2*(mt+1)-1,dt=L[V],gt=V+1,Mt=L[gt];if(0>l(dt,it))gt<ft&&0>l(Mt,dt)?(L[mt]=Mt,L[gt]=it,mt=gt):(L[mt]=dt,L[V]=it,mt=V);else if(gt<ft&&0>l(Mt,it))L[mt]=Mt,L[gt]=it,mt=gt;else break t}}return P}function l(L,P){var it=L.sortIndex-P.sortIndex;return it!==0?it:L.id-P.id}if(r.unstable_now=void 0,typeof performance=="object"&&typeof performance.now=="function"){var c=performance;r.unstable_now=function(){return c.now()}}else{var f=Date,T=f.now();r.unstable_now=function(){return f.now()-T}}var p=[],h=[],m=1,E=null,S=3,g=!1,A=!1,M=!1,x=!1,v=typeof setTimeout=="function"?setTimeout:null,D=typeof clearTimeout=="function"?clearTimeout:null,I=typeof setImmediate<"u"?setImmediate:null;function U(L){for(var P=i(h);P!==null;){if(P.callback===null)s(h);else if(P.startTime<=L)s(h),P.sortIndex=P.expirationTime,t(p,P);else break;P=i(h)}}function Y(L){if(M=!1,U(L),!A)if(i(p)!==null)A=!0,F||(F=!0,$());else{var P=i(h);P!==null&&W(Y,P.startTime-L)}}var F=!1,B=-1,R=5,w=-1;function Z(){return x?!0:!(r.unstable_now()-w<R)}function H(){if(x=!1,F){var L=r.unstable_now();w=L;var P=!0;try{t:{A=!1,M&&(M=!1,D(B),B=-1),g=!0;var it=S;try{e:{for(U(L),E=i(p);E!==null&&!(E.expirationTime>L&&Z());){var mt=E.callback;if(typeof mt=="function"){E.callback=null,S=E.priorityLevel;var ft=mt(E.expirationTime<=L);if(L=r.unstable_now(),typeof ft=="function"){E.callback=ft,U(L),P=!0;break e}E===i(p)&&s(p),U(L)}else s(p);E=i(p)}if(E!==null)P=!0;else{var O=i(h);O!==null&&W(Y,O.startTime-L),P=!1}}break t}finally{E=null,S=it,g=!1}P=void 0}}finally{P?$():F=!1}}}var $;if(typeof I=="function")$=function(){I(H)};else if(typeof MessageChannel<"u"){var ct=new MessageChannel,lt=ct.port2;ct.port1.onmessage=H,$=function(){lt.postMessage(null)}}else $=function(){v(H,0)};function W(L,P){B=v(function(){L(r.unstable_now())},P)}r.unstable_IdlePriority=5,r.unstable_ImmediatePriority=1,r.unstable_LowPriority=4,r.unstable_NormalPriority=3,r.unstable_Profiling=null,r.unstable_UserBlockingPriority=2,r.unstable_cancelCallback=function(L){L.callback=null},r.unstable_forceFrameRate=function(L){0>L||125<L?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):R=0<L?Math.floor(1e3/L):5},r.unstable_getCurrentPriorityLevel=function(){return S},r.unstable_next=function(L){switch(S){case 1:case 2:case 3:var P=3;break;default:P=S}var it=S;S=P;try{return L()}finally{S=it}},r.unstable_requestPaint=function(){x=!0},r.unstable_runWithPriority=function(L,P){switch(L){case 1:case 2:case 3:case 4:case 5:break;default:L=3}var it=S;S=L;try{return P()}finally{S=it}},r.unstable_scheduleCallback=function(L,P,it){var mt=r.unstable_now();switch(typeof it=="object"&&it!==null?(it=it.delay,it=typeof it=="number"&&0<it?mt+it:mt):it=mt,L){case 1:var ft=-1;break;case 2:ft=250;break;case 5:ft=1073741823;break;case 4:ft=1e4;break;default:ft=5e3}return ft=it+ft,L={id:m++,callback:P,priorityLevel:L,startTime:it,expirationTime:ft,sortIndex:-1},it>mt?(L.sortIndex=it,t(h,L),i(p)===null&&L===i(h)&&(M?(D(B),B=-1):M=!0,W(Y,it-mt))):(L.sortIndex=ft,t(p,L),A||g||(A=!0,F||(F=!0,$()))),L},r.unstable_shouldYield=Z,r.unstable_wrapCallback=function(L){var P=S;return function(){var it=S;S=P;try{return L.apply(this,arguments)}finally{S=it}}}})(Sh)),Sh}var rm;function p_(){return rm||(rm=1,Eh.exports=d_()),Eh.exports}var gh={exports:{}},Fn={};var om;function T_(){if(om)return Fn;om=1;var r=e0();function t(p){var h="https://react.dev/errors/"+p;if(1<arguments.length){h+="?args[]="+encodeURIComponent(arguments[1]);for(var m=2;m<arguments.length;m++)h+="&args[]="+encodeURIComponent(arguments[m])}return"Minified React error #"+p+"; visit "+h+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function i(){}var s={d:{f:i,r:function(){throw Error(t(522))},D:i,C:i,L:i,m:i,X:i,S:i,M:i},p:0,findDOMNode:null},l=Symbol.for("react.portal");function c(p,h,m){var E=3<arguments.length&&arguments[3]!==void 0?arguments[3]:null;return{$$typeof:l,key:E==null?null:""+E,children:p,containerInfo:h,implementation:m}}var f=r.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;function T(p,h){if(p==="font")return"";if(typeof h=="string")return h==="use-credentials"?h:""}return Fn.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=s,Fn.createPortal=function(p,h){var m=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null;if(!h||h.nodeType!==1&&h.nodeType!==9&&h.nodeType!==11)throw Error(t(299));return c(p,h,null,m)},Fn.flushSync=function(p){var h=f.T,m=s.p;try{if(f.T=null,s.p=2,p)return p()}finally{f.T=h,s.p=m,s.d.f()}},Fn.preconnect=function(p,h){typeof p=="string"&&(h?(h=h.crossOrigin,h=typeof h=="string"?h==="use-credentials"?h:"":void 0):h=null,s.d.C(p,h))},Fn.prefetchDNS=function(p){typeof p=="string"&&s.d.D(p)},Fn.preinit=function(p,h){if(typeof p=="string"&&h&&typeof h.as=="string"){var m=h.as,E=T(m,h.crossOrigin),S=typeof h.integrity=="string"?h.integrity:void 0,g=typeof h.fetchPriority=="string"?h.fetchPriority:void 0;m==="style"?s.d.S(p,typeof h.precedence=="string"?h.precedence:void 0,{crossOrigin:E,integrity:S,fetchPriority:g}):m==="script"&&s.d.X(p,{crossOrigin:E,integrity:S,fetchPriority:g,nonce:typeof h.nonce=="string"?h.nonce:void 0})}},Fn.preinitModule=function(p,h){if(typeof p=="string")if(typeof h=="object"&&h!==null){if(h.as==null||h.as==="script"){var m=T(h.as,h.crossOrigin);s.d.M(p,{crossOrigin:m,integrity:typeof h.integrity=="string"?h.integrity:void 0,nonce:typeof h.nonce=="string"?h.nonce:void 0})}}else h==null&&s.d.M(p)},Fn.preload=function(p,h){if(typeof p=="string"&&typeof h=="object"&&h!==null&&typeof h.as=="string"){var m=h.as,E=T(m,h.crossOrigin);s.d.L(p,m,{crossOrigin:E,integrity:typeof h.integrity=="string"?h.integrity:void 0,nonce:typeof h.nonce=="string"?h.nonce:void 0,type:typeof h.type=="string"?h.type:void 0,fetchPriority:typeof h.fetchPriority=="string"?h.fetchPriority:void 0,referrerPolicy:typeof h.referrerPolicy=="string"?h.referrerPolicy:void 0,imageSrcSet:typeof h.imageSrcSet=="string"?h.imageSrcSet:void 0,imageSizes:typeof h.imageSizes=="string"?h.imageSizes:void 0,media:typeof h.media=="string"?h.media:void 0})}},Fn.preloadModule=function(p,h){if(typeof p=="string")if(h){var m=T(h.as,h.crossOrigin);s.d.m(p,{as:typeof h.as=="string"&&h.as!=="script"?h.as:void 0,crossOrigin:m,integrity:typeof h.integrity=="string"?h.integrity:void 0})}else s.d.m(p)},Fn.requestFormReset=function(p){s.d.r(p)},Fn.unstable_batchedUpdates=function(p,h){return p(h)},Fn.useFormState=function(p,h,m){return f.H.useFormState(p,h,m)},Fn.useFormStatus=function(){return f.H.useHostTransitionStatus()},Fn.version="19.2.6",Fn}var lm;function m_(){if(lm)return gh.exports;lm=1;function r(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(r)}catch(t){console.error(t)}}return r(),gh.exports=T_(),gh.exports}var cm;function E_(){if(cm)return Ko;cm=1;var r=p_(),t=e0(),i=m_();function s(e){var n="https://react.dev/errors/"+e;if(1<arguments.length){n+="?args[]="+encodeURIComponent(arguments[1]);for(var a=2;a<arguments.length;a++)n+="&args[]="+encodeURIComponent(arguments[a])}return"Minified React error #"+e+"; visit "+n+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function l(e){return!(!e||e.nodeType!==1&&e.nodeType!==9&&e.nodeType!==11)}function c(e){var n=e,a=e;if(e.alternate)for(;n.return;)n=n.return;else{e=n;do n=e,(n.flags&4098)!==0&&(a=n.return),e=n.return;while(e)}return n.tag===3?a:null}function f(e){if(e.tag===13){var n=e.memoizedState;if(n===null&&(e=e.alternate,e!==null&&(n=e.memoizedState)),n!==null)return n.dehydrated}return null}function T(e){if(e.tag===31){var n=e.memoizedState;if(n===null&&(e=e.alternate,e!==null&&(n=e.memoizedState)),n!==null)return n.dehydrated}return null}function p(e){if(c(e)!==e)throw Error(s(188))}function h(e){var n=e.alternate;if(!n){if(n=c(e),n===null)throw Error(s(188));return n!==e?null:e}for(var a=e,o=n;;){var u=a.return;if(u===null)break;var d=u.alternate;if(d===null){if(o=u.return,o!==null){a=o;continue}break}if(u.child===d.child){for(d=u.child;d;){if(d===a)return p(u),e;if(d===o)return p(u),n;d=d.sibling}throw Error(s(188))}if(a.return!==o.return)a=u,o=d;else{for(var _=!1,y=u.child;y;){if(y===a){_=!0,a=u,o=d;break}if(y===o){_=!0,o=u,a=d;break}y=y.sibling}if(!_){for(y=d.child;y;){if(y===a){_=!0,a=d,o=u;break}if(y===o){_=!0,o=d,a=u;break}y=y.sibling}if(!_)throw Error(s(189))}}if(a.alternate!==o)throw Error(s(190))}if(a.tag!==3)throw Error(s(188));return a.stateNode.current===a?e:n}function m(e){var n=e.tag;if(n===5||n===26||n===27||n===6)return e;for(e=e.child;e!==null;){if(n=m(e),n!==null)return n;e=e.sibling}return null}var E=Object.assign,S=Symbol.for("react.element"),g=Symbol.for("react.transitional.element"),A=Symbol.for("react.portal"),M=Symbol.for("react.fragment"),x=Symbol.for("react.strict_mode"),v=Symbol.for("react.profiler"),D=Symbol.for("react.consumer"),I=Symbol.for("react.context"),U=Symbol.for("react.forward_ref"),Y=Symbol.for("react.suspense"),F=Symbol.for("react.suspense_list"),B=Symbol.for("react.memo"),R=Symbol.for("react.lazy"),w=Symbol.for("react.activity"),Z=Symbol.for("react.memo_cache_sentinel"),H=Symbol.iterator;function $(e){return e===null||typeof e!="object"?null:(e=H&&e[H]||e["@@iterator"],typeof e=="function"?e:null)}var ct=Symbol.for("react.client.reference");function lt(e){if(e==null)return null;if(typeof e=="function")return e.$$typeof===ct?null:e.displayName||e.name||null;if(typeof e=="string")return e;switch(e){case M:return"Fragment";case v:return"Profiler";case x:return"StrictMode";case Y:return"Suspense";case F:return"SuspenseList";case w:return"Activity"}if(typeof e=="object")switch(e.$$typeof){case A:return"Portal";case I:return e.displayName||"Context";case D:return(e._context.displayName||"Context")+".Consumer";case U:var n=e.render;return e=e.displayName,e||(e=n.displayName||n.name||"",e=e!==""?"ForwardRef("+e+")":"ForwardRef"),e;case B:return n=e.displayName||null,n!==null?n:lt(e.type)||"Memo";case R:n=e._payload,e=e._init;try{return lt(e(n))}catch{}}return null}var W=Array.isArray,L=t.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,P=i.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,it={pending:!1,data:null,method:null,action:null},mt=[],ft=-1;function O(e){return{current:e}}function V(e){0>ft||(e.current=mt[ft],mt[ft]=null,ft--)}function dt(e,n){ft++,mt[ft]=e.current,e.current=n}var gt=O(null),Mt=O(null),rt=O(null),vt=O(null);function Nt(e,n){switch(dt(rt,n),dt(Mt,e),dt(gt,null),n.nodeType){case 9:case 11:e=(e=n.documentElement)&&(e=e.namespaceURI)?NT(e):0;break;default:if(e=n.tagName,n=n.namespaceURI)n=NT(n),e=MT(n,e);else switch(e){case"svg":e=1;break;case"math":e=2;break;default:e=0}}V(gt),dt(gt,e)}function Pt(){V(gt),V(Mt),V(rt)}function Jt(e){e.memoizedState!==null&&dt(vt,e);var n=gt.current,a=MT(n,e.type);n!==a&&(dt(Mt,e),dt(gt,a))}function Qt(e){Mt.current===e&&(V(gt),V(Mt)),vt.current===e&&(V(vt),Go._currentValue=it)}var ze,fe;function Ee(e){if(ze===void 0)try{throw Error()}catch(a){var n=a.stack.trim().match(/\n( *(at )?)/);ze=n&&n[1]||"",fe=-1<a.stack.indexOf(`
    at`)?" (<anonymous>)":-1<a.stack.indexOf("@")?"@unknown:0:0":""}return`
`+ze+e+fe}var Ie=!1;function le(e,n){if(!e||Ie)return"";Ie=!0;var a=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{var o={DetermineComponentFrameRoot:function(){try{if(n){var _t=function(){throw Error()};if(Object.defineProperty(_t.prototype,"props",{set:function(){throw Error()}}),typeof Reflect=="object"&&Reflect.construct){try{Reflect.construct(_t,[])}catch(ot){var st=ot}Reflect.construct(e,[],_t)}else{try{_t.call()}catch(ot){st=ot}e.call(_t.prototype)}}else{try{throw Error()}catch(ot){st=ot}(_t=e())&&typeof _t.catch=="function"&&_t.catch(function(){})}}catch(ot){if(ot&&st&&typeof ot.stack=="string")return[ot.stack,st.stack]}return[null,null]}};o.DetermineComponentFrameRoot.displayName="DetermineComponentFrameRoot";var u=Object.getOwnPropertyDescriptor(o.DetermineComponentFrameRoot,"name");u&&u.configurable&&Object.defineProperty(o.DetermineComponentFrameRoot,"name",{value:"DetermineComponentFrameRoot"});var d=o.DetermineComponentFrameRoot(),_=d[0],y=d[1];if(_&&y){var X=_.split(`
`),J=y.split(`
`);for(u=o=0;o<X.length&&!X[o].includes("DetermineComponentFrameRoot");)o++;for(;u<J.length&&!J[u].includes("DetermineComponentFrameRoot");)u++;if(o===X.length||u===J.length)for(o=X.length-1,u=J.length-1;1<=o&&0<=u&&X[o]!==J[u];)u--;for(;1<=o&&0<=u;o--,u--)if(X[o]!==J[u]){if(o!==1||u!==1)do if(o--,u--,0>u||X[o]!==J[u]){var pt=`
`+X[o].replace(" at new "," at ");return e.displayName&&pt.includes("<anonymous>")&&(pt=pt.replace("<anonymous>",e.displayName)),pt}while(1<=o&&0<=u);break}}}finally{Ie=!1,Error.prepareStackTrace=a}return(a=e?e.displayName||e.name:"")?Ee(a):""}function sn(e,n){switch(e.tag){case 26:case 27:case 5:return Ee(e.type);case 16:return Ee("Lazy");case 13:return e.child!==n&&n!==null?Ee("Suspense Fallback"):Ee("Suspense");case 19:return Ee("SuspenseList");case 0:case 15:return le(e.type,!1);case 11:return le(e.type.render,!1);case 1:return le(e.type,!0);case 31:return Ee("Activity");default:return""}}function ke(e){try{var n="",a=null;do n+=sn(e,a),a=e,e=e.return;while(e);return n}catch(o){return`
Error generating stack: `+o.message+`
`+o.stack}}var Mn=Object.prototype.hasOwnProperty,k=r.unstable_scheduleCallback,Je=r.unstable_cancelCallback,he=r.unstable_shouldYield,Pe=r.unstable_requestPaint,Ct=r.unstable_now,qe=r.unstable_getCurrentPriorityLevel,b=r.unstable_ImmediatePriority,N=r.unstable_UserBlockingPriority,Q=r.unstable_NormalPriority,St=r.unstable_LowPriority,xt=r.unstable_IdlePriority,yt=r.log,It=r.unstable_setDisableYieldValue,ut=null,ht=null;function Lt(e){if(typeof yt=="function"&&It(e),ht&&typeof ht.setStrictMode=="function")try{ht.setStrictMode(ut,e)}catch{}}var Ut=Math.clz32?Math.clz32:ne,Ot=Math.log,Dt=Math.LN2;function ne(e){return e>>>=0,e===0?32:31-(Ot(e)/Dt|0)|0}var ie=256,de=262144,G=4194304;function Rt(e){var n=e&42;if(n!==0)return n;switch(e&-e){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:return 64;case 128:return 128;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:return e&261888;case 262144:case 524288:case 1048576:case 2097152:return e&3932160;case 4194304:case 8388608:case 16777216:case 33554432:return e&62914560;case 67108864:return 67108864;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 0;default:return e}}function Tt(e,n,a){var o=e.pendingLanes;if(o===0)return 0;var u=0,d=e.suspendedLanes,_=e.pingedLanes;e=e.warmLanes;var y=o&134217727;return y!==0?(o=y&~d,o!==0?u=Rt(o):(_&=y,_!==0?u=Rt(_):a||(a=y&~e,a!==0&&(u=Rt(a))))):(y=o&~d,y!==0?u=Rt(y):_!==0?u=Rt(_):a||(a=o&~e,a!==0&&(u=Rt(a)))),u===0?0:n!==0&&n!==u&&(n&d)===0&&(d=u&-u,a=n&-n,d>=a||d===32&&(a&4194048)!==0)?n:u}function Bt(e,n){return(e.pendingLanes&~(e.suspendedLanes&~e.pingedLanes)&n)===0}function bt(e,n){switch(e){case 1:case 2:case 4:case 8:case 64:return n+250;case 16:case 32:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return n+5e3;case 4194304:case 8388608:case 16777216:case 33554432:return-1;case 67108864:case 134217728:case 268435456:case 536870912:case 1073741824:return-1;default:return-1}}function At(){var e=G;return G<<=1,(G&62914560)===0&&(G=4194304),e}function Wt(e){for(var n=[],a=0;31>a;a++)n.push(e);return n}function te(e,n){e.pendingLanes|=n,n!==268435456&&(e.suspendedLanes=0,e.pingedLanes=0,e.warmLanes=0)}function tn(e,n,a,o,u,d){var _=e.pendingLanes;e.pendingLanes=a,e.suspendedLanes=0,e.pingedLanes=0,e.warmLanes=0,e.expiredLanes&=a,e.entangledLanes&=a,e.errorRecoveryDisabledLanes&=a,e.shellSuspendCounter=0;var y=e.entanglements,X=e.expirationTimes,J=e.hiddenUpdates;for(a=_&~a;0<a;){var pt=31-Ut(a),_t=1<<pt;y[pt]=0,X[pt]=-1;var st=J[pt];if(st!==null)for(J[pt]=null,pt=0;pt<st.length;pt++){var ot=st[pt];ot!==null&&(ot.lane&=-536870913)}a&=~_t}o!==0&&ye(e,o,0),d!==0&&u===0&&e.tag!==0&&(e.suspendedLanes|=d&~(_&~n))}function ye(e,n,a){e.pendingLanes|=n,e.suspendedLanes&=~n;var o=31-Ut(n);e.entangledLanes|=n,e.entanglements[o]=e.entanglements[o]|1073741824|a&261930}function pi(e,n){var a=e.entangledLanes|=n;for(e=e.entanglements;a;){var o=31-Ut(a),u=1<<o;u&n|e[o]&n&&(e[o]|=n),a&=~u}}function ei(e,n){var a=n&-n;return a=(a&42)!==0?1:gs(a),(a&(e.suspendedLanes|n))!==0?0:a}function gs(e){switch(e){case 2:e=1;break;case 8:e=4;break;case 32:e=16;break;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:e=128;break;case 268435456:e=134217728;break;default:e=0}return e}function Jr(e){return e&=-e,2<e?8<e?(e&134217727)!==0?32:268435456:8:2}function to(){var e=P.p;return e!==0?e:(e=window.event,e===void 0?32:ZT(e.type))}function eo(e,n){var a=P.p;try{return P.p=e,n()}finally{P.p=a}}var Ln=Math.random().toString(36).slice(2),rn="__reactFiber$"+Ln,Rn="__reactProps$"+Ln,ia="__reactContainer$"+Ln,La="__reactEvents$"+Ln,hl="__reactListeners$"+Ln,Qs="__reactHandles$"+Ln,no="__reactResources$"+Ln,Ua="__reactMarker$"+Ln;function io(e){delete e[rn],delete e[Rn],delete e[La],delete e[hl],delete e[Qs]}function Fa(e){var n=e[rn];if(n)return n;for(var a=e.parentNode;a;){if(n=a[ia]||a[rn]){if(a=n.alternate,n.child!==null||a!==null&&a.child!==null)for(e=IT(e);e!==null;){if(a=e[rn])return a;e=IT(e)}return n}e=a,a=e.parentNode}return null}function wa(e){if(e=e[rn]||e[ia]){var n=e.tag;if(n===5||n===6||n===13||n===31||n===26||n===27||n===3)return e}return null}function _s(e){var n=e.tag;if(n===5||n===26||n===27||n===6)return e.stateNode;throw Error(s(33))}function Ba(e){var n=e[no];return n||(n=e[no]={hoistableStyles:new Map,hoistableScripts:new Map}),n}function un(e){e[Ua]=!0}var dl=new Set,C={};function K(e,n){at(e,n),at(e+"Capture",n)}function at(e,n){for(C[e]=n,e=0;e<n.length;e++)dl.add(n[e])}var tt=RegExp("^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$"),et={},wt={};function Yt(e){return Mn.call(wt,e)?!0:Mn.call(et,e)?!1:tt.test(e)?wt[e]=!0:(et[e]=!0,!1)}function Ft(e,n,a){if(Yt(n))if(a===null)e.removeAttribute(n);else{switch(typeof a){case"undefined":case"function":case"symbol":e.removeAttribute(n);return;case"boolean":var o=n.toLowerCase().slice(0,5);if(o!=="data-"&&o!=="aria-"){e.removeAttribute(n);return}}e.setAttribute(n,""+a)}}function zt(e,n,a){if(a===null)e.removeAttribute(n);else{switch(typeof a){case"undefined":case"function":case"symbol":case"boolean":e.removeAttribute(n);return}e.setAttribute(n,""+a)}}function Gt(e,n,a,o){if(o===null)e.removeAttribute(a);else{switch(typeof o){case"undefined":case"function":case"symbol":case"boolean":e.removeAttribute(a);return}e.setAttributeNS(n,a,""+o)}}function qt(e){switch(typeof e){case"bigint":case"boolean":case"number":case"string":case"undefined":return e;case"object":return e;default:return""}}function re(e){var n=e.type;return(e=e.nodeName)&&e.toLowerCase()==="input"&&(n==="checkbox"||n==="radio")}function Zt(e,n,a){var o=Object.getOwnPropertyDescriptor(e.constructor.prototype,n);if(!e.hasOwnProperty(n)&&typeof o<"u"&&typeof o.get=="function"&&typeof o.set=="function"){var u=o.get,d=o.set;return Object.defineProperty(e,n,{configurable:!0,get:function(){return u.call(this)},set:function(_){a=""+_,d.call(this,_)}}),Object.defineProperty(e,n,{enumerable:o.enumerable}),{getValue:function(){return a},setValue:function(_){a=""+_},stopTracking:function(){e._valueTracker=null,delete e[n]}}}}function Me(e){if(!e._valueTracker){var n=re(e)?"checked":"value";e._valueTracker=Zt(e,n,""+e[n])}}function $e(e){if(!e)return!1;var n=e._valueTracker;if(!n)return!0;var a=n.getValue(),o="";return e&&(o=re(e)?e.checked?"true":"false":e.value),e=o,e!==a?(n.setValue(e),!0):!1}function Ve(e){if(e=e||(typeof document<"u"?document:void 0),typeof e>"u")return null;try{return e.activeElement||e.body}catch{return e.body}}var Le=/[\n"\\]/g;function Ue(e){return e.replace(Le,function(n){return"\\"+n.charCodeAt(0).toString(16)+" "})}function Ht(e,n,a,o,u,d,_,y){e.name="",_!=null&&typeof _!="function"&&typeof _!="symbol"&&typeof _!="boolean"?e.type=_:e.removeAttribute("type"),n!=null?_==="number"?(n===0&&e.value===""||e.value!=n)&&(e.value=""+qt(n)):e.value!==""+qt(n)&&(e.value=""+qt(n)):_!=="submit"&&_!=="reset"||e.removeAttribute("value"),n!=null?pe(e,_,qt(n)):a!=null?pe(e,_,qt(a)):o!=null&&e.removeAttribute("value"),u==null&&d!=null&&(e.defaultChecked=!!d),u!=null&&(e.checked=u&&typeof u!="function"&&typeof u!="symbol"),y!=null&&typeof y!="function"&&typeof y!="symbol"&&typeof y!="boolean"?e.name=""+qt(y):e.removeAttribute("name")}function Un(e,n,a,o,u,d,_,y){if(d!=null&&typeof d!="function"&&typeof d!="symbol"&&typeof d!="boolean"&&(e.type=d),n!=null||a!=null){if(!(d!=="submit"&&d!=="reset"||n!=null)){Me(e);return}a=a!=null?""+qt(a):"",n=n!=null?""+qt(n):a,y||n===e.value||(e.value=n),e.defaultValue=n}o=o??u,o=typeof o!="function"&&typeof o!="symbol"&&!!o,e.checked=y?e.checked:!!o,e.defaultChecked=!!o,_!=null&&typeof _!="function"&&typeof _!="symbol"&&typeof _!="boolean"&&(e.name=_),Me(e)}function pe(e,n,a){n==="number"&&Ve(e.ownerDocument)===e||e.defaultValue===""+a||(e.defaultValue=""+a)}function mn(e,n,a,o){if(e=e.options,n){n={};for(var u=0;u<a.length;u++)n["$"+a[u]]=!0;for(a=0;a<e.length;a++)u=n.hasOwnProperty("$"+e[a].value),e[a].selected!==u&&(e[a].selected=u),u&&o&&(e[a].defaultSelected=!0)}else{for(a=""+qt(a),n=null,u=0;u<e.length;u++){if(e[u].value===a){e[u].selected=!0,o&&(e[u].defaultSelected=!0);return}n!==null||e[u].disabled||(n=e[u])}n!==null&&(n.selected=!0)}}function ni(e,n,a){if(n!=null&&(n=""+qt(n),n!==e.value&&(e.value=n),a==null)){e.defaultValue!==n&&(e.defaultValue=n);return}e.defaultValue=a!=null?""+qt(a):""}function Mi(e,n,a,o){if(n==null){if(o!=null){if(a!=null)throw Error(s(92));if(W(o)){if(1<o.length)throw Error(s(93));o=o[0]}a=o}a==null&&(a=""),n=a}a=qt(n),e.defaultValue=a,o=e.textContent,o===a&&o!==""&&o!==null&&(e.value=o),Me(e)}function ii(e,n){if(n){var a=e.firstChild;if(a&&a===e.lastChild&&a.nodeType===3){a.nodeValue=n;return}}e.textContent=n}var Fe=new Set("animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp".split(" "));function Qe(e,n,a){var o=n.indexOf("--")===0;a==null||typeof a=="boolean"||a===""?o?e.setProperty(n,""):n==="float"?e.cssFloat="":e[n]="":o?e.setProperty(n,a):typeof a!="number"||a===0||Fe.has(n)?n==="float"?e.cssFloat=a:e[n]=(""+a).trim():e[n]=a+"px"}function Ri(e,n,a){if(n!=null&&typeof n!="object")throw Error(s(62));if(e=e.style,a!=null){for(var o in a)!a.hasOwnProperty(o)||n!=null&&n.hasOwnProperty(o)||(o.indexOf("--")===0?e.setProperty(o,""):o==="float"?e.cssFloat="":e[o]="");for(var u in n)o=n[u],n.hasOwnProperty(u)&&a[u]!==o&&Qe(e,u,o)}else for(var d in n)n.hasOwnProperty(d)&&Qe(e,d,n[d])}function be(e){if(e.indexOf("-")===-1)return!1;switch(e){case"annotation-xml":case"color-profile":case"font-face":case"font-face-src":case"font-face-uri":case"font-face-format":case"font-face-name":case"missing-glyph":return!1;default:return!0}}var Xi=new Map([["acceptCharset","accept-charset"],["htmlFor","for"],["httpEquiv","http-equiv"],["crossOrigin","crossorigin"],["accentHeight","accent-height"],["alignmentBaseline","alignment-baseline"],["arabicForm","arabic-form"],["baselineShift","baseline-shift"],["capHeight","cap-height"],["clipPath","clip-path"],["clipRule","clip-rule"],["colorInterpolation","color-interpolation"],["colorInterpolationFilters","color-interpolation-filters"],["colorProfile","color-profile"],["colorRendering","color-rendering"],["dominantBaseline","dominant-baseline"],["enableBackground","enable-background"],["fillOpacity","fill-opacity"],["fillRule","fill-rule"],["floodColor","flood-color"],["floodOpacity","flood-opacity"],["fontFamily","font-family"],["fontSize","font-size"],["fontSizeAdjust","font-size-adjust"],["fontStretch","font-stretch"],["fontStyle","font-style"],["fontVariant","font-variant"],["fontWeight","font-weight"],["glyphName","glyph-name"],["glyphOrientationHorizontal","glyph-orientation-horizontal"],["glyphOrientationVertical","glyph-orientation-vertical"],["horizAdvX","horiz-adv-x"],["horizOriginX","horiz-origin-x"],["imageRendering","image-rendering"],["letterSpacing","letter-spacing"],["lightingColor","lighting-color"],["markerEnd","marker-end"],["markerMid","marker-mid"],["markerStart","marker-start"],["overlinePosition","overline-position"],["overlineThickness","overline-thickness"],["paintOrder","paint-order"],["panose-1","panose-1"],["pointerEvents","pointer-events"],["renderingIntent","rendering-intent"],["shapeRendering","shape-rendering"],["stopColor","stop-color"],["stopOpacity","stop-opacity"],["strikethroughPosition","strikethrough-position"],["strikethroughThickness","strikethrough-thickness"],["strokeDasharray","stroke-dasharray"],["strokeDashoffset","stroke-dashoffset"],["strokeLinecap","stroke-linecap"],["strokeLinejoin","stroke-linejoin"],["strokeMiterlimit","stroke-miterlimit"],["strokeOpacity","stroke-opacity"],["strokeWidth","stroke-width"],["textAnchor","text-anchor"],["textDecoration","text-decoration"],["textRendering","text-rendering"],["transformOrigin","transform-origin"],["underlinePosition","underline-position"],["underlineThickness","underline-thickness"],["unicodeBidi","unicode-bidi"],["unicodeRange","unicode-range"],["unitsPerEm","units-per-em"],["vAlphabetic","v-alphabetic"],["vHanging","v-hanging"],["vIdeographic","v-ideographic"],["vMathematical","v-mathematical"],["vectorEffect","vector-effect"],["vertAdvY","vert-adv-y"],["vertOriginX","vert-origin-x"],["vertOriginY","vert-origin-y"],["wordSpacing","word-spacing"],["writingMode","writing-mode"],["xmlnsXlink","xmlns:xlink"],["xHeight","x-height"]]),Xa=/^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;function vs(e){return Xa.test(""+e)?"javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')":e}function aa(){}var uu=null;function fu(e){return e=e.target||e.srcElement||window,e.correspondingUseElement&&(e=e.correspondingUseElement),e.nodeType===3?e.parentNode:e}var js=null,Js=null;function x0(e){var n=wa(e);if(n&&(e=n.stateNode)){var a=e[Rn]||null;t:switch(e=n.stateNode,n.type){case"input":if(Ht(e,a.value,a.defaultValue,a.defaultValue,a.checked,a.defaultChecked,a.type,a.name),n=a.name,a.type==="radio"&&n!=null){for(a=e;a.parentNode;)a=a.parentNode;for(a=a.querySelectorAll('input[name="'+Ue(""+n)+'"][type="radio"]'),n=0;n<a.length;n++){var o=a[n];if(o!==e&&o.form===e.form){var u=o[Rn]||null;if(!u)throw Error(s(90));Ht(o,u.value,u.defaultValue,u.defaultValue,u.checked,u.defaultChecked,u.type,u.name)}}for(n=0;n<a.length;n++)o=a[n],o.form===e.form&&$e(o)}break t;case"textarea":ni(e,a.value,a.defaultValue);break t;case"select":n=a.value,n!=null&&mn(e,!!a.multiple,n,!1)}}}var hu=!1;function N0(e,n,a){if(hu)return e(n,a);hu=!0;try{var o=e(n);return o}finally{if(hu=!1,(js!==null||Js!==null)&&(tc(),js&&(n=js,e=Js,Js=js=null,x0(n),e)))for(n=0;n<e.length;n++)x0(e[n])}}function ao(e,n){var a=e.stateNode;if(a===null)return null;var o=a[Rn]||null;if(o===null)return null;a=o[n];t:switch(n){case"onClick":case"onClickCapture":case"onDoubleClick":case"onDoubleClickCapture":case"onMouseDown":case"onMouseDownCapture":case"onMouseMove":case"onMouseMoveCapture":case"onMouseUp":case"onMouseUpCapture":case"onMouseEnter":(o=!o.disabled)||(e=e.type,o=!(e==="button"||e==="input"||e==="select"||e==="textarea")),e=!o;break t;default:e=!1}if(e)return null;if(a&&typeof a!="function")throw Error(s(231,n,typeof a));return a}var sa=!(typeof window>"u"||typeof window.document>"u"||typeof window.document.createElement>"u"),du=!1;if(sa)try{var so={};Object.defineProperty(so,"passive",{get:function(){du=!0}}),window.addEventListener("test",so,so),window.removeEventListener("test",so,so)}catch{du=!1}var Pa=null,pu=null,pl=null;function M0(){if(pl)return pl;var e,n=pu,a=n.length,o,u="value"in Pa?Pa.value:Pa.textContent,d=u.length;for(e=0;e<a&&n[e]===u[e];e++);var _=a-e;for(o=1;o<=_&&n[a-o]===u[d-o];o++);return pl=u.slice(e,1<o?1-o:void 0)}function Tl(e){var n=e.keyCode;return"charCode"in e?(e=e.charCode,e===0&&n===13&&(e=13)):e=n,e===10&&(e=13),32<=e||e===13?e:0}function ml(){return!0}function R0(){return!1}function Vn(e){function n(a,o,u,d,_){this._reactName=a,this._targetInst=u,this.type=o,this.nativeEvent=d,this.target=_,this.currentTarget=null;for(var y in e)e.hasOwnProperty(y)&&(a=e[y],this[y]=a?a(d):d[y]);return this.isDefaultPrevented=(d.defaultPrevented!=null?d.defaultPrevented:d.returnValue===!1)?ml:R0,this.isPropagationStopped=R0,this}return E(n.prototype,{preventDefault:function(){this.defaultPrevented=!0;var a=this.nativeEvent;a&&(a.preventDefault?a.preventDefault():typeof a.returnValue!="unknown"&&(a.returnValue=!1),this.isDefaultPrevented=ml)},stopPropagation:function(){var a=this.nativeEvent;a&&(a.stopPropagation?a.stopPropagation():typeof a.cancelBubble!="unknown"&&(a.cancelBubble=!0),this.isPropagationStopped=ml)},persist:function(){},isPersistent:ml}),n}var As={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(e){return e.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},El=Vn(As),ro=E({},As,{view:0,detail:0}),oS=Vn(ro),Tu,mu,oo,Sl=E({},ro,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:Su,button:0,buttons:0,relatedTarget:function(e){return e.relatedTarget===void 0?e.fromElement===e.srcElement?e.toElement:e.fromElement:e.relatedTarget},movementX:function(e){return"movementX"in e?e.movementX:(e!==oo&&(oo&&e.type==="mousemove"?(Tu=e.screenX-oo.screenX,mu=e.screenY-oo.screenY):mu=Tu=0,oo=e),Tu)},movementY:function(e){return"movementY"in e?e.movementY:mu}}),C0=Vn(Sl),lS=E({},Sl,{dataTransfer:0}),cS=Vn(lS),uS=E({},ro,{relatedTarget:0}),Eu=Vn(uS),fS=E({},As,{animationName:0,elapsedTime:0,pseudoElement:0}),hS=Vn(fS),dS=E({},As,{clipboardData:function(e){return"clipboardData"in e?e.clipboardData:window.clipboardData}}),pS=Vn(dS),TS=E({},As,{data:0}),y0=Vn(TS),mS={Esc:"Escape",Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},ES={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},SS={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function gS(e){var n=this.nativeEvent;return n.getModifierState?n.getModifierState(e):(e=SS[e])?!!n[e]:!1}function Su(){return gS}var _S=E({},ro,{key:function(e){if(e.key){var n=mS[e.key]||e.key;if(n!=="Unidentified")return n}return e.type==="keypress"?(e=Tl(e),e===13?"Enter":String.fromCharCode(e)):e.type==="keydown"||e.type==="keyup"?ES[e.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:Su,charCode:function(e){return e.type==="keypress"?Tl(e):0},keyCode:function(e){return e.type==="keydown"||e.type==="keyup"?e.keyCode:0},which:function(e){return e.type==="keypress"?Tl(e):e.type==="keydown"||e.type==="keyup"?e.keyCode:0}}),vS=Vn(_S),AS=E({},Sl,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0}),D0=Vn(AS),xS=E({},ro,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:Su}),NS=Vn(xS),MS=E({},As,{propertyName:0,elapsedTime:0,pseudoElement:0}),RS=Vn(MS),CS=E({},Sl,{deltaX:function(e){return"deltaX"in e?e.deltaX:"wheelDeltaX"in e?-e.wheelDeltaX:0},deltaY:function(e){return"deltaY"in e?e.deltaY:"wheelDeltaY"in e?-e.wheelDeltaY:"wheelDelta"in e?-e.wheelDelta:0},deltaZ:0,deltaMode:0}),yS=Vn(CS),DS=E({},As,{newState:0,oldState:0}),OS=Vn(DS),bS=[9,13,27,32],gu=sa&&"CompositionEvent"in window,lo=null;sa&&"documentMode"in document&&(lo=document.documentMode);var IS=sa&&"TextEvent"in window&&!lo,O0=sa&&(!gu||lo&&8<lo&&11>=lo),b0=" ",I0=!1;function L0(e,n){switch(e){case"keyup":return bS.indexOf(n.keyCode)!==-1;case"keydown":return n.keyCode!==229;case"keypress":case"mousedown":case"focusout":return!0;default:return!1}}function U0(e){return e=e.detail,typeof e=="object"&&"data"in e?e.data:null}var tr=!1;function LS(e,n){switch(e){case"compositionend":return U0(n);case"keypress":return n.which!==32?null:(I0=!0,b0);case"textInput":return e=n.data,e===b0&&I0?null:e;default:return null}}function US(e,n){if(tr)return e==="compositionend"||!gu&&L0(e,n)?(e=M0(),pl=pu=Pa=null,tr=!1,e):null;switch(e){case"paste":return null;case"keypress":if(!(n.ctrlKey||n.altKey||n.metaKey)||n.ctrlKey&&n.altKey){if(n.char&&1<n.char.length)return n.char;if(n.which)return String.fromCharCode(n.which)}return null;case"compositionend":return O0&&n.locale!=="ko"?null:n.data;default:return null}}var FS={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function F0(e){var n=e&&e.nodeName&&e.nodeName.toLowerCase();return n==="input"?!!FS[e.type]:n==="textarea"}function w0(e,n,a,o){js?Js?Js.push(o):Js=[o]:js=o,n=oc(n,"onChange"),0<n.length&&(a=new El("onChange","change",null,a,o),e.push({event:a,listeners:n}))}var co=null,uo=null;function wS(e){ST(e,0)}function gl(e){var n=_s(e);if($e(n))return e}function B0(e,n){if(e==="change")return n}var X0=!1;if(sa){var _u;if(sa){var vu="oninput"in document;if(!vu){var P0=document.createElement("div");P0.setAttribute("oninput","return;"),vu=typeof P0.oninput=="function"}_u=vu}else _u=!1;X0=_u&&(!document.documentMode||9<document.documentMode)}function H0(){co&&(co.detachEvent("onpropertychange",Y0),uo=co=null)}function Y0(e){if(e.propertyName==="value"&&gl(uo)){var n=[];w0(n,uo,e,fu(e)),N0(wS,n)}}function BS(e,n,a){e==="focusin"?(H0(),co=n,uo=a,co.attachEvent("onpropertychange",Y0)):e==="focusout"&&H0()}function XS(e){if(e==="selectionchange"||e==="keyup"||e==="keydown")return gl(uo)}function PS(e,n){if(e==="click")return gl(n)}function HS(e,n){if(e==="input"||e==="change")return gl(n)}function YS(e,n){return e===n&&(e!==0||1/e===1/n)||e!==e&&n!==n}var ai=typeof Object.is=="function"?Object.is:YS;function fo(e,n){if(ai(e,n))return!0;if(typeof e!="object"||e===null||typeof n!="object"||n===null)return!1;var a=Object.keys(e),o=Object.keys(n);if(a.length!==o.length)return!1;for(o=0;o<a.length;o++){var u=a[o];if(!Mn.call(n,u)||!ai(e[u],n[u]))return!1}return!0}function G0(e){for(;e&&e.firstChild;)e=e.firstChild;return e}function z0(e,n){var a=G0(e);e=0;for(var o;a;){if(a.nodeType===3){if(o=e+a.textContent.length,e<=n&&o>=n)return{node:a,offset:n-e};e=o}t:{for(;a;){if(a.nextSibling){a=a.nextSibling;break t}a=a.parentNode}a=void 0}a=G0(a)}}function V0(e,n){return e&&n?e===n?!0:e&&e.nodeType===3?!1:n&&n.nodeType===3?V0(e,n.parentNode):"contains"in e?e.contains(n):e.compareDocumentPosition?!!(e.compareDocumentPosition(n)&16):!1:!1}function W0(e){e=e!=null&&e.ownerDocument!=null&&e.ownerDocument.defaultView!=null?e.ownerDocument.defaultView:window;for(var n=Ve(e.document);n instanceof e.HTMLIFrameElement;){try{var a=typeof n.contentWindow.location.href=="string"}catch{a=!1}if(a)e=n.contentWindow;else break;n=Ve(e.document)}return n}function Au(e){var n=e&&e.nodeName&&e.nodeName.toLowerCase();return n&&(n==="input"&&(e.type==="text"||e.type==="search"||e.type==="tel"||e.type==="url"||e.type==="password")||n==="textarea"||e.contentEditable==="true")}var GS=sa&&"documentMode"in document&&11>=document.documentMode,er=null,xu=null,ho=null,Nu=!1;function k0(e,n,a){var o=a.window===a?a.document:a.nodeType===9?a:a.ownerDocument;Nu||er==null||er!==Ve(o)||(o=er,"selectionStart"in o&&Au(o)?o={start:o.selectionStart,end:o.selectionEnd}:(o=(o.ownerDocument&&o.ownerDocument.defaultView||window).getSelection(),o={anchorNode:o.anchorNode,anchorOffset:o.anchorOffset,focusNode:o.focusNode,focusOffset:o.focusOffset}),ho&&fo(ho,o)||(ho=o,o=oc(xu,"onSelect"),0<o.length&&(n=new El("onSelect","select",null,n,a),e.push({event:n,listeners:o}),n.target=er)))}function xs(e,n){var a={};return a[e.toLowerCase()]=n.toLowerCase(),a["Webkit"+e]="webkit"+n,a["Moz"+e]="moz"+n,a}var nr={animationend:xs("Animation","AnimationEnd"),animationiteration:xs("Animation","AnimationIteration"),animationstart:xs("Animation","AnimationStart"),transitionrun:xs("Transition","TransitionRun"),transitionstart:xs("Transition","TransitionStart"),transitioncancel:xs("Transition","TransitionCancel"),transitionend:xs("Transition","TransitionEnd")},Mu={},K0={};sa&&(K0=document.createElement("div").style,"AnimationEvent"in window||(delete nr.animationend.animation,delete nr.animationiteration.animation,delete nr.animationstart.animation),"TransitionEvent"in window||delete nr.transitionend.transition);function Ns(e){if(Mu[e])return Mu[e];if(!nr[e])return e;var n=nr[e],a;for(a in n)if(n.hasOwnProperty(a)&&a in K0)return Mu[e]=n[a];return e}var Z0=Ns("animationend"),q0=Ns("animationiteration"),$0=Ns("animationstart"),zS=Ns("transitionrun"),VS=Ns("transitionstart"),WS=Ns("transitioncancel"),Q0=Ns("transitionend"),j0=new Map,Ru="abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");Ru.push("scrollEnd");function Ci(e,n){j0.set(e,n),K(n,[e])}var _l=typeof reportError=="function"?reportError:function(e){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var n=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof e=="object"&&e!==null&&typeof e.message=="string"?String(e.message):String(e),error:e});if(!window.dispatchEvent(n))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",e);return}console.error(e)},Ti=[],ir=0,Cu=0;function vl(){for(var e=ir,n=Cu=ir=0;n<e;){var a=Ti[n];Ti[n++]=null;var o=Ti[n];Ti[n++]=null;var u=Ti[n];Ti[n++]=null;var d=Ti[n];if(Ti[n++]=null,o!==null&&u!==null){var _=o.pending;_===null?u.next=u:(u.next=_.next,_.next=u),o.pending=u}d!==0&&J0(a,u,d)}}function Al(e,n,a,o){Ti[ir++]=e,Ti[ir++]=n,Ti[ir++]=a,Ti[ir++]=o,Cu|=o,e.lanes|=o,e=e.alternate,e!==null&&(e.lanes|=o)}function yu(e,n,a,o){return Al(e,n,a,o),xl(e)}function Ms(e,n){return Al(e,null,null,n),xl(e)}function J0(e,n,a){e.lanes|=a;var o=e.alternate;o!==null&&(o.lanes|=a);for(var u=!1,d=e.return;d!==null;)d.childLanes|=a,o=d.alternate,o!==null&&(o.childLanes|=a),d.tag===22&&(e=d.stateNode,e===null||e._visibility&1||(u=!0)),e=d,d=d.return;return e.tag===3?(d=e.stateNode,u&&n!==null&&(u=31-Ut(a),e=d.hiddenUpdates,o=e[u],o===null?e[u]=[n]:o.push(n),n.lane=a|536870912),d):null}function xl(e){if(50<Fo)throw Fo=0,Xf=null,Error(s(185));for(var n=e.return;n!==null;)e=n,n=e.return;return e.tag===3?e.stateNode:null}var ar={};function kS(e,n,a,o){this.tag=e,this.key=a,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.refCleanup=this.ref=null,this.pendingProps=n,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=o,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function si(e,n,a,o){return new kS(e,n,a,o)}function Du(e){return e=e.prototype,!(!e||!e.isReactComponent)}function ra(e,n){var a=e.alternate;return a===null?(a=si(e.tag,n,e.key,e.mode),a.elementType=e.elementType,a.type=e.type,a.stateNode=e.stateNode,a.alternate=e,e.alternate=a):(a.pendingProps=n,a.type=e.type,a.flags=0,a.subtreeFlags=0,a.deletions=null),a.flags=e.flags&65011712,a.childLanes=e.childLanes,a.lanes=e.lanes,a.child=e.child,a.memoizedProps=e.memoizedProps,a.memoizedState=e.memoizedState,a.updateQueue=e.updateQueue,n=e.dependencies,a.dependencies=n===null?null:{lanes:n.lanes,firstContext:n.firstContext},a.sibling=e.sibling,a.index=e.index,a.ref=e.ref,a.refCleanup=e.refCleanup,a}function t1(e,n){e.flags&=65011714;var a=e.alternate;return a===null?(e.childLanes=0,e.lanes=n,e.child=null,e.subtreeFlags=0,e.memoizedProps=null,e.memoizedState=null,e.updateQueue=null,e.dependencies=null,e.stateNode=null):(e.childLanes=a.childLanes,e.lanes=a.lanes,e.child=a.child,e.subtreeFlags=0,e.deletions=null,e.memoizedProps=a.memoizedProps,e.memoizedState=a.memoizedState,e.updateQueue=a.updateQueue,e.type=a.type,n=a.dependencies,e.dependencies=n===null?null:{lanes:n.lanes,firstContext:n.firstContext}),e}function Nl(e,n,a,o,u,d){var _=0;if(o=e,typeof e=="function")Du(e)&&(_=1);else if(typeof e=="string")_=Qg(e,a,gt.current)?26:e==="html"||e==="head"||e==="body"?27:5;else t:switch(e){case w:return e=si(31,a,n,u),e.elementType=w,e.lanes=d,e;case M:return Rs(a.children,u,d,n);case x:_=8,u|=24;break;case v:return e=si(12,a,n,u|2),e.elementType=v,e.lanes=d,e;case Y:return e=si(13,a,n,u),e.elementType=Y,e.lanes=d,e;case F:return e=si(19,a,n,u),e.elementType=F,e.lanes=d,e;default:if(typeof e=="object"&&e!==null)switch(e.$$typeof){case I:_=10;break t;case D:_=9;break t;case U:_=11;break t;case B:_=14;break t;case R:_=16,o=null;break t}_=29,a=Error(s(130,e===null?"null":typeof e,"")),o=null}return n=si(_,a,n,u),n.elementType=e,n.type=o,n.lanes=d,n}function Rs(e,n,a,o){return e=si(7,e,o,n),e.lanes=a,e}function Ou(e,n,a){return e=si(6,e,null,n),e.lanes=a,e}function e1(e){var n=si(18,null,null,0);return n.stateNode=e,n}function bu(e,n,a){return n=si(4,e.children!==null?e.children:[],e.key,n),n.lanes=a,n.stateNode={containerInfo:e.containerInfo,pendingChildren:null,implementation:e.implementation},n}var n1=new WeakMap;function mi(e,n){if(typeof e=="object"&&e!==null){var a=n1.get(e);return a!==void 0?a:(n={value:e,source:n,stack:ke(n)},n1.set(e,n),n)}return{value:e,source:n,stack:ke(n)}}var sr=[],rr=0,Ml=null,po=0,Ei=[],Si=0,Ha=null,Pi=1,Hi="";function oa(e,n){sr[rr++]=po,sr[rr++]=Ml,Ml=e,po=n}function i1(e,n,a){Ei[Si++]=Pi,Ei[Si++]=Hi,Ei[Si++]=Ha,Ha=e;var o=Pi;e=Hi;var u=32-Ut(o)-1;o&=~(1<<u),a+=1;var d=32-Ut(n)+u;if(30<d){var _=u-u%5;d=(o&(1<<_)-1).toString(32),o>>=_,u-=_,Pi=1<<32-Ut(n)+u|a<<u|o,Hi=d+e}else Pi=1<<d|a<<u|o,Hi=e}function Iu(e){e.return!==null&&(oa(e,1),i1(e,1,0))}function Lu(e){for(;e===Ml;)Ml=sr[--rr],sr[rr]=null,po=sr[--rr],sr[rr]=null;for(;e===Ha;)Ha=Ei[--Si],Ei[Si]=null,Hi=Ei[--Si],Ei[Si]=null,Pi=Ei[--Si],Ei[Si]=null}function a1(e,n){Ei[Si++]=Pi,Ei[Si++]=Hi,Ei[Si++]=Ha,Pi=n.id,Hi=n.overflow,Ha=e}var Cn=null,Ke=null,ve=!1,Ya=null,gi=!1,Uu=Error(s(519));function Ga(e){var n=Error(s(418,1<arguments.length&&arguments[1]!==void 0&&arguments[1]?"text":"HTML",""));throw To(mi(n,e)),Uu}function s1(e){var n=e.stateNode,a=e.type,o=e.memoizedProps;switch(n[rn]=e,n[Rn]=o,a){case"dialog":me("cancel",n),me("close",n);break;case"iframe":case"object":case"embed":me("load",n);break;case"video":case"audio":for(a=0;a<Bo.length;a++)me(Bo[a],n);break;case"source":me("error",n);break;case"img":case"image":case"link":me("error",n),me("load",n);break;case"details":me("toggle",n);break;case"input":me("invalid",n),Un(n,o.value,o.defaultValue,o.checked,o.defaultChecked,o.type,o.name,!0);break;case"select":me("invalid",n);break;case"textarea":me("invalid",n),Mi(n,o.value,o.defaultValue,o.children)}a=o.children,typeof a!="string"&&typeof a!="number"&&typeof a!="bigint"||n.textContent===""+a||o.suppressHydrationWarning===!0||AT(n.textContent,a)?(o.popover!=null&&(me("beforetoggle",n),me("toggle",n)),o.onScroll!=null&&me("scroll",n),o.onScrollEnd!=null&&me("scrollend",n),o.onClick!=null&&(n.onclick=aa),n=!0):n=!1,n||Ga(e,!0)}function r1(e){for(Cn=e.return;Cn;)switch(Cn.tag){case 5:case 31:case 13:gi=!1;return;case 27:case 3:gi=!0;return;default:Cn=Cn.return}}function or(e){if(e!==Cn)return!1;if(!ve)return r1(e),ve=!0,!1;var n=e.tag,a;if((a=n!==3&&n!==27)&&((a=n===5)&&(a=e.type,a=!(a!=="form"&&a!=="button")||Jf(e.type,e.memoizedProps)),a=!a),a&&Ke&&Ga(e),r1(e),n===13){if(e=e.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(s(317));Ke=bT(e)}else if(n===31){if(e=e.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(s(317));Ke=bT(e)}else n===27?(n=Ke,ns(e.type)?(e=ah,ah=null,Ke=e):Ke=n):Ke=Cn?vi(e.stateNode.nextSibling):null;return!0}function Cs(){Ke=Cn=null,ve=!1}function Fu(){var e=Ya;return e!==null&&(Zn===null?Zn=e:Zn.push.apply(Zn,e),Ya=null),e}function To(e){Ya===null?Ya=[e]:Ya.push(e)}var wu=O(null),ys=null,la=null;function za(e,n,a){dt(wu,n._currentValue),n._currentValue=a}function ca(e){e._currentValue=wu.current,V(wu)}function Bu(e,n,a){for(;e!==null;){var o=e.alternate;if((e.childLanes&n)!==n?(e.childLanes|=n,o!==null&&(o.childLanes|=n)):o!==null&&(o.childLanes&n)!==n&&(o.childLanes|=n),e===a)break;e=e.return}}function Xu(e,n,a,o){var u=e.child;for(u!==null&&(u.return=e);u!==null;){var d=u.dependencies;if(d!==null){var _=u.child;d=d.firstContext;t:for(;d!==null;){var y=d;d=u;for(var X=0;X<n.length;X++)if(y.context===n[X]){d.lanes|=a,y=d.alternate,y!==null&&(y.lanes|=a),Bu(d.return,a,e),o||(_=null);break t}d=y.next}}else if(u.tag===18){if(_=u.return,_===null)throw Error(s(341));_.lanes|=a,d=_.alternate,d!==null&&(d.lanes|=a),Bu(_,a,e),_=null}else _=u.child;if(_!==null)_.return=u;else for(_=u;_!==null;){if(_===e){_=null;break}if(u=_.sibling,u!==null){u.return=_.return,_=u;break}_=_.return}u=_}}function lr(e,n,a,o){e=null;for(var u=n,d=!1;u!==null;){if(!d){if((u.flags&524288)!==0)d=!0;else if((u.flags&262144)!==0)break}if(u.tag===10){var _=u.alternate;if(_===null)throw Error(s(387));if(_=_.memoizedProps,_!==null){var y=u.type;ai(u.pendingProps.value,_.value)||(e!==null?e.push(y):e=[y])}}else if(u===vt.current){if(_=u.alternate,_===null)throw Error(s(387));_.memoizedState.memoizedState!==u.memoizedState.memoizedState&&(e!==null?e.push(Go):e=[Go])}u=u.return}e!==null&&Xu(n,e,a,o),n.flags|=262144}function Rl(e){for(e=e.firstContext;e!==null;){if(!ai(e.context._currentValue,e.memoizedValue))return!0;e=e.next}return!1}function Ds(e){ys=e,la=null,e=e.dependencies,e!==null&&(e.firstContext=null)}function yn(e){return o1(ys,e)}function Cl(e,n){return ys===null&&Ds(e),o1(e,n)}function o1(e,n){var a=n._currentValue;if(n={context:n,memoizedValue:a,next:null},la===null){if(e===null)throw Error(s(308));la=n,e.dependencies={lanes:0,firstContext:n},e.flags|=524288}else la=la.next=n;return a}var KS=typeof AbortController<"u"?AbortController:function(){var e=[],n=this.signal={aborted:!1,addEventListener:function(a,o){e.push(o)}};this.abort=function(){n.aborted=!0,e.forEach(function(a){return a()})}},ZS=r.unstable_scheduleCallback,qS=r.unstable_NormalPriority,fn={$$typeof:I,Consumer:null,Provider:null,_currentValue:null,_currentValue2:null,_threadCount:0};function Pu(){return{controller:new KS,data:new Map,refCount:0}}function mo(e){e.refCount--,e.refCount===0&&ZS(qS,function(){e.controller.abort()})}var Eo=null,Hu=0,cr=0,ur=null;function $S(e,n){if(Eo===null){var a=Eo=[];Hu=0,cr=Vf(),ur={status:"pending",value:void 0,then:function(o){a.push(o)}}}return Hu++,n.then(l1,l1),n}function l1(){if(--Hu===0&&Eo!==null){ur!==null&&(ur.status="fulfilled");var e=Eo;Eo=null,cr=0,ur=null;for(var n=0;n<e.length;n++)(0,e[n])()}}function QS(e,n){var a=[],o={status:"pending",value:null,reason:null,then:function(u){a.push(u)}};return e.then(function(){o.status="fulfilled",o.value=n;for(var u=0;u<a.length;u++)(0,a[u])(n)},function(u){for(o.status="rejected",o.reason=u,u=0;u<a.length;u++)(0,a[u])(void 0)}),o}var c1=L.S;L.S=function(e,n){kp=Ct(),typeof n=="object"&&n!==null&&typeof n.then=="function"&&$S(e,n),c1!==null&&c1(e,n)};var Os=O(null);function Yu(){var e=Os.current;return e!==null?e:We.pooledCache}function yl(e,n){n===null?dt(Os,Os.current):dt(Os,n.pool)}function u1(){var e=Yu();return e===null?null:{parent:fn._currentValue,pool:e}}var fr=Error(s(460)),Gu=Error(s(474)),Dl=Error(s(542)),Ol={then:function(){}};function f1(e){return e=e.status,e==="fulfilled"||e==="rejected"}function h1(e,n,a){switch(a=e[a],a===void 0?e.push(n):a!==n&&(n.then(aa,aa),n=a),n.status){case"fulfilled":return n.value;case"rejected":throw e=n.reason,p1(e),e;default:if(typeof n.status=="string")n.then(aa,aa);else{if(e=We,e!==null&&100<e.shellSuspendCounter)throw Error(s(482));e=n,e.status="pending",e.then(function(o){if(n.status==="pending"){var u=n;u.status="fulfilled",u.value=o}},function(o){if(n.status==="pending"){var u=n;u.status="rejected",u.reason=o}})}switch(n.status){case"fulfilled":return n.value;case"rejected":throw e=n.reason,p1(e),e}throw Is=n,fr}}function bs(e){try{var n=e._init;return n(e._payload)}catch(a){throw a!==null&&typeof a=="object"&&typeof a.then=="function"?(Is=a,fr):a}}var Is=null;function d1(){if(Is===null)throw Error(s(459));var e=Is;return Is=null,e}function p1(e){if(e===fr||e===Dl)throw Error(s(483))}var hr=null,So=0;function bl(e){var n=So;return So+=1,hr===null&&(hr=[]),h1(hr,e,n)}function go(e,n){n=n.props.ref,e.ref=n!==void 0?n:null}function Il(e,n){throw n.$$typeof===S?Error(s(525)):(e=Object.prototype.toString.call(n),Error(s(31,e==="[object Object]"?"object with keys {"+Object.keys(n).join(", ")+"}":e)))}function T1(e){function n(q,z){if(e){var j=q.deletions;j===null?(q.deletions=[z],q.flags|=16):j.push(z)}}function a(q,z){if(!e)return null;for(;z!==null;)n(q,z),z=z.sibling;return null}function o(q){for(var z=new Map;q!==null;)q.key!==null?z.set(q.key,q):z.set(q.index,q),q=q.sibling;return z}function u(q,z){return q=ra(q,z),q.index=0,q.sibling=null,q}function d(q,z,j){return q.index=j,e?(j=q.alternate,j!==null?(j=j.index,j<z?(q.flags|=67108866,z):j):(q.flags|=67108866,z)):(q.flags|=1048576,z)}function _(q){return e&&q.alternate===null&&(q.flags|=67108866),q}function y(q,z,j,Et){return z===null||z.tag!==6?(z=Ou(j,q.mode,Et),z.return=q,z):(z=u(z,j),z.return=q,z)}function X(q,z,j,Et){var $t=j.type;return $t===M?pt(q,z,j.props.children,Et,j.key):z!==null&&(z.elementType===$t||typeof $t=="object"&&$t!==null&&$t.$$typeof===R&&bs($t)===z.type)?(z=u(z,j.props),go(z,j),z.return=q,z):(z=Nl(j.type,j.key,j.props,null,q.mode,Et),go(z,j),z.return=q,z)}function J(q,z,j,Et){return z===null||z.tag!==4||z.stateNode.containerInfo!==j.containerInfo||z.stateNode.implementation!==j.implementation?(z=bu(j,q.mode,Et),z.return=q,z):(z=u(z,j.children||[]),z.return=q,z)}function pt(q,z,j,Et,$t){return z===null||z.tag!==7?(z=Rs(j,q.mode,Et,$t),z.return=q,z):(z=u(z,j),z.return=q,z)}function _t(q,z,j){if(typeof z=="string"&&z!==""||typeof z=="number"||typeof z=="bigint")return z=Ou(""+z,q.mode,j),z.return=q,z;if(typeof z=="object"&&z!==null){switch(z.$$typeof){case g:return j=Nl(z.type,z.key,z.props,null,q.mode,j),go(j,z),j.return=q,j;case A:return z=bu(z,q.mode,j),z.return=q,z;case R:return z=bs(z),_t(q,z,j)}if(W(z)||$(z))return z=Rs(z,q.mode,j,null),z.return=q,z;if(typeof z.then=="function")return _t(q,bl(z),j);if(z.$$typeof===I)return _t(q,Cl(q,z),j);Il(q,z)}return null}function st(q,z,j,Et){var $t=z!==null?z.key:null;if(typeof j=="string"&&j!==""||typeof j=="number"||typeof j=="bigint")return $t!==null?null:y(q,z,""+j,Et);if(typeof j=="object"&&j!==null){switch(j.$$typeof){case g:return j.key===$t?X(q,z,j,Et):null;case A:return j.key===$t?J(q,z,j,Et):null;case R:return j=bs(j),st(q,z,j,Et)}if(W(j)||$(j))return $t!==null?null:pt(q,z,j,Et,null);if(typeof j.then=="function")return st(q,z,bl(j),Et);if(j.$$typeof===I)return st(q,z,Cl(q,j),Et);Il(q,j)}return null}function ot(q,z,j,Et,$t){if(typeof Et=="string"&&Et!==""||typeof Et=="number"||typeof Et=="bigint")return q=q.get(j)||null,y(z,q,""+Et,$t);if(typeof Et=="object"&&Et!==null){switch(Et.$$typeof){case g:return q=q.get(Et.key===null?j:Et.key)||null,X(z,q,Et,$t);case A:return q=q.get(Et.key===null?j:Et.key)||null,J(z,q,Et,$t);case R:return Et=bs(Et),ot(q,z,j,Et,$t)}if(W(Et)||$(Et))return q=q.get(j)||null,pt(z,q,Et,$t,null);if(typeof Et.then=="function")return ot(q,z,j,bl(Et),$t);if(Et.$$typeof===I)return ot(q,z,j,Cl(z,Et),$t);Il(z,Et)}return null}function Vt(q,z,j,Et){for(var $t=null,Re=null,kt=z,ce=z=0,ge=null;kt!==null&&ce<j.length;ce++){kt.index>ce?(ge=kt,kt=null):ge=kt.sibling;var Ce=st(q,kt,j[ce],Et);if(Ce===null){kt===null&&(kt=ge);break}e&&kt&&Ce.alternate===null&&n(q,kt),z=d(Ce,z,ce),Re===null?$t=Ce:Re.sibling=Ce,Re=Ce,kt=ge}if(ce===j.length)return a(q,kt),ve&&oa(q,ce),$t;if(kt===null){for(;ce<j.length;ce++)kt=_t(q,j[ce],Et),kt!==null&&(z=d(kt,z,ce),Re===null?$t=kt:Re.sibling=kt,Re=kt);return ve&&oa(q,ce),$t}for(kt=o(kt);ce<j.length;ce++)ge=ot(kt,q,ce,j[ce],Et),ge!==null&&(e&&ge.alternate!==null&&kt.delete(ge.key===null?ce:ge.key),z=d(ge,z,ce),Re===null?$t=ge:Re.sibling=ge,Re=ge);return e&&kt.forEach(function(os){return n(q,os)}),ve&&oa(q,ce),$t}function jt(q,z,j,Et){if(j==null)throw Error(s(151));for(var $t=null,Re=null,kt=z,ce=z=0,ge=null,Ce=j.next();kt!==null&&!Ce.done;ce++,Ce=j.next()){kt.index>ce?(ge=kt,kt=null):ge=kt.sibling;var os=st(q,kt,Ce.value,Et);if(os===null){kt===null&&(kt=ge);break}e&&kt&&os.alternate===null&&n(q,kt),z=d(os,z,ce),Re===null?$t=os:Re.sibling=os,Re=os,kt=ge}if(Ce.done)return a(q,kt),ve&&oa(q,ce),$t;if(kt===null){for(;!Ce.done;ce++,Ce=j.next())Ce=_t(q,Ce.value,Et),Ce!==null&&(z=d(Ce,z,ce),Re===null?$t=Ce:Re.sibling=Ce,Re=Ce);return ve&&oa(q,ce),$t}for(kt=o(kt);!Ce.done;ce++,Ce=j.next())Ce=ot(kt,q,ce,Ce.value,Et),Ce!==null&&(e&&Ce.alternate!==null&&kt.delete(Ce.key===null?ce:Ce.key),z=d(Ce,z,ce),Re===null?$t=Ce:Re.sibling=Ce,Re=Ce);return e&&kt.forEach(function(l_){return n(q,l_)}),ve&&oa(q,ce),$t}function Ge(q,z,j,Et){if(typeof j=="object"&&j!==null&&j.type===M&&j.key===null&&(j=j.props.children),typeof j=="object"&&j!==null){switch(j.$$typeof){case g:t:{for(var $t=j.key;z!==null;){if(z.key===$t){if($t=j.type,$t===M){if(z.tag===7){a(q,z.sibling),Et=u(z,j.props.children),Et.return=q,q=Et;break t}}else if(z.elementType===$t||typeof $t=="object"&&$t!==null&&$t.$$typeof===R&&bs($t)===z.type){a(q,z.sibling),Et=u(z,j.props),go(Et,j),Et.return=q,q=Et;break t}a(q,z);break}else n(q,z);z=z.sibling}j.type===M?(Et=Rs(j.props.children,q.mode,Et,j.key),Et.return=q,q=Et):(Et=Nl(j.type,j.key,j.props,null,q.mode,Et),go(Et,j),Et.return=q,q=Et)}return _(q);case A:t:{for($t=j.key;z!==null;){if(z.key===$t)if(z.tag===4&&z.stateNode.containerInfo===j.containerInfo&&z.stateNode.implementation===j.implementation){a(q,z.sibling),Et=u(z,j.children||[]),Et.return=q,q=Et;break t}else{a(q,z);break}else n(q,z);z=z.sibling}Et=bu(j,q.mode,Et),Et.return=q,q=Et}return _(q);case R:return j=bs(j),Ge(q,z,j,Et)}if(W(j))return Vt(q,z,j,Et);if($(j)){if($t=$(j),typeof $t!="function")throw Error(s(150));return j=$t.call(j),jt(q,z,j,Et)}if(typeof j.then=="function")return Ge(q,z,bl(j),Et);if(j.$$typeof===I)return Ge(q,z,Cl(q,j),Et);Il(q,j)}return typeof j=="string"&&j!==""||typeof j=="number"||typeof j=="bigint"?(j=""+j,z!==null&&z.tag===6?(a(q,z.sibling),Et=u(z,j),Et.return=q,q=Et):(a(q,z),Et=Ou(j,q.mode,Et),Et.return=q,q=Et),_(q)):a(q,z)}return function(q,z,j,Et){try{So=0;var $t=Ge(q,z,j,Et);return hr=null,$t}catch(kt){if(kt===fr||kt===Dl)throw kt;var Re=si(29,kt,null,q.mode);return Re.lanes=Et,Re.return=q,Re}}}var Ls=T1(!0),m1=T1(!1),Va=!1;function zu(e){e.updateQueue={baseState:e.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,lanes:0,hiddenCallbacks:null},callbacks:null}}function Vu(e,n){e=e.updateQueue,n.updateQueue===e&&(n.updateQueue={baseState:e.baseState,firstBaseUpdate:e.firstBaseUpdate,lastBaseUpdate:e.lastBaseUpdate,shared:e.shared,callbacks:null})}function Wa(e){return{lane:e,tag:0,payload:null,callback:null,next:null}}function ka(e,n,a){var o=e.updateQueue;if(o===null)return null;if(o=o.shared,(De&2)!==0){var u=o.pending;return u===null?n.next=n:(n.next=u.next,u.next=n),o.pending=n,n=xl(e),J0(e,null,a),n}return Al(e,o,n,a),xl(e)}function _o(e,n,a){if(n=n.updateQueue,n!==null&&(n=n.shared,(a&4194048)!==0)){var o=n.lanes;o&=e.pendingLanes,a|=o,n.lanes=a,pi(e,a)}}function Wu(e,n){var a=e.updateQueue,o=e.alternate;if(o!==null&&(o=o.updateQueue,a===o)){var u=null,d=null;if(a=a.firstBaseUpdate,a!==null){do{var _={lane:a.lane,tag:a.tag,payload:a.payload,callback:null,next:null};d===null?u=d=_:d=d.next=_,a=a.next}while(a!==null);d===null?u=d=n:d=d.next=n}else u=d=n;a={baseState:o.baseState,firstBaseUpdate:u,lastBaseUpdate:d,shared:o.shared,callbacks:o.callbacks},e.updateQueue=a;return}e=a.lastBaseUpdate,e===null?a.firstBaseUpdate=n:e.next=n,a.lastBaseUpdate=n}var ku=!1;function vo(){if(ku){var e=ur;if(e!==null)throw e}}function Ao(e,n,a,o){ku=!1;var u=e.updateQueue;Va=!1;var d=u.firstBaseUpdate,_=u.lastBaseUpdate,y=u.shared.pending;if(y!==null){u.shared.pending=null;var X=y,J=X.next;X.next=null,_===null?d=J:_.next=J,_=X;var pt=e.alternate;pt!==null&&(pt=pt.updateQueue,y=pt.lastBaseUpdate,y!==_&&(y===null?pt.firstBaseUpdate=J:y.next=J,pt.lastBaseUpdate=X))}if(d!==null){var _t=u.baseState;_=0,pt=J=X=null,y=d;do{var st=y.lane&-536870913,ot=st!==y.lane;if(ot?(Se&st)===st:(o&st)===st){st!==0&&st===cr&&(ku=!0),pt!==null&&(pt=pt.next={lane:0,tag:y.tag,payload:y.payload,callback:null,next:null});t:{var Vt=e,jt=y;st=n;var Ge=a;switch(jt.tag){case 1:if(Vt=jt.payload,typeof Vt=="function"){_t=Vt.call(Ge,_t,st);break t}_t=Vt;break t;case 3:Vt.flags=Vt.flags&-65537|128;case 0:if(Vt=jt.payload,st=typeof Vt=="function"?Vt.call(Ge,_t,st):Vt,st==null)break t;_t=E({},_t,st);break t;case 2:Va=!0}}st=y.callback,st!==null&&(e.flags|=64,ot&&(e.flags|=8192),ot=u.callbacks,ot===null?u.callbacks=[st]:ot.push(st))}else ot={lane:st,tag:y.tag,payload:y.payload,callback:y.callback,next:null},pt===null?(J=pt=ot,X=_t):pt=pt.next=ot,_|=st;if(y=y.next,y===null){if(y=u.shared.pending,y===null)break;ot=y,y=ot.next,ot.next=null,u.lastBaseUpdate=ot,u.shared.pending=null}}while(!0);pt===null&&(X=_t),u.baseState=X,u.firstBaseUpdate=J,u.lastBaseUpdate=pt,d===null&&(u.shared.lanes=0),Qa|=_,e.lanes=_,e.memoizedState=_t}}function E1(e,n){if(typeof e!="function")throw Error(s(191,e));e.call(n)}function S1(e,n){var a=e.callbacks;if(a!==null)for(e.callbacks=null,e=0;e<a.length;e++)E1(a[e],n)}var dr=O(null),Ll=O(0);function g1(e,n){e=Sa,dt(Ll,e),dt(dr,n),Sa=e|n.baseLanes}function Ku(){dt(Ll,Sa),dt(dr,dr.current)}function Zu(){Sa=Ll.current,V(dr),V(Ll)}var ri=O(null),_i=null;function Ka(e){var n=e.alternate;dt(on,on.current&1),dt(ri,e),_i===null&&(n===null||dr.current!==null||n.memoizedState!==null)&&(_i=e)}function qu(e){dt(on,on.current),dt(ri,e),_i===null&&(_i=e)}function _1(e){e.tag===22?(dt(on,on.current),dt(ri,e),_i===null&&(_i=e)):Za()}function Za(){dt(on,on.current),dt(ri,ri.current)}function oi(e){V(ri),_i===e&&(_i=null),V(on)}var on=O(0);function Ul(e){for(var n=e;n!==null;){if(n.tag===13){var a=n.memoizedState;if(a!==null&&(a=a.dehydrated,a===null||nh(a)||ih(a)))return n}else if(n.tag===19&&(n.memoizedProps.revealOrder==="forwards"||n.memoizedProps.revealOrder==="backwards"||n.memoizedProps.revealOrder==="unstable_legacy-backwards"||n.memoizedProps.revealOrder==="together")){if((n.flags&128)!==0)return n}else if(n.child!==null){n.child.return=n,n=n.child;continue}if(n===e)break;for(;n.sibling===null;){if(n.return===null||n.return===e)return null;n=n.return}n.sibling.return=n.return,n=n.sibling}return null}var ua=0,oe=null,He=null,hn=null,Fl=!1,pr=!1,Us=!1,wl=0,xo=0,Tr=null,jS=0;function en(){throw Error(s(321))}function $u(e,n){if(n===null)return!1;for(var a=0;a<n.length&&a<e.length;a++)if(!ai(e[a],n[a]))return!1;return!0}function Qu(e,n,a,o,u,d){return ua=d,oe=n,n.memoizedState=null,n.updateQueue=null,n.lanes=0,L.H=e===null||e.memoizedState===null?ip:df,Us=!1,d=a(o,u),Us=!1,pr&&(d=A1(n,a,o,u)),v1(e),d}function v1(e){L.H=Ro;var n=He!==null&&He.next!==null;if(ua=0,hn=He=oe=null,Fl=!1,xo=0,Tr=null,n)throw Error(s(300));e===null||dn||(e=e.dependencies,e!==null&&Rl(e)&&(dn=!0))}function A1(e,n,a,o){oe=e;var u=0;do{if(pr&&(Tr=null),xo=0,pr=!1,25<=u)throw Error(s(301));if(u+=1,hn=He=null,e.updateQueue!=null){var d=e.updateQueue;d.lastEffect=null,d.events=null,d.stores=null,d.memoCache!=null&&(d.memoCache.index=0)}L.H=ap,d=n(a,o)}while(pr);return d}function JS(){var e=L.H,n=e.useState()[0];return n=typeof n.then=="function"?No(n):n,e=e.useState()[0],(He!==null?He.memoizedState:null)!==e&&(oe.flags|=1024),n}function ju(){var e=wl!==0;return wl=0,e}function Ju(e,n,a){n.updateQueue=e.updateQueue,n.flags&=-2053,e.lanes&=~a}function tf(e){if(Fl){for(e=e.memoizedState;e!==null;){var n=e.queue;n!==null&&(n.pending=null),e=e.next}Fl=!1}ua=0,hn=He=oe=null,pr=!1,xo=wl=0,Tr=null}function Yn(){var e={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return hn===null?oe.memoizedState=hn=e:hn=hn.next=e,hn}function ln(){if(He===null){var e=oe.alternate;e=e!==null?e.memoizedState:null}else e=He.next;var n=hn===null?oe.memoizedState:hn.next;if(n!==null)hn=n,He=e;else{if(e===null)throw oe.alternate===null?Error(s(467)):Error(s(310));He=e,e={memoizedState:He.memoizedState,baseState:He.baseState,baseQueue:He.baseQueue,queue:He.queue,next:null},hn===null?oe.memoizedState=hn=e:hn=hn.next=e}return hn}function Bl(){return{lastEffect:null,events:null,stores:null,memoCache:null}}function No(e){var n=xo;return xo+=1,Tr===null&&(Tr=[]),e=h1(Tr,e,n),n=oe,(hn===null?n.memoizedState:hn.next)===null&&(n=n.alternate,L.H=n===null||n.memoizedState===null?ip:df),e}function Xl(e){if(e!==null&&typeof e=="object"){if(typeof e.then=="function")return No(e);if(e.$$typeof===I)return yn(e)}throw Error(s(438,String(e)))}function ef(e){var n=null,a=oe.updateQueue;if(a!==null&&(n=a.memoCache),n==null){var o=oe.alternate;o!==null&&(o=o.updateQueue,o!==null&&(o=o.memoCache,o!=null&&(n={data:o.data.map(function(u){return u.slice()}),index:0})))}if(n==null&&(n={data:[],index:0}),a===null&&(a=Bl(),oe.updateQueue=a),a.memoCache=n,a=n.data[n.index],a===void 0)for(a=n.data[n.index]=Array(e),o=0;o<e;o++)a[o]=Z;return n.index++,a}function fa(e,n){return typeof n=="function"?n(e):n}function Pl(e){var n=ln();return nf(n,He,e)}function nf(e,n,a){var o=e.queue;if(o===null)throw Error(s(311));o.lastRenderedReducer=a;var u=e.baseQueue,d=o.pending;if(d!==null){if(u!==null){var _=u.next;u.next=d.next,d.next=_}n.baseQueue=u=d,o.pending=null}if(d=e.baseState,u===null)e.memoizedState=d;else{n=u.next;var y=_=null,X=null,J=n,pt=!1;do{var _t=J.lane&-536870913;if(_t!==J.lane?(Se&_t)===_t:(ua&_t)===_t){var st=J.revertLane;if(st===0)X!==null&&(X=X.next={lane:0,revertLane:0,gesture:null,action:J.action,hasEagerState:J.hasEagerState,eagerState:J.eagerState,next:null}),_t===cr&&(pt=!0);else if((ua&st)===st){J=J.next,st===cr&&(pt=!0);continue}else _t={lane:0,revertLane:J.revertLane,gesture:null,action:J.action,hasEagerState:J.hasEagerState,eagerState:J.eagerState,next:null},X===null?(y=X=_t,_=d):X=X.next=_t,oe.lanes|=st,Qa|=st;_t=J.action,Us&&a(d,_t),d=J.hasEagerState?J.eagerState:a(d,_t)}else st={lane:_t,revertLane:J.revertLane,gesture:J.gesture,action:J.action,hasEagerState:J.hasEagerState,eagerState:J.eagerState,next:null},X===null?(y=X=st,_=d):X=X.next=st,oe.lanes|=_t,Qa|=_t;J=J.next}while(J!==null&&J!==n);if(X===null?_=d:X.next=y,!ai(d,e.memoizedState)&&(dn=!0,pt&&(a=ur,a!==null)))throw a;e.memoizedState=d,e.baseState=_,e.baseQueue=X,o.lastRenderedState=d}return u===null&&(o.lanes=0),[e.memoizedState,o.dispatch]}function af(e){var n=ln(),a=n.queue;if(a===null)throw Error(s(311));a.lastRenderedReducer=e;var o=a.dispatch,u=a.pending,d=n.memoizedState;if(u!==null){a.pending=null;var _=u=u.next;do d=e(d,_.action),_=_.next;while(_!==u);ai(d,n.memoizedState)||(dn=!0),n.memoizedState=d,n.baseQueue===null&&(n.baseState=d),a.lastRenderedState=d}return[d,o]}function x1(e,n,a){var o=oe,u=ln(),d=ve;if(d){if(a===void 0)throw Error(s(407));a=a()}else a=n();var _=!ai((He||u).memoizedState,a);if(_&&(u.memoizedState=a,dn=!0),u=u.queue,of(R1.bind(null,o,u,e),[e]),u.getSnapshot!==n||_||hn!==null&&hn.memoizedState.tag&1){if(o.flags|=2048,mr(9,{destroy:void 0},M1.bind(null,o,u,a,n),null),We===null)throw Error(s(349));d||(ua&127)!==0||N1(o,n,a)}return a}function N1(e,n,a){e.flags|=16384,e={getSnapshot:n,value:a},n=oe.updateQueue,n===null?(n=Bl(),oe.updateQueue=n,n.stores=[e]):(a=n.stores,a===null?n.stores=[e]:a.push(e))}function M1(e,n,a,o){n.value=a,n.getSnapshot=o,C1(n)&&y1(e)}function R1(e,n,a){return a(function(){C1(n)&&y1(e)})}function C1(e){var n=e.getSnapshot;e=e.value;try{var a=n();return!ai(e,a)}catch{return!0}}function y1(e){var n=Ms(e,2);n!==null&&qn(n,e,2)}function sf(e){var n=Yn();if(typeof e=="function"){var a=e;if(e=a(),Us){Lt(!0);try{a()}finally{Lt(!1)}}}return n.memoizedState=n.baseState=e,n.queue={pending:null,lanes:0,dispatch:null,lastRenderedReducer:fa,lastRenderedState:e},n}function D1(e,n,a,o){return e.baseState=a,nf(e,He,typeof o=="function"?o:fa)}function tg(e,n,a,o,u){if(Gl(e))throw Error(s(485));if(e=n.action,e!==null){var d={payload:u,action:e,next:null,isTransition:!0,status:"pending",value:null,reason:null,listeners:[],then:function(_){d.listeners.push(_)}};L.T!==null?a(!0):d.isTransition=!1,o(d),a=n.pending,a===null?(d.next=n.pending=d,O1(n,d)):(d.next=a.next,n.pending=a.next=d)}}function O1(e,n){var a=n.action,o=n.payload,u=e.state;if(n.isTransition){var d=L.T,_={};L.T=_;try{var y=a(u,o),X=L.S;X!==null&&X(_,y),b1(e,n,y)}catch(J){rf(e,n,J)}finally{d!==null&&_.types!==null&&(d.types=_.types),L.T=d}}else try{d=a(u,o),b1(e,n,d)}catch(J){rf(e,n,J)}}function b1(e,n,a){a!==null&&typeof a=="object"&&typeof a.then=="function"?a.then(function(o){I1(e,n,o)},function(o){return rf(e,n,o)}):I1(e,n,a)}function I1(e,n,a){n.status="fulfilled",n.value=a,L1(n),e.state=a,n=e.pending,n!==null&&(a=n.next,a===n?e.pending=null:(a=a.next,n.next=a,O1(e,a)))}function rf(e,n,a){var o=e.pending;if(e.pending=null,o!==null){o=o.next;do n.status="rejected",n.reason=a,L1(n),n=n.next;while(n!==o)}e.action=null}function L1(e){e=e.listeners;for(var n=0;n<e.length;n++)(0,e[n])()}function U1(e,n){return n}function F1(e,n){if(ve){var a=We.formState;if(a!==null){t:{var o=oe;if(ve){if(Ke){e:{for(var u=Ke,d=gi;u.nodeType!==8;){if(!d){u=null;break e}if(u=vi(u.nextSibling),u===null){u=null;break e}}d=u.data,u=d==="F!"||d==="F"?u:null}if(u){Ke=vi(u.nextSibling),o=u.data==="F!";break t}}Ga(o)}o=!1}o&&(n=a[0])}}return a=Yn(),a.memoizedState=a.baseState=n,o={pending:null,lanes:0,dispatch:null,lastRenderedReducer:U1,lastRenderedState:n},a.queue=o,a=tp.bind(null,oe,o),o.dispatch=a,o=sf(!1),d=hf.bind(null,oe,!1,o.queue),o=Yn(),u={state:n,dispatch:null,action:e,pending:null},o.queue=u,a=tg.bind(null,oe,u,d,a),u.dispatch=a,o.memoizedState=e,[n,a,!1]}function w1(e){var n=ln();return B1(n,He,e)}function B1(e,n,a){if(n=nf(e,n,U1)[0],e=Pl(fa)[0],typeof n=="object"&&n!==null&&typeof n.then=="function")try{var o=No(n)}catch(_){throw _===fr?Dl:_}else o=n;n=ln();var u=n.queue,d=u.dispatch;return a!==n.memoizedState&&(oe.flags|=2048,mr(9,{destroy:void 0},eg.bind(null,u,a),null)),[o,d,e]}function eg(e,n){e.action=n}function X1(e){var n=ln(),a=He;if(a!==null)return B1(n,a,e);ln(),n=n.memoizedState,a=ln();var o=a.queue.dispatch;return a.memoizedState=e,[n,o,!1]}function mr(e,n,a,o){return e={tag:e,create:a,deps:o,inst:n,next:null},n=oe.updateQueue,n===null&&(n=Bl(),oe.updateQueue=n),a=n.lastEffect,a===null?n.lastEffect=e.next=e:(o=a.next,a.next=e,e.next=o,n.lastEffect=e),e}function P1(){return ln().memoizedState}function Hl(e,n,a,o){var u=Yn();oe.flags|=e,u.memoizedState=mr(1|n,{destroy:void 0},a,o===void 0?null:o)}function Yl(e,n,a,o){var u=ln();o=o===void 0?null:o;var d=u.memoizedState.inst;He!==null&&o!==null&&$u(o,He.memoizedState.deps)?u.memoizedState=mr(n,d,a,o):(oe.flags|=e,u.memoizedState=mr(1|n,d,a,o))}function H1(e,n){Hl(8390656,8,e,n)}function of(e,n){Yl(2048,8,e,n)}function ng(e){oe.flags|=4;var n=oe.updateQueue;if(n===null)n=Bl(),oe.updateQueue=n,n.events=[e];else{var a=n.events;a===null?n.events=[e]:a.push(e)}}function Y1(e){var n=ln().memoizedState;return ng({ref:n,nextImpl:e}),function(){if((De&2)!==0)throw Error(s(440));return n.impl.apply(void 0,arguments)}}function G1(e,n){return Yl(4,2,e,n)}function z1(e,n){return Yl(4,4,e,n)}function V1(e,n){if(typeof n=="function"){e=e();var a=n(e);return function(){typeof a=="function"?a():n(null)}}if(n!=null)return e=e(),n.current=e,function(){n.current=null}}function W1(e,n,a){a=a!=null?a.concat([e]):null,Yl(4,4,V1.bind(null,n,e),a)}function lf(){}function k1(e,n){var a=ln();n=n===void 0?null:n;var o=a.memoizedState;return n!==null&&$u(n,o[1])?o[0]:(a.memoizedState=[e,n],e)}function K1(e,n){var a=ln();n=n===void 0?null:n;var o=a.memoizedState;if(n!==null&&$u(n,o[1]))return o[0];if(o=e(),Us){Lt(!0);try{e()}finally{Lt(!1)}}return a.memoizedState=[o,n],o}function cf(e,n,a){return a===void 0||(ua&1073741824)!==0&&(Se&261930)===0?e.memoizedState=n:(e.memoizedState=a,e=Zp(),oe.lanes|=e,Qa|=e,a)}function Z1(e,n,a,o){return ai(a,n)?a:dr.current!==null?(e=cf(e,a,o),ai(e,n)||(dn=!0),e):(ua&42)===0||(ua&1073741824)!==0&&(Se&261930)===0?(dn=!0,e.memoizedState=a):(e=Zp(),oe.lanes|=e,Qa|=e,n)}function q1(e,n,a,o,u){var d=P.p;P.p=d!==0&&8>d?d:8;var _=L.T,y={};L.T=y,hf(e,!1,n,a);try{var X=u(),J=L.S;if(J!==null&&J(y,X),X!==null&&typeof X=="object"&&typeof X.then=="function"){var pt=QS(X,o);Mo(e,n,pt,ui(e))}else Mo(e,n,o,ui(e))}catch(_t){Mo(e,n,{then:function(){},status:"rejected",reason:_t},ui())}finally{P.p=d,_!==null&&y.types!==null&&(_.types=y.types),L.T=_}}function ig(){}function uf(e,n,a,o){if(e.tag!==5)throw Error(s(476));var u=$1(e).queue;q1(e,u,n,it,a===null?ig:function(){return Q1(e),a(o)})}function $1(e){var n=e.memoizedState;if(n!==null)return n;n={memoizedState:it,baseState:it,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:fa,lastRenderedState:it},next:null};var a={};return n.next={memoizedState:a,baseState:a,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:fa,lastRenderedState:a},next:null},e.memoizedState=n,e=e.alternate,e!==null&&(e.memoizedState=n),n}function Q1(e){var n=$1(e);n.next===null&&(n=e.alternate.memoizedState),Mo(e,n.next.queue,{},ui())}function ff(){return yn(Go)}function j1(){return ln().memoizedState}function J1(){return ln().memoizedState}function ag(e){for(var n=e.return;n!==null;){switch(n.tag){case 24:case 3:var a=ui();e=Wa(a);var o=ka(n,e,a);o!==null&&(qn(o,n,a),_o(o,n,a)),n={cache:Pu()},e.payload=n;return}n=n.return}}function sg(e,n,a){var o=ui();a={lane:o,revertLane:0,gesture:null,action:a,hasEagerState:!1,eagerState:null,next:null},Gl(e)?ep(n,a):(a=yu(e,n,a,o),a!==null&&(qn(a,e,o),np(a,n,o)))}function tp(e,n,a){var o=ui();Mo(e,n,a,o)}function Mo(e,n,a,o){var u={lane:o,revertLane:0,gesture:null,action:a,hasEagerState:!1,eagerState:null,next:null};if(Gl(e))ep(n,u);else{var d=e.alternate;if(e.lanes===0&&(d===null||d.lanes===0)&&(d=n.lastRenderedReducer,d!==null))try{var _=n.lastRenderedState,y=d(_,a);if(u.hasEagerState=!0,u.eagerState=y,ai(y,_))return Al(e,n,u,0),We===null&&vl(),!1}catch{}if(a=yu(e,n,u,o),a!==null)return qn(a,e,o),np(a,n,o),!0}return!1}function hf(e,n,a,o){if(o={lane:2,revertLane:Vf(),gesture:null,action:o,hasEagerState:!1,eagerState:null,next:null},Gl(e)){if(n)throw Error(s(479))}else n=yu(e,a,o,2),n!==null&&qn(n,e,2)}function Gl(e){var n=e.alternate;return e===oe||n!==null&&n===oe}function ep(e,n){pr=Fl=!0;var a=e.pending;a===null?n.next=n:(n.next=a.next,a.next=n),e.pending=n}function np(e,n,a){if((a&4194048)!==0){var o=n.lanes;o&=e.pendingLanes,a|=o,n.lanes=a,pi(e,a)}}var Ro={readContext:yn,use:Xl,useCallback:en,useContext:en,useEffect:en,useImperativeHandle:en,useLayoutEffect:en,useInsertionEffect:en,useMemo:en,useReducer:en,useRef:en,useState:en,useDebugValue:en,useDeferredValue:en,useTransition:en,useSyncExternalStore:en,useId:en,useHostTransitionStatus:en,useFormState:en,useActionState:en,useOptimistic:en,useMemoCache:en,useCacheRefresh:en};Ro.useEffectEvent=en;var ip={readContext:yn,use:Xl,useCallback:function(e,n){return Yn().memoizedState=[e,n===void 0?null:n],e},useContext:yn,useEffect:H1,useImperativeHandle:function(e,n,a){a=a!=null?a.concat([e]):null,Hl(4194308,4,V1.bind(null,n,e),a)},useLayoutEffect:function(e,n){return Hl(4194308,4,e,n)},useInsertionEffect:function(e,n){Hl(4,2,e,n)},useMemo:function(e,n){var a=Yn();n=n===void 0?null:n;var o=e();if(Us){Lt(!0);try{e()}finally{Lt(!1)}}return a.memoizedState=[o,n],o},useReducer:function(e,n,a){var o=Yn();if(a!==void 0){var u=a(n);if(Us){Lt(!0);try{a(n)}finally{Lt(!1)}}}else u=n;return o.memoizedState=o.baseState=u,e={pending:null,lanes:0,dispatch:null,lastRenderedReducer:e,lastRenderedState:u},o.queue=e,e=e.dispatch=sg.bind(null,oe,e),[o.memoizedState,e]},useRef:function(e){var n=Yn();return e={current:e},n.memoizedState=e},useState:function(e){e=sf(e);var n=e.queue,a=tp.bind(null,oe,n);return n.dispatch=a,[e.memoizedState,a]},useDebugValue:lf,useDeferredValue:function(e,n){var a=Yn();return cf(a,e,n)},useTransition:function(){var e=sf(!1);return e=q1.bind(null,oe,e.queue,!0,!1),Yn().memoizedState=e,[!1,e]},useSyncExternalStore:function(e,n,a){var o=oe,u=Yn();if(ve){if(a===void 0)throw Error(s(407));a=a()}else{if(a=n(),We===null)throw Error(s(349));(Se&127)!==0||N1(o,n,a)}u.memoizedState=a;var d={value:a,getSnapshot:n};return u.queue=d,H1(R1.bind(null,o,d,e),[e]),o.flags|=2048,mr(9,{destroy:void 0},M1.bind(null,o,d,a,n),null),a},useId:function(){var e=Yn(),n=We.identifierPrefix;if(ve){var a=Hi,o=Pi;a=(o&~(1<<32-Ut(o)-1)).toString(32)+a,n="_"+n+"R_"+a,a=wl++,0<a&&(n+="H"+a.toString(32)),n+="_"}else a=jS++,n="_"+n+"r_"+a.toString(32)+"_";return e.memoizedState=n},useHostTransitionStatus:ff,useFormState:F1,useActionState:F1,useOptimistic:function(e){var n=Yn();n.memoizedState=n.baseState=e;var a={pending:null,lanes:0,dispatch:null,lastRenderedReducer:null,lastRenderedState:null};return n.queue=a,n=hf.bind(null,oe,!0,a),a.dispatch=n,[e,n]},useMemoCache:ef,useCacheRefresh:function(){return Yn().memoizedState=ag.bind(null,oe)},useEffectEvent:function(e){var n=Yn(),a={impl:e};return n.memoizedState=a,function(){if((De&2)!==0)throw Error(s(440));return a.impl.apply(void 0,arguments)}}},df={readContext:yn,use:Xl,useCallback:k1,useContext:yn,useEffect:of,useImperativeHandle:W1,useInsertionEffect:G1,useLayoutEffect:z1,useMemo:K1,useReducer:Pl,useRef:P1,useState:function(){return Pl(fa)},useDebugValue:lf,useDeferredValue:function(e,n){var a=ln();return Z1(a,He.memoizedState,e,n)},useTransition:function(){var e=Pl(fa)[0],n=ln().memoizedState;return[typeof e=="boolean"?e:No(e),n]},useSyncExternalStore:x1,useId:j1,useHostTransitionStatus:ff,useFormState:w1,useActionState:w1,useOptimistic:function(e,n){var a=ln();return D1(a,He,e,n)},useMemoCache:ef,useCacheRefresh:J1};df.useEffectEvent=Y1;var ap={readContext:yn,use:Xl,useCallback:k1,useContext:yn,useEffect:of,useImperativeHandle:W1,useInsertionEffect:G1,useLayoutEffect:z1,useMemo:K1,useReducer:af,useRef:P1,useState:function(){return af(fa)},useDebugValue:lf,useDeferredValue:function(e,n){var a=ln();return He===null?cf(a,e,n):Z1(a,He.memoizedState,e,n)},useTransition:function(){var e=af(fa)[0],n=ln().memoizedState;return[typeof e=="boolean"?e:No(e),n]},useSyncExternalStore:x1,useId:j1,useHostTransitionStatus:ff,useFormState:X1,useActionState:X1,useOptimistic:function(e,n){var a=ln();return He!==null?D1(a,He,e,n):(a.baseState=e,[e,a.queue.dispatch])},useMemoCache:ef,useCacheRefresh:J1};ap.useEffectEvent=Y1;function pf(e,n,a,o){n=e.memoizedState,a=a(o,n),a=a==null?n:E({},n,a),e.memoizedState=a,e.lanes===0&&(e.updateQueue.baseState=a)}var Tf={enqueueSetState:function(e,n,a){e=e._reactInternals;var o=ui(),u=Wa(o);u.payload=n,a!=null&&(u.callback=a),n=ka(e,u,o),n!==null&&(qn(n,e,o),_o(n,e,o))},enqueueReplaceState:function(e,n,a){e=e._reactInternals;var o=ui(),u=Wa(o);u.tag=1,u.payload=n,a!=null&&(u.callback=a),n=ka(e,u,o),n!==null&&(qn(n,e,o),_o(n,e,o))},enqueueForceUpdate:function(e,n){e=e._reactInternals;var a=ui(),o=Wa(a);o.tag=2,n!=null&&(o.callback=n),n=ka(e,o,a),n!==null&&(qn(n,e,a),_o(n,e,a))}};function sp(e,n,a,o,u,d,_){return e=e.stateNode,typeof e.shouldComponentUpdate=="function"?e.shouldComponentUpdate(o,d,_):n.prototype&&n.prototype.isPureReactComponent?!fo(a,o)||!fo(u,d):!0}function rp(e,n,a,o){e=n.state,typeof n.componentWillReceiveProps=="function"&&n.componentWillReceiveProps(a,o),typeof n.UNSAFE_componentWillReceiveProps=="function"&&n.UNSAFE_componentWillReceiveProps(a,o),n.state!==e&&Tf.enqueueReplaceState(n,n.state,null)}function Fs(e,n){var a=n;if("ref"in n){a={};for(var o in n)o!=="ref"&&(a[o]=n[o])}if(e=e.defaultProps){a===n&&(a=E({},a));for(var u in e)a[u]===void 0&&(a[u]=e[u])}return a}function op(e){_l(e)}function lp(e){console.error(e)}function cp(e){_l(e)}function zl(e,n){try{var a=e.onUncaughtError;a(n.value,{componentStack:n.stack})}catch(o){setTimeout(function(){throw o})}}function up(e,n,a){try{var o=e.onCaughtError;o(a.value,{componentStack:a.stack,errorBoundary:n.tag===1?n.stateNode:null})}catch(u){setTimeout(function(){throw u})}}function mf(e,n,a){return a=Wa(a),a.tag=3,a.payload={element:null},a.callback=function(){zl(e,n)},a}function fp(e){return e=Wa(e),e.tag=3,e}function hp(e,n,a,o){var u=a.type.getDerivedStateFromError;if(typeof u=="function"){var d=o.value;e.payload=function(){return u(d)},e.callback=function(){up(n,a,o)}}var _=a.stateNode;_!==null&&typeof _.componentDidCatch=="function"&&(e.callback=function(){up(n,a,o),typeof u!="function"&&(ja===null?ja=new Set([this]):ja.add(this));var y=o.stack;this.componentDidCatch(o.value,{componentStack:y!==null?y:""})})}function rg(e,n,a,o,u){if(a.flags|=32768,o!==null&&typeof o=="object"&&typeof o.then=="function"){if(n=a.alternate,n!==null&&lr(n,a,u,!0),a=ri.current,a!==null){switch(a.tag){case 31:case 13:return _i===null?ec():a.alternate===null&&nn===0&&(nn=3),a.flags&=-257,a.flags|=65536,a.lanes=u,o===Ol?a.flags|=16384:(n=a.updateQueue,n===null?a.updateQueue=new Set([o]):n.add(o),Yf(e,o,u)),!1;case 22:return a.flags|=65536,o===Ol?a.flags|=16384:(n=a.updateQueue,n===null?(n={transitions:null,markerInstances:null,retryQueue:new Set([o])},a.updateQueue=n):(a=n.retryQueue,a===null?n.retryQueue=new Set([o]):a.add(o)),Yf(e,o,u)),!1}throw Error(s(435,a.tag))}return Yf(e,o,u),ec(),!1}if(ve)return n=ri.current,n!==null?((n.flags&65536)===0&&(n.flags|=256),n.flags|=65536,n.lanes=u,o!==Uu&&(e=Error(s(422),{cause:o}),To(mi(e,a)))):(o!==Uu&&(n=Error(s(423),{cause:o}),To(mi(n,a))),e=e.current.alternate,e.flags|=65536,u&=-u,e.lanes|=u,o=mi(o,a),u=mf(e.stateNode,o,u),Wu(e,u),nn!==4&&(nn=2)),!1;var d=Error(s(520),{cause:o});if(d=mi(d,a),Uo===null?Uo=[d]:Uo.push(d),nn!==4&&(nn=2),n===null)return!0;o=mi(o,a),a=n;do{switch(a.tag){case 3:return a.flags|=65536,e=u&-u,a.lanes|=e,e=mf(a.stateNode,o,e),Wu(a,e),!1;case 1:if(n=a.type,d=a.stateNode,(a.flags&128)===0&&(typeof n.getDerivedStateFromError=="function"||d!==null&&typeof d.componentDidCatch=="function"&&(ja===null||!ja.has(d))))return a.flags|=65536,u&=-u,a.lanes|=u,u=fp(u),hp(u,e,a,o),Wu(a,u),!1}a=a.return}while(a!==null);return!1}var Ef=Error(s(461)),dn=!1;function Dn(e,n,a,o){n.child=e===null?m1(n,null,a,o):Ls(n,e.child,a,o)}function dp(e,n,a,o,u){a=a.render;var d=n.ref;if("ref"in o){var _={};for(var y in o)y!=="ref"&&(_[y]=o[y])}else _=o;return Ds(n),o=Qu(e,n,a,_,d,u),y=ju(),e!==null&&!dn?(Ju(e,n,u),ha(e,n,u)):(ve&&y&&Iu(n),n.flags|=1,Dn(e,n,o,u),n.child)}function pp(e,n,a,o,u){if(e===null){var d=a.type;return typeof d=="function"&&!Du(d)&&d.defaultProps===void 0&&a.compare===null?(n.tag=15,n.type=d,Tp(e,n,d,o,u)):(e=Nl(a.type,null,o,n,n.mode,u),e.ref=n.ref,e.return=n,n.child=e)}if(d=e.child,!Mf(e,u)){var _=d.memoizedProps;if(a=a.compare,a=a!==null?a:fo,a(_,o)&&e.ref===n.ref)return ha(e,n,u)}return n.flags|=1,e=ra(d,o),e.ref=n.ref,e.return=n,n.child=e}function Tp(e,n,a,o,u){if(e!==null){var d=e.memoizedProps;if(fo(d,o)&&e.ref===n.ref)if(dn=!1,n.pendingProps=o=d,Mf(e,u))(e.flags&131072)!==0&&(dn=!0);else return n.lanes=e.lanes,ha(e,n,u)}return Sf(e,n,a,o,u)}function mp(e,n,a,o){var u=o.children,d=e!==null?e.memoizedState:null;if(e===null&&n.stateNode===null&&(n.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),o.mode==="hidden"){if((n.flags&128)!==0){if(d=d!==null?d.baseLanes|a:a,e!==null){for(o=n.child=e.child,u=0;o!==null;)u=u|o.lanes|o.childLanes,o=o.sibling;o=u&~d}else o=0,n.child=null;return Ep(e,n,d,a,o)}if((a&536870912)!==0)n.memoizedState={baseLanes:0,cachePool:null},e!==null&&yl(n,d!==null?d.cachePool:null),d!==null?g1(n,d):Ku(),_1(n);else return o=n.lanes=536870912,Ep(e,n,d!==null?d.baseLanes|a:a,a,o)}else d!==null?(yl(n,d.cachePool),g1(n,d),Za(),n.memoizedState=null):(e!==null&&yl(n,null),Ku(),Za());return Dn(e,n,u,a),n.child}function Co(e,n){return e!==null&&e.tag===22||n.stateNode!==null||(n.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),n.sibling}function Ep(e,n,a,o,u){var d=Yu();return d=d===null?null:{parent:fn._currentValue,pool:d},n.memoizedState={baseLanes:a,cachePool:d},e!==null&&yl(n,null),Ku(),_1(n),e!==null&&lr(e,n,o,!0),n.childLanes=u,null}function Vl(e,n){return n=kl({mode:n.mode,children:n.children},e.mode),n.ref=e.ref,e.child=n,n.return=e,n}function Sp(e,n,a){return Ls(n,e.child,null,a),e=Vl(n,n.pendingProps),e.flags|=2,oi(n),n.memoizedState=null,e}function og(e,n,a){var o=n.pendingProps,u=(n.flags&128)!==0;if(n.flags&=-129,e===null){if(ve){if(o.mode==="hidden")return e=Vl(n,o),n.lanes=536870912,Co(null,e);if(qu(n),(e=Ke)?(e=OT(e,gi),e=e!==null&&e.data==="&"?e:null,e!==null&&(n.memoizedState={dehydrated:e,treeContext:Ha!==null?{id:Pi,overflow:Hi}:null,retryLane:536870912,hydrationErrors:null},a=e1(e),a.return=n,n.child=a,Cn=n,Ke=null)):e=null,e===null)throw Ga(n);return n.lanes=536870912,null}return Vl(n,o)}var d=e.memoizedState;if(d!==null){var _=d.dehydrated;if(qu(n),u)if(n.flags&256)n.flags&=-257,n=Sp(e,n,a);else if(n.memoizedState!==null)n.child=e.child,n.flags|=128,n=null;else throw Error(s(558));else if(dn||lr(e,n,a,!1),u=(a&e.childLanes)!==0,dn||u){if(o=We,o!==null&&(_=ei(o,a),_!==0&&_!==d.retryLane))throw d.retryLane=_,Ms(e,_),qn(o,e,_),Ef;ec(),n=Sp(e,n,a)}else e=d.treeContext,Ke=vi(_.nextSibling),Cn=n,ve=!0,Ya=null,gi=!1,e!==null&&a1(n,e),n=Vl(n,o),n.flags|=4096;return n}return e=ra(e.child,{mode:o.mode,children:o.children}),e.ref=n.ref,n.child=e,e.return=n,e}function Wl(e,n){var a=n.ref;if(a===null)e!==null&&e.ref!==null&&(n.flags|=4194816);else{if(typeof a!="function"&&typeof a!="object")throw Error(s(284));(e===null||e.ref!==a)&&(n.flags|=4194816)}}function Sf(e,n,a,o,u){return Ds(n),a=Qu(e,n,a,o,void 0,u),o=ju(),e!==null&&!dn?(Ju(e,n,u),ha(e,n,u)):(ve&&o&&Iu(n),n.flags|=1,Dn(e,n,a,u),n.child)}function gp(e,n,a,o,u,d){return Ds(n),n.updateQueue=null,a=A1(n,o,a,u),v1(e),o=ju(),e!==null&&!dn?(Ju(e,n,d),ha(e,n,d)):(ve&&o&&Iu(n),n.flags|=1,Dn(e,n,a,d),n.child)}function _p(e,n,a,o,u){if(Ds(n),n.stateNode===null){var d=ar,_=a.contextType;typeof _=="object"&&_!==null&&(d=yn(_)),d=new a(o,d),n.memoizedState=d.state!==null&&d.state!==void 0?d.state:null,d.updater=Tf,n.stateNode=d,d._reactInternals=n,d=n.stateNode,d.props=o,d.state=n.memoizedState,d.refs={},zu(n),_=a.contextType,d.context=typeof _=="object"&&_!==null?yn(_):ar,d.state=n.memoizedState,_=a.getDerivedStateFromProps,typeof _=="function"&&(pf(n,a,_,o),d.state=n.memoizedState),typeof a.getDerivedStateFromProps=="function"||typeof d.getSnapshotBeforeUpdate=="function"||typeof d.UNSAFE_componentWillMount!="function"&&typeof d.componentWillMount!="function"||(_=d.state,typeof d.componentWillMount=="function"&&d.componentWillMount(),typeof d.UNSAFE_componentWillMount=="function"&&d.UNSAFE_componentWillMount(),_!==d.state&&Tf.enqueueReplaceState(d,d.state,null),Ao(n,o,d,u),vo(),d.state=n.memoizedState),typeof d.componentDidMount=="function"&&(n.flags|=4194308),o=!0}else if(e===null){d=n.stateNode;var y=n.memoizedProps,X=Fs(a,y);d.props=X;var J=d.context,pt=a.contextType;_=ar,typeof pt=="object"&&pt!==null&&(_=yn(pt));var _t=a.getDerivedStateFromProps;pt=typeof _t=="function"||typeof d.getSnapshotBeforeUpdate=="function",y=n.pendingProps!==y,pt||typeof d.UNSAFE_componentWillReceiveProps!="function"&&typeof d.componentWillReceiveProps!="function"||(y||J!==_)&&rp(n,d,o,_),Va=!1;var st=n.memoizedState;d.state=st,Ao(n,o,d,u),vo(),J=n.memoizedState,y||st!==J||Va?(typeof _t=="function"&&(pf(n,a,_t,o),J=n.memoizedState),(X=Va||sp(n,a,X,o,st,J,_))?(pt||typeof d.UNSAFE_componentWillMount!="function"&&typeof d.componentWillMount!="function"||(typeof d.componentWillMount=="function"&&d.componentWillMount(),typeof d.UNSAFE_componentWillMount=="function"&&d.UNSAFE_componentWillMount()),typeof d.componentDidMount=="function"&&(n.flags|=4194308)):(typeof d.componentDidMount=="function"&&(n.flags|=4194308),n.memoizedProps=o,n.memoizedState=J),d.props=o,d.state=J,d.context=_,o=X):(typeof d.componentDidMount=="function"&&(n.flags|=4194308),o=!1)}else{d=n.stateNode,Vu(e,n),_=n.memoizedProps,pt=Fs(a,_),d.props=pt,_t=n.pendingProps,st=d.context,J=a.contextType,X=ar,typeof J=="object"&&J!==null&&(X=yn(J)),y=a.getDerivedStateFromProps,(J=typeof y=="function"||typeof d.getSnapshotBeforeUpdate=="function")||typeof d.UNSAFE_componentWillReceiveProps!="function"&&typeof d.componentWillReceiveProps!="function"||(_!==_t||st!==X)&&rp(n,d,o,X),Va=!1,st=n.memoizedState,d.state=st,Ao(n,o,d,u),vo();var ot=n.memoizedState;_!==_t||st!==ot||Va||e!==null&&e.dependencies!==null&&Rl(e.dependencies)?(typeof y=="function"&&(pf(n,a,y,o),ot=n.memoizedState),(pt=Va||sp(n,a,pt,o,st,ot,X)||e!==null&&e.dependencies!==null&&Rl(e.dependencies))?(J||typeof d.UNSAFE_componentWillUpdate!="function"&&typeof d.componentWillUpdate!="function"||(typeof d.componentWillUpdate=="function"&&d.componentWillUpdate(o,ot,X),typeof d.UNSAFE_componentWillUpdate=="function"&&d.UNSAFE_componentWillUpdate(o,ot,X)),typeof d.componentDidUpdate=="function"&&(n.flags|=4),typeof d.getSnapshotBeforeUpdate=="function"&&(n.flags|=1024)):(typeof d.componentDidUpdate!="function"||_===e.memoizedProps&&st===e.memoizedState||(n.flags|=4),typeof d.getSnapshotBeforeUpdate!="function"||_===e.memoizedProps&&st===e.memoizedState||(n.flags|=1024),n.memoizedProps=o,n.memoizedState=ot),d.props=o,d.state=ot,d.context=X,o=pt):(typeof d.componentDidUpdate!="function"||_===e.memoizedProps&&st===e.memoizedState||(n.flags|=4),typeof d.getSnapshotBeforeUpdate!="function"||_===e.memoizedProps&&st===e.memoizedState||(n.flags|=1024),o=!1)}return d=o,Wl(e,n),o=(n.flags&128)!==0,d||o?(d=n.stateNode,a=o&&typeof a.getDerivedStateFromError!="function"?null:d.render(),n.flags|=1,e!==null&&o?(n.child=Ls(n,e.child,null,u),n.child=Ls(n,null,a,u)):Dn(e,n,a,u),n.memoizedState=d.state,e=n.child):e=ha(e,n,u),e}function vp(e,n,a,o){return Cs(),n.flags|=256,Dn(e,n,a,o),n.child}var gf={dehydrated:null,treeContext:null,retryLane:0,hydrationErrors:null};function _f(e){return{baseLanes:e,cachePool:u1()}}function vf(e,n,a){return e=e!==null?e.childLanes&~a:0,n&&(e|=ci),e}function Ap(e,n,a){var o=n.pendingProps,u=!1,d=(n.flags&128)!==0,_;if((_=d)||(_=e!==null&&e.memoizedState===null?!1:(on.current&2)!==0),_&&(u=!0,n.flags&=-129),_=(n.flags&32)!==0,n.flags&=-33,e===null){if(ve){if(u?Ka(n):Za(),(e=Ke)?(e=OT(e,gi),e=e!==null&&e.data!=="&"?e:null,e!==null&&(n.memoizedState={dehydrated:e,treeContext:Ha!==null?{id:Pi,overflow:Hi}:null,retryLane:536870912,hydrationErrors:null},a=e1(e),a.return=n,n.child=a,Cn=n,Ke=null)):e=null,e===null)throw Ga(n);return ih(e)?n.lanes=32:n.lanes=536870912,null}var y=o.children;return o=o.fallback,u?(Za(),u=n.mode,y=kl({mode:"hidden",children:y},u),o=Rs(o,u,a,null),y.return=n,o.return=n,y.sibling=o,n.child=y,o=n.child,o.memoizedState=_f(a),o.childLanes=vf(e,_,a),n.memoizedState=gf,Co(null,o)):(Ka(n),Af(n,y))}var X=e.memoizedState;if(X!==null&&(y=X.dehydrated,y!==null)){if(d)n.flags&256?(Ka(n),n.flags&=-257,n=xf(e,n,a)):n.memoizedState!==null?(Za(),n.child=e.child,n.flags|=128,n=null):(Za(),y=o.fallback,u=n.mode,o=kl({mode:"visible",children:o.children},u),y=Rs(y,u,a,null),y.flags|=2,o.return=n,y.return=n,o.sibling=y,n.child=o,Ls(n,e.child,null,a),o=n.child,o.memoizedState=_f(a),o.childLanes=vf(e,_,a),n.memoizedState=gf,n=Co(null,o));else if(Ka(n),ih(y)){if(_=y.nextSibling&&y.nextSibling.dataset,_)var J=_.dgst;_=J,o=Error(s(419)),o.stack="",o.digest=_,To({value:o,source:null,stack:null}),n=xf(e,n,a)}else if(dn||lr(e,n,a,!1),_=(a&e.childLanes)!==0,dn||_){if(_=We,_!==null&&(o=ei(_,a),o!==0&&o!==X.retryLane))throw X.retryLane=o,Ms(e,o),qn(_,e,o),Ef;nh(y)||ec(),n=xf(e,n,a)}else nh(y)?(n.flags|=192,n.child=e.child,n=null):(e=X.treeContext,Ke=vi(y.nextSibling),Cn=n,ve=!0,Ya=null,gi=!1,e!==null&&a1(n,e),n=Af(n,o.children),n.flags|=4096);return n}return u?(Za(),y=o.fallback,u=n.mode,X=e.child,J=X.sibling,o=ra(X,{mode:"hidden",children:o.children}),o.subtreeFlags=X.subtreeFlags&65011712,J!==null?y=ra(J,y):(y=Rs(y,u,a,null),y.flags|=2),y.return=n,o.return=n,o.sibling=y,n.child=o,Co(null,o),o=n.child,y=e.child.memoizedState,y===null?y=_f(a):(u=y.cachePool,u!==null?(X=fn._currentValue,u=u.parent!==X?{parent:X,pool:X}:u):u=u1(),y={baseLanes:y.baseLanes|a,cachePool:u}),o.memoizedState=y,o.childLanes=vf(e,_,a),n.memoizedState=gf,Co(e.child,o)):(Ka(n),a=e.child,e=a.sibling,a=ra(a,{mode:"visible",children:o.children}),a.return=n,a.sibling=null,e!==null&&(_=n.deletions,_===null?(n.deletions=[e],n.flags|=16):_.push(e)),n.child=a,n.memoizedState=null,a)}function Af(e,n){return n=kl({mode:"visible",children:n},e.mode),n.return=e,e.child=n}function kl(e,n){return e=si(22,e,null,n),e.lanes=0,e}function xf(e,n,a){return Ls(n,e.child,null,a),e=Af(n,n.pendingProps.children),e.flags|=2,n.memoizedState=null,e}function xp(e,n,a){e.lanes|=n;var o=e.alternate;o!==null&&(o.lanes|=n),Bu(e.return,n,a)}function Nf(e,n,a,o,u,d){var _=e.memoizedState;_===null?e.memoizedState={isBackwards:n,rendering:null,renderingStartTime:0,last:o,tail:a,tailMode:u,treeForkCount:d}:(_.isBackwards=n,_.rendering=null,_.renderingStartTime=0,_.last=o,_.tail=a,_.tailMode=u,_.treeForkCount=d)}function Np(e,n,a){var o=n.pendingProps,u=o.revealOrder,d=o.tail;o=o.children;var _=on.current,y=(_&2)!==0;if(y?(_=_&1|2,n.flags|=128):_&=1,dt(on,_),Dn(e,n,o,a),o=ve?po:0,!y&&e!==null&&(e.flags&128)!==0)t:for(e=n.child;e!==null;){if(e.tag===13)e.memoizedState!==null&&xp(e,a,n);else if(e.tag===19)xp(e,a,n);else if(e.child!==null){e.child.return=e,e=e.child;continue}if(e===n)break t;for(;e.sibling===null;){if(e.return===null||e.return===n)break t;e=e.return}e.sibling.return=e.return,e=e.sibling}switch(u){case"forwards":for(a=n.child,u=null;a!==null;)e=a.alternate,e!==null&&Ul(e)===null&&(u=a),a=a.sibling;a=u,a===null?(u=n.child,n.child=null):(u=a.sibling,a.sibling=null),Nf(n,!1,u,a,d,o);break;case"backwards":case"unstable_legacy-backwards":for(a=null,u=n.child,n.child=null;u!==null;){if(e=u.alternate,e!==null&&Ul(e)===null){n.child=u;break}e=u.sibling,u.sibling=a,a=u,u=e}Nf(n,!0,a,null,d,o);break;case"together":Nf(n,!1,null,null,void 0,o);break;default:n.memoizedState=null}return n.child}function ha(e,n,a){if(e!==null&&(n.dependencies=e.dependencies),Qa|=n.lanes,(a&n.childLanes)===0)if(e!==null){if(lr(e,n,a,!1),(a&n.childLanes)===0)return null}else return null;if(e!==null&&n.child!==e.child)throw Error(s(153));if(n.child!==null){for(e=n.child,a=ra(e,e.pendingProps),n.child=a,a.return=n;e.sibling!==null;)e=e.sibling,a=a.sibling=ra(e,e.pendingProps),a.return=n;a.sibling=null}return n.child}function Mf(e,n){return(e.lanes&n)!==0?!0:(e=e.dependencies,!!(e!==null&&Rl(e)))}function lg(e,n,a){switch(n.tag){case 3:Nt(n,n.stateNode.containerInfo),za(n,fn,e.memoizedState.cache),Cs();break;case 27:case 5:Jt(n);break;case 4:Nt(n,n.stateNode.containerInfo);break;case 10:za(n,n.type,n.memoizedProps.value);break;case 31:if(n.memoizedState!==null)return n.flags|=128,qu(n),null;break;case 13:var o=n.memoizedState;if(o!==null)return o.dehydrated!==null?(Ka(n),n.flags|=128,null):(a&n.child.childLanes)!==0?Ap(e,n,a):(Ka(n),e=ha(e,n,a),e!==null?e.sibling:null);Ka(n);break;case 19:var u=(e.flags&128)!==0;if(o=(a&n.childLanes)!==0,o||(lr(e,n,a,!1),o=(a&n.childLanes)!==0),u){if(o)return Np(e,n,a);n.flags|=128}if(u=n.memoizedState,u!==null&&(u.rendering=null,u.tail=null,u.lastEffect=null),dt(on,on.current),o)break;return null;case 22:return n.lanes=0,mp(e,n,a,n.pendingProps);case 24:za(n,fn,e.memoizedState.cache)}return ha(e,n,a)}function Mp(e,n,a){if(e!==null)if(e.memoizedProps!==n.pendingProps)dn=!0;else{if(!Mf(e,a)&&(n.flags&128)===0)return dn=!1,lg(e,n,a);dn=(e.flags&131072)!==0}else dn=!1,ve&&(n.flags&1048576)!==0&&i1(n,po,n.index);switch(n.lanes=0,n.tag){case 16:t:{var o=n.pendingProps;if(e=bs(n.elementType),n.type=e,typeof e=="function")Du(e)?(o=Fs(e,o),n.tag=1,n=_p(null,n,e,o,a)):(n.tag=0,n=Sf(null,n,e,o,a));else{if(e!=null){var u=e.$$typeof;if(u===U){n.tag=11,n=dp(null,n,e,o,a);break t}else if(u===B){n.tag=14,n=pp(null,n,e,o,a);break t}}throw n=lt(e)||e,Error(s(306,n,""))}}return n;case 0:return Sf(e,n,n.type,n.pendingProps,a);case 1:return o=n.type,u=Fs(o,n.pendingProps),_p(e,n,o,u,a);case 3:t:{if(Nt(n,n.stateNode.containerInfo),e===null)throw Error(s(387));o=n.pendingProps;var d=n.memoizedState;u=d.element,Vu(e,n),Ao(n,o,null,a);var _=n.memoizedState;if(o=_.cache,za(n,fn,o),o!==d.cache&&Xu(n,[fn],a,!0),vo(),o=_.element,d.isDehydrated)if(d={element:o,isDehydrated:!1,cache:_.cache},n.updateQueue.baseState=d,n.memoizedState=d,n.flags&256){n=vp(e,n,o,a);break t}else if(o!==u){u=mi(Error(s(424)),n),To(u),n=vp(e,n,o,a);break t}else for(e=n.stateNode.containerInfo,e.nodeType===9?e=e.body:e=e.nodeName==="HTML"?e.ownerDocument.body:e,Ke=vi(e.firstChild),Cn=n,ve=!0,Ya=null,gi=!0,a=m1(n,null,o,a),n.child=a;a;)a.flags=a.flags&-3|4096,a=a.sibling;else{if(Cs(),o===u){n=ha(e,n,a);break t}Dn(e,n,o,a)}n=n.child}return n;case 26:return Wl(e,n),e===null?(a=wT(n.type,null,n.pendingProps,null))?n.memoizedState=a:ve||(a=n.type,e=n.pendingProps,o=lc(rt.current).createElement(a),o[rn]=n,o[Rn]=e,On(o,a,e),un(o),n.stateNode=o):n.memoizedState=wT(n.type,e.memoizedProps,n.pendingProps,e.memoizedState),null;case 27:return Jt(n),e===null&&ve&&(o=n.stateNode=LT(n.type,n.pendingProps,rt.current),Cn=n,gi=!0,u=Ke,ns(n.type)?(ah=u,Ke=vi(o.firstChild)):Ke=u),Dn(e,n,n.pendingProps.children,a),Wl(e,n),e===null&&(n.flags|=4194304),n.child;case 5:return e===null&&ve&&((u=o=Ke)&&(o=Xg(o,n.type,n.pendingProps,gi),o!==null?(n.stateNode=o,Cn=n,Ke=vi(o.firstChild),gi=!1,u=!0):u=!1),u||Ga(n)),Jt(n),u=n.type,d=n.pendingProps,_=e!==null?e.memoizedProps:null,o=d.children,Jf(u,d)?o=null:_!==null&&Jf(u,_)&&(n.flags|=32),n.memoizedState!==null&&(u=Qu(e,n,JS,null,null,a),Go._currentValue=u),Wl(e,n),Dn(e,n,o,a),n.child;case 6:return e===null&&ve&&((e=a=Ke)&&(a=Pg(a,n.pendingProps,gi),a!==null?(n.stateNode=a,Cn=n,Ke=null,e=!0):e=!1),e||Ga(n)),null;case 13:return Ap(e,n,a);case 4:return Nt(n,n.stateNode.containerInfo),o=n.pendingProps,e===null?n.child=Ls(n,null,o,a):Dn(e,n,o,a),n.child;case 11:return dp(e,n,n.type,n.pendingProps,a);case 7:return Dn(e,n,n.pendingProps,a),n.child;case 8:return Dn(e,n,n.pendingProps.children,a),n.child;case 12:return Dn(e,n,n.pendingProps.children,a),n.child;case 10:return o=n.pendingProps,za(n,n.type,o.value),Dn(e,n,o.children,a),n.child;case 9:return u=n.type._context,o=n.pendingProps.children,Ds(n),u=yn(u),o=o(u),n.flags|=1,Dn(e,n,o,a),n.child;case 14:return pp(e,n,n.type,n.pendingProps,a);case 15:return Tp(e,n,n.type,n.pendingProps,a);case 19:return Np(e,n,a);case 31:return og(e,n,a);case 22:return mp(e,n,a,n.pendingProps);case 24:return Ds(n),o=yn(fn),e===null?(u=Yu(),u===null&&(u=We,d=Pu(),u.pooledCache=d,d.refCount++,d!==null&&(u.pooledCacheLanes|=a),u=d),n.memoizedState={parent:o,cache:u},zu(n),za(n,fn,u)):((e.lanes&a)!==0&&(Vu(e,n),Ao(n,null,null,a),vo()),u=e.memoizedState,d=n.memoizedState,u.parent!==o?(u={parent:o,cache:o},n.memoizedState=u,n.lanes===0&&(n.memoizedState=n.updateQueue.baseState=u),za(n,fn,o)):(o=d.cache,za(n,fn,o),o!==u.cache&&Xu(n,[fn],a,!0))),Dn(e,n,n.pendingProps.children,a),n.child;case 29:throw n.pendingProps}throw Error(s(156,n.tag))}function da(e){e.flags|=4}function Rf(e,n,a,o,u){if((n=(e.mode&32)!==0)&&(n=!1),n){if(e.flags|=16777216,(u&335544128)===u)if(e.stateNode.complete)e.flags|=8192;else if(jp())e.flags|=8192;else throw Is=Ol,Gu}else e.flags&=-16777217}function Rp(e,n){if(n.type!=="stylesheet"||(n.state.loading&4)!==0)e.flags&=-16777217;else if(e.flags|=16777216,!YT(n))if(jp())e.flags|=8192;else throw Is=Ol,Gu}function Kl(e,n){n!==null&&(e.flags|=4),e.flags&16384&&(n=e.tag!==22?At():536870912,e.lanes|=n,_r|=n)}function yo(e,n){if(!ve)switch(e.tailMode){case"hidden":n=e.tail;for(var a=null;n!==null;)n.alternate!==null&&(a=n),n=n.sibling;a===null?e.tail=null:a.sibling=null;break;case"collapsed":a=e.tail;for(var o=null;a!==null;)a.alternate!==null&&(o=a),a=a.sibling;o===null?n||e.tail===null?e.tail=null:e.tail.sibling=null:o.sibling=null}}function Ze(e){var n=e.alternate!==null&&e.alternate.child===e.child,a=0,o=0;if(n)for(var u=e.child;u!==null;)a|=u.lanes|u.childLanes,o|=u.subtreeFlags&65011712,o|=u.flags&65011712,u.return=e,u=u.sibling;else for(u=e.child;u!==null;)a|=u.lanes|u.childLanes,o|=u.subtreeFlags,o|=u.flags,u.return=e,u=u.sibling;return e.subtreeFlags|=o,e.childLanes=a,n}function cg(e,n,a){var o=n.pendingProps;switch(Lu(n),n.tag){case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return Ze(n),null;case 1:return Ze(n),null;case 3:return a=n.stateNode,o=null,e!==null&&(o=e.memoizedState.cache),n.memoizedState.cache!==o&&(n.flags|=2048),ca(fn),Pt(),a.pendingContext&&(a.context=a.pendingContext,a.pendingContext=null),(e===null||e.child===null)&&(or(n)?da(n):e===null||e.memoizedState.isDehydrated&&(n.flags&256)===0||(n.flags|=1024,Fu())),Ze(n),null;case 26:var u=n.type,d=n.memoizedState;return e===null?(da(n),d!==null?(Ze(n),Rp(n,d)):(Ze(n),Rf(n,u,null,o,a))):d?d!==e.memoizedState?(da(n),Ze(n),Rp(n,d)):(Ze(n),n.flags&=-16777217):(e=e.memoizedProps,e!==o&&da(n),Ze(n),Rf(n,u,e,o,a)),null;case 27:if(Qt(n),a=rt.current,u=n.type,e!==null&&n.stateNode!=null)e.memoizedProps!==o&&da(n);else{if(!o){if(n.stateNode===null)throw Error(s(166));return Ze(n),null}e=gt.current,or(n)?s1(n):(e=LT(u,o,a),n.stateNode=e,da(n))}return Ze(n),null;case 5:if(Qt(n),u=n.type,e!==null&&n.stateNode!=null)e.memoizedProps!==o&&da(n);else{if(!o){if(n.stateNode===null)throw Error(s(166));return Ze(n),null}if(d=gt.current,or(n))s1(n);else{var _=lc(rt.current);switch(d){case 1:d=_.createElementNS("http://www.w3.org/2000/svg",u);break;case 2:d=_.createElementNS("http://www.w3.org/1998/Math/MathML",u);break;default:switch(u){case"svg":d=_.createElementNS("http://www.w3.org/2000/svg",u);break;case"math":d=_.createElementNS("http://www.w3.org/1998/Math/MathML",u);break;case"script":d=_.createElement("div"),d.innerHTML="<script><\/script>",d=d.removeChild(d.firstChild);break;case"select":d=typeof o.is=="string"?_.createElement("select",{is:o.is}):_.createElement("select"),o.multiple?d.multiple=!0:o.size&&(d.size=o.size);break;default:d=typeof o.is=="string"?_.createElement(u,{is:o.is}):_.createElement(u)}}d[rn]=n,d[Rn]=o;t:for(_=n.child;_!==null;){if(_.tag===5||_.tag===6)d.appendChild(_.stateNode);else if(_.tag!==4&&_.tag!==27&&_.child!==null){_.child.return=_,_=_.child;continue}if(_===n)break t;for(;_.sibling===null;){if(_.return===null||_.return===n)break t;_=_.return}_.sibling.return=_.return,_=_.sibling}n.stateNode=d;t:switch(On(d,u,o),u){case"button":case"input":case"select":case"textarea":o=!!o.autoFocus;break t;case"img":o=!0;break t;default:o=!1}o&&da(n)}}return Ze(n),Rf(n,n.type,e===null?null:e.memoizedProps,n.pendingProps,a),null;case 6:if(e&&n.stateNode!=null)e.memoizedProps!==o&&da(n);else{if(typeof o!="string"&&n.stateNode===null)throw Error(s(166));if(e=rt.current,or(n)){if(e=n.stateNode,a=n.memoizedProps,o=null,u=Cn,u!==null)switch(u.tag){case 27:case 5:o=u.memoizedProps}e[rn]=n,e=!!(e.nodeValue===a||o!==null&&o.suppressHydrationWarning===!0||AT(e.nodeValue,a)),e||Ga(n,!0)}else e=lc(e).createTextNode(o),e[rn]=n,n.stateNode=e}return Ze(n),null;case 31:if(a=n.memoizedState,e===null||e.memoizedState!==null){if(o=or(n),a!==null){if(e===null){if(!o)throw Error(s(318));if(e=n.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(s(557));e[rn]=n}else Cs(),(n.flags&128)===0&&(n.memoizedState=null),n.flags|=4;Ze(n),e=!1}else a=Fu(),e!==null&&e.memoizedState!==null&&(e.memoizedState.hydrationErrors=a),e=!0;if(!e)return n.flags&256?(oi(n),n):(oi(n),null);if((n.flags&128)!==0)throw Error(s(558))}return Ze(n),null;case 13:if(o=n.memoizedState,e===null||e.memoizedState!==null&&e.memoizedState.dehydrated!==null){if(u=or(n),o!==null&&o.dehydrated!==null){if(e===null){if(!u)throw Error(s(318));if(u=n.memoizedState,u=u!==null?u.dehydrated:null,!u)throw Error(s(317));u[rn]=n}else Cs(),(n.flags&128)===0&&(n.memoizedState=null),n.flags|=4;Ze(n),u=!1}else u=Fu(),e!==null&&e.memoizedState!==null&&(e.memoizedState.hydrationErrors=u),u=!0;if(!u)return n.flags&256?(oi(n),n):(oi(n),null)}return oi(n),(n.flags&128)!==0?(n.lanes=a,n):(a=o!==null,e=e!==null&&e.memoizedState!==null,a&&(o=n.child,u=null,o.alternate!==null&&o.alternate.memoizedState!==null&&o.alternate.memoizedState.cachePool!==null&&(u=o.alternate.memoizedState.cachePool.pool),d=null,o.memoizedState!==null&&o.memoizedState.cachePool!==null&&(d=o.memoizedState.cachePool.pool),d!==u&&(o.flags|=2048)),a!==e&&a&&(n.child.flags|=8192),Kl(n,n.updateQueue),Ze(n),null);case 4:return Pt(),e===null&&Zf(n.stateNode.containerInfo),Ze(n),null;case 10:return ca(n.type),Ze(n),null;case 19:if(V(on),o=n.memoizedState,o===null)return Ze(n),null;if(u=(n.flags&128)!==0,d=o.rendering,d===null)if(u)yo(o,!1);else{if(nn!==0||e!==null&&(e.flags&128)!==0)for(e=n.child;e!==null;){if(d=Ul(e),d!==null){for(n.flags|=128,yo(o,!1),e=d.updateQueue,n.updateQueue=e,Kl(n,e),n.subtreeFlags=0,e=a,a=n.child;a!==null;)t1(a,e),a=a.sibling;return dt(on,on.current&1|2),ve&&oa(n,o.treeForkCount),n.child}e=e.sibling}o.tail!==null&&Ct()>jl&&(n.flags|=128,u=!0,yo(o,!1),n.lanes=4194304)}else{if(!u)if(e=Ul(d),e!==null){if(n.flags|=128,u=!0,e=e.updateQueue,n.updateQueue=e,Kl(n,e),yo(o,!0),o.tail===null&&o.tailMode==="hidden"&&!d.alternate&&!ve)return Ze(n),null}else 2*Ct()-o.renderingStartTime>jl&&a!==536870912&&(n.flags|=128,u=!0,yo(o,!1),n.lanes=4194304);o.isBackwards?(d.sibling=n.child,n.child=d):(e=o.last,e!==null?e.sibling=d:n.child=d,o.last=d)}return o.tail!==null?(e=o.tail,o.rendering=e,o.tail=e.sibling,o.renderingStartTime=Ct(),e.sibling=null,a=on.current,dt(on,u?a&1|2:a&1),ve&&oa(n,o.treeForkCount),e):(Ze(n),null);case 22:case 23:return oi(n),Zu(),o=n.memoizedState!==null,e!==null?e.memoizedState!==null!==o&&(n.flags|=8192):o&&(n.flags|=8192),o?(a&536870912)!==0&&(n.flags&128)===0&&(Ze(n),n.subtreeFlags&6&&(n.flags|=8192)):Ze(n),a=n.updateQueue,a!==null&&Kl(n,a.retryQueue),a=null,e!==null&&e.memoizedState!==null&&e.memoizedState.cachePool!==null&&(a=e.memoizedState.cachePool.pool),o=null,n.memoizedState!==null&&n.memoizedState.cachePool!==null&&(o=n.memoizedState.cachePool.pool),o!==a&&(n.flags|=2048),e!==null&&V(Os),null;case 24:return a=null,e!==null&&(a=e.memoizedState.cache),n.memoizedState.cache!==a&&(n.flags|=2048),ca(fn),Ze(n),null;case 25:return null;case 30:return null}throw Error(s(156,n.tag))}function ug(e,n){switch(Lu(n),n.tag){case 1:return e=n.flags,e&65536?(n.flags=e&-65537|128,n):null;case 3:return ca(fn),Pt(),e=n.flags,(e&65536)!==0&&(e&128)===0?(n.flags=e&-65537|128,n):null;case 26:case 27:case 5:return Qt(n),null;case 31:if(n.memoizedState!==null){if(oi(n),n.alternate===null)throw Error(s(340));Cs()}return e=n.flags,e&65536?(n.flags=e&-65537|128,n):null;case 13:if(oi(n),e=n.memoizedState,e!==null&&e.dehydrated!==null){if(n.alternate===null)throw Error(s(340));Cs()}return e=n.flags,e&65536?(n.flags=e&-65537|128,n):null;case 19:return V(on),null;case 4:return Pt(),null;case 10:return ca(n.type),null;case 22:case 23:return oi(n),Zu(),e!==null&&V(Os),e=n.flags,e&65536?(n.flags=e&-65537|128,n):null;case 24:return ca(fn),null;case 25:return null;default:return null}}function Cp(e,n){switch(Lu(n),n.tag){case 3:ca(fn),Pt();break;case 26:case 27:case 5:Qt(n);break;case 4:Pt();break;case 31:n.memoizedState!==null&&oi(n);break;case 13:oi(n);break;case 19:V(on);break;case 10:ca(n.type);break;case 22:case 23:oi(n),Zu(),e!==null&&V(Os);break;case 24:ca(fn)}}function Do(e,n){try{var a=n.updateQueue,o=a!==null?a.lastEffect:null;if(o!==null){var u=o.next;a=u;do{if((a.tag&e)===e){o=void 0;var d=a.create,_=a.inst;o=d(),_.destroy=o}a=a.next}while(a!==u)}}catch(y){Be(n,n.return,y)}}function qa(e,n,a){try{var o=n.updateQueue,u=o!==null?o.lastEffect:null;if(u!==null){var d=u.next;o=d;do{if((o.tag&e)===e){var _=o.inst,y=_.destroy;if(y!==void 0){_.destroy=void 0,u=n;var X=a,J=y;try{J()}catch(pt){Be(u,X,pt)}}}o=o.next}while(o!==d)}}catch(pt){Be(n,n.return,pt)}}function yp(e){var n=e.updateQueue;if(n!==null){var a=e.stateNode;try{S1(n,a)}catch(o){Be(e,e.return,o)}}}function Dp(e,n,a){a.props=Fs(e.type,e.memoizedProps),a.state=e.memoizedState;try{a.componentWillUnmount()}catch(o){Be(e,n,o)}}function Oo(e,n){try{var a=e.ref;if(a!==null){switch(e.tag){case 26:case 27:case 5:var o=e.stateNode;break;case 30:o=e.stateNode;break;default:o=e.stateNode}typeof a=="function"?e.refCleanup=a(o):a.current=o}}catch(u){Be(e,n,u)}}function Yi(e,n){var a=e.ref,o=e.refCleanup;if(a!==null)if(typeof o=="function")try{o()}catch(u){Be(e,n,u)}finally{e.refCleanup=null,e=e.alternate,e!=null&&(e.refCleanup=null)}else if(typeof a=="function")try{a(null)}catch(u){Be(e,n,u)}else a.current=null}function Op(e){var n=e.type,a=e.memoizedProps,o=e.stateNode;try{t:switch(n){case"button":case"input":case"select":case"textarea":a.autoFocus&&o.focus();break t;case"img":a.src?o.src=a.src:a.srcSet&&(o.srcset=a.srcSet)}}catch(u){Be(e,e.return,u)}}function Cf(e,n,a){try{var o=e.stateNode;Ig(o,e.type,a,n),o[Rn]=n}catch(u){Be(e,e.return,u)}}function bp(e){return e.tag===5||e.tag===3||e.tag===26||e.tag===27&&ns(e.type)||e.tag===4}function yf(e){t:for(;;){for(;e.sibling===null;){if(e.return===null||bp(e.return))return null;e=e.return}for(e.sibling.return=e.return,e=e.sibling;e.tag!==5&&e.tag!==6&&e.tag!==18;){if(e.tag===27&&ns(e.type)||e.flags&2||e.child===null||e.tag===4)continue t;e.child.return=e,e=e.child}if(!(e.flags&2))return e.stateNode}}function Df(e,n,a){var o=e.tag;if(o===5||o===6)e=e.stateNode,n?(a.nodeType===9?a.body:a.nodeName==="HTML"?a.ownerDocument.body:a).insertBefore(e,n):(n=a.nodeType===9?a.body:a.nodeName==="HTML"?a.ownerDocument.body:a,n.appendChild(e),a=a._reactRootContainer,a!=null||n.onclick!==null||(n.onclick=aa));else if(o!==4&&(o===27&&ns(e.type)&&(a=e.stateNode,n=null),e=e.child,e!==null))for(Df(e,n,a),e=e.sibling;e!==null;)Df(e,n,a),e=e.sibling}function Zl(e,n,a){var o=e.tag;if(o===5||o===6)e=e.stateNode,n?a.insertBefore(e,n):a.appendChild(e);else if(o!==4&&(o===27&&ns(e.type)&&(a=e.stateNode),e=e.child,e!==null))for(Zl(e,n,a),e=e.sibling;e!==null;)Zl(e,n,a),e=e.sibling}function Ip(e){var n=e.stateNode,a=e.memoizedProps;try{for(var o=e.type,u=n.attributes;u.length;)n.removeAttributeNode(u[0]);On(n,o,a),n[rn]=e,n[Rn]=a}catch(d){Be(e,e.return,d)}}var pa=!1,pn=!1,Of=!1,Lp=typeof WeakSet=="function"?WeakSet:Set,An=null;function fg(e,n){if(e=e.containerInfo,Qf=Tc,e=W0(e),Au(e)){if("selectionStart"in e)var a={start:e.selectionStart,end:e.selectionEnd};else t:{a=(a=e.ownerDocument)&&a.defaultView||window;var o=a.getSelection&&a.getSelection();if(o&&o.rangeCount!==0){a=o.anchorNode;var u=o.anchorOffset,d=o.focusNode;o=o.focusOffset;try{a.nodeType,d.nodeType}catch{a=null;break t}var _=0,y=-1,X=-1,J=0,pt=0,_t=e,st=null;e:for(;;){for(var ot;_t!==a||u!==0&&_t.nodeType!==3||(y=_+u),_t!==d||o!==0&&_t.nodeType!==3||(X=_+o),_t.nodeType===3&&(_+=_t.nodeValue.length),(ot=_t.firstChild)!==null;)st=_t,_t=ot;for(;;){if(_t===e)break e;if(st===a&&++J===u&&(y=_),st===d&&++pt===o&&(X=_),(ot=_t.nextSibling)!==null)break;_t=st,st=_t.parentNode}_t=ot}a=y===-1||X===-1?null:{start:y,end:X}}else a=null}a=a||{start:0,end:0}}else a=null;for(jf={focusedElem:e,selectionRange:a},Tc=!1,An=n;An!==null;)if(n=An,e=n.child,(n.subtreeFlags&1028)!==0&&e!==null)e.return=n,An=e;else for(;An!==null;){switch(n=An,d=n.alternate,e=n.flags,n.tag){case 0:if((e&4)!==0&&(e=n.updateQueue,e=e!==null?e.events:null,e!==null))for(a=0;a<e.length;a++)u=e[a],u.ref.impl=u.nextImpl;break;case 11:case 15:break;case 1:if((e&1024)!==0&&d!==null){e=void 0,a=n,u=d.memoizedProps,d=d.memoizedState,o=a.stateNode;try{var Vt=Fs(a.type,u);e=o.getSnapshotBeforeUpdate(Vt,d),o.__reactInternalSnapshotBeforeUpdate=e}catch(jt){Be(a,a.return,jt)}}break;case 3:if((e&1024)!==0){if(e=n.stateNode.containerInfo,a=e.nodeType,a===9)eh(e);else if(a===1)switch(e.nodeName){case"HEAD":case"HTML":case"BODY":eh(e);break;default:e.textContent=""}}break;case 5:case 26:case 27:case 6:case 4:case 17:break;default:if((e&1024)!==0)throw Error(s(163))}if(e=n.sibling,e!==null){e.return=n.return,An=e;break}An=n.return}}function Up(e,n,a){var o=a.flags;switch(a.tag){case 0:case 11:case 15:ma(e,a),o&4&&Do(5,a);break;case 1:if(ma(e,a),o&4)if(e=a.stateNode,n===null)try{e.componentDidMount()}catch(_){Be(a,a.return,_)}else{var u=Fs(a.type,n.memoizedProps);n=n.memoizedState;try{e.componentDidUpdate(u,n,e.__reactInternalSnapshotBeforeUpdate)}catch(_){Be(a,a.return,_)}}o&64&&yp(a),o&512&&Oo(a,a.return);break;case 3:if(ma(e,a),o&64&&(e=a.updateQueue,e!==null)){if(n=null,a.child!==null)switch(a.child.tag){case 27:case 5:n=a.child.stateNode;break;case 1:n=a.child.stateNode}try{S1(e,n)}catch(_){Be(a,a.return,_)}}break;case 27:n===null&&o&4&&Ip(a);case 26:case 5:ma(e,a),n===null&&o&4&&Op(a),o&512&&Oo(a,a.return);break;case 12:ma(e,a);break;case 31:ma(e,a),o&4&&Bp(e,a);break;case 13:ma(e,a),o&4&&Xp(e,a),o&64&&(e=a.memoizedState,e!==null&&(e=e.dehydrated,e!==null&&(a=_g.bind(null,a),Hg(e,a))));break;case 22:if(o=a.memoizedState!==null||pa,!o){n=n!==null&&n.memoizedState!==null||pn,u=pa;var d=pn;pa=o,(pn=n)&&!d?Ea(e,a,(a.subtreeFlags&8772)!==0):ma(e,a),pa=u,pn=d}break;case 30:break;default:ma(e,a)}}function Fp(e){var n=e.alternate;n!==null&&(e.alternate=null,Fp(n)),e.child=null,e.deletions=null,e.sibling=null,e.tag===5&&(n=e.stateNode,n!==null&&io(n)),e.stateNode=null,e.return=null,e.dependencies=null,e.memoizedProps=null,e.memoizedState=null,e.pendingProps=null,e.stateNode=null,e.updateQueue=null}var je=null,Wn=!1;function Ta(e,n,a){for(a=a.child;a!==null;)wp(e,n,a),a=a.sibling}function wp(e,n,a){if(ht&&typeof ht.onCommitFiberUnmount=="function")try{ht.onCommitFiberUnmount(ut,a)}catch{}switch(a.tag){case 26:pn||Yi(a,n),Ta(e,n,a),a.memoizedState?a.memoizedState.count--:a.stateNode&&(a=a.stateNode,a.parentNode.removeChild(a));break;case 27:pn||Yi(a,n);var o=je,u=Wn;ns(a.type)&&(je=a.stateNode,Wn=!1),Ta(e,n,a),Po(a.stateNode),je=o,Wn=u;break;case 5:pn||Yi(a,n);case 6:if(o=je,u=Wn,je=null,Ta(e,n,a),je=o,Wn=u,je!==null)if(Wn)try{(je.nodeType===9?je.body:je.nodeName==="HTML"?je.ownerDocument.body:je).removeChild(a.stateNode)}catch(d){Be(a,n,d)}else try{je.removeChild(a.stateNode)}catch(d){Be(a,n,d)}break;case 18:je!==null&&(Wn?(e=je,yT(e.nodeType===9?e.body:e.nodeName==="HTML"?e.ownerDocument.body:e,a.stateNode),yr(e)):yT(je,a.stateNode));break;case 4:o=je,u=Wn,je=a.stateNode.containerInfo,Wn=!0,Ta(e,n,a),je=o,Wn=u;break;case 0:case 11:case 14:case 15:qa(2,a,n),pn||qa(4,a,n),Ta(e,n,a);break;case 1:pn||(Yi(a,n),o=a.stateNode,typeof o.componentWillUnmount=="function"&&Dp(a,n,o)),Ta(e,n,a);break;case 21:Ta(e,n,a);break;case 22:pn=(o=pn)||a.memoizedState!==null,Ta(e,n,a),pn=o;break;default:Ta(e,n,a)}}function Bp(e,n){if(n.memoizedState===null&&(e=n.alternate,e!==null&&(e=e.memoizedState,e!==null))){e=e.dehydrated;try{yr(e)}catch(a){Be(n,n.return,a)}}}function Xp(e,n){if(n.memoizedState===null&&(e=n.alternate,e!==null&&(e=e.memoizedState,e!==null&&(e=e.dehydrated,e!==null))))try{yr(e)}catch(a){Be(n,n.return,a)}}function hg(e){switch(e.tag){case 31:case 13:case 19:var n=e.stateNode;return n===null&&(n=e.stateNode=new Lp),n;case 22:return e=e.stateNode,n=e._retryCache,n===null&&(n=e._retryCache=new Lp),n;default:throw Error(s(435,e.tag))}}function ql(e,n){var a=hg(e);n.forEach(function(o){if(!a.has(o)){a.add(o);var u=vg.bind(null,e,o);o.then(u,u)}})}function kn(e,n){var a=n.deletions;if(a!==null)for(var o=0;o<a.length;o++){var u=a[o],d=e,_=n,y=_;t:for(;y!==null;){switch(y.tag){case 27:if(ns(y.type)){je=y.stateNode,Wn=!1;break t}break;case 5:je=y.stateNode,Wn=!1;break t;case 3:case 4:je=y.stateNode.containerInfo,Wn=!0;break t}y=y.return}if(je===null)throw Error(s(160));wp(d,_,u),je=null,Wn=!1,d=u.alternate,d!==null&&(d.return=null),u.return=null}if(n.subtreeFlags&13886)for(n=n.child;n!==null;)Pp(n,e),n=n.sibling}var yi=null;function Pp(e,n){var a=e.alternate,o=e.flags;switch(e.tag){case 0:case 11:case 14:case 15:kn(n,e),Kn(e),o&4&&(qa(3,e,e.return),Do(3,e),qa(5,e,e.return));break;case 1:kn(n,e),Kn(e),o&512&&(pn||a===null||Yi(a,a.return)),o&64&&pa&&(e=e.updateQueue,e!==null&&(o=e.callbacks,o!==null&&(a=e.shared.hiddenCallbacks,e.shared.hiddenCallbacks=a===null?o:a.concat(o))));break;case 26:var u=yi;if(kn(n,e),Kn(e),o&512&&(pn||a===null||Yi(a,a.return)),o&4){var d=a!==null?a.memoizedState:null;if(o=e.memoizedState,a===null)if(o===null)if(e.stateNode===null){t:{o=e.type,a=e.memoizedProps,u=u.ownerDocument||u;e:switch(o){case"title":d=u.getElementsByTagName("title")[0],(!d||d[Ua]||d[rn]||d.namespaceURI==="http://www.w3.org/2000/svg"||d.hasAttribute("itemprop"))&&(d=u.createElement(o),u.head.insertBefore(d,u.querySelector("head > title"))),On(d,o,a),d[rn]=e,un(d),o=d;break t;case"link":var _=PT("link","href",u).get(o+(a.href||""));if(_){for(var y=0;y<_.length;y++)if(d=_[y],d.getAttribute("href")===(a.href==null||a.href===""?null:a.href)&&d.getAttribute("rel")===(a.rel==null?null:a.rel)&&d.getAttribute("title")===(a.title==null?null:a.title)&&d.getAttribute("crossorigin")===(a.crossOrigin==null?null:a.crossOrigin)){_.splice(y,1);break e}}d=u.createElement(o),On(d,o,a),u.head.appendChild(d);break;case"meta":if(_=PT("meta","content",u).get(o+(a.content||""))){for(y=0;y<_.length;y++)if(d=_[y],d.getAttribute("content")===(a.content==null?null:""+a.content)&&d.getAttribute("name")===(a.name==null?null:a.name)&&d.getAttribute("property")===(a.property==null?null:a.property)&&d.getAttribute("http-equiv")===(a.httpEquiv==null?null:a.httpEquiv)&&d.getAttribute("charset")===(a.charSet==null?null:a.charSet)){_.splice(y,1);break e}}d=u.createElement(o),On(d,o,a),u.head.appendChild(d);break;default:throw Error(s(468,o))}d[rn]=e,un(d),o=d}e.stateNode=o}else HT(u,e.type,e.stateNode);else e.stateNode=XT(u,o,e.memoizedProps);else d!==o?(d===null?a.stateNode!==null&&(a=a.stateNode,a.parentNode.removeChild(a)):d.count--,o===null?HT(u,e.type,e.stateNode):XT(u,o,e.memoizedProps)):o===null&&e.stateNode!==null&&Cf(e,e.memoizedProps,a.memoizedProps)}break;case 27:kn(n,e),Kn(e),o&512&&(pn||a===null||Yi(a,a.return)),a!==null&&o&4&&Cf(e,e.memoizedProps,a.memoizedProps);break;case 5:if(kn(n,e),Kn(e),o&512&&(pn||a===null||Yi(a,a.return)),e.flags&32){u=e.stateNode;try{ii(u,"")}catch(Vt){Be(e,e.return,Vt)}}o&4&&e.stateNode!=null&&(u=e.memoizedProps,Cf(e,u,a!==null?a.memoizedProps:u)),o&1024&&(Of=!0);break;case 6:if(kn(n,e),Kn(e),o&4){if(e.stateNode===null)throw Error(s(162));o=e.memoizedProps,a=e.stateNode;try{a.nodeValue=o}catch(Vt){Be(e,e.return,Vt)}}break;case 3:if(fc=null,u=yi,yi=cc(n.containerInfo),kn(n,e),yi=u,Kn(e),o&4&&a!==null&&a.memoizedState.isDehydrated)try{yr(n.containerInfo)}catch(Vt){Be(e,e.return,Vt)}Of&&(Of=!1,Hp(e));break;case 4:o=yi,yi=cc(e.stateNode.containerInfo),kn(n,e),Kn(e),yi=o;break;case 12:kn(n,e),Kn(e);break;case 31:kn(n,e),Kn(e),o&4&&(o=e.updateQueue,o!==null&&(e.updateQueue=null,ql(e,o)));break;case 13:kn(n,e),Kn(e),e.child.flags&8192&&e.memoizedState!==null!=(a!==null&&a.memoizedState!==null)&&(Ql=Ct()),o&4&&(o=e.updateQueue,o!==null&&(e.updateQueue=null,ql(e,o)));break;case 22:u=e.memoizedState!==null;var X=a!==null&&a.memoizedState!==null,J=pa,pt=pn;if(pa=J||u,pn=pt||X,kn(n,e),pn=pt,pa=J,Kn(e),o&8192)t:for(n=e.stateNode,n._visibility=u?n._visibility&-2:n._visibility|1,u&&(a===null||X||pa||pn||ws(e)),a=null,n=e;;){if(n.tag===5||n.tag===26){if(a===null){X=a=n;try{if(d=X.stateNode,u)_=d.style,typeof _.setProperty=="function"?_.setProperty("display","none","important"):_.display="none";else{y=X.stateNode;var _t=X.memoizedProps.style,st=_t!=null&&_t.hasOwnProperty("display")?_t.display:null;y.style.display=st==null||typeof st=="boolean"?"":(""+st).trim()}}catch(Vt){Be(X,X.return,Vt)}}}else if(n.tag===6){if(a===null){X=n;try{X.stateNode.nodeValue=u?"":X.memoizedProps}catch(Vt){Be(X,X.return,Vt)}}}else if(n.tag===18){if(a===null){X=n;try{var ot=X.stateNode;u?DT(ot,!0):DT(X.stateNode,!1)}catch(Vt){Be(X,X.return,Vt)}}}else if((n.tag!==22&&n.tag!==23||n.memoizedState===null||n===e)&&n.child!==null){n.child.return=n,n=n.child;continue}if(n===e)break t;for(;n.sibling===null;){if(n.return===null||n.return===e)break t;a===n&&(a=null),n=n.return}a===n&&(a=null),n.sibling.return=n.return,n=n.sibling}o&4&&(o=e.updateQueue,o!==null&&(a=o.retryQueue,a!==null&&(o.retryQueue=null,ql(e,a))));break;case 19:kn(n,e),Kn(e),o&4&&(o=e.updateQueue,o!==null&&(e.updateQueue=null,ql(e,o)));break;case 30:break;case 21:break;default:kn(n,e),Kn(e)}}function Kn(e){var n=e.flags;if(n&2){try{for(var a,o=e.return;o!==null;){if(bp(o)){a=o;break}o=o.return}if(a==null)throw Error(s(160));switch(a.tag){case 27:var u=a.stateNode,d=yf(e);Zl(e,d,u);break;case 5:var _=a.stateNode;a.flags&32&&(ii(_,""),a.flags&=-33);var y=yf(e);Zl(e,y,_);break;case 3:case 4:var X=a.stateNode.containerInfo,J=yf(e);Df(e,J,X);break;default:throw Error(s(161))}}catch(pt){Be(e,e.return,pt)}e.flags&=-3}n&4096&&(e.flags&=-4097)}function Hp(e){if(e.subtreeFlags&1024)for(e=e.child;e!==null;){var n=e;Hp(n),n.tag===5&&n.flags&1024&&n.stateNode.reset(),e=e.sibling}}function ma(e,n){if(n.subtreeFlags&8772)for(n=n.child;n!==null;)Up(e,n.alternate,n),n=n.sibling}function ws(e){for(e=e.child;e!==null;){var n=e;switch(n.tag){case 0:case 11:case 14:case 15:qa(4,n,n.return),ws(n);break;case 1:Yi(n,n.return);var a=n.stateNode;typeof a.componentWillUnmount=="function"&&Dp(n,n.return,a),ws(n);break;case 27:Po(n.stateNode);case 26:case 5:Yi(n,n.return),ws(n);break;case 22:n.memoizedState===null&&ws(n);break;case 30:ws(n);break;default:ws(n)}e=e.sibling}}function Ea(e,n,a){for(a=a&&(n.subtreeFlags&8772)!==0,n=n.child;n!==null;){var o=n.alternate,u=e,d=n,_=d.flags;switch(d.tag){case 0:case 11:case 15:Ea(u,d,a),Do(4,d);break;case 1:if(Ea(u,d,a),o=d,u=o.stateNode,typeof u.componentDidMount=="function")try{u.componentDidMount()}catch(J){Be(o,o.return,J)}if(o=d,u=o.updateQueue,u!==null){var y=o.stateNode;try{var X=u.shared.hiddenCallbacks;if(X!==null)for(u.shared.hiddenCallbacks=null,u=0;u<X.length;u++)E1(X[u],y)}catch(J){Be(o,o.return,J)}}a&&_&64&&yp(d),Oo(d,d.return);break;case 27:Ip(d);case 26:case 5:Ea(u,d,a),a&&o===null&&_&4&&Op(d),Oo(d,d.return);break;case 12:Ea(u,d,a);break;case 31:Ea(u,d,a),a&&_&4&&Bp(u,d);break;case 13:Ea(u,d,a),a&&_&4&&Xp(u,d);break;case 22:d.memoizedState===null&&Ea(u,d,a),Oo(d,d.return);break;case 30:break;default:Ea(u,d,a)}n=n.sibling}}function bf(e,n){var a=null;e!==null&&e.memoizedState!==null&&e.memoizedState.cachePool!==null&&(a=e.memoizedState.cachePool.pool),e=null,n.memoizedState!==null&&n.memoizedState.cachePool!==null&&(e=n.memoizedState.cachePool.pool),e!==a&&(e!=null&&e.refCount++,a!=null&&mo(a))}function If(e,n){e=null,n.alternate!==null&&(e=n.alternate.memoizedState.cache),n=n.memoizedState.cache,n!==e&&(n.refCount++,e!=null&&mo(e))}function Di(e,n,a,o){if(n.subtreeFlags&10256)for(n=n.child;n!==null;)Yp(e,n,a,o),n=n.sibling}function Yp(e,n,a,o){var u=n.flags;switch(n.tag){case 0:case 11:case 15:Di(e,n,a,o),u&2048&&Do(9,n);break;case 1:Di(e,n,a,o);break;case 3:Di(e,n,a,o),u&2048&&(e=null,n.alternate!==null&&(e=n.alternate.memoizedState.cache),n=n.memoizedState.cache,n!==e&&(n.refCount++,e!=null&&mo(e)));break;case 12:if(u&2048){Di(e,n,a,o),e=n.stateNode;try{var d=n.memoizedProps,_=d.id,y=d.onPostCommit;typeof y=="function"&&y(_,n.alternate===null?"mount":"update",e.passiveEffectDuration,-0)}catch(X){Be(n,n.return,X)}}else Di(e,n,a,o);break;case 31:Di(e,n,a,o);break;case 13:Di(e,n,a,o);break;case 23:break;case 22:d=n.stateNode,_=n.alternate,n.memoizedState!==null?d._visibility&2?Di(e,n,a,o):bo(e,n):d._visibility&2?Di(e,n,a,o):(d._visibility|=2,Er(e,n,a,o,(n.subtreeFlags&10256)!==0||!1)),u&2048&&bf(_,n);break;case 24:Di(e,n,a,o),u&2048&&If(n.alternate,n);break;default:Di(e,n,a,o)}}function Er(e,n,a,o,u){for(u=u&&((n.subtreeFlags&10256)!==0||!1),n=n.child;n!==null;){var d=e,_=n,y=a,X=o,J=_.flags;switch(_.tag){case 0:case 11:case 15:Er(d,_,y,X,u),Do(8,_);break;case 23:break;case 22:var pt=_.stateNode;_.memoizedState!==null?pt._visibility&2?Er(d,_,y,X,u):bo(d,_):(pt._visibility|=2,Er(d,_,y,X,u)),u&&J&2048&&bf(_.alternate,_);break;case 24:Er(d,_,y,X,u),u&&J&2048&&If(_.alternate,_);break;default:Er(d,_,y,X,u)}n=n.sibling}}function bo(e,n){if(n.subtreeFlags&10256)for(n=n.child;n!==null;){var a=e,o=n,u=o.flags;switch(o.tag){case 22:bo(a,o),u&2048&&bf(o.alternate,o);break;case 24:bo(a,o),u&2048&&If(o.alternate,o);break;default:bo(a,o)}n=n.sibling}}var Io=8192;function Sr(e,n,a){if(e.subtreeFlags&Io)for(e=e.child;e!==null;)Gp(e,n,a),e=e.sibling}function Gp(e,n,a){switch(e.tag){case 26:Sr(e,n,a),e.flags&Io&&e.memoizedState!==null&&jg(a,yi,e.memoizedState,e.memoizedProps);break;case 5:Sr(e,n,a);break;case 3:case 4:var o=yi;yi=cc(e.stateNode.containerInfo),Sr(e,n,a),yi=o;break;case 22:e.memoizedState===null&&(o=e.alternate,o!==null&&o.memoizedState!==null?(o=Io,Io=16777216,Sr(e,n,a),Io=o):Sr(e,n,a));break;default:Sr(e,n,a)}}function zp(e){var n=e.alternate;if(n!==null&&(e=n.child,e!==null)){n.child=null;do n=e.sibling,e.sibling=null,e=n;while(e!==null)}}function Lo(e){var n=e.deletions;if((e.flags&16)!==0){if(n!==null)for(var a=0;a<n.length;a++){var o=n[a];An=o,Wp(o,e)}zp(e)}if(e.subtreeFlags&10256)for(e=e.child;e!==null;)Vp(e),e=e.sibling}function Vp(e){switch(e.tag){case 0:case 11:case 15:Lo(e),e.flags&2048&&qa(9,e,e.return);break;case 3:Lo(e);break;case 12:Lo(e);break;case 22:var n=e.stateNode;e.memoizedState!==null&&n._visibility&2&&(e.return===null||e.return.tag!==13)?(n._visibility&=-3,$l(e)):Lo(e);break;default:Lo(e)}}function $l(e){var n=e.deletions;if((e.flags&16)!==0){if(n!==null)for(var a=0;a<n.length;a++){var o=n[a];An=o,Wp(o,e)}zp(e)}for(e=e.child;e!==null;){switch(n=e,n.tag){case 0:case 11:case 15:qa(8,n,n.return),$l(n);break;case 22:a=n.stateNode,a._visibility&2&&(a._visibility&=-3,$l(n));break;default:$l(n)}e=e.sibling}}function Wp(e,n){for(;An!==null;){var a=An;switch(a.tag){case 0:case 11:case 15:qa(8,a,n);break;case 23:case 22:if(a.memoizedState!==null&&a.memoizedState.cachePool!==null){var o=a.memoizedState.cachePool.pool;o!=null&&o.refCount++}break;case 24:mo(a.memoizedState.cache)}if(o=a.child,o!==null)o.return=a,An=o;else t:for(a=e;An!==null;){o=An;var u=o.sibling,d=o.return;if(Fp(o),o===a){An=null;break t}if(u!==null){u.return=d,An=u;break t}An=d}}}var dg={getCacheForType:function(e){var n=yn(fn),a=n.data.get(e);return a===void 0&&(a=e(),n.data.set(e,a)),a},cacheSignal:function(){return yn(fn).controller.signal}},pg=typeof WeakMap=="function"?WeakMap:Map,De=0,We=null,Te=null,Se=0,we=0,li=null,$a=!1,gr=!1,Lf=!1,Sa=0,nn=0,Qa=0,Bs=0,Uf=0,ci=0,_r=0,Uo=null,Zn=null,Ff=!1,Ql=0,kp=0,jl=1/0,Jl=null,ja=null,En=0,Ja=null,vr=null,ga=0,wf=0,Bf=null,Kp=null,Fo=0,Xf=null;function ui(){return(De&2)!==0&&Se!==0?Se&-Se:L.T!==null?Vf():to()}function Zp(){if(ci===0)if((Se&536870912)===0||ve){var e=de;de<<=1,(de&3932160)===0&&(de=262144),ci=e}else ci=536870912;return e=ri.current,e!==null&&(e.flags|=32),ci}function qn(e,n,a){(e===We&&(we===2||we===9)||e.cancelPendingCommit!==null)&&(Ar(e,0),ts(e,Se,ci,!1)),te(e,a),((De&2)===0||e!==We)&&(e===We&&((De&2)===0&&(Bs|=a),nn===4&&ts(e,Se,ci,!1)),Gi(e))}function qp(e,n,a){if((De&6)!==0)throw Error(s(327));var o=!a&&(n&127)===0&&(n&e.expiredLanes)===0||Bt(e,n),u=o?Eg(e,n):Hf(e,n,!0),d=o;do{if(u===0){gr&&!o&&ts(e,n,0,!1);break}else{if(a=e.current.alternate,d&&!Tg(a)){u=Hf(e,n,!1),d=!1;continue}if(u===2){if(d=n,e.errorRecoveryDisabledLanes&d)var _=0;else _=e.pendingLanes&-536870913,_=_!==0?_:_&536870912?536870912:0;if(_!==0){n=_;t:{var y=e;u=Uo;var X=y.current.memoizedState.isDehydrated;if(X&&(Ar(y,_).flags|=256),_=Hf(y,_,!1),_!==2){if(Lf&&!X){y.errorRecoveryDisabledLanes|=d,Bs|=d,u=4;break t}d=Zn,Zn=u,d!==null&&(Zn===null?Zn=d:Zn.push.apply(Zn,d))}u=_}if(d=!1,u!==2)continue}}if(u===1){Ar(e,0),ts(e,n,0,!0);break}t:{switch(o=e,d=u,d){case 0:case 1:throw Error(s(345));case 4:if((n&4194048)!==n)break;case 6:ts(o,n,ci,!$a);break t;case 2:Zn=null;break;case 3:case 5:break;default:throw Error(s(329))}if((n&62914560)===n&&(u=Ql+300-Ct(),10<u)){if(ts(o,n,ci,!$a),Tt(o,0,!0)!==0)break t;ga=n,o.timeoutHandle=RT($p.bind(null,o,a,Zn,Jl,Ff,n,ci,Bs,_r,$a,d,"Throttled",-0,0),u);break t}$p(o,a,Zn,Jl,Ff,n,ci,Bs,_r,$a,d,null,-0,0)}}break}while(!0);Gi(e)}function $p(e,n,a,o,u,d,_,y,X,J,pt,_t,st,ot){if(e.timeoutHandle=-1,_t=n.subtreeFlags,_t&8192||(_t&16785408)===16785408){_t={stylesheets:null,count:0,imgCount:0,imgBytes:0,suspenseyImages:[],waitingForImages:!0,waitingForViewTransition:!1,unsuspend:aa},Gp(n,d,_t);var Vt=(d&62914560)===d?Ql-Ct():(d&4194048)===d?kp-Ct():0;if(Vt=Jg(_t,Vt),Vt!==null){ga=d,e.cancelPendingCommit=Vt(aT.bind(null,e,n,d,a,o,u,_,y,X,pt,_t,null,st,ot)),ts(e,d,_,!J);return}}aT(e,n,d,a,o,u,_,y,X)}function Tg(e){for(var n=e;;){var a=n.tag;if((a===0||a===11||a===15)&&n.flags&16384&&(a=n.updateQueue,a!==null&&(a=a.stores,a!==null)))for(var o=0;o<a.length;o++){var u=a[o],d=u.getSnapshot;u=u.value;try{if(!ai(d(),u))return!1}catch{return!1}}if(a=n.child,n.subtreeFlags&16384&&a!==null)a.return=n,n=a;else{if(n===e)break;for(;n.sibling===null;){if(n.return===null||n.return===e)return!0;n=n.return}n.sibling.return=n.return,n=n.sibling}}return!0}function ts(e,n,a,o){n&=~Uf,n&=~Bs,e.suspendedLanes|=n,e.pingedLanes&=~n,o&&(e.warmLanes|=n),o=e.expirationTimes;for(var u=n;0<u;){var d=31-Ut(u),_=1<<d;o[d]=-1,u&=~_}a!==0&&ye(e,a,n)}function tc(){return(De&6)===0?(wo(0),!1):!0}function Pf(){if(Te!==null){if(we===0)var e=Te.return;else e=Te,la=ys=null,tf(e),hr=null,So=0,e=Te;for(;e!==null;)Cp(e.alternate,e),e=e.return;Te=null}}function Ar(e,n){var a=e.timeoutHandle;a!==-1&&(e.timeoutHandle=-1,Fg(a)),a=e.cancelPendingCommit,a!==null&&(e.cancelPendingCommit=null,a()),ga=0,Pf(),We=e,Te=a=ra(e.current,null),Se=n,we=0,li=null,$a=!1,gr=Bt(e,n),Lf=!1,_r=ci=Uf=Bs=Qa=nn=0,Zn=Uo=null,Ff=!1,(n&8)!==0&&(n|=n&32);var o=e.entangledLanes;if(o!==0)for(e=e.entanglements,o&=n;0<o;){var u=31-Ut(o),d=1<<u;n|=e[u],o&=~d}return Sa=n,vl(),a}function Qp(e,n){oe=null,L.H=Ro,n===fr||n===Dl?(n=d1(),we=3):n===Gu?(n=d1(),we=4):we=n===Ef?8:n!==null&&typeof n=="object"&&typeof n.then=="function"?6:1,li=n,Te===null&&(nn=1,zl(e,mi(n,e.current)))}function jp(){var e=ri.current;return e===null?!0:(Se&4194048)===Se?_i===null:(Se&62914560)===Se||(Se&536870912)!==0?e===_i:!1}function Jp(){var e=L.H;return L.H=Ro,e===null?Ro:e}function tT(){var e=L.A;return L.A=dg,e}function ec(){nn=4,$a||(Se&4194048)!==Se&&ri.current!==null||(gr=!0),(Qa&134217727)===0&&(Bs&134217727)===0||We===null||ts(We,Se,ci,!1)}function Hf(e,n,a){var o=De;De|=2;var u=Jp(),d=tT();(We!==e||Se!==n)&&(Jl=null,Ar(e,n)),n=!1;var _=nn;t:do try{if(we!==0&&Te!==null){var y=Te,X=li;switch(we){case 8:Pf(),_=6;break t;case 3:case 2:case 9:case 6:ri.current===null&&(n=!0);var J=we;if(we=0,li=null,xr(e,y,X,J),a&&gr){_=0;break t}break;default:J=we,we=0,li=null,xr(e,y,X,J)}}mg(),_=nn;break}catch(pt){Qp(e,pt)}while(!0);return n&&e.shellSuspendCounter++,la=ys=null,De=o,L.H=u,L.A=d,Te===null&&(We=null,Se=0,vl()),_}function mg(){for(;Te!==null;)eT(Te)}function Eg(e,n){var a=De;De|=2;var o=Jp(),u=tT();We!==e||Se!==n?(Jl=null,jl=Ct()+500,Ar(e,n)):gr=Bt(e,n);t:do try{if(we!==0&&Te!==null){n=Te;var d=li;e:switch(we){case 1:we=0,li=null,xr(e,n,d,1);break;case 2:case 9:if(f1(d)){we=0,li=null,nT(n);break}n=function(){we!==2&&we!==9||We!==e||(we=7),Gi(e)},d.then(n,n);break t;case 3:we=7;break t;case 4:we=5;break t;case 7:f1(d)?(we=0,li=null,nT(n)):(we=0,li=null,xr(e,n,d,7));break;case 5:var _=null;switch(Te.tag){case 26:_=Te.memoizedState;case 5:case 27:var y=Te;if(_?YT(_):y.stateNode.complete){we=0,li=null;var X=y.sibling;if(X!==null)Te=X;else{var J=y.return;J!==null?(Te=J,nc(J)):Te=null}break e}}we=0,li=null,xr(e,n,d,5);break;case 6:we=0,li=null,xr(e,n,d,6);break;case 8:Pf(),nn=6;break t;default:throw Error(s(462))}}Sg();break}catch(pt){Qp(e,pt)}while(!0);return la=ys=null,L.H=o,L.A=u,De=a,Te!==null?0:(We=null,Se=0,vl(),nn)}function Sg(){for(;Te!==null&&!he();)eT(Te)}function eT(e){var n=Mp(e.alternate,e,Sa);e.memoizedProps=e.pendingProps,n===null?nc(e):Te=n}function nT(e){var n=e,a=n.alternate;switch(n.tag){case 15:case 0:n=gp(a,n,n.pendingProps,n.type,void 0,Se);break;case 11:n=gp(a,n,n.pendingProps,n.type.render,n.ref,Se);break;case 5:tf(n);default:Cp(a,n),n=Te=t1(n,Sa),n=Mp(a,n,Sa)}e.memoizedProps=e.pendingProps,n===null?nc(e):Te=n}function xr(e,n,a,o){la=ys=null,tf(n),hr=null,So=0;var u=n.return;try{if(rg(e,u,n,a,Se)){nn=1,zl(e,mi(a,e.current)),Te=null;return}}catch(d){if(u!==null)throw Te=u,d;nn=1,zl(e,mi(a,e.current)),Te=null;return}n.flags&32768?(ve||o===1?e=!0:gr||(Se&536870912)!==0?e=!1:($a=e=!0,(o===2||o===9||o===3||o===6)&&(o=ri.current,o!==null&&o.tag===13&&(o.flags|=16384))),iT(n,e)):nc(n)}function nc(e){var n=e;do{if((n.flags&32768)!==0){iT(n,$a);return}e=n.return;var a=cg(n.alternate,n,Sa);if(a!==null){Te=a;return}if(n=n.sibling,n!==null){Te=n;return}Te=n=e}while(n!==null);nn===0&&(nn=5)}function iT(e,n){do{var a=ug(e.alternate,e);if(a!==null){a.flags&=32767,Te=a;return}if(a=e.return,a!==null&&(a.flags|=32768,a.subtreeFlags=0,a.deletions=null),!n&&(e=e.sibling,e!==null)){Te=e;return}Te=e=a}while(e!==null);nn=6,Te=null}function aT(e,n,a,o,u,d,_,y,X){e.cancelPendingCommit=null;do ic();while(En!==0);if((De&6)!==0)throw Error(s(327));if(n!==null){if(n===e.current)throw Error(s(177));if(d=n.lanes|n.childLanes,d|=Cu,tn(e,a,d,_,y,X),e===We&&(Te=We=null,Se=0),vr=n,Ja=e,ga=a,wf=d,Bf=u,Kp=o,(n.subtreeFlags&10256)!==0||(n.flags&10256)!==0?(e.callbackNode=null,e.callbackPriority=0,Ag(Q,function(){return cT(),null})):(e.callbackNode=null,e.callbackPriority=0),o=(n.flags&13878)!==0,(n.subtreeFlags&13878)!==0||o){o=L.T,L.T=null,u=P.p,P.p=2,_=De,De|=4;try{fg(e,n,a)}finally{De=_,P.p=u,L.T=o}}En=1,sT(),rT(),oT()}}function sT(){if(En===1){En=0;var e=Ja,n=vr,a=(n.flags&13878)!==0;if((n.subtreeFlags&13878)!==0||a){a=L.T,L.T=null;var o=P.p;P.p=2;var u=De;De|=4;try{Pp(n,e);var d=jf,_=W0(e.containerInfo),y=d.focusedElem,X=d.selectionRange;if(_!==y&&y&&y.ownerDocument&&V0(y.ownerDocument.documentElement,y)){if(X!==null&&Au(y)){var J=X.start,pt=X.end;if(pt===void 0&&(pt=J),"selectionStart"in y)y.selectionStart=J,y.selectionEnd=Math.min(pt,y.value.length);else{var _t=y.ownerDocument||document,st=_t&&_t.defaultView||window;if(st.getSelection){var ot=st.getSelection(),Vt=y.textContent.length,jt=Math.min(X.start,Vt),Ge=X.end===void 0?jt:Math.min(X.end,Vt);!ot.extend&&jt>Ge&&(_=Ge,Ge=jt,jt=_);var q=z0(y,jt),z=z0(y,Ge);if(q&&z&&(ot.rangeCount!==1||ot.anchorNode!==q.node||ot.anchorOffset!==q.offset||ot.focusNode!==z.node||ot.focusOffset!==z.offset)){var j=_t.createRange();j.setStart(q.node,q.offset),ot.removeAllRanges(),jt>Ge?(ot.addRange(j),ot.extend(z.node,z.offset)):(j.setEnd(z.node,z.offset),ot.addRange(j))}}}}for(_t=[],ot=y;ot=ot.parentNode;)ot.nodeType===1&&_t.push({element:ot,left:ot.scrollLeft,top:ot.scrollTop});for(typeof y.focus=="function"&&y.focus(),y=0;y<_t.length;y++){var Et=_t[y];Et.element.scrollLeft=Et.left,Et.element.scrollTop=Et.top}}Tc=!!Qf,jf=Qf=null}finally{De=u,P.p=o,L.T=a}}e.current=n,En=2}}function rT(){if(En===2){En=0;var e=Ja,n=vr,a=(n.flags&8772)!==0;if((n.subtreeFlags&8772)!==0||a){a=L.T,L.T=null;var o=P.p;P.p=2;var u=De;De|=4;try{Up(e,n.alternate,n)}finally{De=u,P.p=o,L.T=a}}En=3}}function oT(){if(En===4||En===3){En=0,Pe();var e=Ja,n=vr,a=ga,o=Kp;(n.subtreeFlags&10256)!==0||(n.flags&10256)!==0?En=5:(En=0,vr=Ja=null,lT(e,e.pendingLanes));var u=e.pendingLanes;if(u===0&&(ja=null),Jr(a),n=n.stateNode,ht&&typeof ht.onCommitFiberRoot=="function")try{ht.onCommitFiberRoot(ut,n,void 0,(n.current.flags&128)===128)}catch{}if(o!==null){n=L.T,u=P.p,P.p=2,L.T=null;try{for(var d=e.onRecoverableError,_=0;_<o.length;_++){var y=o[_];d(y.value,{componentStack:y.stack})}}finally{L.T=n,P.p=u}}(ga&3)!==0&&ic(),Gi(e),u=e.pendingLanes,(a&261930)!==0&&(u&42)!==0?e===Xf?Fo++:(Fo=0,Xf=e):Fo=0,wo(0)}}function lT(e,n){(e.pooledCacheLanes&=n)===0&&(n=e.pooledCache,n!=null&&(e.pooledCache=null,mo(n)))}function ic(){return sT(),rT(),oT(),cT()}function cT(){if(En!==5)return!1;var e=Ja,n=wf;wf=0;var a=Jr(ga),o=L.T,u=P.p;try{P.p=32>a?32:a,L.T=null,a=Bf,Bf=null;var d=Ja,_=ga;if(En=0,vr=Ja=null,ga=0,(De&6)!==0)throw Error(s(331));var y=De;if(De|=4,Vp(d.current),Yp(d,d.current,_,a),De=y,wo(0,!1),ht&&typeof ht.onPostCommitFiberRoot=="function")try{ht.onPostCommitFiberRoot(ut,d)}catch{}return!0}finally{P.p=u,L.T=o,lT(e,n)}}function uT(e,n,a){n=mi(a,n),n=mf(e.stateNode,n,2),e=ka(e,n,2),e!==null&&(te(e,2),Gi(e))}function Be(e,n,a){if(e.tag===3)uT(e,e,a);else for(;n!==null;){if(n.tag===3){uT(n,e,a);break}else if(n.tag===1){var o=n.stateNode;if(typeof n.type.getDerivedStateFromError=="function"||typeof o.componentDidCatch=="function"&&(ja===null||!ja.has(o))){e=mi(a,e),a=fp(2),o=ka(n,a,2),o!==null&&(hp(a,o,n,e),te(o,2),Gi(o));break}}n=n.return}}function Yf(e,n,a){var o=e.pingCache;if(o===null){o=e.pingCache=new pg;var u=new Set;o.set(n,u)}else u=o.get(n),u===void 0&&(u=new Set,o.set(n,u));u.has(a)||(Lf=!0,u.add(a),e=gg.bind(null,e,n,a),n.then(e,e))}function gg(e,n,a){var o=e.pingCache;o!==null&&o.delete(n),e.pingedLanes|=e.suspendedLanes&a,e.warmLanes&=~a,We===e&&(Se&a)===a&&(nn===4||nn===3&&(Se&62914560)===Se&&300>Ct()-Ql?(De&2)===0&&Ar(e,0):Uf|=a,_r===Se&&(_r=0)),Gi(e)}function fT(e,n){n===0&&(n=At()),e=Ms(e,n),e!==null&&(te(e,n),Gi(e))}function _g(e){var n=e.memoizedState,a=0;n!==null&&(a=n.retryLane),fT(e,a)}function vg(e,n){var a=0;switch(e.tag){case 31:case 13:var o=e.stateNode,u=e.memoizedState;u!==null&&(a=u.retryLane);break;case 19:o=e.stateNode;break;case 22:o=e.stateNode._retryCache;break;default:throw Error(s(314))}o!==null&&o.delete(n),fT(e,a)}function Ag(e,n){return k(e,n)}var ac=null,Nr=null,Gf=!1,sc=!1,zf=!1,es=0;function Gi(e){e!==Nr&&e.next===null&&(Nr===null?ac=Nr=e:Nr=Nr.next=e),sc=!0,Gf||(Gf=!0,Ng())}function wo(e,n){if(!zf&&sc){zf=!0;do for(var a=!1,o=ac;o!==null;){if(e!==0){var u=o.pendingLanes;if(u===0)var d=0;else{var _=o.suspendedLanes,y=o.pingedLanes;d=(1<<31-Ut(42|e)+1)-1,d&=u&~(_&~y),d=d&201326741?d&201326741|1:d?d|2:0}d!==0&&(a=!0,TT(o,d))}else d=Se,d=Tt(o,o===We?d:0,o.cancelPendingCommit!==null||o.timeoutHandle!==-1),(d&3)===0||Bt(o,d)||(a=!0,TT(o,d));o=o.next}while(a);zf=!1}}function xg(){hT()}function hT(){sc=Gf=!1;var e=0;es!==0&&Ug()&&(e=es);for(var n=Ct(),a=null,o=ac;o!==null;){var u=o.next,d=dT(o,n);d===0?(o.next=null,a===null?ac=u:a.next=u,u===null&&(Nr=a)):(a=o,(e!==0||(d&3)!==0)&&(sc=!0)),o=u}En!==0&&En!==5||wo(e),es!==0&&(es=0)}function dT(e,n){for(var a=e.suspendedLanes,o=e.pingedLanes,u=e.expirationTimes,d=e.pendingLanes&-62914561;0<d;){var _=31-Ut(d),y=1<<_,X=u[_];X===-1?((y&a)===0||(y&o)!==0)&&(u[_]=bt(y,n)):X<=n&&(e.expiredLanes|=y),d&=~y}if(n=We,a=Se,a=Tt(e,e===n?a:0,e.cancelPendingCommit!==null||e.timeoutHandle!==-1),o=e.callbackNode,a===0||e===n&&(we===2||we===9)||e.cancelPendingCommit!==null)return o!==null&&o!==null&&Je(o),e.callbackNode=null,e.callbackPriority=0;if((a&3)===0||Bt(e,a)){if(n=a&-a,n===e.callbackPriority)return n;switch(o!==null&&Je(o),Jr(a)){case 2:case 8:a=N;break;case 32:a=Q;break;case 268435456:a=xt;break;default:a=Q}return o=pT.bind(null,e),a=k(a,o),e.callbackPriority=n,e.callbackNode=a,n}return o!==null&&o!==null&&Je(o),e.callbackPriority=2,e.callbackNode=null,2}function pT(e,n){if(En!==0&&En!==5)return e.callbackNode=null,e.callbackPriority=0,null;var a=e.callbackNode;if(ic()&&e.callbackNode!==a)return null;var o=Se;return o=Tt(e,e===We?o:0,e.cancelPendingCommit!==null||e.timeoutHandle!==-1),o===0?null:(qp(e,o,n),dT(e,Ct()),e.callbackNode!=null&&e.callbackNode===a?pT.bind(null,e):null)}function TT(e,n){if(ic())return null;qp(e,n,!0)}function Ng(){wg(function(){(De&6)!==0?k(b,xg):hT()})}function Vf(){if(es===0){var e=cr;e===0&&(e=ie,ie<<=1,(ie&261888)===0&&(ie=256)),es=e}return es}function mT(e){return e==null||typeof e=="symbol"||typeof e=="boolean"?null:typeof e=="function"?e:vs(""+e)}function ET(e,n){var a=n.ownerDocument.createElement("input");return a.name=n.name,a.value=n.value,e.id&&a.setAttribute("form",e.id),n.parentNode.insertBefore(a,n),e=new FormData(e),a.parentNode.removeChild(a),e}function Mg(e,n,a,o,u){if(n==="submit"&&a&&a.stateNode===u){var d=mT((u[Rn]||null).action),_=o.submitter;_&&(n=(n=_[Rn]||null)?mT(n.formAction):_.getAttribute("formAction"),n!==null&&(d=n,_=null));var y=new El("action","action",null,o,u);e.push({event:y,listeners:[{instance:null,listener:function(){if(o.defaultPrevented){if(es!==0){var X=_?ET(u,_):new FormData(u);uf(a,{pending:!0,data:X,method:u.method,action:d},null,X)}}else typeof d=="function"&&(y.preventDefault(),X=_?ET(u,_):new FormData(u),uf(a,{pending:!0,data:X,method:u.method,action:d},d,X))},currentTarget:u}]})}}for(var Wf=0;Wf<Ru.length;Wf++){var kf=Ru[Wf],Rg=kf.toLowerCase(),Cg=kf[0].toUpperCase()+kf.slice(1);Ci(Rg,"on"+Cg)}Ci(Z0,"onAnimationEnd"),Ci(q0,"onAnimationIteration"),Ci($0,"onAnimationStart"),Ci("dblclick","onDoubleClick"),Ci("focusin","onFocus"),Ci("focusout","onBlur"),Ci(zS,"onTransitionRun"),Ci(VS,"onTransitionStart"),Ci(WS,"onTransitionCancel"),Ci(Q0,"onTransitionEnd"),at("onMouseEnter",["mouseout","mouseover"]),at("onMouseLeave",["mouseout","mouseover"]),at("onPointerEnter",["pointerout","pointerover"]),at("onPointerLeave",["pointerout","pointerover"]),K("onChange","change click focusin focusout input keydown keyup selectionchange".split(" ")),K("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" ")),K("onBeforeInput",["compositionend","keypress","textInput","paste"]),K("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" ")),K("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" ")),K("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var Bo="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),yg=new Set("beforetoggle cancel close invalid load scroll scrollend toggle".split(" ").concat(Bo));function ST(e,n){n=(n&4)!==0;for(var a=0;a<e.length;a++){var o=e[a],u=o.event;o=o.listeners;t:{var d=void 0;if(n)for(var _=o.length-1;0<=_;_--){var y=o[_],X=y.instance,J=y.currentTarget;if(y=y.listener,X!==d&&u.isPropagationStopped())break t;d=y,u.currentTarget=J;try{d(u)}catch(pt){_l(pt)}u.currentTarget=null,d=X}else for(_=0;_<o.length;_++){if(y=o[_],X=y.instance,J=y.currentTarget,y=y.listener,X!==d&&u.isPropagationStopped())break t;d=y,u.currentTarget=J;try{d(u)}catch(pt){_l(pt)}u.currentTarget=null,d=X}}}}function me(e,n){var a=n[La];a===void 0&&(a=n[La]=new Set);var o=e+"__bubble";a.has(o)||(gT(n,e,2,!1),a.add(o))}function Kf(e,n,a){var o=0;n&&(o|=4),gT(a,e,o,n)}var rc="_reactListening"+Math.random().toString(36).slice(2);function Zf(e){if(!e[rc]){e[rc]=!0,dl.forEach(function(a){a!=="selectionchange"&&(yg.has(a)||Kf(a,!1,e),Kf(a,!0,e))});var n=e.nodeType===9?e:e.ownerDocument;n===null||n[rc]||(n[rc]=!0,Kf("selectionchange",!1,n))}}function gT(e,n,a,o){switch(ZT(n)){case 2:var u=n_;break;case 8:u=i_;break;default:u=ch}a=u.bind(null,n,a,e),u=void 0,!du||n!=="touchstart"&&n!=="touchmove"&&n!=="wheel"||(u=!0),o?u!==void 0?e.addEventListener(n,a,{capture:!0,passive:u}):e.addEventListener(n,a,!0):u!==void 0?e.addEventListener(n,a,{passive:u}):e.addEventListener(n,a,!1)}function qf(e,n,a,o,u){var d=o;if((n&1)===0&&(n&2)===0&&o!==null)t:for(;;){if(o===null)return;var _=o.tag;if(_===3||_===4){var y=o.stateNode.containerInfo;if(y===u)break;if(_===4)for(_=o.return;_!==null;){var X=_.tag;if((X===3||X===4)&&_.stateNode.containerInfo===u)return;_=_.return}for(;y!==null;){if(_=Fa(y),_===null)return;if(X=_.tag,X===5||X===6||X===26||X===27){o=d=_;continue t}y=y.parentNode}}o=o.return}N0(function(){var J=d,pt=fu(a),_t=[];t:{var st=j0.get(e);if(st!==void 0){var ot=El,Vt=e;switch(e){case"keypress":if(Tl(a)===0)break t;case"keydown":case"keyup":ot=vS;break;case"focusin":Vt="focus",ot=Eu;break;case"focusout":Vt="blur",ot=Eu;break;case"beforeblur":case"afterblur":ot=Eu;break;case"click":if(a.button===2)break t;case"auxclick":case"dblclick":case"mousedown":case"mousemove":case"mouseup":case"mouseout":case"mouseover":case"contextmenu":ot=C0;break;case"drag":case"dragend":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"dragstart":case"drop":ot=cS;break;case"touchcancel":case"touchend":case"touchmove":case"touchstart":ot=NS;break;case Z0:case q0:case $0:ot=hS;break;case Q0:ot=RS;break;case"scroll":case"scrollend":ot=oS;break;case"wheel":ot=yS;break;case"copy":case"cut":case"paste":ot=pS;break;case"gotpointercapture":case"lostpointercapture":case"pointercancel":case"pointerdown":case"pointermove":case"pointerout":case"pointerover":case"pointerup":ot=D0;break;case"toggle":case"beforetoggle":ot=OS}var jt=(n&4)!==0,Ge=!jt&&(e==="scroll"||e==="scrollend"),q=jt?st!==null?st+"Capture":null:st;jt=[];for(var z=J,j;z!==null;){var Et=z;if(j=Et.stateNode,Et=Et.tag,Et!==5&&Et!==26&&Et!==27||j===null||q===null||(Et=ao(z,q),Et!=null&&jt.push(Xo(z,Et,j))),Ge)break;z=z.return}0<jt.length&&(st=new ot(st,Vt,null,a,pt),_t.push({event:st,listeners:jt}))}}if((n&7)===0){t:{if(st=e==="mouseover"||e==="pointerover",ot=e==="mouseout"||e==="pointerout",st&&a!==uu&&(Vt=a.relatedTarget||a.fromElement)&&(Fa(Vt)||Vt[ia]))break t;if((ot||st)&&(st=pt.window===pt?pt:(st=pt.ownerDocument)?st.defaultView||st.parentWindow:window,ot?(Vt=a.relatedTarget||a.toElement,ot=J,Vt=Vt?Fa(Vt):null,Vt!==null&&(Ge=c(Vt),jt=Vt.tag,Vt!==Ge||jt!==5&&jt!==27&&jt!==6)&&(Vt=null)):(ot=null,Vt=J),ot!==Vt)){if(jt=C0,Et="onMouseLeave",q="onMouseEnter",z="mouse",(e==="pointerout"||e==="pointerover")&&(jt=D0,Et="onPointerLeave",q="onPointerEnter",z="pointer"),Ge=ot==null?st:_s(ot),j=Vt==null?st:_s(Vt),st=new jt(Et,z+"leave",ot,a,pt),st.target=Ge,st.relatedTarget=j,Et=null,Fa(pt)===J&&(jt=new jt(q,z+"enter",Vt,a,pt),jt.target=j,jt.relatedTarget=Ge,Et=jt),Ge=Et,ot&&Vt)e:{for(jt=Dg,q=ot,z=Vt,j=0,Et=q;Et;Et=jt(Et))j++;Et=0;for(var $t=z;$t;$t=jt($t))Et++;for(;0<j-Et;)q=jt(q),j--;for(;0<Et-j;)z=jt(z),Et--;for(;j--;){if(q===z||z!==null&&q===z.alternate){jt=q;break e}q=jt(q),z=jt(z)}jt=null}else jt=null;ot!==null&&_T(_t,st,ot,jt,!1),Vt!==null&&Ge!==null&&_T(_t,Ge,Vt,jt,!0)}}t:{if(st=J?_s(J):window,ot=st.nodeName&&st.nodeName.toLowerCase(),ot==="select"||ot==="input"&&st.type==="file")var Re=B0;else if(F0(st))if(X0)Re=HS;else{Re=XS;var kt=BS}else ot=st.nodeName,!ot||ot.toLowerCase()!=="input"||st.type!=="checkbox"&&st.type!=="radio"?J&&be(J.elementType)&&(Re=B0):Re=PS;if(Re&&(Re=Re(e,J))){w0(_t,Re,a,pt);break t}kt&&kt(e,st,J),e==="focusout"&&J&&st.type==="number"&&J.memoizedProps.value!=null&&pe(st,"number",st.value)}switch(kt=J?_s(J):window,e){case"focusin":(F0(kt)||kt.contentEditable==="true")&&(er=kt,xu=J,ho=null);break;case"focusout":ho=xu=er=null;break;case"mousedown":Nu=!0;break;case"contextmenu":case"mouseup":case"dragend":Nu=!1,k0(_t,a,pt);break;case"selectionchange":if(GS)break;case"keydown":case"keyup":k0(_t,a,pt)}var ce;if(gu)t:{switch(e){case"compositionstart":var ge="onCompositionStart";break t;case"compositionend":ge="onCompositionEnd";break t;case"compositionupdate":ge="onCompositionUpdate";break t}ge=void 0}else tr?L0(e,a)&&(ge="onCompositionEnd"):e==="keydown"&&a.keyCode===229&&(ge="onCompositionStart");ge&&(O0&&a.locale!=="ko"&&(tr||ge!=="onCompositionStart"?ge==="onCompositionEnd"&&tr&&(ce=M0()):(Pa=pt,pu="value"in Pa?Pa.value:Pa.textContent,tr=!0)),kt=oc(J,ge),0<kt.length&&(ge=new y0(ge,e,null,a,pt),_t.push({event:ge,listeners:kt}),ce?ge.data=ce:(ce=U0(a),ce!==null&&(ge.data=ce)))),(ce=IS?LS(e,a):US(e,a))&&(ge=oc(J,"onBeforeInput"),0<ge.length&&(kt=new y0("onBeforeInput","beforeinput",null,a,pt),_t.push({event:kt,listeners:ge}),kt.data=ce)),Mg(_t,e,J,a,pt)}ST(_t,n)})}function Xo(e,n,a){return{instance:e,listener:n,currentTarget:a}}function oc(e,n){for(var a=n+"Capture",o=[];e!==null;){var u=e,d=u.stateNode;if(u=u.tag,u!==5&&u!==26&&u!==27||d===null||(u=ao(e,a),u!=null&&o.unshift(Xo(e,u,d)),u=ao(e,n),u!=null&&o.push(Xo(e,u,d))),e.tag===3)return o;e=e.return}return[]}function Dg(e){if(e===null)return null;do e=e.return;while(e&&e.tag!==5&&e.tag!==27);return e||null}function _T(e,n,a,o,u){for(var d=n._reactName,_=[];a!==null&&a!==o;){var y=a,X=y.alternate,J=y.stateNode;if(y=y.tag,X!==null&&X===o)break;y!==5&&y!==26&&y!==27||J===null||(X=J,u?(J=ao(a,d),J!=null&&_.unshift(Xo(a,J,X))):u||(J=ao(a,d),J!=null&&_.push(Xo(a,J,X)))),a=a.return}_.length!==0&&e.push({event:n,listeners:_})}var Og=/\r\n?/g,bg=/\u0000|\uFFFD/g;function vT(e){return(typeof e=="string"?e:""+e).replace(Og,`
`).replace(bg,"")}function AT(e,n){return n=vT(n),vT(e)===n}function Ye(e,n,a,o,u,d){switch(a){case"children":typeof o=="string"?n==="body"||n==="textarea"&&o===""||ii(e,o):(typeof o=="number"||typeof o=="bigint")&&n!=="body"&&ii(e,""+o);break;case"className":zt(e,"class",o);break;case"tabIndex":zt(e,"tabindex",o);break;case"dir":case"role":case"viewBox":case"width":case"height":zt(e,a,o);break;case"style":Ri(e,o,d);break;case"data":if(n!=="object"){zt(e,"data",o);break}case"src":case"href":if(o===""&&(n!=="a"||a!=="href")){e.removeAttribute(a);break}if(o==null||typeof o=="function"||typeof o=="symbol"||typeof o=="boolean"){e.removeAttribute(a);break}o=vs(""+o),e.setAttribute(a,o);break;case"action":case"formAction":if(typeof o=="function"){e.setAttribute(a,"javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')");break}else typeof d=="function"&&(a==="formAction"?(n!=="input"&&Ye(e,n,"name",u.name,u,null),Ye(e,n,"formEncType",u.formEncType,u,null),Ye(e,n,"formMethod",u.formMethod,u,null),Ye(e,n,"formTarget",u.formTarget,u,null)):(Ye(e,n,"encType",u.encType,u,null),Ye(e,n,"method",u.method,u,null),Ye(e,n,"target",u.target,u,null)));if(o==null||typeof o=="symbol"||typeof o=="boolean"){e.removeAttribute(a);break}o=vs(""+o),e.setAttribute(a,o);break;case"onClick":o!=null&&(e.onclick=aa);break;case"onScroll":o!=null&&me("scroll",e);break;case"onScrollEnd":o!=null&&me("scrollend",e);break;case"dangerouslySetInnerHTML":if(o!=null){if(typeof o!="object"||!("__html"in o))throw Error(s(61));if(a=o.__html,a!=null){if(u.children!=null)throw Error(s(60));e.innerHTML=a}}break;case"multiple":e.multiple=o&&typeof o!="function"&&typeof o!="symbol";break;case"muted":e.muted=o&&typeof o!="function"&&typeof o!="symbol";break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"defaultValue":case"defaultChecked":case"innerHTML":case"ref":break;case"autoFocus":break;case"xlinkHref":if(o==null||typeof o=="function"||typeof o=="boolean"||typeof o=="symbol"){e.removeAttribute("xlink:href");break}a=vs(""+o),e.setAttributeNS("http://www.w3.org/1999/xlink","xlink:href",a);break;case"contentEditable":case"spellCheck":case"draggable":case"value":case"autoReverse":case"externalResourcesRequired":case"focusable":case"preserveAlpha":o!=null&&typeof o!="function"&&typeof o!="symbol"?e.setAttribute(a,""+o):e.removeAttribute(a);break;case"inert":case"allowFullScreen":case"async":case"autoPlay":case"controls":case"default":case"defer":case"disabled":case"disablePictureInPicture":case"disableRemotePlayback":case"formNoValidate":case"hidden":case"loop":case"noModule":case"noValidate":case"open":case"playsInline":case"readOnly":case"required":case"reversed":case"scoped":case"seamless":case"itemScope":o&&typeof o!="function"&&typeof o!="symbol"?e.setAttribute(a,""):e.removeAttribute(a);break;case"capture":case"download":o===!0?e.setAttribute(a,""):o!==!1&&o!=null&&typeof o!="function"&&typeof o!="symbol"?e.setAttribute(a,o):e.removeAttribute(a);break;case"cols":case"rows":case"size":case"span":o!=null&&typeof o!="function"&&typeof o!="symbol"&&!isNaN(o)&&1<=o?e.setAttribute(a,o):e.removeAttribute(a);break;case"rowSpan":case"start":o==null||typeof o=="function"||typeof o=="symbol"||isNaN(o)?e.removeAttribute(a):e.setAttribute(a,o);break;case"popover":me("beforetoggle",e),me("toggle",e),Ft(e,"popover",o);break;case"xlinkActuate":Gt(e,"http://www.w3.org/1999/xlink","xlink:actuate",o);break;case"xlinkArcrole":Gt(e,"http://www.w3.org/1999/xlink","xlink:arcrole",o);break;case"xlinkRole":Gt(e,"http://www.w3.org/1999/xlink","xlink:role",o);break;case"xlinkShow":Gt(e,"http://www.w3.org/1999/xlink","xlink:show",o);break;case"xlinkTitle":Gt(e,"http://www.w3.org/1999/xlink","xlink:title",o);break;case"xlinkType":Gt(e,"http://www.w3.org/1999/xlink","xlink:type",o);break;case"xmlBase":Gt(e,"http://www.w3.org/XML/1998/namespace","xml:base",o);break;case"xmlLang":Gt(e,"http://www.w3.org/XML/1998/namespace","xml:lang",o);break;case"xmlSpace":Gt(e,"http://www.w3.org/XML/1998/namespace","xml:space",o);break;case"is":Ft(e,"is",o);break;case"innerText":case"textContent":break;default:(!(2<a.length)||a[0]!=="o"&&a[0]!=="O"||a[1]!=="n"&&a[1]!=="N")&&(a=Xi.get(a)||a,Ft(e,a,o))}}function $f(e,n,a,o,u,d){switch(a){case"style":Ri(e,o,d);break;case"dangerouslySetInnerHTML":if(o!=null){if(typeof o!="object"||!("__html"in o))throw Error(s(61));if(a=o.__html,a!=null){if(u.children!=null)throw Error(s(60));e.innerHTML=a}}break;case"children":typeof o=="string"?ii(e,o):(typeof o=="number"||typeof o=="bigint")&&ii(e,""+o);break;case"onScroll":o!=null&&me("scroll",e);break;case"onScrollEnd":o!=null&&me("scrollend",e);break;case"onClick":o!=null&&(e.onclick=aa);break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"innerHTML":case"ref":break;case"innerText":case"textContent":break;default:if(!C.hasOwnProperty(a))t:{if(a[0]==="o"&&a[1]==="n"&&(u=a.endsWith("Capture"),n=a.slice(2,u?a.length-7:void 0),d=e[Rn]||null,d=d!=null?d[a]:null,typeof d=="function"&&e.removeEventListener(n,d,u),typeof o=="function")){typeof d!="function"&&d!==null&&(a in e?e[a]=null:e.hasAttribute(a)&&e.removeAttribute(a)),e.addEventListener(n,o,u);break t}a in e?e[a]=o:o===!0?e.setAttribute(a,""):Ft(e,a,o)}}}function On(e,n,a){switch(n){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"img":me("error",e),me("load",e);var o=!1,u=!1,d;for(d in a)if(a.hasOwnProperty(d)){var _=a[d];if(_!=null)switch(d){case"src":o=!0;break;case"srcSet":u=!0;break;case"children":case"dangerouslySetInnerHTML":throw Error(s(137,n));default:Ye(e,n,d,_,a,null)}}u&&Ye(e,n,"srcSet",a.srcSet,a,null),o&&Ye(e,n,"src",a.src,a,null);return;case"input":me("invalid",e);var y=d=_=u=null,X=null,J=null;for(o in a)if(a.hasOwnProperty(o)){var pt=a[o];if(pt!=null)switch(o){case"name":u=pt;break;case"type":_=pt;break;case"checked":X=pt;break;case"defaultChecked":J=pt;break;case"value":d=pt;break;case"defaultValue":y=pt;break;case"children":case"dangerouslySetInnerHTML":if(pt!=null)throw Error(s(137,n));break;default:Ye(e,n,o,pt,a,null)}}Un(e,d,y,X,J,_,u,!1);return;case"select":me("invalid",e),o=_=d=null;for(u in a)if(a.hasOwnProperty(u)&&(y=a[u],y!=null))switch(u){case"value":d=y;break;case"defaultValue":_=y;break;case"multiple":o=y;default:Ye(e,n,u,y,a,null)}n=d,a=_,e.multiple=!!o,n!=null?mn(e,!!o,n,!1):a!=null&&mn(e,!!o,a,!0);return;case"textarea":me("invalid",e),d=u=o=null;for(_ in a)if(a.hasOwnProperty(_)&&(y=a[_],y!=null))switch(_){case"value":o=y;break;case"defaultValue":u=y;break;case"children":d=y;break;case"dangerouslySetInnerHTML":if(y!=null)throw Error(s(91));break;default:Ye(e,n,_,y,a,null)}Mi(e,o,u,d);return;case"option":for(X in a)a.hasOwnProperty(X)&&(o=a[X],o!=null)&&(X==="selected"?e.selected=o&&typeof o!="function"&&typeof o!="symbol":Ye(e,n,X,o,a,null));return;case"dialog":me("beforetoggle",e),me("toggle",e),me("cancel",e),me("close",e);break;case"iframe":case"object":me("load",e);break;case"video":case"audio":for(o=0;o<Bo.length;o++)me(Bo[o],e);break;case"image":me("error",e),me("load",e);break;case"details":me("toggle",e);break;case"embed":case"source":case"link":me("error",e),me("load",e);case"area":case"base":case"br":case"col":case"hr":case"keygen":case"meta":case"param":case"track":case"wbr":case"menuitem":for(J in a)if(a.hasOwnProperty(J)&&(o=a[J],o!=null))switch(J){case"children":case"dangerouslySetInnerHTML":throw Error(s(137,n));default:Ye(e,n,J,o,a,null)}return;default:if(be(n)){for(pt in a)a.hasOwnProperty(pt)&&(o=a[pt],o!==void 0&&$f(e,n,pt,o,a,void 0));return}}for(y in a)a.hasOwnProperty(y)&&(o=a[y],o!=null&&Ye(e,n,y,o,a,null))}function Ig(e,n,a,o){switch(n){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"input":var u=null,d=null,_=null,y=null,X=null,J=null,pt=null;for(ot in a){var _t=a[ot];if(a.hasOwnProperty(ot)&&_t!=null)switch(ot){case"checked":break;case"value":break;case"defaultValue":X=_t;default:o.hasOwnProperty(ot)||Ye(e,n,ot,null,o,_t)}}for(var st in o){var ot=o[st];if(_t=a[st],o.hasOwnProperty(st)&&(ot!=null||_t!=null))switch(st){case"type":d=ot;break;case"name":u=ot;break;case"checked":J=ot;break;case"defaultChecked":pt=ot;break;case"value":_=ot;break;case"defaultValue":y=ot;break;case"children":case"dangerouslySetInnerHTML":if(ot!=null)throw Error(s(137,n));break;default:ot!==_t&&Ye(e,n,st,ot,o,_t)}}Ht(e,_,y,X,J,pt,d,u);return;case"select":ot=_=y=st=null;for(d in a)if(X=a[d],a.hasOwnProperty(d)&&X!=null)switch(d){case"value":break;case"multiple":ot=X;default:o.hasOwnProperty(d)||Ye(e,n,d,null,o,X)}for(u in o)if(d=o[u],X=a[u],o.hasOwnProperty(u)&&(d!=null||X!=null))switch(u){case"value":st=d;break;case"defaultValue":y=d;break;case"multiple":_=d;default:d!==X&&Ye(e,n,u,d,o,X)}n=y,a=_,o=ot,st!=null?mn(e,!!a,st,!1):!!o!=!!a&&(n!=null?mn(e,!!a,n,!0):mn(e,!!a,a?[]:"",!1));return;case"textarea":ot=st=null;for(y in a)if(u=a[y],a.hasOwnProperty(y)&&u!=null&&!o.hasOwnProperty(y))switch(y){case"value":break;case"children":break;default:Ye(e,n,y,null,o,u)}for(_ in o)if(u=o[_],d=a[_],o.hasOwnProperty(_)&&(u!=null||d!=null))switch(_){case"value":st=u;break;case"defaultValue":ot=u;break;case"children":break;case"dangerouslySetInnerHTML":if(u!=null)throw Error(s(91));break;default:u!==d&&Ye(e,n,_,u,o,d)}ni(e,st,ot);return;case"option":for(var Vt in a)st=a[Vt],a.hasOwnProperty(Vt)&&st!=null&&!o.hasOwnProperty(Vt)&&(Vt==="selected"?e.selected=!1:Ye(e,n,Vt,null,o,st));for(X in o)st=o[X],ot=a[X],o.hasOwnProperty(X)&&st!==ot&&(st!=null||ot!=null)&&(X==="selected"?e.selected=st&&typeof st!="function"&&typeof st!="symbol":Ye(e,n,X,st,o,ot));return;case"img":case"link":case"area":case"base":case"br":case"col":case"embed":case"hr":case"keygen":case"meta":case"param":case"source":case"track":case"wbr":case"menuitem":for(var jt in a)st=a[jt],a.hasOwnProperty(jt)&&st!=null&&!o.hasOwnProperty(jt)&&Ye(e,n,jt,null,o,st);for(J in o)if(st=o[J],ot=a[J],o.hasOwnProperty(J)&&st!==ot&&(st!=null||ot!=null))switch(J){case"children":case"dangerouslySetInnerHTML":if(st!=null)throw Error(s(137,n));break;default:Ye(e,n,J,st,o,ot)}return;default:if(be(n)){for(var Ge in a)st=a[Ge],a.hasOwnProperty(Ge)&&st!==void 0&&!o.hasOwnProperty(Ge)&&$f(e,n,Ge,void 0,o,st);for(pt in o)st=o[pt],ot=a[pt],!o.hasOwnProperty(pt)||st===ot||st===void 0&&ot===void 0||$f(e,n,pt,st,o,ot);return}}for(var q in a)st=a[q],a.hasOwnProperty(q)&&st!=null&&!o.hasOwnProperty(q)&&Ye(e,n,q,null,o,st);for(_t in o)st=o[_t],ot=a[_t],!o.hasOwnProperty(_t)||st===ot||st==null&&ot==null||Ye(e,n,_t,st,o,ot)}function xT(e){switch(e){case"css":case"script":case"font":case"img":case"image":case"input":case"link":return!0;default:return!1}}function Lg(){if(typeof performance.getEntriesByType=="function"){for(var e=0,n=0,a=performance.getEntriesByType("resource"),o=0;o<a.length;o++){var u=a[o],d=u.transferSize,_=u.initiatorType,y=u.duration;if(d&&y&&xT(_)){for(_=0,y=u.responseEnd,o+=1;o<a.length;o++){var X=a[o],J=X.startTime;if(J>y)break;var pt=X.transferSize,_t=X.initiatorType;pt&&xT(_t)&&(X=X.responseEnd,_+=pt*(X<y?1:(y-J)/(X-J)))}if(--o,n+=8*(d+_)/(u.duration/1e3),e++,10<e)break}}if(0<e)return n/e/1e6}return navigator.connection&&(e=navigator.connection.downlink,typeof e=="number")?e:5}var Qf=null,jf=null;function lc(e){return e.nodeType===9?e:e.ownerDocument}function NT(e){switch(e){case"http://www.w3.org/2000/svg":return 1;case"http://www.w3.org/1998/Math/MathML":return 2;default:return 0}}function MT(e,n){if(e===0)switch(n){case"svg":return 1;case"math":return 2;default:return 0}return e===1&&n==="foreignObject"?0:e}function Jf(e,n){return e==="textarea"||e==="noscript"||typeof n.children=="string"||typeof n.children=="number"||typeof n.children=="bigint"||typeof n.dangerouslySetInnerHTML=="object"&&n.dangerouslySetInnerHTML!==null&&n.dangerouslySetInnerHTML.__html!=null}var th=null;function Ug(){var e=window.event;return e&&e.type==="popstate"?e===th?!1:(th=e,!0):(th=null,!1)}var RT=typeof setTimeout=="function"?setTimeout:void 0,Fg=typeof clearTimeout=="function"?clearTimeout:void 0,CT=typeof Promise=="function"?Promise:void 0,wg=typeof queueMicrotask=="function"?queueMicrotask:typeof CT<"u"?function(e){return CT.resolve(null).then(e).catch(Bg)}:RT;function Bg(e){setTimeout(function(){throw e})}function ns(e){return e==="head"}function yT(e,n){var a=n,o=0;do{var u=a.nextSibling;if(e.removeChild(a),u&&u.nodeType===8)if(a=u.data,a==="/$"||a==="/&"){if(o===0){e.removeChild(u),yr(n);return}o--}else if(a==="$"||a==="$?"||a==="$~"||a==="$!"||a==="&")o++;else if(a==="html")Po(e.ownerDocument.documentElement);else if(a==="head"){a=e.ownerDocument.head,Po(a);for(var d=a.firstChild;d;){var _=d.nextSibling,y=d.nodeName;d[Ua]||y==="SCRIPT"||y==="STYLE"||y==="LINK"&&d.rel.toLowerCase()==="stylesheet"||a.removeChild(d),d=_}}else a==="body"&&Po(e.ownerDocument.body);a=u}while(a);yr(n)}function DT(e,n){var a=e;e=0;do{var o=a.nextSibling;if(a.nodeType===1?n?(a._stashedDisplay=a.style.display,a.style.display="none"):(a.style.display=a._stashedDisplay||"",a.getAttribute("style")===""&&a.removeAttribute("style")):a.nodeType===3&&(n?(a._stashedText=a.nodeValue,a.nodeValue=""):a.nodeValue=a._stashedText||""),o&&o.nodeType===8)if(a=o.data,a==="/$"){if(e===0)break;e--}else a!=="$"&&a!=="$?"&&a!=="$~"&&a!=="$!"||e++;a=o}while(a)}function eh(e){var n=e.firstChild;for(n&&n.nodeType===10&&(n=n.nextSibling);n;){var a=n;switch(n=n.nextSibling,a.nodeName){case"HTML":case"HEAD":case"BODY":eh(a),io(a);continue;case"SCRIPT":case"STYLE":continue;case"LINK":if(a.rel.toLowerCase()==="stylesheet")continue}e.removeChild(a)}}function Xg(e,n,a,o){for(;e.nodeType===1;){var u=a;if(e.nodeName.toLowerCase()!==n.toLowerCase()){if(!o&&(e.nodeName!=="INPUT"||e.type!=="hidden"))break}else if(o){if(!e[Ua])switch(n){case"meta":if(!e.hasAttribute("itemprop"))break;return e;case"link":if(d=e.getAttribute("rel"),d==="stylesheet"&&e.hasAttribute("data-precedence"))break;if(d!==u.rel||e.getAttribute("href")!==(u.href==null||u.href===""?null:u.href)||e.getAttribute("crossorigin")!==(u.crossOrigin==null?null:u.crossOrigin)||e.getAttribute("title")!==(u.title==null?null:u.title))break;return e;case"style":if(e.hasAttribute("data-precedence"))break;return e;case"script":if(d=e.getAttribute("src"),(d!==(u.src==null?null:u.src)||e.getAttribute("type")!==(u.type==null?null:u.type)||e.getAttribute("crossorigin")!==(u.crossOrigin==null?null:u.crossOrigin))&&d&&e.hasAttribute("async")&&!e.hasAttribute("itemprop"))break;return e;default:return e}}else if(n==="input"&&e.type==="hidden"){var d=u.name==null?null:""+u.name;if(u.type==="hidden"&&e.getAttribute("name")===d)return e}else return e;if(e=vi(e.nextSibling),e===null)break}return null}function Pg(e,n,a){if(n==="")return null;for(;e.nodeType!==3;)if((e.nodeType!==1||e.nodeName!=="INPUT"||e.type!=="hidden")&&!a||(e=vi(e.nextSibling),e===null))return null;return e}function OT(e,n){for(;e.nodeType!==8;)if((e.nodeType!==1||e.nodeName!=="INPUT"||e.type!=="hidden")&&!n||(e=vi(e.nextSibling),e===null))return null;return e}function nh(e){return e.data==="$?"||e.data==="$~"}function ih(e){return e.data==="$!"||e.data==="$?"&&e.ownerDocument.readyState!=="loading"}function Hg(e,n){var a=e.ownerDocument;if(e.data==="$~")e._reactRetry=n;else if(e.data!=="$?"||a.readyState!=="loading")n();else{var o=function(){n(),a.removeEventListener("DOMContentLoaded",o)};a.addEventListener("DOMContentLoaded",o),e._reactRetry=o}}function vi(e){for(;e!=null;e=e.nextSibling){var n=e.nodeType;if(n===1||n===3)break;if(n===8){if(n=e.data,n==="$"||n==="$!"||n==="$?"||n==="$~"||n==="&"||n==="F!"||n==="F")break;if(n==="/$"||n==="/&")return null}}return e}var ah=null;function bT(e){e=e.nextSibling;for(var n=0;e;){if(e.nodeType===8){var a=e.data;if(a==="/$"||a==="/&"){if(n===0)return vi(e.nextSibling);n--}else a!=="$"&&a!=="$!"&&a!=="$?"&&a!=="$~"&&a!=="&"||n++}e=e.nextSibling}return null}function IT(e){e=e.previousSibling;for(var n=0;e;){if(e.nodeType===8){var a=e.data;if(a==="$"||a==="$!"||a==="$?"||a==="$~"||a==="&"){if(n===0)return e;n--}else a!=="/$"&&a!=="/&"||n++}e=e.previousSibling}return null}function LT(e,n,a){switch(n=lc(a),e){case"html":if(e=n.documentElement,!e)throw Error(s(452));return e;case"head":if(e=n.head,!e)throw Error(s(453));return e;case"body":if(e=n.body,!e)throw Error(s(454));return e;default:throw Error(s(451))}}function Po(e){for(var n=e.attributes;n.length;)e.removeAttributeNode(n[0]);io(e)}var Ai=new Map,UT=new Set;function cc(e){return typeof e.getRootNode=="function"?e.getRootNode():e.nodeType===9?e:e.ownerDocument}var _a=P.d;P.d={f:Yg,r:Gg,D:zg,C:Vg,L:Wg,m:kg,X:Zg,S:Kg,M:qg};function Yg(){var e=_a.f(),n=tc();return e||n}function Gg(e){var n=wa(e);n!==null&&n.tag===5&&n.type==="form"?Q1(n):_a.r(e)}var Mr=typeof document>"u"?null:document;function FT(e,n,a){var o=Mr;if(o&&typeof n=="string"&&n){var u=Ue(n);u='link[rel="'+e+'"][href="'+u+'"]',typeof a=="string"&&(u+='[crossorigin="'+a+'"]'),UT.has(u)||(UT.add(u),e={rel:e,crossOrigin:a,href:n},o.querySelector(u)===null&&(n=o.createElement("link"),On(n,"link",e),un(n),o.head.appendChild(n)))}}function zg(e){_a.D(e),FT("dns-prefetch",e,null)}function Vg(e,n){_a.C(e,n),FT("preconnect",e,n)}function Wg(e,n,a){_a.L(e,n,a);var o=Mr;if(o&&e&&n){var u='link[rel="preload"][as="'+Ue(n)+'"]';n==="image"&&a&&a.imageSrcSet?(u+='[imagesrcset="'+Ue(a.imageSrcSet)+'"]',typeof a.imageSizes=="string"&&(u+='[imagesizes="'+Ue(a.imageSizes)+'"]')):u+='[href="'+Ue(e)+'"]';var d=u;switch(n){case"style":d=Rr(e);break;case"script":d=Cr(e)}Ai.has(d)||(e=E({rel:"preload",href:n==="image"&&a&&a.imageSrcSet?void 0:e,as:n},a),Ai.set(d,e),o.querySelector(u)!==null||n==="style"&&o.querySelector(Ho(d))||n==="script"&&o.querySelector(Yo(d))||(n=o.createElement("link"),On(n,"link",e),un(n),o.head.appendChild(n)))}}function kg(e,n){_a.m(e,n);var a=Mr;if(a&&e){var o=n&&typeof n.as=="string"?n.as:"script",u='link[rel="modulepreload"][as="'+Ue(o)+'"][href="'+Ue(e)+'"]',d=u;switch(o){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":d=Cr(e)}if(!Ai.has(d)&&(e=E({rel:"modulepreload",href:e},n),Ai.set(d,e),a.querySelector(u)===null)){switch(o){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":if(a.querySelector(Yo(d)))return}o=a.createElement("link"),On(o,"link",e),un(o),a.head.appendChild(o)}}}function Kg(e,n,a){_a.S(e,n,a);var o=Mr;if(o&&e){var u=Ba(o).hoistableStyles,d=Rr(e);n=n||"default";var _=u.get(d);if(!_){var y={loading:0,preload:null};if(_=o.querySelector(Ho(d)))y.loading=5;else{e=E({rel:"stylesheet",href:e,"data-precedence":n},a),(a=Ai.get(d))&&sh(e,a);var X=_=o.createElement("link");un(X),On(X,"link",e),X._p=new Promise(function(J,pt){X.onload=J,X.onerror=pt}),X.addEventListener("load",function(){y.loading|=1}),X.addEventListener("error",function(){y.loading|=2}),y.loading|=4,uc(_,n,o)}_={type:"stylesheet",instance:_,count:1,state:y},u.set(d,_)}}}function Zg(e,n){_a.X(e,n);var a=Mr;if(a&&e){var o=Ba(a).hoistableScripts,u=Cr(e),d=o.get(u);d||(d=a.querySelector(Yo(u)),d||(e=E({src:e,async:!0},n),(n=Ai.get(u))&&rh(e,n),d=a.createElement("script"),un(d),On(d,"link",e),a.head.appendChild(d)),d={type:"script",instance:d,count:1,state:null},o.set(u,d))}}function qg(e,n){_a.M(e,n);var a=Mr;if(a&&e){var o=Ba(a).hoistableScripts,u=Cr(e),d=o.get(u);d||(d=a.querySelector(Yo(u)),d||(e=E({src:e,async:!0,type:"module"},n),(n=Ai.get(u))&&rh(e,n),d=a.createElement("script"),un(d),On(d,"link",e),a.head.appendChild(d)),d={type:"script",instance:d,count:1,state:null},o.set(u,d))}}function wT(e,n,a,o){var u=(u=rt.current)?cc(u):null;if(!u)throw Error(s(446));switch(e){case"meta":case"title":return null;case"style":return typeof a.precedence=="string"&&typeof a.href=="string"?(n=Rr(a.href),a=Ba(u).hoistableStyles,o=a.get(n),o||(o={type:"style",instance:null,count:0,state:null},a.set(n,o)),o):{type:"void",instance:null,count:0,state:null};case"link":if(a.rel==="stylesheet"&&typeof a.href=="string"&&typeof a.precedence=="string"){e=Rr(a.href);var d=Ba(u).hoistableStyles,_=d.get(e);if(_||(u=u.ownerDocument||u,_={type:"stylesheet",instance:null,count:0,state:{loading:0,preload:null}},d.set(e,_),(d=u.querySelector(Ho(e)))&&!d._p&&(_.instance=d,_.state.loading=5),Ai.has(e)||(a={rel:"preload",as:"style",href:a.href,crossOrigin:a.crossOrigin,integrity:a.integrity,media:a.media,hrefLang:a.hrefLang,referrerPolicy:a.referrerPolicy},Ai.set(e,a),d||$g(u,e,a,_.state))),n&&o===null)throw Error(s(528,""));return _}if(n&&o!==null)throw Error(s(529,""));return null;case"script":return n=a.async,a=a.src,typeof a=="string"&&n&&typeof n!="function"&&typeof n!="symbol"?(n=Cr(a),a=Ba(u).hoistableScripts,o=a.get(n),o||(o={type:"script",instance:null,count:0,state:null},a.set(n,o)),o):{type:"void",instance:null,count:0,state:null};default:throw Error(s(444,e))}}function Rr(e){return'href="'+Ue(e)+'"'}function Ho(e){return'link[rel="stylesheet"]['+e+"]"}function BT(e){return E({},e,{"data-precedence":e.precedence,precedence:null})}function $g(e,n,a,o){e.querySelector('link[rel="preload"][as="style"]['+n+"]")?o.loading=1:(n=e.createElement("link"),o.preload=n,n.addEventListener("load",function(){return o.loading|=1}),n.addEventListener("error",function(){return o.loading|=2}),On(n,"link",a),un(n),e.head.appendChild(n))}function Cr(e){return'[src="'+Ue(e)+'"]'}function Yo(e){return"script[async]"+e}function XT(e,n,a){if(n.count++,n.instance===null)switch(n.type){case"style":var o=e.querySelector('style[data-href~="'+Ue(a.href)+'"]');if(o)return n.instance=o,un(o),o;var u=E({},a,{"data-href":a.href,"data-precedence":a.precedence,href:null,precedence:null});return o=(e.ownerDocument||e).createElement("style"),un(o),On(o,"style",u),uc(o,a.precedence,e),n.instance=o;case"stylesheet":u=Rr(a.href);var d=e.querySelector(Ho(u));if(d)return n.state.loading|=4,n.instance=d,un(d),d;o=BT(a),(u=Ai.get(u))&&sh(o,u),d=(e.ownerDocument||e).createElement("link"),un(d);var _=d;return _._p=new Promise(function(y,X){_.onload=y,_.onerror=X}),On(d,"link",o),n.state.loading|=4,uc(d,a.precedence,e),n.instance=d;case"script":return d=Cr(a.src),(u=e.querySelector(Yo(d)))?(n.instance=u,un(u),u):(o=a,(u=Ai.get(d))&&(o=E({},a),rh(o,u)),e=e.ownerDocument||e,u=e.createElement("script"),un(u),On(u,"link",o),e.head.appendChild(u),n.instance=u);case"void":return null;default:throw Error(s(443,n.type))}else n.type==="stylesheet"&&(n.state.loading&4)===0&&(o=n.instance,n.state.loading|=4,uc(o,a.precedence,e));return n.instance}function uc(e,n,a){for(var o=a.querySelectorAll('link[rel="stylesheet"][data-precedence],style[data-precedence]'),u=o.length?o[o.length-1]:null,d=u,_=0;_<o.length;_++){var y=o[_];if(y.dataset.precedence===n)d=y;else if(d!==u)break}d?d.parentNode.insertBefore(e,d.nextSibling):(n=a.nodeType===9?a.head:a,n.insertBefore(e,n.firstChild))}function sh(e,n){e.crossOrigin==null&&(e.crossOrigin=n.crossOrigin),e.referrerPolicy==null&&(e.referrerPolicy=n.referrerPolicy),e.title==null&&(e.title=n.title)}function rh(e,n){e.crossOrigin==null&&(e.crossOrigin=n.crossOrigin),e.referrerPolicy==null&&(e.referrerPolicy=n.referrerPolicy),e.integrity==null&&(e.integrity=n.integrity)}var fc=null;function PT(e,n,a){if(fc===null){var o=new Map,u=fc=new Map;u.set(a,o)}else u=fc,o=u.get(a),o||(o=new Map,u.set(a,o));if(o.has(e))return o;for(o.set(e,null),a=a.getElementsByTagName(e),u=0;u<a.length;u++){var d=a[u];if(!(d[Ua]||d[rn]||e==="link"&&d.getAttribute("rel")==="stylesheet")&&d.namespaceURI!=="http://www.w3.org/2000/svg"){var _=d.getAttribute(n)||"";_=e+_;var y=o.get(_);y?y.push(d):o.set(_,[d])}}return o}function HT(e,n,a){e=e.ownerDocument||e,e.head.insertBefore(a,n==="title"?e.querySelector("head > title"):null)}function Qg(e,n,a){if(a===1||n.itemProp!=null)return!1;switch(e){case"meta":case"title":return!0;case"style":if(typeof n.precedence!="string"||typeof n.href!="string"||n.href==="")break;return!0;case"link":if(typeof n.rel!="string"||typeof n.href!="string"||n.href===""||n.onLoad||n.onError)break;return n.rel==="stylesheet"?(e=n.disabled,typeof n.precedence=="string"&&e==null):!0;case"script":if(n.async&&typeof n.async!="function"&&typeof n.async!="symbol"&&!n.onLoad&&!n.onError&&n.src&&typeof n.src=="string")return!0}return!1}function YT(e){return!(e.type==="stylesheet"&&(e.state.loading&3)===0)}function jg(e,n,a,o){if(a.type==="stylesheet"&&(typeof o.media!="string"||matchMedia(o.media).matches!==!1)&&(a.state.loading&4)===0){if(a.instance===null){var u=Rr(o.href),d=n.querySelector(Ho(u));if(d){n=d._p,n!==null&&typeof n=="object"&&typeof n.then=="function"&&(e.count++,e=hc.bind(e),n.then(e,e)),a.state.loading|=4,a.instance=d,un(d);return}d=n.ownerDocument||n,o=BT(o),(u=Ai.get(u))&&sh(o,u),d=d.createElement("link"),un(d);var _=d;_._p=new Promise(function(y,X){_.onload=y,_.onerror=X}),On(d,"link",o),a.instance=d}e.stylesheets===null&&(e.stylesheets=new Map),e.stylesheets.set(a,n),(n=a.state.preload)&&(a.state.loading&3)===0&&(e.count++,a=hc.bind(e),n.addEventListener("load",a),n.addEventListener("error",a))}}var oh=0;function Jg(e,n){return e.stylesheets&&e.count===0&&pc(e,e.stylesheets),0<e.count||0<e.imgCount?function(a){var o=setTimeout(function(){if(e.stylesheets&&pc(e,e.stylesheets),e.unsuspend){var d=e.unsuspend;e.unsuspend=null,d()}},6e4+n);0<e.imgBytes&&oh===0&&(oh=62500*Lg());var u=setTimeout(function(){if(e.waitingForImages=!1,e.count===0&&(e.stylesheets&&pc(e,e.stylesheets),e.unsuspend)){var d=e.unsuspend;e.unsuspend=null,d()}},(e.imgBytes>oh?50:800)+n);return e.unsuspend=a,function(){e.unsuspend=null,clearTimeout(o),clearTimeout(u)}}:null}function hc(){if(this.count--,this.count===0&&(this.imgCount===0||!this.waitingForImages)){if(this.stylesheets)pc(this,this.stylesheets);else if(this.unsuspend){var e=this.unsuspend;this.unsuspend=null,e()}}}var dc=null;function pc(e,n){e.stylesheets=null,e.unsuspend!==null&&(e.count++,dc=new Map,n.forEach(t_,e),dc=null,hc.call(e))}function t_(e,n){if(!(n.state.loading&4)){var a=dc.get(e);if(a)var o=a.get(null);else{a=new Map,dc.set(e,a);for(var u=e.querySelectorAll("link[data-precedence],style[data-precedence]"),d=0;d<u.length;d++){var _=u[d];(_.nodeName==="LINK"||_.getAttribute("media")!=="not all")&&(a.set(_.dataset.precedence,_),o=_)}o&&a.set(null,o)}u=n.instance,_=u.getAttribute("data-precedence"),d=a.get(_)||o,d===o&&a.set(null,u),a.set(_,u),this.count++,o=hc.bind(this),u.addEventListener("load",o),u.addEventListener("error",o),d?d.parentNode.insertBefore(u,d.nextSibling):(e=e.nodeType===9?e.head:e,e.insertBefore(u,e.firstChild)),n.state.loading|=4}}var Go={$$typeof:I,Provider:null,Consumer:null,_currentValue:it,_currentValue2:it,_threadCount:0};function e_(e,n,a,o,u,d,_,y,X){this.tag=1,this.containerInfo=e,this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.next=this.pendingContext=this.context=this.cancelPendingCommit=null,this.callbackPriority=0,this.expirationTimes=Wt(-1),this.entangledLanes=this.shellSuspendCounter=this.errorRecoveryDisabledLanes=this.expiredLanes=this.warmLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=Wt(0),this.hiddenUpdates=Wt(null),this.identifierPrefix=o,this.onUncaughtError=u,this.onCaughtError=d,this.onRecoverableError=_,this.pooledCache=null,this.pooledCacheLanes=0,this.formState=X,this.incompleteTransitions=new Map}function GT(e,n,a,o,u,d,_,y,X,J,pt,_t){return e=new e_(e,n,a,_,X,J,pt,_t,y),n=1,d===!0&&(n|=24),d=si(3,null,null,n),e.current=d,d.stateNode=e,n=Pu(),n.refCount++,e.pooledCache=n,n.refCount++,d.memoizedState={element:o,isDehydrated:a,cache:n},zu(d),e}function zT(e){return e?(e=ar,e):ar}function VT(e,n,a,o,u,d){u=zT(u),o.context===null?o.context=u:o.pendingContext=u,o=Wa(n),o.payload={element:a},d=d===void 0?null:d,d!==null&&(o.callback=d),a=ka(e,o,n),a!==null&&(qn(a,e,n),_o(a,e,n))}function WT(e,n){if(e=e.memoizedState,e!==null&&e.dehydrated!==null){var a=e.retryLane;e.retryLane=a!==0&&a<n?a:n}}function lh(e,n){WT(e,n),(e=e.alternate)&&WT(e,n)}function kT(e){if(e.tag===13||e.tag===31){var n=Ms(e,67108864);n!==null&&qn(n,e,67108864),lh(e,67108864)}}function KT(e){if(e.tag===13||e.tag===31){var n=ui();n=gs(n);var a=Ms(e,n);a!==null&&qn(a,e,n),lh(e,n)}}var Tc=!0;function n_(e,n,a,o){var u=L.T;L.T=null;var d=P.p;try{P.p=2,ch(e,n,a,o)}finally{P.p=d,L.T=u}}function i_(e,n,a,o){var u=L.T;L.T=null;var d=P.p;try{P.p=8,ch(e,n,a,o)}finally{P.p=d,L.T=u}}function ch(e,n,a,o){if(Tc){var u=uh(o);if(u===null)qf(e,n,o,mc,a),qT(e,o);else if(s_(u,e,n,a,o))o.stopPropagation();else if(qT(e,o),n&4&&-1<a_.indexOf(e)){for(;u!==null;){var d=wa(u);if(d!==null)switch(d.tag){case 3:if(d=d.stateNode,d.current.memoizedState.isDehydrated){var _=Rt(d.pendingLanes);if(_!==0){var y=d;for(y.pendingLanes|=2,y.entangledLanes|=2;_;){var X=1<<31-Ut(_);y.entanglements[1]|=X,_&=~X}Gi(d),(De&6)===0&&(jl=Ct()+500,wo(0))}}break;case 31:case 13:y=Ms(d,2),y!==null&&qn(y,d,2),tc(),lh(d,2)}if(d=uh(o),d===null&&qf(e,n,o,mc,a),d===u)break;u=d}u!==null&&o.stopPropagation()}else qf(e,n,o,null,a)}}function uh(e){return e=fu(e),fh(e)}var mc=null;function fh(e){if(mc=null,e=Fa(e),e!==null){var n=c(e);if(n===null)e=null;else{var a=n.tag;if(a===13){if(e=f(n),e!==null)return e;e=null}else if(a===31){if(e=T(n),e!==null)return e;e=null}else if(a===3){if(n.stateNode.current.memoizedState.isDehydrated)return n.tag===3?n.stateNode.containerInfo:null;e=null}else n!==e&&(e=null)}}return mc=e,null}function ZT(e){switch(e){case"beforetoggle":case"cancel":case"click":case"close":case"contextmenu":case"copy":case"cut":case"auxclick":case"dblclick":case"dragend":case"dragstart":case"drop":case"focusin":case"focusout":case"input":case"invalid":case"keydown":case"keypress":case"keyup":case"mousedown":case"mouseup":case"paste":case"pause":case"play":case"pointercancel":case"pointerdown":case"pointerup":case"ratechange":case"reset":case"resize":case"seeked":case"submit":case"toggle":case"touchcancel":case"touchend":case"touchstart":case"volumechange":case"change":case"selectionchange":case"textInput":case"compositionstart":case"compositionend":case"compositionupdate":case"beforeblur":case"afterblur":case"beforeinput":case"blur":case"fullscreenchange":case"focus":case"hashchange":case"popstate":case"select":case"selectstart":return 2;case"drag":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"mousemove":case"mouseout":case"mouseover":case"pointermove":case"pointerout":case"pointerover":case"scroll":case"touchmove":case"wheel":case"mouseenter":case"mouseleave":case"pointerenter":case"pointerleave":return 8;case"message":switch(qe()){case b:return 2;case N:return 8;case Q:case St:return 32;case xt:return 268435456;default:return 32}default:return 32}}var hh=!1,is=null,as=null,ss=null,zo=new Map,Vo=new Map,rs=[],a_="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset".split(" ");function qT(e,n){switch(e){case"focusin":case"focusout":is=null;break;case"dragenter":case"dragleave":as=null;break;case"mouseover":case"mouseout":ss=null;break;case"pointerover":case"pointerout":zo.delete(n.pointerId);break;case"gotpointercapture":case"lostpointercapture":Vo.delete(n.pointerId)}}function Wo(e,n,a,o,u,d){return e===null||e.nativeEvent!==d?(e={blockedOn:n,domEventName:a,eventSystemFlags:o,nativeEvent:d,targetContainers:[u]},n!==null&&(n=wa(n),n!==null&&kT(n)),e):(e.eventSystemFlags|=o,n=e.targetContainers,u!==null&&n.indexOf(u)===-1&&n.push(u),e)}function s_(e,n,a,o,u){switch(n){case"focusin":return is=Wo(is,e,n,a,o,u),!0;case"dragenter":return as=Wo(as,e,n,a,o,u),!0;case"mouseover":return ss=Wo(ss,e,n,a,o,u),!0;case"pointerover":var d=u.pointerId;return zo.set(d,Wo(zo.get(d)||null,e,n,a,o,u)),!0;case"gotpointercapture":return d=u.pointerId,Vo.set(d,Wo(Vo.get(d)||null,e,n,a,o,u)),!0}return!1}function $T(e){var n=Fa(e.target);if(n!==null){var a=c(n);if(a!==null){if(n=a.tag,n===13){if(n=f(a),n!==null){e.blockedOn=n,eo(e.priority,function(){KT(a)});return}}else if(n===31){if(n=T(a),n!==null){e.blockedOn=n,eo(e.priority,function(){KT(a)});return}}else if(n===3&&a.stateNode.current.memoizedState.isDehydrated){e.blockedOn=a.tag===3?a.stateNode.containerInfo:null;return}}}e.blockedOn=null}function Ec(e){if(e.blockedOn!==null)return!1;for(var n=e.targetContainers;0<n.length;){var a=uh(e.nativeEvent);if(a===null){a=e.nativeEvent;var o=new a.constructor(a.type,a);uu=o,a.target.dispatchEvent(o),uu=null}else return n=wa(a),n!==null&&kT(n),e.blockedOn=a,!1;n.shift()}return!0}function QT(e,n,a){Ec(e)&&a.delete(n)}function r_(){hh=!1,is!==null&&Ec(is)&&(is=null),as!==null&&Ec(as)&&(as=null),ss!==null&&Ec(ss)&&(ss=null),zo.forEach(QT),Vo.forEach(QT)}function Sc(e,n){e.blockedOn===n&&(e.blockedOn=null,hh||(hh=!0,r.unstable_scheduleCallback(r.unstable_NormalPriority,r_)))}var gc=null;function jT(e){gc!==e&&(gc=e,r.unstable_scheduleCallback(r.unstable_NormalPriority,function(){gc===e&&(gc=null);for(var n=0;n<e.length;n+=3){var a=e[n],o=e[n+1],u=e[n+2];if(typeof o!="function"){if(fh(o||a)===null)continue;break}var d=wa(a);d!==null&&(e.splice(n,3),n-=3,uf(d,{pending:!0,data:u,method:a.method,action:o},o,u))}}))}function yr(e){function n(X){return Sc(X,e)}is!==null&&Sc(is,e),as!==null&&Sc(as,e),ss!==null&&Sc(ss,e),zo.forEach(n),Vo.forEach(n);for(var a=0;a<rs.length;a++){var o=rs[a];o.blockedOn===e&&(o.blockedOn=null)}for(;0<rs.length&&(a=rs[0],a.blockedOn===null);)$T(a),a.blockedOn===null&&rs.shift();if(a=(e.ownerDocument||e).$$reactFormReplay,a!=null)for(o=0;o<a.length;o+=3){var u=a[o],d=a[o+1],_=u[Rn]||null;if(typeof d=="function")_||jT(a);else if(_){var y=null;if(d&&d.hasAttribute("formAction")){if(u=d,_=d[Rn]||null)y=_.formAction;else if(fh(u)!==null)continue}else y=_.action;typeof y=="function"?a[o+1]=y:(a.splice(o,3),o-=3),jT(a)}}}function JT(){function e(d){d.canIntercept&&d.info==="react-transition"&&d.intercept({handler:function(){return new Promise(function(_){return u=_})},focusReset:"manual",scroll:"manual"})}function n(){u!==null&&(u(),u=null),o||setTimeout(a,20)}function a(){if(!o&&!navigation.transition){var d=navigation.currentEntry;d&&d.url!=null&&navigation.navigate(d.url,{state:d.getState(),info:"react-transition",history:"replace"})}}if(typeof navigation=="object"){var o=!1,u=null;return navigation.addEventListener("navigate",e),navigation.addEventListener("navigatesuccess",n),navigation.addEventListener("navigateerror",n),setTimeout(a,100),function(){o=!0,navigation.removeEventListener("navigate",e),navigation.removeEventListener("navigatesuccess",n),navigation.removeEventListener("navigateerror",n),u!==null&&(u(),u=null)}}}function dh(e){this._internalRoot=e}_c.prototype.render=dh.prototype.render=function(e){var n=this._internalRoot;if(n===null)throw Error(s(409));var a=n.current,o=ui();VT(a,o,e,n,null,null)},_c.prototype.unmount=dh.prototype.unmount=function(){var e=this._internalRoot;if(e!==null){this._internalRoot=null;var n=e.containerInfo;VT(e.current,2,null,e,null,null),tc(),n[ia]=null}};function _c(e){this._internalRoot=e}_c.prototype.unstable_scheduleHydration=function(e){if(e){var n=to();e={blockedOn:null,target:e,priority:n};for(var a=0;a<rs.length&&n!==0&&n<rs[a].priority;a++);rs.splice(a,0,e),a===0&&$T(e)}};var tm=t.version;if(tm!=="19.2.6")throw Error(s(527,tm,"19.2.6"));P.findDOMNode=function(e){var n=e._reactInternals;if(n===void 0)throw typeof e.render=="function"?Error(s(188)):(e=Object.keys(e).join(","),Error(s(268,e)));return e=h(n),e=e!==null?m(e):null,e=e===null?null:e.stateNode,e};var o_={bundleType:0,version:"19.2.6",rendererPackageName:"react-dom",currentDispatcherRef:L,reconcilerVersion:"19.2.6"};if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<"u"){var vc=__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!vc.isDisabled&&vc.supportsFiber)try{ut=vc.inject(o_),ht=vc}catch{}}return Ko.createRoot=function(e,n){if(!l(e))throw Error(s(299));var a=!1,o="",u=op,d=lp,_=cp;return n!=null&&(n.unstable_strictMode===!0&&(a=!0),n.identifierPrefix!==void 0&&(o=n.identifierPrefix),n.onUncaughtError!==void 0&&(u=n.onUncaughtError),n.onCaughtError!==void 0&&(d=n.onCaughtError),n.onRecoverableError!==void 0&&(_=n.onRecoverableError)),n=GT(e,1,!1,null,null,a,o,null,u,d,_,JT),e[ia]=n.current,Zf(e),new dh(n)},Ko.hydrateRoot=function(e,n,a){if(!l(e))throw Error(s(299));var o=!1,u="",d=op,_=lp,y=cp,X=null;return a!=null&&(a.unstable_strictMode===!0&&(o=!0),a.identifierPrefix!==void 0&&(u=a.identifierPrefix),a.onUncaughtError!==void 0&&(d=a.onUncaughtError),a.onCaughtError!==void 0&&(_=a.onCaughtError),a.onRecoverableError!==void 0&&(y=a.onRecoverableError),a.formState!==void 0&&(X=a.formState)),n=GT(e,1,!0,n,a??null,o,u,X,d,_,y,JT),n.context=zT(null),a=n.current,o=ui(),o=gs(o),u=Wa(o),u.callback=null,ka(a,u,o),a=o,n.current.lanes=a,te(n,a),Gi(n),e[ia]=n.current,Zf(e),new _c(n)},Ko.version="19.2.6",Ko}var um;function S_(){if(um)return mh.exports;um=1;function r(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(r)}catch(t){console.error(t)}}return r(),mh.exports=E_(),mh.exports}var dR=S_();const g_=" 11  65  12  65  12  66  12  67  12  68  12  69  13  69  13  70  13  71  13  72  13  73  14  73  14  74  14  75  14  76  14  77  14  78  15  78  15  79  15  80  15  81  16  81  16  82  16  83  16  84  16  85  17  85  17  86  17  87  17  88  17  89  18  89  18  90  18  91  18  92  18  93  18  94  19  94  19  95  19  96  19  97  19  98  19  99  20  99  20  100  20  101  20  102  20  103  20  104  21  104  21  105  21  106  21  107  21  108  21  109  21  110  21  111  21  112  22  112  22  111  22  110  22  109  22  108  22  107  22  106  22  105  22  104  23  104  23  103  24  103  24  102  24  101  24  100  24  99  24  98  25  98  25  97  25  96  25  95  26  95  26  94  26  93  26  92  27  92  27  91  27  90  27  89  27  88  28  88  28  87  28  86  28  85  28  84  28  83  29  83  29  82  29  81  30  81  30  80  30  79  30  78  31  78  31  77  31  76  31  75  32  75  32  74  32  73  32  72  32  71  33  71  33  70  33  69  33  68  34  68  34  67  34  66  44  66  45  66  46  66  47  66  48  66  49  66  50  66  51  66  52  66  53  66  54  66  55  66  56  66  57  66  58  66  59  66  60  66  49  68  49  69  49  70  49  71  49  72  49  73  49  74  49  75  49  76  49  77  49  78  49  79  49  80  49  81  49  82  49  83  49  84  49  85  49  86  49  87  49  88  49  89  49  90  49  91  49  92  49  93  49  94  49  95  49  96  49  97  49  98  49  99  49  100  49  101  49  102  49  103  49  104  41  105  42  105  43  105  44  105  45  105  46  105  47  105  48  105  49  105  50  105  51  105  52  105  53  105  54  105  55  105  56  105  68  68  68  69  68  70  68  71  68  72  68  73  68  74  68  75  68  76  68  77  68  78  68  79  68  80  68  81  68  82  68  83  68  84  68  85  68  86  68  87  68  88  68  89  68  90  68  91  68  92  68  93  68  94  68  95  68  96  68  97  68  98  68  99  68  100  68  101  68  102  68  103  68  104  68  105  68  106  68  107  68  108  70  67  71  67  71  68  72  68  72  69  73  69  73  70  74  70  75  70  75  71  76  71  76  72  77  72  77  73  78  73  78  74  78  75  79  75  79  76  80  76  80  77  81  77  81  78  81  79  82  79  82  80  82  81  81  81  81  82  81  83  80  83  80  84  79  84  79  85  78  85  78  86  77  86  76  86  76  87  75  87  74  87  74  88  73  88  72  88  71  88  70  88  70  89  71  89  71  90  72  90  72  91  72  92  73  92  73  93  74  93  74  94  75  94  75  95  76  95  76  96  76  97  77  97  78  97  78  98  78  99  78  100  79  100  79  101  79  102  80  102  80  103  80  104  81  104  82  104  82  105  82  106  82  107  83  107  83  108  84  108  93  69  94  69  94  70  95  70  96  70  97  70  98  70  99  70  99  69  100  69  101  69  102  69  103  69  104  69  104  68  105  68  106  68  107  68  108  68  109  68  110  68  111  68  112  68  113  68  114  68  115  68  101  71  101  72  101  73  102  73  102  74  102  75  102  76  103  76  103  77  103  78  103  79  103  80  103  81  103  82  103  83  103  84  103  85  103  86  102  86  102  87  102  88  102  89  102  90  102  91  102  92  102  93  102  94  103  94  103  95  103  96  103  97  103  98  104  98  104  99  104  100  104  101  104  102  104  103  104  104  104  105  104  106  104  107  122  71  123  71  123  72  123  73  123  74  123  75  123  76  124  76  124  77  124  78  124  79  124  80  124  81  124  82  124  83  124  84  124  85  124  86  123  86  123  87  123  88  123  89  123  90  124  90  124  91  124  92  124  93  124  94  124  95  124  96  124  97  124  98  124  99  125  99  125  100  125  101  126  101  126  102  127  102  127  103  128  103  128  104  129  104  130  104  131  104  132  104  133  104  133  103  134  103  135  103  135  102  136  102  136  101  137  101  137  100  138  100  138  99  139  99  139  98  140  98  140  97  141  97  141  96  141  95  141  94  141  93  141  92  141  91  141  90  142  90  142  89  142  88  142  87  142  86  142  85  142  84  142  83  142  82  142  81  142  80  143  80  143  79  143  78  143  77  143  76  143  75  143  74  143  73  143  72  143  71  152  102  153  102  153  101  153  100  153  99  153  98  153  97  153  96  153  95  153  94  153  93  153  92  153  91  152  91  152  90  152  89  152  88  152  87  152  86  152  85  152  84  152  83  152  82  152  81  152  80  153  80  153  79  153  78  153  77  153  76  154  76  154  75  154  74  154  73  155  73  155  72  156  72  156  71  157  71  157  70  158  70  159  70  160  70  161  70  162  70  163  70  164  70  164  71  165  71  166  71  167  71  167  72  168  72  168  73  169  73  169  74  170  74  170  75  171  75  171  76  172  76  172  77  172  78  173  78  173  79  173  80  173  81  173  82  173  83  173  84  173  85  172  85  172  86  172  87  172  88  172  89  172  90  172  91  172  92  172  93  172  94  172  95  172  96  173  96  173  97  173  98  173  99  173  100  173  101  173  102  173  103  173  104  173  105  154  87  155  87  156  87  156  88  157  88  158  88  159  88  160  88  161  88  162  88  163  88  163  89  164  89  165  89  166  89  167  89  167  88  168  88  169  88  170  88  171  88  180  72  180  73  181  73  181  74  181  75  181  76  181  77  181  78  182  78  182  79  182  80  182  81  182  82  182  83  182  84  182  85  182  86  182  87  182  88  182  89  181  89  181  90  181  91  181  92  181  93  181  94  181  95  181  96  181  97  182  97  182  98  182  99  182  100  182  101  182  102  182  103  183  103  184  103  185  103  186  103  187  103  187  102  188  102  189  102  190  102  191  102  192  102  192  103  193  103  194  103  195  103  196  103  197  103  198  103  199  103  200  103  200  104  201  104  202  104  212  70  213  70  214  70  215  70  216  70  217  70  218  70  219  70  220  70  221  70  222  70  223  70  224  70  225  70  226  70  227  70  228  70  229  70  230  70  231  70  232  70  221  72  221  73  221  74  221  75  221  76  221  77  221  78  221  79  221  80  221  81  221  82  221  83  221  84  221  85  221  86  221  87  221  88  221  89  221  90  221  91  221  92  221  93  221  94  221  95  221  96  221  97  221  98  221  99  221  100  221  101  221  102  221  103  211  104  212  104  213  104  214  104  215  104  216  104  217  104  218  104  219  104  220  104  221  104  222  104  223  104  224  104  225  104  226  104  227  104  228  104  229  104  242  71  243  71  243  72  244  72  245  72  246  72  247  72  247  71  248  71  249  71  250  71  251  71  252  71  253  71  253  72  254  72  255  72  256  72  257  72  258  72  258  71  259  71  260  71  261  71  262  71  263  71  264  71  252  73  252  74  252  75  253  75  253  76  253  77  253  78  253  79  253  80  253  81  253  82  253  83  253  84  253  85  253  86  254  86  254  87  254  88  254  89  254  90  254  91  254  92  254  93  254  94  254  95  254  96  254  97  254  98  254  99  254  100  254  101  254  102  254  103  254  104  254  105  276  72  277  72  277  73  277  74  278  74  279  74  279  75  279  76  279  77  280  77  280  78  281  78  281  79  282  79  282  80  283  80  283  81  284  81  284  82  284  83  285  83  285  84  286  84  286  85  287  85  287  86  287  87  287  88  287  89  287  90  287  91  287  92  287  93  287  94  288  94  288  95  288  96  288  97  288  98  288  99  288  100  288  101  288  102  288  103  288  104  288  105  288  106  288  107  288  108  288  84  289  84  289  83  290  83  290  82  291  82  291  81  292  81  292  80  292  79  293  79  294  79  294  78  294  77  295  77  295  76  296  76  296  75  297  75  297  74  298  74  298  73  298  72  299  72  299  71  299  70  300  70  300  69  301  69  301  68  302  68  302  67 ",__=" 113  104  113  103  113  102  113  101  113  100  113  99  113  98  113  97  113  96  113  95  113  94  113  93  113  92  113  91  113  90  113  89  113  88  114  88  114  89  115  89  115  90  116  90  116  91  116  92  117  92  117  93  118  93  118  94  119  94  119  95  120  95  120  94  121  94  121  93  122  93  122  92  123  92  123  91  124  91  124  90  125  90  125  89  126  89  126  88  127  88  127  89  127  90  127  91  127  92  127  93  127  94  127  95  127  96  127  97  127  98  127  99  127  100  127  101  127  102  127  103  127  104  147  89  146  89  145  89  144  89  143  89  142  89  141  89  140  89  139  89  138  89  137  89  136  89  135  89  135  90  135  91  135  92  135  93  135  94  135  95  135  96  135  97  135  98  135  99  135  100  135  101  135  102  135  103  135  104  136  104  137  104  138  104  139  104  140  104  141  104  142  104  143  104  144  104  145  104  146  104  147  104  148  104  144  97  143  97  142  97  141  97  140  97  139  97  138  97  137  97  136  97  135  97  156  102  156  101  156  100  156  99  156  98  156  97  156  96  156  95  156  94  156  93  156  92  156  91  156  90  156  89  157  89  157  90  158  90  158  91  158  92  159  92  159  93  159  94  160  94  160  95  160  96  161  96  161  97  162  97  162  98  162  99  163  99  163  100  163  101  164  101  164  100  164  99  164  98  164  97  164  96  164  95  164  94  164  93  164  92  164  91  164  90  164  89  164  88  164  87  171  90  171  91  171  92  171  93  171  94  171  95  171  96  171  97  172  97  172  98  172  99  173  99  173  100  174  100  174  101  175  101  176  101  177  101  178  101  178  100  179  100  179  99  180  99  180  98  181  98  181  97  181  96  181  95  181  94  181  93  181  92  181  91  181  90  181  89  181  88  181  87  181  86  181  85  181  84 ",v_=" 122  90  121  90  120  90  119  90  118  90  117  90  116  90  115  90  114  90  113  90  112  90  111  90  110  90  109  90  108  90  107  90  106  90  105  90  104  90  104  91  104  92  104  93  104  94  104  95  104  96  104  97  104  98  104  99  104  100  104  101  104  102  104  103  104  104  104  105  104  106  104  107  104  108  104  109  105  109  106  109  107  109  108  109  109  109  110  109  111  109  112  109  113  109  114  109  115  109  116  109  117  109  118  109  119  109  120  109  121  109  122  109  123  109  124  109  125  109  126  109  127  109  128  109  106  101  107  101  108  101  109  101  110  101  111  101  112  101  113  101  114  101  115  101  116  101  117  101  118  101  119  101  120  101  121  101  127  93  128  93  129  93  129  94  130  94  130  95  131  95  131  96  132  96  132  97  133  97  133  98  134  98  134  99  135  99  135  100  136  100  136  101  137  101  137  102  138  102  138  103  139  103  139  104  140  104  140  105  141  105  141  106  142  106  142  107  143  107  143  108  129  105  129  104  130  104  130  103  131  103  131  102  132  102  132  101  133  101  133  100  134  100  134  99  135  99  135  98  136  98  136  97  137  97  137  96  138  96  138  95  139  95  139  94  140  94  140  93  141  93  141  92  142  92  142  91  156  93  156  94  156  95  156  96  156  97  156  98  156  99  156  100  156  101  156  102  156  103  156  104  156  105  156  106  156  107  156  108  167  92  168  92  169  92  170  92  171  92  172  92  173  92  174  92  175  92  176  92  177  92  178  92  179  92  180  92  181  92  182  92  183  92  184  92  185  92  186  92  187  92  188  92  189  92  175  94  175  95  175  96  175  97  175  98  175  99  175  100  175  101  175  102  175  103  175  104  175  105  175  106  175  107  175  108  175  109  175  110  175  111  175  112  175  113  175  114 ",A_=" 125  85  126  85  127  85  128  85  129  85  130  85  131  85  132  85  133  85  134  85  135  85  136  85  137  85  130  87  130  88  130  89  130  90  130  91  130  92  130  93  130  94  130  95  130  96  130  97  130  98  130  99  130  100  130  101  130  102  130  103  130  104  130  105  130  106  124  107  125  107  126  107  127  107  128  107  129  107  130  107  131  107  132  107  133  107  134  107  135  107  136  107  146  106  146  105  146  104  146  103  146  102  146  101  146  100  146  99  146  98  146  97  146  96  146  95  146  94  146  93  146  92  146  91  146  90  146  89  146  88  146  87  146  86  147  86  147  87  148  87  148  88  149  88  149  89  150  89  150  90  150  91  151  91  151  92  151  93  152  93  152  94  152  95  152  96  153  96  153  97  154  97  154  98  154  99  154  100  155  100  155  101  155  102  156  102  156  103  157  103  157  104  158  104  158  105  159  105  159  104  159  103  159  102  159  101  159  100  159  99  159  98  159  97  159  96  159  95  159  94  159  93  159  92  159  91  159  90  159  89  159  88  159  87  159  86  159  85  182  85  181  85  180  85  179  85  178  85  177  85  176  85  175  85  174  85  173  85  172  85  171  85  170  85  169  85  169  86  169  87  169  88  169  89  169  90  169  91  169  92  169  93  169  94  169  95  169  96  169  97  169  98  169  99  169  100  169  101  169  102  169  103  169  104  169  105  169  106  171  97  172  97  173  97  174  97  175  97  176  97  177  97  178  97  179  97  180  97  181  97  190  96  191  96  191  95  191  94  192  94  192  93  192  92  192  91  193  91  193  90  194  90  194  89  194  88  195  88  195  87  196  87  196  86  197  86  198  86  199  86  200  86  201  86  202  86  203  86  203  87  204  87  205  87  205  88  206  88  206  89  207  89  207  90  208  90  208  91  208  92  208  93  208  94  209  94  209  95  209  96  210  96  210  97  210  98  210  99  210  100  210  101  209  101  209  102  209  103  209  104  208  104  208  105  207  105  207  106  206  106  206  107  205  107  205  108  204  108  203  108  202  108  201  108  200  108  200  107  199  107  198  107  197  107  197  106  196  106  196  105  195  105  195  104  194  104  194  103  193  103  193  102  192  102  192  101  191  101  191  100  191  99  190  99  190  98  190  97 ",x_=" 106  83  106  84  106  85  106  86  106  87  106  88  106  89  107  89  108  89  109  89  110  89  110  88  110  87  109  87  108  87  107  87  114  87  114  88  114  89  115  89  116  89  117  89  118  89  118  88  118  87  118  88  118  89  118  90  118  91  118  92  118  93  118  94  128  85  128  86  128  87  128  88  128  89  128  90  128  91  130  85  131  85  132  85  132  86  132  87  131  87  130  87  130  88  131  88  131  89  132  89  132  90  133  90  133  91  136  88  136  89  137  89  137  90  138  90  139  90  139  89  140  89  140  88  140  87  139  87  139  86  138  86  138  85  137  85  137  86  136  86  136  87  143  86  144  86  144  87  145  87  145  88  146  88  147  88  147  87  148  87  148  86  148  85  149  85  146  89  146  90  146  91  146  92  156  86  156  87  156  88  156  89  156  90  156  91  156  92  157  85  157  86  158  86  158  87  158  88  159  88  160  88  160  87  161  87  161  86  162  86  162  85  162  86  162  87  162  88  162  89  162  90  162  91  162  92  165  92  166  92  166  91  165  91 ",N_=`'$DYNAMIC
DECLARE SUB SAVER2 ()
DECLARE SUB SAVER3 ()
DECLARE SUB SAVER ()
DECLARE SUB BALL ()
DECLARE SUB COOLER ()
DECLARE SUB COOLX ()
DECLARE SUB CRAPER ()
DECLARE SUB CYBER ()
DECLARE SUB DELTA ()
DECLARE SUB DISCO ()
DECLARE SUB LASER ()
DECLARE SUB LINES ()
DECLARE SUB OMEGA ()
DECLARE SUB SHELLA ()
DECLARE SUB SPHERES ()
DECLARE SUB SPOTS ()
DECLARE SUB TUNNELS ()
DECLARE SUB TYPE1 ()
DECLARE SUB TYPE2 ()
DECLARE SUB COOL ()
DECLARE SUB SHOW (AX$, BX!, BY!)
DECLARE SUB FINISH ()
DECLARE SUB INFO ()
CLEAR
ON ERROR GOTO 669
SCREEN 13: CLS
RANDOMIZE TIMER
FOR X = 16 TO 28 STEP .007
COLOR X
LOCATE 10, 17: PRINT "R O Y"
NEXT X
FOR X = 16 TO 25 STEP .007
COLOR X
LOCATE 13, 16: PRINT "PRESENTS"
NEXT X
SLEEP 1
AX$ = "ROY MASSAAD"
SCREEN 13: CLS
FOR GTS = 1 TO 300
XS = INT(RND * 318) + 1
YS = INT(RND * 198) + 1
COLS = INT(RND * 14) + 18
PSET (XS, YS), COLS
NEXT GTS

OPEN "DATA" FOR INPUT AS #1
O = 25
AX$ = "ROY MASSAAD"
DO
INPUT #1, X: INPUT #1, Y
O = O + .1
CIRCLE (X, Y), 5, O, , , 2
LOOP UNTIL (EOF(1))
G = 20
FOR X = 30 TO 280
G = G + .04
LINE (X, 120)-(X + 5, 125), G
FOR T = 1 TO 500: NEXT T
NEXT X
FOR X = 16 TO 31 STEP .007
COLOR X
LOCATE 20, 12: PRINT "A 1997 PRODUCTION"
NEXT X

SLEEP 1

RANDOMIZE TIMER
ROY = 150
DIM A(ROY), DX(ROY), DY(ROY), XX(ROY), YY(ROY), S(ROY), G(ROY), X(ROY), Y(ROY), B(ROY), XC(ROY), YC(ROY), DD(ROY), SS(ROY)
FOR T = 1 TO ROY
M = 4.7
A(T) = 4.7
DX(T) = INT(RND * 35) + 35
DY(T) = 600
XX(T) = INT(RND * 300) + 10
YY(T) = DY(T)
S(T) = 1
G(T) = 30
X(T) = XX(T): Y(T) = -1
SS(T) = .01
DD(T) = INT(RND * 17) + 5
NEXT T
DO
FOR T = 1 TO ROY
XC(T) = X(T): YC(T) = Y(T)
IF S(T) = 1 THEN A(T) = A(T) + SS(T)
IF S(T) = 2 THEN A(T) = A(T) - SS(T)

X(T) = (COS(A(T)) * DX(T)) + XX(T)
Y(T) = (SIN(A(T)) * DY(T)) + YY(T)

'G(T) = G(T) + 1
'LINE (XC(T), YC(T))-(X(T), Y(T)), G(T)

PRESET (XC(T), YC(T))
PSET (X(T), Y(T)), G(T)

'CIRCLE (XC(T), YC(T)), DD(T), 0
'CIRCLE (X(T), Y(T)), DD(T), G(T)

IF B(T) = 1 AND Y(T) < 200 THEN B(T) = 0

IF Y(T) > 200 AND B(T) = 0 AND S(T) = 1 THEN A(T) = M - (A(T) - M): DX(T) = DX(T) + 20: XX(T) = XX(T) + (DX(T) * 1.25): DY(T) = DY(T) - 20: B(T) = 1: SS(T) = SS(T) + .00001: GOTO 11
IF Y(T) > 200 AND B(T) = 0 AND S(T) = 2 THEN A(T) = M + (M - A(T)): DX(T) = DX(T) + 20: XX(T) = XX(T) - (DX(T) * 1.25): DY(T) = DY(T) - 20: B(T) = 1: SS(T) = SS(T) + .00001: GOTO 11

IF X(T) < 0 AND B(T) = 0 AND S(T) = 2 THEN S(T) = 1: DX(T) = DX(T) + 25: B(T) = 1: SS(T) = SS(T) + .00001: GOTO 11
IF X(T) > 320 AND B(T) = 0 AND S(T) = 1 THEN S(T) = 2: DX(T) = DX(T) + 25: B(T) = 1: SS(T) = SS(T) + .00001: GOTO 11

IF Y(T) > 300 THEN GOSUB 11188
11
NEXT T
LOOP WHILE INKEY$ = ""
ERASE A, DX, DY, XX, YY, S, G, X, Y, B, XC, YC, DD, SS
GOTO 6545
11188
A(T) = 4.7
DX(T) = INT(RND * 35) + 35
DY(T) = 600
XX(T) = INT(RND * 300) + 10
YY(T) = DY(T)
S(T) = 1
X(T) = XX(T): Y(T) = -1
G(T) = G(T) + 1
RETURN






6545
FOR T = 300 TO 1 STEP -.6
CIRCLE (160, 100), T, 0, , , .5
K$ = INKEY$
IF K$ <> "" OR K$ = "" THEN K$ = "\`"
NEXT T
10 CLEAR , , 20000
DES = 2
GGG = 20
SCREEN 13: CLS
FOR GTS = 1 TO 300
XS = INT(RND * 318) + 1
YS = INT(RND * 198) + 1
COLS = INT(RND * 14) + 18
PSET (XS, YS), COLS
NEXT GTS
OPEN "DATA" FOR INPUT AS #1
O = 19
FOR G1 = T TO 465
INPUT #1, X: INPUT #1, Y
O = O + .007
LINE (160, 70)-(X, Y - 50), O
PSET (X, Y - 50), 10
NEXT G1
O = (O - 19) + O
REDIM ACE(500)
REDIM ACE2(500)
FOR G1 = 1 TO 379
INPUT #1, ACE(G1): INPUT #1, ACE2(G1)
NEXT G1
FOR G1 = 379 TO 1 STEP -1
O = O - .01
LINE (160, 70)-(ACE(G1) - 1, (ACE2(G1) + 1) - 50), O
PSET (ACE(G1), ACE2(G1) - 50), 10
NEXT G1
CLOSE #1
ERASE ACE, ACE2
OPEN "DATA" FOR INPUT AS #1
DO
INPUT #1, X: INPUT #1, Y
PSET (X, Y - 50), 10
LOOP UNTIL (EOF(1))
REDIM COL(2500)
CLOSE
OO = 30
OPEN "DATA2" FOR INPUT AS #1
DO
INPUT #1, X: INPUT #1, Y
OO = OO + .1
LINE (X + 10, Y)-((X + 10) + 3, Y + 3), OO
LOOP UNTIL (EOF(1))
CLOSE
OPEN "DATA3" FOR INPUT AS #1
DO
INPUT #1, X: INPUT #1, Y
OO = OO + .1
LINE (X + 100, Y + 50)-((X + 100) + 3, (Y + 50) + 3), OO
LOOP UNTIL (EOF(1))
CLOSE
OPEN "DATA4" FOR INPUT AS #1
DO
INPUT #1, X: INPUT #1, Y
OO = OO + .1
LINE ((X - 100), Y + 50)-((X - 100) + 3, (Y + 50) + 3), OO
LOOP UNTIL (EOF(1))
FOR H = 1 TO 2500
COL(H) = INT(RND * 10) + 16
NEXT H
CLOSE

OPEN "DATA5" FOR INPUT AS #1
O = 35
DO
INPUT #1, X: INPUT #1, Y
O = O + .1
PSET (X + 20, Y + 100), O
LOOP UNTIL (EOF(1))
CLOSE

LINE (130, 120)-(181, 171), 0, BF
LINE (131, 121)-(180, 170), 10, B
DO
'''
FOR Y = 1 TO 48 STEP 1
A = A + 1
FOR X = 1 TO 48 STEP 1
A = A + 1
GREAT = COL(A) + ROY
IF GREAT > 200 THEN ROY = 0
PSET (X + 131, Y + 121), GREAT
NEXT X
NEXT Y
KEY(1) ON
K$ = INKEY$
QAZXSW = QAZXSW + 1
IF K$ <> "" THEN QAZXSW = 0
IF QAZXSW = 400 THEN CALL SAVER: GOTO 10
IF K$ = CHR$(0) + "K" THEN GOSUB 112
IF K$ = CHR$(0) + "M" THEN GOSUB 113
ON KEY(1) GOSUB 123
IF K$ = CHR$(27) THEN DES = 3
IF UCASE$(K$) = "I" THEN DES = 1
IF UCASE$(K$) = "M" THEN DES = 2
IF UCASE$(K$) = "E" THEN DES = 3
IF UCASE$(K$) = "Q" THEN DES = 3
IF DES >= 4 THEN DES = 1
IF DES <= 0 THEN DES = 3
IF DES = 2 THEN XXX = 160: YYY = 95: CIRCLE (250, 150), 61, 0, , , -.6: CIRCLE (60, 150), 61, 0, , , -.6
IF DES = 3 THEN XXX = 250: YYY = 150:  CIRCLE (160, 95), 61, 0, , , -.6: CIRCLE (60, 150), 61, 0, , , -.6
IF DES = 1 THEN XXX = 60: YYY = 150: CIRCLE (250, 150), 61, 0, , , -.6: CIRCLE (160, 95), 61, 0, , , -.6
GGG = GGG + .5
IF GGG = 30 THEN GGG = 20
CIRCLE (XXX, YYY), 61, GGG, , , -.6
IF K$ = CHR$(32) OR K$ = CHR$(13) THEN GOTO 333
A = 0
ROY = ROY + 1
LOOP
CLOSE
112 DES = DES - 1: RETURN
113 DES = DES + 1: RETURN
333 IF DES = 1 THEN ERASE COL: CALL INFO: CLEAR : GOTO 10
IF DES = 3 THEN ERASE COL: CALL FINISH: CLEAR : GOTO 10
IF DES = 2 THEN ERASE COL: CALL COOL: CLEAR : GOTO 10
123 DES = 1: RETURN
669
CLEAR
SCREEN 0: CLS
WIDTH 80, 25
COLOR 15
PRINT "                  AN ERROR WAS DETECTED , PROGRAM ABORTED ."
BEEP
COLOR 7
SYSTEM

REM $STATIC
SUB BALL
RANDOMIZE TIMER
SCREEN 0: CLS
WIDTH 80, 25
LOCATE 3, 25: COLOR 10: PRINT "SPACE BY ROY ROY MASSAAD 1997@. "
943 LOCATE 6, 30: COLOR 15: INPUT "CHOOSE A MODE (1-8) "; DDD
IF DDD > 8 OR DDD < 1 THEN GOTO 943
IF DDD = 1 THEN GOTO 761
IF DDD = 2 THEN GOTO 762
IF DDD = 3 THEN GOTO 763
IF DDD = 4 THEN GOTO 764
IF DDD = 5 THEN GOTO 765
IF DDD = 6 THEN GOTO 767
IF DDD = 7 THEN GOTO 766
IF DDD = 8 THEN GOTO 768

761 RANDOMIZE TIMER
SCREEN 13: CLS
BAK = 0
69
ROY = 100
REDIM A(ROY), S(ROY), XB(ROY), YB(ROY), Y(ROY), X(ROY), D(ROY), C(ROY)
CCC = 160
CCC2 = 100
FOR T = 1 TO ROY
A(T) = (INT(RND * 73) + 1) / 10
S(T) = INT(RND * 95) + 5
D(T) = INT(RND * 5) + 1
Y(T) = CCC: X(T) = CCC2
C(T) = 18
NEXT T
DO
FOR T = 1 TO ROY
K$ = INKEY$
IF K$ = CHR$(27) THEN ERASE A, S, XB, YB, Y, X, D, C: GOTO 922
YB(T) = Y(T): XB(T) = X(T)
S(T) = S(T) + D(T)
X(T) = COS(A(T)) * S(T)
Y(T) = SIN(A(T)) * S(T)
COLOR C(T)
C(T) = C(T) + 2
HJU = 6 - (D(T) * 1.2)
IF HJU = 0 THEN HJU = 6
IF C(T) > 30 - HJU THEN C(T) = 30 - HJU
PSET (X(T) + CCC, Y(T) + CCC2)
PRESET (XB(T) + CCC, YB(T) + CCC2)
IF (Y(T) + CCC2) < 0 OR (Y(T) + CCC2) > 200 OR (X(T) + CCC) < 0 OR (X(T) + CCC) > 320 THEN GOSUB 60
NEXT T
LINE (0, 0)-(319, 199), 0, B
68
LOOP
60
A(T) = (INT(RND * 73) + 1) / 10
S(T) = INT(RND * 95) + 5
D(T) = INT(RND * 5) + 1
Y(T) = CCC: X(T) = CCC2
C(T) = 18
RETURN

762 SCREEN 13: CLS
RANDOMIZE TIMER
ROY = 80
REDIM A(ROY), S(ROY), XB(ROY), YB(ROY), Y(ROY), X(ROY), D(ROY), C(ROY)
CCC = 160
CCC2 = 100
FOR T = 1 TO ROY
A(T) = (INT(RND * 73) + 1) / 10
S(T) = INT(RND * 60) + 100
D(T) = INT(RND * 5) + 1
Y(T) = CCC: X(T) = CCC2
C(T) = INT(RND * 7) + 23
NEXT T
DO
FOR T = 1 TO ROY
COLOR C(T)
K$ = INKEY$
IF K$ = CHR$(27) THEN ERASE A, S, XB, YB, Y, X, D, C: GOTO 922
YB(T) = Y(T): XB(T) = X(T)
S(T) = S(T) - D(T)
X(T) = COS(A(T)) * S(T)
Y(T) = SIN(A(T)) * S(T)
DIST = SQR(((Y - 100) * (Y - 100)) + ((X - 160) * (X - 160)))
  POW = X(T) + CCC: POW2 = Y(T) + CCC2
PSET (POW, POW2)
  WOW = XB(T) + CCC: WOW2 = YB(T) + CCC2
PRESET (WOW, WOW2)
UIU = INT(RND * 20) + 1
IF S(T) < UIU THEN GOSUB 61
NEXT T
LOOP
61
YB(T) = Y(T): XB(T) = X(T): PRESET (XB(T) + CCC, YB(T) + CCC2)
A(T) = (INT(RND * 73) + 1) / 10
S(T) = INT(RND * 60) + 100
D(T) = INT(RND * 5) + 1
Y(T) = CCC: X(T) = CCC2
C(T) = INT(RND * 7) + 23
RETURN

763 SCREEN 13: CLS
ROY = 60
REDIM A(ROY), S(ROY), XB(ROY), YB(ROY), Y(ROY), X(ROY), D(ROY), C(ROY), AA3(ROY), POW(ROY), POW2(ROY), WOW(ROY), WOW2(ROY), FUF(ROY), FUF2(ROY)
CCC = 160
CCC2 = 100
FOR T = 1 TO ROY
A(T) = (INT(RND * 73) + 1) / 10
S(T) = INT(RND * 150) + 50
D(T) = INT(RND * 5) + 1
Y(T) = CCC: X(T) = CCC2
C(T) = INT(RND * 7) + 23
AA3(T) = A(T)
NEXT T
DO
FOR T = 1 TO ROY
COLOR C(T)
AA3(T) = AA3(T) + .1
IF AA3(T) = 7 THEN AA3(T) = 1
K$ = INKEY$
IF K$ = CHR$(27) THEN ERASE A, S, XB, YB, Y, X, D, C, AA3, POW, POW2, WOW, WOW2, FUF, FUF2: GOTO 922
YB(T) = Y(T): XB(T) = X(T)
S(T) = S(T) - D(T)
X(T) = COS(A(T)) * S(T)
Y(T) = SIN(A(T)) * S(T)
  POW(T) = X(T) + CCC: POW2(T) = Y(T) + CCC2
DIST = SQR(((POW2(T) - 100) * (POW2(T) - 100)) + ((POW(T) - 160) * (POW(T) - 160)))
X2 = (COS(AA3(T)) * DIST) + 160
Y2 = (SIN(AA3(T)) * DIST) + 100
PSET (X2, Y2)
  WOW(T) = XB(T) + CCC: WOW2(T) = YB(T) + CCC2
DIST = SQR(((WOW2(T) - 100) * (WOW2(T) - 100)) + ((WOW(T) - 160) * (WOW(T) - 160)))
X3 = (COS(AA3(T) - .1) * DIST) + 160
Y3 = (SIN(AA3(T) - .1) * DIST) + 100
PRESET (X3, Y3)
FUF(T) = X2: FUF2(T) = Y2
IF S(T) < 1 THEN GOSUB 52
NEXT T
LOOP
52
PRESET (FUF(T), FUF2(T))
A(T) = (INT(RND * 73) + 1) / 10
S(T) = INT(RND * 150) + 50
D(T) = INT(RND * 5) + 1
Y(T) = CCC: X(T) = CCC2
C(T) = INT(RND * 7) + 23
RETURN

764 SCREEN 13: CLS
ROY = 60
REDIM A(ROY), S(ROY), XB(ROY), YB(ROY), Y(ROY), X(ROY), D(ROY), C(ROY), AA3(ROY), POW(ROY), POW2(ROY), WOW(ROY), WOW2(ROY), FUF(ROY), FUF2(ROY)
CCC = 160
CCC2 = 100
FOR T = 1 TO ROY
A(T) = (INT(RND * 73) + 1) / 10
S(T) = INT(RND * 10) + 1
D(T) = INT(RND * 5) + 1
Y(T) = CCC: X(T) = CCC2
C(T) = INT(RND * 7) + 23
AA3(T) = A(T)
NEXT T
DO
FOR T = 1 TO ROY
COLOR C(T)
AA3(T) = AA3(T) + .1
IF AA3(T) = 7 THEN AA3(T) = 1
K$ = INKEY$
IF K$ = CHR$(27) THEN ERASE A, S, XB, YB, Y, X, D, C, AA3, POW, POW2, WOW, WOW2, FUF, FUF2: GOTO 922
YB(T) = Y(T): XB(T) = X(T)
S(T) = S(T) + D(T)
X(T) = COS(A(T)) * S(T)
Y(T) = SIN(A(T)) * S(T)
  POW(T) = X(T) + CCC: POW2(T) = Y(T) + CCC2
DIST = SQR(((POW2(T) - 100) * (POW2(T) - 100)) + ((POW(T) - 160) * (POW(T) - 160)))
X2 = (COS(AA3(T)) * DIST) + 160
Y2 = (SIN(AA3(T)) * DIST) + 100
PSET (X2, Y2)
  WOW(T) = XB(T) + CCC: WOW2(T) = YB(T) + CCC2
DIST = SQR(((WOW2(T) - 100) * (WOW2(T) - 100)) + ((WOW(T) - 160) * (WOW(T) - 160)))
X3 = (COS(AA3(T) - .1) * DIST) + 160
Y3 = (SIN(AA3(T) - .1) * DIST) + 100
PRESET (X3, Y3)
FUF(T) = X2: FUF2(T) = Y2
IF (Y(T) + CCC2) < 0 OR (Y(T) + CCC2) > 200 OR (X(T) + CCC) < 0 OR (X(T) + CCC) > 320 THEN GOSUB 56
NEXT T
LOOP
56
PRESET (FUF(T), FUF2(T))
A(T) = (INT(RND * 73) + 1) / 10
S(T) = INT(RND * 10) + 1
D(T) = INT(RND * 5) + 1
Y(T) = CCC: X(T) = CCC2
C(T) = INT(RND * 7) + 23
RETURN

765 SCREEN 13: CLS
RANDOMIZE TIMER
ROY = 50
REDIM X(ROY), Y(ROY), A(ROY), COL(ROY), XXX(ROY), YYY(ROY)
FOR T = 1 TO ROY
X(T) = INT(RND * 320) + 1
Y(T) = INT(RND * 200) + 1
A(T) = INT(RND * 4) + 1
COL(T) = INT(RND * 10) + 20
XXX(T) = INT(RND * 2) + 1
YYY(T) = INT(RND * 2) + 1
NEXT T
T = 0
PPP3 = 0
DO
K$ = INKEY$
IF K$ <> "" THEN ERASE X, Y, A, COL, XXX, YYY: GOTO 922
T = T + 1
IF T > ROY THEN T = 1
IF PPP3 = 0 THEN COL(T) = COL(T) + 1
IF PPP3 = 1 THEN COL(T) = COL(T) - 1
IF COL(T) > 30 THEN PPP3 = 1: COL(T) = 30
IF COL(T) < 20 THEN PPP3 = 0: COL(T) = 20
IF A(T) = 1 THEN X(T) = (X(T) + XXX(T)): Y(T) = (Y(T) + YYY(T))
IF A(T) = 2 THEN X(T) = (X(T) - XXX(T)): Y(T) = (Y(T) - YYY(T))
IF A(T) = 3 THEN X(T) = (X(T) + XXX(T)): Y(T) = (Y(T) - YYY(T))
IF A(T) = 4 THEN X(T) = (X(T) - XXX(T)): Y(T) = (Y(T) + YYY(T))
IF X(T) > 320 AND A(T) = 1 THEN A(T) = 4: X(T) = 320
IF X(T) > 320 AND A(T) = 3 THEN A(T) = 2: X(T) = 320
IF X(T) < 0 AND A(T) = 4 THEN A(T) = 1:  X(T) = 0
IF X(T) < 0 AND A(T) = 2 THEN A(T) = 3:  X(T) = 0
IF Y(T) > 200 AND A(T) = 1 THEN A(T) = 3:  Y(T) = 200
IF Y(T) > 200 AND A(T) = 4 THEN A(T) = 2:  Y(T) = 200
IF Y(T) < 0 AND A(T) = 3 THEN A(T) = 1:  Y(T) = 0
IF Y(T) < 0 AND A(T) = 2 THEN A(T) = 4:  Y(T) = 0
PSET (X(T), Y(T)), COL(T)
IF T <> ROY THEN PRESET (X(T + 1), Y(T + 1))
IF T = ROY THEN PRESET (X(1), Y(1))
LOOP


766
SCREEN 13: CLS
RANDOMIZE TIMER
DIM XS(100): DIM YS(100): DIM COLS(100)
FOR GTS = 1 TO 100
XS(GTS) = INT(RND * 318) + 1
YS(GTS) = INT(RND * 198) + 1
COLS(GTS) = INT(RND * 14) + 18
NEXT GTS
145 ROY = INT(RND * 90) + 10
WWW = INT(RND * 30) + 30
COL = INT(RND * 50) + 30
REDIM A(ROY), S(ROY), XB(ROY), YB(ROY), Y(ROY), X(ROY), D(ROY)
CCC = INT(RND * 320) + 1
CCC2 = INT(RND * 200) + 1
FOR T = 1 TO ROY
A(T) = (INT(RND * 73) + 1) / 10
S(T) = INT(RND * 10) + 1
D(T) = INT(RND * 5) + 1
Y(T) = CCC: X(T) = CCC2
NEXT T
DO
COL = COL + .2
COLOR COL
FOR T = 1 TO ROY
K$ = INKEY$
IF K$ = CHR$(27) THEN ERASE A, S, XB, YB, Y, X, D: GOTO 922
YB(T) = Y(T): XB(T) = X(T)
S(T) = S(T) + D(T)
X(T) = COS(A(T)) * S(T)
Y(T) = SIN(A(T)) * S(T)
PSET (X(T) + CCC, Y(T) + CCC2)
PRESET (XB(T) + CCC, YB(T) + CCC2)
NEXT T
FOR T = 1 TO 100
PSET (XS(T), YS(T)), COLS(T)
NEXT T
FOR TOT = 1 TO 100: NEXT TOT
HH = HH + 1
IF HH = WWW THEN FOR T = 1 TO ROY: YB(T) = Y(T): XB(T) = X(T): PRESET (XB(T) + CCC, YB(T) + CCC2): NEXT T: HH = 0: GOTO 145
LOOP

767
RANDOMIZE TIMER
SCREEN 13: CLS
ROY = 130
REDIM X(ROY), Y(ROY), A(ROY), S(ROY), C(ROY), R(ROY), SNS(ROY), XX(ROY), YY(ROY)
FOR T = 1 TO ROY
A(T) = (INT(RND * 73)) / 10
R(T) = INT(RND * 150) + 5
X(T) = (COS(A(T)) * R(T)) + 160
Y(T) = (SIN(A(T)) * R(T)) + 100
S(T) = INT(RND * 10) / 100
C(T) = INT(RND * 10) + 19
SNS(T) = INT(RND * 2) + 1
NEXT T

DO
FOR T = 1 TO ROY
XX(T) = X(T): YY(T) = Y(T)
IF SNS(T) = 1 THEN A(T) = A(T) + S(T)
IF SNS(T) = 2 THEN A(T) = A(T) - S(T)
X(T) = (COS(A(T)) * R(T)) + 160
Y(T) = (SIN(A(T)) * R(T)) + 100
PSET (X(T), Y(T)), C(T)
PRESET (XX(T), YY(T))
IF INKEY$ = CHR$(27) THEN ERASE X, Y, A, S, C, R, SNS, XX, YY: GOTO 922
NEXT T
LOOP

768
REM START
RANDOMIZE TIMER
SCREEN 13: CLS

REM DECALARATIONS
ROY = 150
CCC = 160
CCC2 = 100
REDIM A(ROY), S(ROY), XB(ROY), YB(ROY), Y(ROY), X(ROY), D(ROY), C(ROY), VT(ROY)




REM INITIALIZATION
FOR T = 1 TO ROY
VT(T) = 1
GOSUB 60890
NEXT T


REM RUNNING
DO

FOR T = 1 TO ROY
IF INKEY$ = CHR$(27) THEN ERASE A, S, XB, YB, Y, X, D, C, VT: GOTO 922
YB(T) = Y(T): XB(T) = X(T)
S(T) = (S(T) + D(T)) + 1
IF VT(T) = 1 THEN X(T) = COS(A(T)) * S(T)
IF VT(T) = 1 THEN Y(T) = SIN(A(T)) * S(T)

IF VT(T) = 2 THEN X(T) = TAN(A(T)) * S(T)
IF VT(T) = 2 THEN Y(T) = SIN(A(T)) * S(T)

IF VT(T) = 3 THEN X(T) = TAN(A(T)) * S(T)
IF VT(T) = 3 THEN Y(T) = COS(A(T)) * S(T)

IF VT(T) = 4 THEN X(T) = COS(A(T)) * S(T)
IF VT(T) = 4 THEN Y(T) = TAN(A(T)) * S(T)

IF VT(T) = 5 THEN X(T) = SIN(A(T)) * S(T)
IF VT(T) = 5 THEN Y(T) = TAN(A(T)) * S(T)

IF VT(T) = 6 THEN X(T) = COS(A(T)) * S(T)
IF VT(T) = 6 THEN Y(T) = SIN(A(T)) * S(T)

IF VT(T) = 7 THEN X(T) = COS(A(T)) * S(T)
IF VT(T) = 7 THEN Y(T) = SIN(A(T)) * S(T)

C(T) = C(T) + .5
IF C(T) > 50 THEN C(T) = 35
PSET (X(T) + CCC, Y(T) + CCC2), C(T)
PRESET (XB(T) + CCC, YB(T) + CCC2)
IF (Y(T) + CCC2) < -10 OR (Y(T) + CCC2) > 220 OR (X(T) + CCC) < -10 OR (X(T) + CCC) > 340 THEN GOSUB 60890
NEXT T

68890
LOOP


REM REINITIALIZATION
60890
IF CHC = 0 THEN QTX = INT(RND * 7) + 1: CHC = 1: NMB = INT(RND * 150) + 50: VX = 0: CCC = 160: VTT = INT(RND * 7) + 1
IF QTX = 1 THEN GOTO 111890
IF QTX = 2 THEN GOTO 222890
IF QTX = 7 THEN GOTO 222890
IF QTX = 3 THEN GOTO 333890
IF QTX = 4 THEN GOTO 444890
IF QTX = 5 THEN GOTO 555890
IF QTX = 6 THEN GOTO 666890

111890
Y(T) = CCC2: X(T) = CCC
S(T) = 5
D(T) = 5
VX = VX + 1
FG = FG + .1
IF FG > 7.3 THEN FG = 1
A(T) = FG
C(T) = 35
VT(T) = VTT
IF VX = NMB THEN CHC = 0
RETURN

222890
VX = VX + 1
A(T) = (INT(RND * 73) + 1) / 10
S(T) = 5
D(T) = 5
Y(T) = CCC: X(T) = CCC2
C(T) = 35
VT(T) = VTT
IF VX = NMB THEN CHC = 0
RETURN
       
333890
Y(T) = CCC2: X(T) = CCC
S(T) = 5
D(T) = 10
VX = VX + 1
FG = FG - .1
IF FG < -7.3 THEN FG = 1
A(T) = FG
C(T) = 35
VT(T) = VTT
IF VX = NMB THEN CHC = 0

RETURN


444890
Y(T) = CCC2: X(T) = CCC
S(T) = 5
D(T) = 10
VX = VX + 1
FG = ((FG * 2) / VX) + 1
A(T) = FG
C(T) = 35
VT(T) = VTT
IF VX = NMB THEN CHC = 0

RETURN

555890
Y(T) = CCC2: X(T) = CCC
S(T) = 90
D(T) = 10
VX = VX + 1
FG = FG - .1
A(T) = FG
C(T) = 35
VT(T) = VTT
IF VX = NMB THEN CHC = 0

RETURN

666890
Y(T) = CCC2: X(T) = CCC
S(T) = 20
D(T) = 5
VX = VX + 1
FG = FG + .01
A(T) = FG
C(T) = 35
VT(T) = VTT
IF VX = NMB THEN CHC = 0

RETURN




922

END SUB

SUB COOL
167 SCREEN 13: CLS
FOR GTS = 1 TO 300
XS = INT(RND * 318) + 1
YS = INT(RND * 198) + 1
COLS = INT(RND * 14) + 18
PSET (XS, YS), COLS
NEXT GTS
COLOR 33
LOCATE 2, 1: PRINT "1-OMEGA"
COLOR 34
LOCATE 5, 1: PRINT "2-LASER"
COLOR 35
LOCATE 8, 1: PRINT "3-CRAPER"
COLOR 36
LOCATE 11, 1: PRINT "4-COOLER"
COLOR 37
LOCATE 14, 1: PRINT "5-CYBER"
COLOR 38
LOCATE 17, 1: PRINT "6-DELTA"
COLOR 39
LOCATE 20, 1: PRINT "7-SPACE"
COLOR 40
LOCATE 23, 1: PRINT "8-LINES"
COLOR 43
LOCATE 2, 32: PRINT "A-GRAVITY"
COLOR 44
LOCATE 5, 32: PRINT "B-WARP"
COLOR 45
LOCATE 8, 32: PRINT "C-DOORWAY"
COLOR 46
LOCATE 11, 32: PRINT "D-BUGS"
COLOR 47
LOCATE 14, 32: PRINT "E-COOL"
COLOR 48
LOCATE 17, 32: PRINT "F-MORPH"
COLOR 49
LOCATE 20, 32: PRINT "G-SPHERES"
COLOR 50
LOCATE 23, 32: PRINT "H-SPOTS"
OPEN "DATA2" FOR INPUT AS #1
RER1 = 33
DID = INT(RND * 50) + 33
COLOR DID
DO
INPUT #1, X1: INPUT #1, Y1
T1 = 1.3
YY1 = Y1
XX1 = ((7.2 * X1) / 320) + T1
RER1 = RER1 + .1
CIRCLE (158, 100), YY1, RER1, XX1, (XX1 + .1)
LOOP UNTIL (EOF(1))
CLOSE
DO
FOR X = 1 TO 7.3 STEP .1
GHY = GHY + 1
IF GHY = 4 THEN GHY = 1
K$ = INKEY$
XX9 = COS(X - .3) * 7
YY9 = SIN(X - .3) * 7

XX = COS(X) * 7
YY = SIN(X) * 7
XX2 = COS(X + .3) * 7
YY2 = SIN(X + .3) * 7
XX3 = COS(X + .6) * 7
YY3 = SIN(X + .6) * 7
XX4 = COS(X + .9) * 7
YY4 = SIN(X + .9) * 7
XX5 = COS(X + 1.2) * 7
YY5 = SIN(X + 1.2) * 7
XX6 = COS(X + 1.5) * 7
YY6 = SIN(X + 1.5) * 7
XX7 = COS(X + 1.8) * 7
YY7 = SIN(X + 1.8) * 7
XX8 = COS(X + 2.1) * 7
IF GHY < 3 THEN GOTO 6786

LOCATE YYY + 9, XXX + 21: PRINT " "
LOCATE YYY2 + 9, XXX2 + 21: PRINT " "
LOCATE YYY3 + 9, XXX3 + 21: PRINT " "
LOCATE YYY4 + 9, XXX4 + 21: PRINT " "
LOCATE YYY5 + 9, XXX5 + 21: PRINT " "
LOCATE YYY6 + 9, XXX6 + 21: PRINT " "
LOCATE YYY7 + 9, XXX7 + 21: PRINT " "

LOCATE YY + 9, XX + 21: PRINT "V"
LOCATE YY2 + 9, XX2 + 21: PRINT "I"
LOCATE YY3 + 9, XX3 + 21: PRINT "R"
LOCATE YY4 + 9, XX4 + 21: PRINT "T"
LOCATE YY5 + 9, XX5 + 21: PRINT "U"
LOCATE YY6 + 9, XX6 + 21: PRINT "A"
LOCATE YY7 + 9, XX7 + 21: PRINT "L"

XXX = XX
XXX2 = XX2
XXX3 = XX3
XXX4 = XX2
XXX5 = XX5
XXX6 = XX6
XXX7 = XX7

YYY = YY
YYY2 = YY2
YYY3 = YY3
YYY4 = YY4
YYY5 = YY5
YYY6 = YY6
YYY7 = YY7

6786

LOCATE YY9 + 9, XX9 + 21: PRINT " "
COL = COL + 3
IF COL >= 300 THEN COL = 20
FOR XG = 1 TO 45 STEP 1
K$ = INKEY$
IF K$ = CHR$(27) THEN KTX$ = "":  GOTO 55
IF K$ = "1" THEN CALL SHOW("OMEGA BEEMS", 20, 14): KTX$ = "1"
IF K$ = "2" THEN CALL SHOW("LASER BEEMS", 20, 14): KTX$ = "2"
IF K$ = "3" THEN CALL SHOW("   CRAPER  ", 20, 14): KTX$ = "3"
IF K$ = "4" THEN CALL SHOW("   COOLER  ", 20, 14): KTX$ = "4"
IF K$ = "5" THEN CALL SHOW("CYBER STORM", 20, 14): KTX$ = "5"
IF K$ = "6" THEN CALL SHOW("   DELTA   ", 20, 14): KTX$ = "6"
IF K$ = "7" THEN CALL SHOW("   SPACE   ", 20, 14): KTX$ = "7"
IF K$ = "8" THEN CALL SHOW("   LINES   ", 20, 14): KTX$ = "8"
IF UCASE$(K$) = "A" THEN CALL SHOW("  GRAVITY  ", 20, 14): KTX$ = "A"
IF UCASE$(K$) = "B" THEN CALL SHOW("    WARP   ", 20, 14): KTX$ = "B"
IF UCASE$(K$) = "C" THEN CALL SHOW("  DOORWAYS ", 20, 14): KTX$ = "C"
IF UCASE$(K$) = "D" THEN CALL SHOW("BUGS__WORMS", 20, 14): KTX$ = "D"
IF UCASE$(K$) = "E" THEN CALL SHOW("   COOL    ", 20, 14): KTX$ = "E"
IF UCASE$(K$) = "F" THEN CALL SHOW("   MORPH   ", 20, 14): KTX$ = "F"
IF UCASE$(K$) = "G" THEN CALL SHOW("  SPHERES  ", 20, 14): KTX$ = "G"
IF UCASE$(K$) = "H" THEN CALL SHOW("   SPOTS   ", 20, 14): KTX$ = "H"
IF K$ = CHR$(32) OR K$ = CHR$(13) AND KTX$ <> "" THEN GOTO 666
321
CIRCLE (159, 60), XG, (XG + COL) / 2, , , .7
NEXT XG
NEXT X
QAZXSW = QAZXSW + 1
IF K$ <> "" THEN QAZXSW = 0
IF QAZXSW = 33 THEN CALL SAVER3: GOTO 167
LOOP
666
IF KTX$ = "1" THEN CALL OMEGA: GOTO 167
IF KTX$ = "2" THEN CALL LASER: GOTO 167
IF KTX$ = "3" THEN CALL CRAPER: GOTO 167
IF KTX$ = "4" THEN CALL COOLER: GOTO 167
IF KTX$ = "5" THEN CALL CYBER: GOTO 167
IF KTX$ = "6" THEN CALL DELTA: GOTO 167
IF KTX$ = "7" THEN CALL BALL: GOTO 167
IF KTX$ = "8" THEN CALL LINES: GOTO 167
IF KTX$ = "A" THEN CALL SHELLA: GOTO 167
IF KTX$ = "B" THEN CALL TYPE1: GOTO 167
IF KTX$ = "C" THEN CALL TYPE2: GOTO 167
IF KTX$ = "D" THEN CALL TUNNELS: GOTO 167
IF KTX$ = "E" THEN CALL COOLX: GOTO 167
IF KTX$ = "F" THEN CALL DISCO: GOTO 167
IF KTX$ = "G" THEN CALL SPHERES: GOTO 167
IF KTX$ = "H" THEN CALL SPOTS: GOTO 167:  ELSE GOTO 321
55
FOR T = 1 TO 300
CIRCLE (160, 100), T, 0, , , .5
NEXT T
END SUB

SUB COOLER
SCREEN 0: CLS
WIDTH 80, 25
LOCATE 3, 25: COLOR 10: PRINT "COOLER BY ROY MASSAAD 1997@. "
1675 LOCATE 6, 30: COLOR 15: INPUT "CHOOSE A MODE (1-2) "; DDD
IF DDD > 2 OR DDD < 1 THEN GOTO 1675
IF DDD = 1 THEN GOTO 9876
IF DDD = 2 THEN GOTO 9877
9877
SCREEN 13: CLS
RANDOMIZE TIMER
G = 16
DO
F = F + .1
IF FG = 1 THEN FF = FF + 1
IF FG = 2 THEN FF = FF - 1
IF FF < 5 THEN FG = 1
IF FF > 100 THEN FG = 2
FOR T = 2 TO 7.2 STEP 1.26
X2 = (COS(T + F) * (40 + FF)) + 160
Y2 = (SIN(T + F) * (40 + FF)) + 100
LINE (X2, Y2)-((COS((T + .62) + F) * (10 + FF)) + 160, (SIN((T + .62) + F) * (10 + FF)) + 100), G
LINE (X2, Y2)-((COS((T - .62) + F) * (10 + FF)) + 160, (SIN((T - .62) + F) * (10 + FF)) + 100), G
NEXT T
FOR Z = 1 TO 2500: NEXT Z
IF INKEY$ = CHR$(27) THEN GOTO 91
G = G + .1
LOOP

9876 SCREEN 13: CLS
RANDOMIZE TIMER
G = 150
C = INT(RND * 100) + 18
DDD = C
RTR = INT(RND * 6) + 1
QWQ = INT(RND * 25) + 5
DO
K = K + 2
G = G - 1
X = COS(K) * G
Y = SIN(K) * G
X2 = COS(K + 1) * G
Y2 = SIN(K + 1) * G
C = DDD
FOR T = 1 TO QWQ STEP RTR
C = C + .3
X = COS(K) * (G - T)
Y = SIN(K) * (G - T)
X2 = COS(K + 1) * (G - T)
Y2 = SIN(K + 1) * (G - T)
LINE (X + 150, Y + 100)-(X2 + 150, Y2 + 100), C
NEXT T
K$ = INKEY$
IF K$ = CHR$(27) THEN GOTO 91
IF G < -200 THEN GOTO 9876
FOR TOT = 1 TO 2500: NEXT TOT
LOOP
91
END SUB

SUB COOLX
SCREEN 0: CLS
WIDTH 80, 25
RANDOMIZE TIMER
COL = 25
SCREEN 0: CLS
COLOR 10
LOCATE 2, 20: PRINT "COOL STUFF BY ROY MASSAAD 1997 .tM"
7779 LOCATE 4, 20: COLOR 15: INPUT "CHOOSE A MODE (1-2)"; MD
IF MD <= 0 OR MD >= 3 THEN GOTO 7779
IF MD = 1 THEN GOTO 7778
IF MD = 2 THEN GOTO 7777
7778
COLOR 14
LOCATE 6, 28: PRINT "1-CUSTOM   2-RANDOM"
DO
K$ = INKEY$
IF K$ = "2" THEN GOTO 222
IF K$ = "1" THEN GOTO 555
LOOP
555 LOCATE 9, 26: COLOR 11: INPUT "CHOOSE A MODE (1-5) "; FEF
IF FEF <= 0 OR FEF >= 6 THEN GOTO 555
PASS = 1
GOTO 567
222 FEF = INT(RND * 5) + 1
567
SCREEN 13: CLS
DO
CLS
FOR GTS = 1 TO 150
XS = INT(RND * 318) + 1
YS = INT(RND * 198) + 1
COLS = INT(RND * 14) + 18
PSET (XS, YS), COLS
NEXT GTS
S1 = INT(RND * 10) + 1
S2 = INT(RND * 50) + 1
S3 = INT(RND * 10) + 1
S4 = INT(RND * 50) + 1
S5 = INT(RND * 50) + 1
S6 = INT(RND * 50) + 1
FOR T = 1 TO 8 STEP .007
K$ = INKEY$
IF K$ = CHR$(27) THEN GOTO 93
XX = (COS(S1 * T) * S2) + 150
YY = (SIN(S3 * T) * S4) + 100
X = (COS(T) * S5) + XX
Y = (SIN(T) * S6) + YY
COL = COL + .01
IF COL > 250 THEN COL = 25
IF FEF = 1 THEN PSET (X, Y), COL
IF FEF = 2 THEN LINE (X, Y)-(X + 5, Y + 5), COL
IF FEF = 3 THEN CIRCLE (X, Y), 5, COL
IF FEF = 4 THEN LINE (X, Y)-(150, 100), COL

IF FEF = 5 THEN ANG = (INT(RND * 63) + 1) / 10
IF FEF = 5 THEN LENG = INT(RND * 15) + 1
IF FEF = 5 THEN XP = (COS(ANG) * LENG) + X
IF FEF = 5 THEN YP = (SIN(ANG) * LENG) + Y
IF FEF = 5 THEN LINE (X, Y)-(XP, YP), COL
IF FEF = 5 THEN CIRCLE (XP, YP), 0, COL
FOR TOT = 1 TO 500: NEXT TOT
NEXT T
IF PASS = 0 THEN FEF = INT(RND * 5) + 1
LOOP

7777
SCREEN 13: CLS
RANDOMIZE TIMER
X = INT(RND * 320) + 1
Y = INT(RND * 200) + 1
A = INT(RND * 4) + 1
CCC = 20
AAC = INT(RND * 5) + 1: BBC = INT(RND * 5) + 1
HHH = INT(RND * 7) + 1
HHH2 = INT(RND * 7) + 1
ROY = INT(RND * 3) + 1
DRT = INT(RND * 15) + 1
AQAQ = INT(RND * 1000) + 1000
FRGR = 0
DO
FRGR = FRGR + 1
K$ = INKEY$
IF K$ = CHR$(27) THEN GOTO 93
IF FRGR = AQAQ THEN GOTO 7777
IF A = 1 THEN X = (X + AAC): Y = (Y + BBC)
IF A = 2 THEN X = (X - AAC): Y = (Y - BBC)
IF A = 3 THEN X = (X + AAC): Y = (Y - BBC)
IF A = 4 THEN X = (X - AAC): Y = (Y + BBC)
IF X > 320 AND A = 1 THEN A = 4: X = 320
IF X > 320 AND A = 3 THEN A = 2:  X = 320
IF X < 0 AND A = 4 THEN A = 1:  X = 0
IF X < 0 AND A = 2 THEN A = 3:  X = 0
IF Y > 200 AND A = 1 THEN A = 3: : Y = 200
IF Y > 200 AND A = 4 THEN A = 2:  Y = 200
IF Y < 0 AND A = 3 THEN A = 1:  Y = 0
IF Y < 0 AND A = 2 THEN A = 4: Y = 0
IF COL > 300 THEN COL = 20
IF COL < 20 THEN COL = 20
CCC = CCC + .05
IF CCC > 300 THEN CCC = 20
HHH = HHH + .1
IF HHH > 7 THEN HHH = 1
HHH2 = HHH2 + .1
IF HHH2 > 7 THEN HHH2 = 1
F = COS(HHH) * 3
FF = SIN(HHH2) * 3
X = X + F
Y = Y + FF
IF ROY = 1 THEN CIRCLE (X, Y), DRT, CCC
IF ROY = 2 THEN LINE (X, Y)-(X + 10, Y + 10), CCC
IF ROY = 3 THEN PSET (X, Y), CCC
FOR TOT = 1 TO 1000: NEXT TOT
LOOP
93
END SUB

SUB CRAPER
SCREEN 0: CLS
WIDTH 80, 25
LOCATE 3, 20: COLOR 10: PRINT "CRAPER BY ROY MASSAAD"
13 LOCATE 6, 20: COLOR 15: INPUT "CHOOSE A MODE (1-5)"; MD
IF MD <= 0 OR MD >= 6 THEN GOTO 13
SCREEN 13: CLS
A = 160: B = 100
RANDOMIZE TIMER
DO
K$ = INKEY$
IF K$ = CHR$(27) THEN GOTO 89
ANG = (INT(RND * 63) + 1) / 10
LENG = INT(RND * 15) + 1
'COL = INT(RND * 300) + 1
COL = COL + .01
X = COS(ANG)
Y = SIN(ANG)
IF MD = 1 THEN LINE (A, B)-((X * LENG) + A, (Y * LENG) + B), COL
IF MD = 2 THEN FOR T = 1 TO 10 STEP 1: CIRCLE (A, B), T, (T + COL) / 1: NEXT T
IF MD = 3 THEN LINE (A - 5, B - 5)-(A + 5, B + 5), COL, B
IF MD = 4 THEN PSET (A, B), COL / 10
IF MD = 5 THEN LINE (150, 100)-(A, B), FFF
BAK = A: BAK2 = B
A = (X * LENG) + A
B = (Y * LENG) + B
FFF = FFF + .01
IF FFF > 320 THEN FFF = 0
IF MD = 5 THEN LINE (BAK, BAK2)-(A, B), FFF
IF A > 320 OR A < 0 THEN A = 160
IF B > 200 OR B < 0 THEN B = 100

FOR TOT = 1 TO 250: NEXT TOT
LOOP
89
END SUB

SUB CYBER
'ON ERROR GOTO 100001
SCREEN 0: CLS
WIDTH 80, 25
LOCATE 3, 25: COLOR 14: PRINT "CYBER BY ROY MASSAAD"
LOCATE 6, 26: COLOR 15: PRINT "1-CUSTOM OR 2-RANDOM"
DO
K$ = INKEY$
IF K$ = "1" THEN GOTO 444
IF K$ = "2" THEN GOTO 789
IF K$ = CHR$(27) THEN GOTO 67
LOOP
444 LOCATE 9, 25: INPUT "CHOOSE A MODE (1-7) "; CL
IF CL <= 0 OR CL >= 8 THEN GOTO 444
HHH = 1
789 SCREEN 13: CLS
RANDOMIZE TIMER
COLOR 10
GUG = 20
U = 150
22 CLS
FOR GTS = 1 TO 150
XS = INT(RND * 318) + 1
YS = INT(RND * 198) + 1
COLS = INT(RND * 14) + 18
PSET (XS, YS), COLS
NEXT GTS
RAY = INT(RND * 2) + 1
CST = INT(RND * 4) + 1
SPR = INT(RND * 3) + 1
DUD3 = INT(RND * 30) + 1
S6 = (INT(RND * 10) + 1) / 100
U6 = (INT(RND * 10)) / 10
BIG6 = (INT(RND * 10) + 1) / 100
BIG26 = (INT(RND * 10) + 1) / 100
GUG6 = (INT(RND * 20) + 1) / 100
DUD6 = INT(RND * 20)
BIG = INT(RND * 30) + 1
BIG2 = INT(RND * 30) + 1
ON6 = INT(RND * 4) - 3
IF ON6 < 0 THEN ON6 = 1
FRT = INT(RND * 300) + 20
IF HHH = 0 THEN CL = INT(RND * 7) + 1
OP = INT(RND * 3) + 1
MOVE6 = INT(RND * 5) + 1
TUT6 = (INT(RND * 10) + 1) / 10
IF OP = 1 AND CL = 2 THEN U = 0
IF OP = 2 AND CL = 2 THEN U = 320
IF OP = 3 AND CL = 2 THEN U = 150
IF CL <> 2 THEN U = 150
DO
FOR A = 0 TO 6.3 STEP S6
IF OP = 1 THEN U = U + (U6 * ON6)
IF OP = 2 THEN U = U - (U6 * ON6)
K$ = INKEY$
FOR TOT = 1 TO 1500: NEXT TOT
IF K$ = CHR$(27) THEN GOTO 67
IF CST = 1 OR CST = 4 THEN X = COS(A): Y = SIN(A)
IF CST = 2 THEN X = TAN(A): Y = SIN(A)
IF CST = 3 THEN X = COS(A): Y = TAN(A)
BIG = BIG + (BIG6 * ON6)
BIG2 = BIG2 + (BIG26 * ON6)
GUG = GUG + GUG6
IF GUG > FRT THEN GUG = 20
IF PASS = 0 THEN DUD = DUD + 1
IF PASS = 1 THEN DUD = DUD - 1
IF DUD > DUD6 AND SPR = 1 THEN PASS = 1
IF DUD < 1 AND SPR = 1 THEN PASS = 0
IF DUD > DUD6 AND SPR = 2 THEN DUD = 0
IF DUD < 1 AND SPR = 2 THEN PASS = 0
IF SPR = 3 THEN DUD = DUD3
DUD5 = DUD5 + .01
IF RAY = 2 THEN DUD = DUD5
IF CL = 1 THEN TUT = TUT + TUT6: LINE ((X * (BIG + TUT)) + 150, (Y * (BIG2)) + 100)-((X * (BIG)) + 150, (Y * (BIG2)) + 100), GUG
IF CL = 2 THEN CIRCLE ((X * (BIG)) + U, (Y * (BIG2)) + 100), DUD, GUG
IF CL = 3 THEN LINE ((X * (BIG)) + 150, (Y * (BIG2)) + 100)-((X * (BIG) + 5) + 150, (Y * (BIG2) + 5) + 100), GUG
IF CL = 4 THEN LINE (1, 1)-((X * (BIG)) + 150, (Y * (BIG2)) + 100), GUG: LINE (1, 199)-((X * (BIG)) + 150, (Y * (BIG2)) + 100), GUG: LINE (315, 1)-((X * (BIG)) + 150, (Y * (BIG2)) + 100), GUG: LINE (315, 199)-((X * (BIG)) + 150, (Y * (BIG2)) + 100) _
, GUG
IF CL = 5 THEN LINE (150, 100)-((X * (BIG)) + 150, (Y * (BIG2)) + 100), GUG
IF CL = 6 THEN LINE ((X * (BIG - 15)) + 150, (Y * (BIG2)) + 100)-((X * (BIG + 15)) + 150, (Y * (BIG2)) + 100), GUG: LINE ((X * (BIG - 15)) + 150, (Y * (BIG2)) + 100)-((X * (BIG)) + 150, (Y * (BIG2 - 15)) + 100), GUG: LINE ((X * (BIG + 15)) + 150, (Y _
 * (BIG2)) + 100)-((X * (BIG)) + 150, (Y * (BIG2 - 15)) + 100), GUG
IF CL = 7 THEN LINE (X * BIG + 150, Y * BIG2 + 150)-(Y + DUD + BIG, X + GUG + BIG2), GUG
NEXT A
DID = DID + 1
IF DID = 10 THEN DID = 0: U = 150: DUD5 = 0: GOTO 22
LOOP
  

67
END SUB

SUB DELTA
RANDOMIZE TIMER
SCREEN 0: CLS
WIDTH 80, 25
LOCATE 3, 25: COLOR 10: PRINT "DELTA BY ROY ROY MASSAAD 1997@. "
143 LOCATE 6, 30: COLOR 15: INPUT "CHOOSE A MODE (1-6) "; DDD
IF DDD > 6 OR DDD < 1 THEN GOTO 143
IF DDD = 1 THEN GOTO 161
IF DDD = 2 THEN GOTO 162
IF DDD = 3 THEN GOTO 163
IF DDD = 4 THEN GOTO 164
IF DDD = 5 THEN GOTO 165
IF DDD = 6 THEN GOTO 166
161
SCREEN 13: CLS
DO
K$ = INKEY$
IF K$ = CHR$(27) THEN GOTO 66
COL = INT(RND * 300) + 1
X = INT(RND * 160) + 1
Y = INT(RND * 200) + 1
M = INT(RND * 200) + 1
M2 = INT(RND * 200) + 1
XP = (320 - X)
YP = Y
LINE (X, Y)-(160, M), COL
LINE (XP, YP)-(160, M), COL
LINE (X, Y)-(160, M2), COL
LINE (XP, YP)-(160, M2), COL
I = INT(RND * 200) + 1
I2 = INT(RND * 200) + 1
I3 = INT(RND * 200) + 1
I4 = INT(RND * 200) + 1
I5 = INT(RND * 200) + 1
TILE$ = CHR$(I) + CHR$(I2) + CHR$(I3) + CHR$(I4) + CHR$(I5)
PAINT (160, (M + M2) / 2), TILE$, COL
C = C + 1
FOR T = 1 TO 16000: NEXT T
IF C = 10 THEN C = 0: FOR T = 1 TO 1000: NEXT T: CLS
LOOP
162

SCREEN 13: CLS
RANDOMIZE TIMER
CCC = 30
DO
IF CCC > 100 THEN CCC = 30
F = F + .1
CCC = CCC + 1
FOR T = 2 TO 7.2 STEP 1.26
X2 = (COS(T + F) * 80) + 160
Y2 = (SIN(T + F) * 80) + 100
LINE (X2, Y2)-((COS(T + .62) * 50) + 160, (SIN(T + .62) * 50) + 100), CCC
LINE (X2, Y2)-((COS(T - .62) * 50) + 160, (SIN(T - .62) * 50) + 100), CCC
NEXT T
FOR Z = 1 TO 15000: NEXT Z
FOR T = 2 TO 7.2 STEP 1.26
X2 = (COS(T + F) * 80) + 160
Y2 = (SIN(T + F) * 80) + 100
LINE (X2, Y2)-((COS(T + .62) * 50) + 160, (SIN(T + .62) * 50) + 100), 0
LINE (X2, Y2)-((COS(T - .62) * 50) + 160, (SIN(T - .62) * 50) + 100), 0
NEXT T
IF INKEY$ = CHR$(27) THEN GOTO 66
LOOP


163
SCREEN 13: CLS
DO
FOR Y = 1 TO 200 STEP 2
FOR X = 1 TO 320 STEP 5
LINE (160, 100)-(X, Y), (X / 10) + 16 + FFF
NEXT X
IF INKEY$ = CHR$(27) THEN GOTO 66
FOR X2 = 1 TO 320 STEP 5
LINE (160, 100)-(X2, Y), 0
NEXT X2
FFF = FFF + 1
NEXT Y

FOR Y = 200 TO 1 STEP -2
FOR X = 1 TO 320 STEP 5
LINE (160, 100)-(X, Y), (X / 10) + 16 + FFF
NEXT X
IF INKEY$ = CHR$(27) THEN GOTO 66
FOR X2 = 1 TO 320 STEP 5
LINE (160, 100)-(X2, Y), 0
NEXT X2
FFF = FFF - 1
NEXT Y
LOOP

164
SCREEN 13: CLS
RANDOMIZE TIMER
CCC = 30
DO
F = F + .1
IF CCC > 100 THEN CCC = 30
CCC = CCC + 1
IF FG = 1 THEN FF = FF + 1
IF FG = 2 THEN FF = FF - 1
IF FF < 5 THEN FG = 1
IF FF > 100 THEN FG = 2
FOR T = 2 TO 7.2 STEP 1.26
X2 = (COS(T + F) * (40 + FF)) + 160
Y2 = (SIN(T + F) * (40 + FF)) + 100
LINE (X2, Y2)-((COS((T + .62) + F) * (10 + FF)) + 160, (SIN((T + .62) + F) * (10 + FF)) + 100), CCC
LINE (X2, Y2)-((COS((T - .62) + F) * (10 + FF)) + 160, (SIN((T - .62) + F) * (10 + FF)) + 100), CCC
NEXT T
FOR Z = 1 TO 15000: NEXT Z
IF INKEY$ = CHR$(27) THEN GOTO 66
FOR T = 2 TO 7.2 STEP 1.26
X2 = (COS(T + F) * (40 + FF)) + 160
Y2 = (SIN(T + F) * (40 + FF)) + 100
LINE (X2, Y2)-((COS((T + .62) + F) * (10 + FF)) + 160, (SIN((T + .62) + F) * (10 + FF)) + 100), 0
LINE (X2, Y2)-((COS((T - .62) + F) * (10 + FF)) + 160, (SIN((T - .62) + F) * (10 + FF)) + 100), 0
NEXT T

LOOP

165

SCREEN 13: CLS
RANDOMIZE TIMER
CCC = 30
DO
CCC = CCC + 1
IF CCC > 100 THEN CCC = 30
F = F + .1
FOR T = 2 TO 7.2 STEP 1.26
X2 = (COS(T) * 80) + 160
Y2 = (SIN(T) * 80) + 100
LINE (X2, Y2)-((COS((T + .62) + F) * 50) + 160, (SIN((T + .62) + F) * 50) + 100), CCC
LINE (X2, Y2)-((COS((T - .62) + F) * 50) + 160, (SIN((T - .62) + F) * 50) + 100), CCC
NEXT T
FOR Z = 1 TO 15000: NEXT Z
FOR T = 2 TO 7.2 STEP 1.26
X2 = (COS(T) * 80) + 160
Y2 = (SIN(T) * 80) + 100
LINE (X2, Y2)-((COS((T + .62) + F) * 50) + 160, (SIN((T + .62) + F) * 50) + 100), 0
LINE (X2, Y2)-((COS((T - .62) + F) * 50) + 160, (SIN((T - .62) + F) * 50) + 100), 0
NEXT T
IF INKEY$ = CHR$(27) THEN GOTO 66
LOOP
166

SCREEN 13: CLS
RANDOMIZE TIMER
AX = INT(RND * 320) + 1
AY = INT(RND * 200) + 1
BX = INT(RND * 320) + 1
BY = INT(RND * 200) + 1
AD = INT(RND * 15) + 40
BD = INT(RND * 15) + 40
A = INT(RND * 4) + 1
B = INT(RND * 4) + 1

DO
FAX = AX: FAY = AY: FBX = BX: FBY = BY
IF A = 1 THEN AX = AX + 2: AY = AY + 2
IF A = 2 THEN AX = AX - 2: AY = AY - 2
IF A = 3 THEN AX = AX + 2: AY = AY - 2
IF A = 4 THEN AX = AX - 2: AY = AY + 2
IF AX > 320 AND A = 1 THEN A = 4: AX = 320
IF AX > 320 AND A = 3 THEN A = 2: AX = 320
IF AX < 0 AND A = 4 THEN A = 1:  AX = 0
IF AX < 0 AND A = 2 THEN A = 3:  AX = 0
IF AY > 200 AND A = 1 THEN A = 3: AY = 200
IF AY > 200 AND A = 4 THEN A = 2:  AY = 200
IF AY < 0 AND A = 3 THEN A = 1:  AY = 0
IF AY < 0 AND A = 2 THEN A = 4:  AY = 0
WW = WW + .1
FOR T = 1 TO 7.3 STEP .2
AAX = (COS(T) * AD) + AX
AAY = (SIN(T) * AD) + AY
LINE (160, 100)-(AAX, AAY), 18 + T + WW
LINE (AX, AY)-(AAX, AAY), 18 + T + WW
NEXT T
FOR T = 1 TO 1000: NEXT T
FOR T = 1 TO 7.3 STEP .2
AAX = (COS(T) * AD) + AX
AAY = (SIN(T) * AD) + AY
LINE (160, 100)-(AAX, AAY), 0
LINE (AX, AY)-(AAX, AAY), 0
NEXT T
IF INKEY$ = CHR$(27) THEN GOTO 66
LOOP



66
END SUB

SUB DISCO
1323 SCREEN 13: CLS
RANDOMIZE TIMER
REDIM X1(100), Y1(100), X2(100), Y2(100), XB1(100), YB1(100)
CTY = INT(RND * 100) + 20
GOSUB 888323
GOSUB 666323

DO
FOR T = 1 TO 100
OP = ((INT(RND * 0) + 10) / 10)
Q = Q + 1

IF Q > 27500 AND H = 1 THEN : ERASE X1, Y1, X2, Y2, XB1, YB1: T99 = 0: S99 = 0: D1 = 0: D2 = 0: C88 = 0: Y88 = 0: X88 = 0: H = 0: A88 = 0: V88 = 0: CT88 = 0: VU = 0: QQ = 0: RR = 0: PO = 0: FG = 0: YU = 0: A = 0: B = 0: TT = 0: SA = 0: S1 = 0: S2 =  _
0: F = 0: CTY = 0: T = 0: OP = 0: Q = 0: H = 0: GOTO 1323: GOSUB 444323: GOSUB 999323: Q = 0: LINE (0, 0)-(320, 200), 0, BF: GOTO 7323
IF Q > 27500 AND H = 2 THEN GOSUB 444323: GOSUB 777323: Q = 0: LINE (0, 0)-(320, 200), 0, BF:  GOTO 7323
IF Q > 27500 AND H = 3 THEN GOSUB 444323: GOSUB 888323: Q = 0: LINE (0, 0)-(320, 200), 0, BF:  GOTO 7323

XB1(T) = X1(T): YB1(T) = Y1(T)

A = ABS(X1(T) - X2(T))
B = ABS(Y1(T) - Y2(T))

IF A >= B THEN GOSUB 10323: GOTO 3323
IF B >= A THEN GOSUB 20323: GOTO 3323
3323
F = F + .01
CTY = CTY + .001
CIRCLE (XB1(T), YB1(T)), 1, 0


CIRCLE (X1(T), Y1(T)), 1, CTY
7323
NEXT T
LOOP UNTIL INKEY$ = CHR$(27)
ERASE X1, Y1, X2, Y2, XB1, YB1
GOTO 1122334

10323
IF X1(T) >= X2(T) THEN GOTO 11323
IF X1(T) <= X2(T) THEN GOTO 12323

11323
TT = X1(T) - OP
IF TT = X2(T) - 1 THEN TT = X2(T)
Y1(T) = ((Y2(T) * X1(T) - Y1(T) * X2(T)) - (TT) * (Y2(T) - Y1(T))) / (X1(T) - X2(T))
X1(T) = TT
RETURN

12323
TT = X1(T) + OP
IF TT = X2(T) + 1 THEN TT = X2(T)
Y1(T) = ((Y2(T) * X1(T) - Y1(T) * X2(T)) - (TT) * (Y2(T) - Y1(T))) / (X1(T) - X2(T))
X1(T) = TT
RETURN

20323
IF Y1(T) >= Y2(T) THEN GOTO 21323
IF Y1(T) <= Y2(T) THEN GOTO 22323

21323
TT = Y1(T) - OP
IF TT = Y2(T) - 1 THEN TT = Y2(T)
X1(T) = ((TT * (X1(T) - X2(T))) - (Y2(T) * X1(T) - Y1(T) * X2(T))) / (Y1(T) - Y2(T))
Y1(T) = TT
RETURN

22323
TT = Y1(T) + OP
IF TT = Y2(T) + 1 THEN TT = Y2(T)
X1(T) = ((TT * (X1(T) - X2(T))) - (Y2(T) * X1(T) - Y1(T) * X2(T))) / (Y1(T) - Y2(T))
Y1(T) = TT
RETURN




666323
SA = 0
S1 = INT(RND * 30) + 30
S2 = INT(RND * 170) + 50
VU = INT(RND * 3) + 1
QQ = 0: RR = 0
FOR YU = 1 TO 3
FOR PO = 1 TO 33
SA = SA + 1
IF YU = 1 THEN QQ = (QQ + VU): RR = (RR + (VU / 1)): X1(SA) = QQ + S2: Y1(SA) = RR + S1
IF YU = 2 THEN QQ = (QQ - (VU * 2)): X1(SA) = QQ + S2: Y1(SA) = RR + S1
IF YU = 3 THEN QQ = (QQ + VU): RR = (RR - (VU / 1)): X1(SA) = QQ + S2: Y1(SA) = RR + S1
XB1(SA) = X1(SA): YB1(SA) = Y1(SA)
CIRCLE (X1(SA), Y1(SA)), 1, CTY
NEXT PO
NEXT YU
X1(100) = X1(1): Y1(100) = Y1(1)
XB1(100) = XB1(1): YB1(100) = YB1(1)
FOR FG = 1 TO 7000: NEXT FG
RETURN

777323
H = 1
A88 = 1
V88 = INT(RND * 4) + 3
CT88 = 0
C88 = 0
Y88 = 0
X88 = 0
S1 = INT(RND * 120) + 70
S2 = INT(RND * 25) + 25
DO
C88 = C88 + 1
IF C88 > 25 AND A88 = 4 THEN RETURN
IF C88 > 25 THEN C88 = 0: A88 = A88 + 1: GOTO 31323
IF A88 = 1 THEN X88 = X88 + V88
IF A88 = 2 THEN Y88 = Y88 + V88
IF A88 = 3 THEN X88 = X88 - V88
IF A88 = 4 THEN Y88 = Y88 - V88
X2(CT88 + 1) = X88 + S1
Y2(CT88 + 1) = Y88 + S2
IF X2(CT88 + 1) = 0 THEN X2(CT88 + 1) = 1
IF Y2(CT88 + 1) = 0 THEN Y2(CT88 + 1) = 1
CT88 = CT88 + 1
31323
LOOP

888323
H = 2
S99 = .0627
D1 = INT(RND * 50) + 40
D2 = INT(RND * 50) + 40
S1 = INT(RND * 140) + 90
S2 = INT(RND * 140) + 90
FOR T99 = 1 TO 100
S99 = S99 + .0627
X2(T99) = (COS(S99) * D1) + S1
Y2(T99) = (SIN(S99) * D2) + S2
IF X2(T99) = 0 THEN X2(T99) = 1
IF Y2(T99) = 0 THEN Y2(T99) = 1
NEXT T99
RETURN

999323
H = 3
SA = 0
S1 = INT(RND * 40) + 40
S2 = INT(RND * 150) + 50
VU = INT(RND * 3) + 1
QQ = 0: RR = 0
FOR YU = 1 TO 3
FOR PO = 1 TO 33
SA = SA + 1
IF YU = 1 THEN QQ = (QQ + VU): RR = (RR + (VU / 1)): X2(SA) = QQ + S2: Y2(SA) = RR + S1
IF YU = 2 THEN QQ = (QQ - (VU * 2)): X2(SA) = QQ + S2: Y2(SA) = RR + S1
IF YU = 3 THEN QQ = (QQ + VU): RR = (RR - (VU / 1)): X2(SA) = QQ + S2: Y2(SA) = RR + S1
'PSET (X2(SA), Y2(SA)), 15
NEXT PO
NEXT YU
X2(100) = X2(1): Y2(100) = Y2(1)
RETURN



444323
FOR U = 1 TO 100
X1(U) = X2(U)
Y1(U) = Y2(U)
XB1(U) = X1(U)
YB1(U) = Y1(U)
NEXT U
RETURN

1122334
END SUB

SUB FINISH
CALL SHOW("EXIT TO DOS (Y/N)", 23, 11)
DO
K$ = INKEY$
IF UCASE$(K$) = "Y" THEN CALL SHOW("SEE YAAAAAAAAAAAA", 23, 11): SLEEP 2:  GOSUB 9090: CLS : SCREEN 0: WIDTH 80, 25: COLOR 26: PRINT "THANK YOU FOR TAKING A MOMENT TO SEE THIS PROGRAM ...": COLOR 7: SYSTEM
IF UCASE$(K$) = "N" THEN GOTO 35
LOOP
9090
FOR T = 1 TO 5 STEP .006
T2 = T + 3
T3 = T + 6
LINE (80, 174 + T)-(221, 174 + T), 0
LINE (80, 174 + T2)-(221, 174 + T2), 0
LINE (80, 174 + T3)-(221, 174 + T3), 0
NEXT T
FOR T = 1 TO 100
LINE (1, T)-(320, 200 - T), 0, B
FOR C = 1 TO 2000: NEXT C
NEXT T
RETURN
35
END SUB

SUB INFO
CLOSE
SCREEN 13: CLS
REDIM QWE(150): REDIM ASD(150): REDIM ZXC(150): REDIM PLY(150): REDIM FGF(150)
FOR TR = 1 TO 150
QWE(TR) = INT(RND * 360) + 1
ASD(TR) = INT(RND * 200) + 1
ZXC(TR) = INT(RND * 10) + 20
PLY(TR) = 1
FGF(TR) = (INT(RND * 10) + 1) / 5
NEXT TR
T = 0
PLY = 1

OPEN "DATA" FOR INPUT AS #1
E = 20
DO
INPUT #1, X: INPUT #1, Y
X = X / 2
Y = Y / 2
O = O + .1
T = COS(O) * 2
TT = SIN(O) * 2
X = X + T + M
Y = Y + TT + MM
E = E + .1
PSET (X + 80, Y - 30), E
LOOP UNTIL (EOF(1))
CLOSE
AD = 1
COC = 18
DO
FOR COL = 1 TO 500 STEP 1
FOR X = 1 TO 35 STEP 1

TR = TR + 1
IF TR > 150 THEN TR = 1
IF PLY(TR) = 1 THEN ZXC(TR) = ZXC(TR) + FGF(TR)
IF PLY(TR) = 2 THEN ZXC(TR) = ZXC(TR) - FGF(TR)
IF ZXC(TR) > 30 THEN ZXC(TR) = 30: PLY(TR) = 2
IF ZXC(TR) < 20 THEN ZXC(TR) = 20: PLY(TR) = 1
IF QWE(TR) > 85 AND QWE(TR) < 225 THEN GOSUB 6789
PSET (QWE(TR), ASD(TR)), ZXC(TR)
9879
K$ = INKEY$
IF K$ = CHR$(27) THEN GOTO 45
LINE (85 + X, 35 + X)-(225 - X, 175 - X), X + COL, B
IF COC >= 31 THEN AD = 0
IF COC <= 17 THEN AD = 1
IF AD = 1 THEN COC = COC + .03
IF AD = 0 THEN COC = COC - .03
COLOR COC
LOCATE 11, 18: PRINT "CODED"
LOCATE 13, 20: PRINT "B"
LOCATE 14, 20: PRINT "Y"
LOCATE 16, 19: PRINT "ROY"
QAZXSW = QAZXSW + 1
IF K$ <> "" THEN QAZXSW = 0
IF QAZXSW = 10000 THEN ERASE QWE, ASD, ZXC, PLY, FGF: CALL SAVER2: GOTO 45
NEXT X
NEXT COL
LOOP
6789
IF ASD(TR) > 35 AND ASD(TR) < 175 THEN GOTO 9879
RETURN
45
DO
FGH = FGH + 1
XC = (INT(RND * 69) - 5) * 5
YC = (INT(RND * 45) - 5) * 5
LINE (XC, YC)-(XC + 5, YC + 5), 0, BF
LOOP WHILE FGH < 15000
CLS
END SUB

SUB LASER
SCREEN 0: CLS
WIDTH 80, 25
COLOR 15: LOCATE 3, 21: PRINT "* LASER BEEMS BY ROY MASSAAD (1997) *"
14 COLOR 10: LOCATE 8, 24: INPUT "ENTER MOVEMENT SPEED (0-30) "; AAA
IF AAA < 0 OR AAA > 30 THEN GOTO 14
AAA = AAA / 2
2 LOCATE 10, 26: INPUT "ENTER COLOR SPEED (0-100) "; BBB
IF BBB < 0 OR BBB > 100 THEN GOTO 2
BBB = BBB / 100
SCREEN 13: CLS
RANDOMIZE TIMER
X = INT(RND * 318) + 1
Y = INT(RND * 198) + 1
Z = INT(RND * 318) + 1
W = INT(RND * 198) + 1
M = INT(RND * 318) + 1
N = INT(RND * 198) + 1
A = INT(RND * 4) + 1
B = INT(RND * 4) + 1
C = INT(RND * 4) + 1
X1 = INT(RND * 318) + 1
Y1 = INT(RND * 198) + 1
Z1 = INT(RND * 318) + 1
W1 = INT(RND * 198) + 1
M1 = INT(RND * 318) + 1
N1 = INT(RND * 198) + 1
A1 = INT(RND * 4) + 1
B1 = INT(RND * 4) + 1
C1 = INT(RND * 4) + 1
REDIM XS(200): REDIM YS(200): REDIM COLS(200)
FOR GTS = 1 TO 200
XS(GTS) = INT(RND * 318) + 1
YS(GTS) = INT(RND * 198) + 1
COLS(GTS) = INT(RND * 14) + 18
PSET (XS(GTS), YS(GTS)), COLS(GTS)
NEXT GTS
GTS = 0
DO
GTS = GTS + 1
IF GTS = 200 THEN GTS = 1
PSET (XS(GTS), YS(GTS)), COLS(GTS)
PUSSY = PUSSY + (.06 + BBB)
IF PUSSY > 220 THEN PUSSY = 1
K$ = INKEY$
LINE (X1, Y1)-(X, Y), 25 + PUSSY: LINE (Z1, W1)-(Z, W), 26 + PUSSY: LINE (M1, N1)-(M, N), 27 + PUSSY
PSET (XS(GTS), YS(GTS)), COLS(GTS)
LINE (X1 - 5, Y1 - 5)-(X - 5, Y - 5), 25 + PUSSY: LINE (Z1 - 5, W1 - 5)-(Z - 5, W - 5), 26 + PUSSY: LINE (M1 - 5, N1 - 5)-(M - 5, N - 5), 27 + PUSSY
PSET (XS(GTS), YS(GTS)), COLS(GTS)
LINE (X1 - 9, Y1 - 9)-(X - 9, Y - 9), 25 + PUSSY: LINE (Z1 - 9, W1 - 9)-(Z - 9, W - 9), 26 + PUSSY: LINE (M1 - 9, N1 - 9)-(M - 9, N - 9), 27 + PUSSY
PSET (XS(GTS), YS(GTS)), COLS(GTS)
LINE (X, Y)-(Z, W), 18 + PUSSY: LINE (Z, W)-(M, N), 21 + PUSSY: LINE (M, N)-(X, Y), 24 + PUSSY
PSET (XS(GTS), YS(GTS)), COLS(GTS)
LINE (X - 5, Y - 5)-(Z - 5, W - 5), 19 + PUSSY: LINE (Z - 5, W - 5)-(M - 5, N - 5), 22 + PUSSY: LINE (M - 5, N - 5)-(X - 5, Y - 5), 24 + PUSSY
PSET (XS(GTS), YS(GTS)), COLS(GTS)
LINE (X - 9, Y - 9)-(Z - 9, W - 9), 20 + PUSSY: LINE (Z - 9, W - 9)-(M - 9, N - 9), 23 + PUSSY: LINE (M - 9, N - 9)-(X - 9, Y - 9), 24 + PUSSY
PSET (XS(GTS), YS(GTS)), COLS(GTS)
HEAD = Y: BUTT = X: HEAD2 = W: BUTT2 = Z: HEAD3 = N: BUTT3 = M
IF A = 1 THEN X = X + (1 + AAA): Y = Y + (1 + AAA)
IF A = 2 THEN X = X - (1 + AAA): Y = Y - (1 + AAA)
IF A = 3 THEN X = X + (1 + AAA): Y = Y - (1 + AAA)
IF A = 4 THEN X = X - (1 + AAA): Y = Y + (1 + AAA)
IF X >= 320 AND Y > HEAD AND X > BUTT THEN A = 4
IF X >= 320 AND Y < HEAD AND X > BUTT THEN A = 2
IF X <= 7 AND Y > HEAD AND X < BUTT THEN A = 1
IF X <= 7 AND Y < HEAD AND X < BUTT THEN A = 3
IF Y >= 200 AND X > BUTT AND Y > HEAD THEN A = 3
IF Y >= 200 AND X < BUTT AND Y > HEAD THEN A = 2
IF Y <= 7 AND X > BUTT AND Y < HEAD THEN A = 1
IF Y <= 7 AND X < BUTT AND Y < HEAD THEN A = 4
IF B = 1 THEN Z = Z + (.5 + AAA): W = W + (.5 + AAA)
IF B = 2 THEN Z = Z - (.5 + AAA): W = W - (.5 + AAA)
IF B = 3 THEN Z = Z + (.5 + AAA): W = W - (.5 + AAA)
IF B = 4 THEN Z = Z - (.5 + AAA): W = W + (.5 + AAA)
IF Z >= 320 AND W > HEAD2 AND Z > BUTT2 THEN B = 4
IF Z >= 320 AND W < HEAD2 AND Z > BUTT2 THEN B = 2
IF Z <= 7 AND W > HEAD2 AND Z < BUTT2 THEN B = 1
IF Z <= 7 AND W < HEAD2 AND Z < BUTT2 THEN B = 3
IF W >= 200 AND Z > BUTT2 AND W > HEAD2 THEN B = 3
IF W >= 200 AND Z < BUTT2 AND W > HEAD2 THEN B = 2
IF W <= 7 AND Z > BUTT2 AND W < HEAD2 THEN B = 1
IF W <= 7 AND Z < BUTT2 AND W < HEAD2 THEN B = 4
IF C = 1 THEN M = M + (.75 + AAA): N = N + (.75 + AAA)
IF C = 2 THEN M = M - (.75 + AAA): N = N - (.75 + AAA)
IF C = 3 THEN M = M + (.75 + AAA): N = N - (.75 + AAA)
IF C = 4 THEN M = M - (.75 + AAA): N = N + (.75 + AAA)
IF M >= 320 AND N > HEAD3 AND M > BUTT3 THEN C = 4
IF M >= 320 AND N < HEAD3 AND M > BUTT3 THEN C = 2
IF M <= 7 AND N > HEAD3 AND M < BUTT3 THEN C = 1
IF M <= 7 AND N < HEAD3 AND M < BUTT3 THEN C = 3
IF N >= 200 AND M > BUTT3 AND N > HEAD3 THEN C = 3
IF N >= 200 AND M < BUTT3 AND N > HEAD3 THEN C = 2
IF N <= 7 AND M > BUTT3 AND N < HEAD3 THEN C = 1
IF N <= 7 AND M < BUTT3 AND N < HEAD3 THEN C = 4
LINE (X1, Y1)-(Z1, W1), 28 + PUSSY: LINE (Z1, W1)-(M1, N1), 31 + PUSSY: LINE (M1, N1)-(X1, Y1), 34 + PUSSY
LINE (X1, Y1)-(Z1, W1), 28 + PUSSY: LINE (Z1, W1)-(M1, N1), 31 + PUSSY: LINE (M1, N1)-(X1, Y1), 34 + PUSSY
LINE (X1 - 5, Y1 - 5)-(Z1 - 5, W1 - 5), 29 + PUSSY: LINE (Z1 - 5, W1 - 5)-(M1 - 5, N1 - 5), 32 + PUSSY: LINE (M1 - 5, N1 - 5)-(X1 - 5, Y1 - 5), 35 + PUSSY
PSET (XS(GTS), YS(GTS)), COLS(GTS)
PSET (XS(GTS), YS(GTS)), COLS(GTS)
LINE (X1 - 5, Y1 - 5)-(Z1 - 5, W1 - 5), 29 + PUSSY: LINE (Z1 - 5, W1 - 5)-(M1 - 5, N1 - 5), 32 + PUSSY: LINE (M1 - 5, N1 - 5)-(X1 - 5, Y1 - 5), 35 + PUSSY
PSET (XS(GTS), YS(GTS)), COLS(GTS)
LINE (X1 - 9, Y1 - 9)-(Z1 - 9, W1 - 9), 30 + PUSSY: LINE (Z1 - 9, W1 - 9)-(M1 - 9, N1 - 9), 33 + PUSSY: LINE (M1 - 9, N1 - 9)-(X1 - 9, Y1 - 9), 36 + PUSSY
PSET (XS(GTS), YS(GTS)), COLS(GTS)
FOR DX = 1 TO 5000: NEXT DX
LINE (BUTT, HEAD)-(BUTT2, HEAD2), 0: LINE (BUTT2, HEAD2)-(BUTT3, HEAD3), 0: LINE (BUTT3, HEAD3)-(BUTT, HEAD), 0
PSET (XS(GTS), YS(GTS)), COLS(GTS)
LINE (BUTT - 5, HEAD - 5)-(BUTT2 - 5, HEAD2 - 5), 0: LINE (BUTT2 - 5, HEAD2 - 5)-(BUTT3 - 5, HEAD3 - 5), 0: LINE (BUTT3 - 5, HEAD3 - 5)-(BUTT - 5, HEAD - 5), 0
PSET (XS(GTS), YS(GTS)), COLS(GTS)
LINE (BUTT - 9, HEAD - 9)-(BUTT2 - 9, HEAD2 - 9), 0: LINE (BUTT2 - 9, HEAD2 - 9)-(BUTT3 - 9, HEAD3 - 9), 0: LINE (BUTT3 - 9, HEAD3 - 9)-(BUTT - 9, HEAD - 9), 0
HEAD1 = Y1: BUTT1 = X1: HEAD21 = W1: BUTT21 = Z1: HEAD31 = N1: BUTT31 = M1
IF A1 = 1 THEN X1 = X1 + (.25 + AAA): Y1 = Y1 + (.25 + AAA)
IF A1 = 2 THEN X1 = X1 - (.25 + AAA): Y1 = Y1 - (.25 + AAA)
IF A1 = 3 THEN X1 = X1 + (.25 + AAA): Y1 = Y1 - (.25 + AAA)
IF A1 = 4 THEN X1 = X1 - (.25 + AAA): Y1 = Y1 + (.25 + AAA)
IF X1 >= 320 AND Y1 > HEAD1 AND X1 > BUTT1 THEN A1 = 4
IF X1 >= 320 AND Y1 < HEAD1 AND X1 > BUTT1 THEN A1 = 2
IF X1 <= 7 AND Y1 > HEAD1 AND X1 < BUTT1 THEN A1 = 1
IF X1 <= 7 AND Y1 < HEAD1 AND X1 < BUTT1 THEN A1 = 3
IF Y1 >= 200 AND X1 > BUTT1 AND Y1 > HEAD1 THEN A1 = 3
IF Y1 >= 200 AND X1 < BUTT1 AND Y1 > HEAD1 THEN A1 = 2
IF Y1 <= 7 AND X1 > BUTT1 AND Y1 < HEAD1 THEN A1 = 1
IF Y1 <= 7 AND X1 < BUTT1 AND Y1 < HEAD1 THEN A1 = 4
IF B1 = 1 THEN Z1 = Z1 + (1.5 + AAA): W1 = W1 + (1.5 + AAA)
IF B1 = 2 THEN Z1 = Z1 - (1.5 + AAA): W1 = W1 - (1.5 + AAA)
IF B1 = 3 THEN Z1 = Z1 + (1.5 + AAA): W1 = W1 - (1.5 + AAA)
IF B1 = 4 THEN Z1 = Z1 - (1.5 + AAA): W1 = W1 + (1.5 + AAA)
IF Z1 >= 320 AND W1 > HEAD21 AND Z1 > BUTT21 THEN B1 = 4
IF Z1 >= 320 AND W1 < HEAD21 AND Z1 > BUTT21 THEN B1 = 2
IF Z1 <= 7 AND W1 > HEAD21 AND Z1 < BUTT21 THEN B1 = 1
IF Z1 <= 7 AND W1 < HEAD21 AND Z1 < BUTT21 THEN B1 = 3
IF W1 >= 200 AND Z1 > BUTT21 AND W1 > HEAD21 THEN B1 = 3
IF W1 >= 200 AND Z1 < BUTT21 AND W1 > HEAD21 THEN B1 = 2
IF W1 <= 7 AND Z1 > BUTT21 AND W1 < HEAD21 THEN B1 = 1
IF W1 <= 7 AND Z1 < BUTT21 AND W1 < HEAD21 THEN B1 = 4
IF C1 = 1 THEN M1 = M1 + (.75 + AAA): N1 = N1 + (.75 + AAA)
IF C1 = 2 THEN M1 = M1 - (.75 + AAA): N1 = N1 - (.75 + AAA)
IF C1 = 3 THEN M1 = M1 + (.75 + AAA): N1 = N1 - (.75 + AAA)
IF C1 = 4 THEN M1 = M1 - (.75 + AAA): N1 = N1 + (.75 + AAA)
IF M1 >= 320 AND N1 > HEAD31 AND M1 > BUTT31 THEN C1 = 4
IF M1 >= 320 AND N1 < HEAD31 AND M1 > BUTT31 THEN C1 = 2
IF M1 <= 7 AND N1 > HEAD31 AND M1 < BUTT31 THEN C1 = 1
IF M1 <= 7 AND N1 < HEAD31 AND M1 < BUTT31 THEN C1 = 3
IF N1 >= 200 AND M1 > BUTT31 AND N1 > HEAD31 THEN C1 = 3
IF N1 >= 200 AND M1 < BUTT31 AND N1 > HEAD31 THEN C1 = 2
IF N1 <= 7 AND M1 > BUTT31 AND N1 < HEAD31 THEN C1 = 1
IF N1 <= 7 AND M1 < BUTT31 AND N1 < HEAD31 THEN C1 = 4
FOR DX = 1 TO 100: NEXT DX
LINE (BUTT1, HEAD1)-(BUTT21, HEAD21), 0: LINE (BUTT21, HEAD21)-(BUTT31, HEAD31), 0: LINE (BUTT31, HEAD31)-(BUTT1, HEAD1), 0
PSET (XS(GTS), YS(GTS)), COLS(GTS)
LINE (BUTT1 - 5, HEAD1 - 5)-(BUTT21 - 5, HEAD21 - 5), 0: LINE (BUTT21 - 5, HEAD21 - 5)-(BUTT31 - 5, HEAD31 - 5), 0: LINE (BUTT31 - 5, HEAD31 - 5)-(BUTT1 - 5, HEAD1 - 5), 0
PSET (XS(GTS), YS(GTS)), COLS(GTS)
LINE (BUTT1 - 9, HEAD1 - 9)-(BUTT21 - 9, HEAD21 - 9), 0: LINE (BUTT21 - 9, HEAD21 - 9)-(BUTT31 - 9, HEAD31 - 9), 0: LINE (BUTT31 - 9, HEAD31 - 9)-(BUTT1 - 9, HEAD1 - 9), 0
PSET (XS(GTS), YS(GTS)), COLS(GTS)
LINE (BUTT, HEAD)-(BUTT1, HEAD1), 0: LINE (BUTT2, HEAD2)-(BUTT21, HEAD21), 0: LINE (BUTT3, HEAD3)-(BUTT31, HEAD31), 0
PSET (XS(GTS), YS(GTS)), COLS(GTS)
LINE (BUTT - 5, HEAD - 5)-(BUTT1 - 5, HEAD1 - 5), 0: LINE (BUTT2 - 5, HEAD2 - 5)-(BUTT21 - 5, HEAD21 - 5), 0: LINE (BUTT3 - 5, HEAD3 - 5)-(BUTT31 - 5, HEAD31 - 5), 0
PSET (XS(GTS), YS(GTS)), COLS(GTS)
LINE (BUTT - 9, HEAD - 9)-(BUTT1 - 9, HEAD1 - 9), 0: LINE (BUTT2 - 9, HEAD2 - 9)-(BUTT21 - 9, HEAD21 - 9), 0: LINE (BUTT3 - 9, HEAD3 - 9)-(BUTT31 - 9, HEAD31 - 9), 0
IF K$ = CHR$(27) THEN GOTO 100
PSET (XS(GTS), YS(GTS)), COLS(GTS)
LOOP
100
ERASE XS, YS, COLS

END SUB

SUB LINES
SCREEN 0: CLS
WIDTH 80, 25
LOCATE 3, 25: COLOR 10: PRINT "LINES BY ROY ROY MEGA GAMES 1997@. "
5675 LOCATE 6, 30: COLOR 15: INPUT "CHOOSE A MODE (1-6) "; DDD
IF DDD > 6 OR DDD < 1 THEN GOTO 5675
IF DDD = 1 THEN GOTO 901
IF DDD = 2 THEN GOTO 902
IF DDD = 3 THEN GOTO 903
IF DDD = 4 THEN GOTO 904
IF DDD = 5 THEN GOTO 905
IF DDD = 6 THEN GOTO 906

901 SCREEN 13: CLS
RANDOMIZE TIMER
DO
K$ = INKEY$
C = INT(RND * 300)
X = INT(RND * 315)
YY = INT(RND * 2)
Y = YY * 199
X1 = INT(RND * 315)
YY1 = INT(RND * 2)
Y1 = YY1 * 199
LINE (X, Y)-(X1, Y1), C

C2 = INT(RND * 300)
XX2 = INT(RND * 2)
Y2 = INT(RND * 199)
X2 = XX2 * 315
XX21 = INT(RND * 2)
Y21 = INT(RND * 199)
X21 = XX21 * 315
LINE (X2, Y2)-(X21, Y21), C2

IF K$ = CHR$(27) THEN GOTO 78
SHIT = SHIT + .5
IF SHIT > 200 THEN SHIT = 1
CIRCLE (150, 100), SHIT, 0, , , 1

SHIT2 = SHIT2 + 1
IF SHIT2 > 200 THEN SHIT2 = 1
CIRCLE (150, 100), SHIT2, 0
FOR T = 1 TO 100: NEXT T

LOOP

902 SCREEN 13: CLS
RANDOMIZE TIMER
X = INT(RND * 320) + 1
Y = INT(RND * 200) + 1
A = INT(RND * 4) + 1
COL = 20
AAC = 1: BBC = 1

X2 = INT(RND * 320) + 1
Y2 = INT(RND * 200) + 1
A2 = INT(RND * 4) + 1
AAC2 = 1: BBC2 = 1

DO
K$ = INKEY$
IF K$ = CHR$(27) THEN GOTO 78
IF K$ <> "" THEN GOTO 902
IF A = 1 THEN X = (X + AAC): Y = (Y + BBC)
IF A = 2 THEN X = (X - AAC): Y = (Y - BBC)
IF A = 3 THEN X = (X + AAC): Y = (Y - BBC)
IF A = 4 THEN X = (X - AAC): Y = (Y + BBC)
IF X > 320 AND A = 1 THEN A = 4: X = 320
IF X > 320 AND A = 3 THEN A = 2: X = 320
IF X < 0 AND A = 4 THEN A = 1:  X = 0
IF X < 0 AND A = 2 THEN A = 3:  X = 0
IF Y > 200 AND A = 1 THEN A = 3: Y = 200
IF Y > 200 AND A = 4 THEN A = 2:  Y = 200
IF Y < 0 AND A = 3 THEN A = 1:  Y = 0
IF Y < 0 AND A = 2 THEN A = 4:  Y = 0


IF A2 = 1 THEN X2 = (X2 + AAC2): Y2 = (Y2 + BBC2)
IF A2 = 2 THEN X2 = (X2 - AAC2): Y2 = (Y2 - BBC2)
IF A2 = 3 THEN X2 = (X2 + AAC2): Y2 = (Y2 - BBC2)
IF A2 = 4 THEN X2 = (X2 - AAC2): Y2 = (Y2 + BBC2)
IF X2 > 320 AND A2 = 1 THEN A2 = 4: X2 = 320
IF X2 > 320 AND A2 = 3 THEN A2 = 2:  X2 = 320
IF X2 < 0 AND A2 = 4 THEN A2 = 1:  X2 = 0
IF X2 < 0 AND A2 = 2 THEN A2 = 3:  X2 = 0
IF Y2 > 200 AND A2 = 1 THEN A2 = 3:  Y2 = 200
IF Y2 > 200 AND A2 = 4 THEN A2 = 2:  Y2 = 200
IF Y2 < 0 AND A2 = 3 THEN A2 = 1: Y2 = 0
IF Y2 < 0 AND A2 = 2 THEN A2 = 4: Y2 = 0


COL = COL + .05
IF COL > 300 THEN COL = 20
IF COL < 20 THEN COL = 20

LINE (X2, Y2)-(X, Y), COL
FOR TOT = 1 TO 1000: NEXT TOT
LOOP


903
SCREEN 13: CLS
Y3 = 200: Y4 = 1
COL = 30
IOI = 0
DO
FOR T = 1 TO 7.25 STEP .01
Y4 = Y4 + .05
Y3 = Y3 - .05
K$ = INKEY$
IF K$ = CHR$(27) THEN GOTO 78
X1 = (COS(T) * 30)
Y1 = (SIN(T) * 30)
T2 = (T * (-1))
X2 = (COS(T2) * 30)
Y2 = (SIN(T2) * 30)
X5 = (COS(T) * 10)
Y5 = (SIN(T) * 10)
COL = COL + .05
IOI = IOI + 1
IF IOI = 10000 THEN GOTO 903
LINE (X5 + 160, Y5 + 100)-(X2 + 50, Y2 + Y4), COL, B: LINE (X5 + 160, Y5 + 100)-(X1 + 250, Y1 + Y3), COL, B: LINE (X5 + 160, Y5 + 100)-((X2 - 20) + 50, (Y2 - 20) + Y4), COL, B: LINE (X5 + 160, Y5 + 100)-((X1 + 20) + 250, (Y1 + 20) + Y3), COL, B: _
                            LINE (X2 + 50, Y2 + Y4)-((X2 - 20) + 50, (Y2 - 20) + Y4), COL, B: LINE (X1 + 250, Y1 + Y3)-((X1 + 20) + 250, (Y1 + 20) + Y3), COL, B: LINE (X2 + 50, Y2 + Y4)-(X1 + 250, Y1 + Y3), COL, B: LINE ((X2 - 20) + 50, (Y2 - 20) +  _
Y4)-((X1 + 20) + 250, (Y1 + 20) + Y3), COL, B:

NEXT T
LOOP

904
SCREEN 13: CLS
DO
FOR T = 1 TO 7.3 STEP .1
X = (COS(T) * 70) + 160
Y = (SIN(T) * 50) + 100
CIRCLE (X, Y), 5, (T * 10)
PRINT " "
IF INKEY$ = CHR$(27) THEN GOTO 78
NEXT T
LOOP
905

SCREEN 13: CLS
RANDOMIZE TIMER
M = 4.7
A = 4.7
DX = INT(RND * 35) + 35
DY = 600
XX = INT(RND * 300) + 10
YY = DY
S = INT(RND * 2) + 1
G = 20
X = XX: Y = -1
DO
XC = X: YC = Y
IF S = 1 THEN A = A + .02
IF S = 2 THEN A = A - .02

X = (COS(A) * DX) + XX
Y = (SIN(A) * DY) + YY
G = G + .01
LINE (X, Y)-(XC, YC), G
FOR TOT = 1 TO 1000: NEXT TOT
IF B = 1 AND Y < 200 THEN B = 0

IF Y > 220 AND B = 0 AND S = 1 THEN A = M - (A - M): DX = DX + 20: XX = XX + (DX * 1.25): DY = DY - 20: B = 1:  GOTO 11789
IF Y > 220 AND B = 0 AND S = 2 THEN A = M + (M - A): DX = DX + 20: XX = XX - (DX * 1.25): DY = DY - 20: B = 1:  GOTO 11789

IF X < 0 AND B = 0 AND S = 2 THEN S = 1: DX = DX + 25: B = 1: H = 0: GOTO 11789
IF X > 330 AND B = 0 AND S = 1 THEN S = 2: DX = DX + 25: B = 1: H = 0: GOTO 11789

IF Y > 300 THEN GOTO 905
11789

LOOP UNTIL INKEY$ = CHR$(27)
GOTO 78

906
SCREEN 13: CLS
RANDOMIZE TIMER
ROY = 6
REDIM X(ROY), Y(ROY), A(ROY), XB(ROY), YB(ROY)
S = 1
C = 20
FOR T = 1 TO ROY
X(T) = INT(RND * 320) + 1
Y(T) = INT(RND * 200) + 1
A(T) = INT(RND * 4) + 1
NEXT T
DO
FOR T = 1 TO ROY

YB(T) = Y(T): XB(T) = X(T)

IF A(T) = 1 THEN X(T) = X(T) - S: Y(T) = Y(T) - S
IF A(T) = 2 THEN X(T) = X(T) - S: Y(T) = Y(T) + S
IF A(T) = 3 THEN X(T) = X(T) + S: Y(T) = Y(T) + S
IF A(T) = 4 THEN X(T) = X(T) + S: Y(T) = Y(T) - S

IF X(T) < 0 AND A(T) = 1 THEN A(T) = 4
IF X(T) < 0 AND A(T) = 2 THEN A(T) = 3
IF X(T) > 320 AND A(T) = 4 THEN A(T) = 1
IF X(T) > 320 AND A(T) = 3 THEN A(T) = 2

IF Y(T) < 0 AND A(T) = 1 THEN A(T) = 2
IF Y(T) < 0 AND A(T) = 4 THEN A(T) = 3
IF Y(T) > 200 AND A(T) = 2 THEN A(T) = 1
IF Y(T) > 200 AND A(T) = 3 THEN A(T) = 4

FOR TT = 1 TO ROY - 1

XX = 160 - X(TT)
YY = Y(TT)
XX2 = 160 - X(TT + 1)
YY2 = Y(TT + 1)

ZZ = 160 - XB(TT)
WW = YB(TT)
ZZ2 = 160 - XB(TT + 1)
WW2 = YB(TT + 1)

LINE (160 + ZZ, WW)-(160 + ZZ2, WW2), 0
LINE (XB(TT), YB(TT))-(XB(TT + 1), YB(TT + 1)), 0

C = C + .01
IF C > 200 THEN C = 20

LINE (X(TT), Y(TT))-(X(TT + 1), Y(TT + 1)), 10 + C
LINE (160 + XX, YY)-(160 + XX2, YY2), 15 + C


NEXT TT

NEXT T
LOOP UNTIL INKEY$ = CHR$(27)
ERASE X, Y, A, XB, YB

78
END SUB

SUB OMEGA
SCREEN 0: CLS
WIDTH 80, 25
COLOR 15: LOCATE 3, 21: PRINT "* OMEGA BEEMS BY ROY MASSAAD (1997) *"
COLOR 10
255
3 LOCATE 8, 22: INPUT "ENTER LENGTH LEVEL (-150 150) "; CCC1
IF CCC1 < -150 OR CCC1 > 150 THEN GOTO 3
4 LOCATE 10, 22: INPUT "ENTER DENSITY LEVEL (1-95) "; DENS
IF DENS < 0 OR DENS > 95 THEN GOTO 4
IF DENS = 0 THEN DENS = 85
DENS = 100 - DENS
SCREEN 13: CLS
RANDOMIZE TIMER
X = INT(RND * 318) + 1
Y = INT(RND * 198) + 1
Z = INT(RND * 318) + 1
W = INT(RND * 198) + 1
M = INT(RND * 318) + 1
N = INT(RND * 198) + 1
A = INT(RND * 4) + 1
B = INT(RND * 4) + 1
C = INT(RND * 4) + 1
REDIM BX(1000)
REDIM BY(1000)
REDIM BZ(1000)
REDIM BW(1000)
REDIM BM(1000)
REDIM BN(1000)
BUTT = 15
DO
BUTT = BUTT + .001
IF BUTT >= 320 THEN BUTT = 16
SHIT = SHIT + 1
IF SHIT = (201 + CCC1) THEN SHIT = 1
BX(SHIT) = X
BY(SHIT) = Y
BZ(SHIT) = Z
BW(SHIT) = W
BM(SHIT) = M
BN(SHIT) = N
LINE (X, Y)-(Z, W), 11 + BUTT: LINE (Z, W)-(M, N), 12 + BUTT: LINE (M, N)-(X, Y), 13 + BUTT
FOR AAA = 1 TO (200 + CCC1) STEP DENS
BUTT = BUTT + .001
HEAD = HEAD + 1
IF HEAD = 11 THEN HEAD = 1
ABC = SHIT - AAA
IF ABC < 0 THEN ABC = ABC + (200 + CCC1)
LINE (BX(ABC), BY(ABC))-(BZ(ABC), BW(ABC)), BUTT + 4: LINE (BZ(ABC), BW(ABC))-(BM(ABC), BN(ABC)), BUTT + 4: LINE (BM(ABC), BN(ABC))-(BX(ABC), BY(ABC)), BUTT + 4
NEXT AAA
HEAD1 = Y: BUTT1 = X: HEAD2 = W: BUTT2 = Z: HEAD3 = N: BUTT3 = M
K$ = INKEY$
IF K$ = CHR$(27) THEN GOTO 1001
IF A = 1 THEN X = X + .25: Y = Y + .25
IF A = 2 THEN X = X - .25: Y = Y - .25
IF A = 3 THEN X = X + .25: Y = Y - .25
IF A = 4 THEN X = X - .25: Y = Y + .25
IF X >= 320 AND Y > HEAD1 AND X > BUTT1 THEN A = 4
IF X >= 320 AND Y < HEAD1 AND X > BUTT1 THEN A = 2
IF X <= 0 AND Y > HEAD1 AND X < BUTT1 THEN A = 1
IF X <= 0 AND Y < HEAD1 AND X < BUTT1 THEN A = 3
IF Y >= 200 AND X > BUTT1 AND Y > HEAD1 THEN A = 3
IF Y >= 200 AND X < BUTT1 AND Y > HEAD1 THEN A = 2
IF Y <= 0 AND X > BUTT1 AND Y < HEAD1 THEN A = 1
IF Y <= 0 AND X < BUTT1 AND Y < HEAD1 THEN A = 4
IF B = 1 THEN Z = Z + .55: W = W + .55
IF B = 2 THEN Z = Z - .55: W = W - .55
IF B = 3 THEN Z = Z + .55: W = W - .55
IF B = 4 THEN Z = Z - .55: W = W + .55
IF Z >= 320 AND W > HEAD2 AND Z > BUTT2 THEN B = 4
IF Z >= 320 AND W < HEAD2 AND Z > BUTT2 THEN B = 2
IF Z <= 0 AND W > HEAD2 AND Z < BUTT2 THEN B = 1
IF Z <= 0 AND W < HEAD2 AND Z < BUTT2 THEN B = 3
IF W >= 200 AND Z > BUTT2 AND W > HEAD2 THEN B = 3
IF W >= 200 AND Z < BUTT2 AND W > HEAD2 THEN B = 2
IF W <= 0 AND Z > BUTT2 AND W < HEAD2 THEN B = 1
IF W <= 0 AND Z < BUTT2 AND W < HEAD2 THEN B = 4
IF C = 1 THEN M = M + .74: N = N + .74
IF C = 2 THEN M = M - .74: N = N - .74
IF C = 3 THEN M = M + .74: N = N - .74
IF C = 4 THEN M = M - .74: N = N + .74
IF M >= 320 AND N > HEAD3 AND M > BUTT3 THEN C = 4
IF M >= 320 AND N < HEAD3 AND M > BUTT3 THEN C = 2
IF M <= 0 AND N > HEAD3 AND M < BUTT3 THEN C = 1
IF M <= 0 AND N < HEAD3 AND M < BUTT3 THEN C = 3
IF N >= 200 AND M > BUTT3 AND N > HEAD3 THEN C = 3
IF N >= 200 AND M < BUTT3 AND N > HEAD3 THEN C = 2
IF N <= 0 AND M > BUTT3 AND N < HEAD3 THEN C = 1
IF N <= 0 AND M < BUTT3 AND N < HEAD3 THEN C = 4
FOR TOT = 1 TO 500: NEXT TOT
LINE (BUTT1, HEAD1)-(BUTT2, HEAD2), 0: LINE (BUTT2, HEAD2)-(BUTT3, HEAD3), 0: LINE (BUTT3, HEAD3)-(BUTT1, HEAD1), 0
FOR AAA = 1 TO (200 + CCC1) STEP DENS
BUTT = BUTT + .001
ABC = SHIT - AAA
IF ABC < 0 THEN ABC = ABC + (200 + CCC1)
LINE (BX(ABC), BY(ABC))-(BZ(ABC), BW(ABC)), 0: LINE (BZ(ABC), BW(ABC))-(BM(ABC), BN(ABC)), 0: LINE (BM(ABC), BN(ABC))-(BX(ABC), BY(ABC)), 0
NEXT AAA
LOOP
1001
ERASE BX, BY, BZ, BW, BM, BN

END SUB

SUB SAVER
SCREEN 13: CLS
RANDOMIZE TIMER
ROY = 50
REDIM X(ROY), Y(ROY), A(ROY), COL(ROY), XXX(ROY), YYY(ROY)
FOR T = 1 TO ROY
X(T) = INT(RND * 320) + 1
Y(T) = INT(RND * 200) + 1
A(T) = INT(RND * 4) + 1
COL(T) = INT(RND * 10) + 20
XXX(T) = INT(RND * 4) + 3
YYY(T) = INT(RND * 4) + 3
NEXT T
T = 0
PPP3 = 0
DO
K$ = INKEY$
IF K$ <> "" THEN ERASE X, Y, A, COL, XXX, YYY: GOTO 11113
T = T + 1
IF T > ROY THEN T = 1
IF PPP3 = 0 THEN COL(T) = COL(T) + 1
IF PPP3 = 1 THEN COL(T) = COL(T) - 1
IF COL(T) > 30 THEN PPP3 = 1: COL(T) = 30
IF COL(T) < 20 THEN PPP3 = 0: COL(T) = 20
IF A(T) = 1 THEN X(T) = (X(T) + XXX(T)): Y(T) = (Y(T) + YYY(T))
IF A(T) = 2 THEN X(T) = (X(T) - XXX(T)): Y(T) = (Y(T) - YYY(T))
IF A(T) = 3 THEN X(T) = (X(T) + XXX(T)): Y(T) = (Y(T) - YYY(T))
IF A(T) = 4 THEN X(T) = (X(T) - XXX(T)): Y(T) = (Y(T) + YYY(T))
IF X(T) > 320 AND A(T) = 1 THEN A(T) = 4: X(T) = 320
IF X(T) > 320 AND A(T) = 3 THEN A(T) = 2: X(T) = 320
IF X(T) < 0 AND A(T) = 4 THEN A(T) = 1:  X(T) = 0
IF X(T) < 0 AND A(T) = 2 THEN A(T) = 3:  X(T) = 0
IF Y(T) > 200 AND A(T) = 1 THEN A(T) = 3:  Y(T) = 200
IF Y(T) > 200 AND A(T) = 4 THEN A(T) = 2:  Y(T) = 200
IF Y(T) < 0 AND A(T) = 3 THEN A(T) = 1:  Y(T) = 0
IF Y(T) < 0 AND A(T) = 2 THEN A(T) = 4:  Y(T) = 0
PSET (X(T), Y(T)), COL(T)
IF T <> ROY THEN PRESET (X(T + 1), Y(T + 1))
IF T = ROY THEN PRESET (X(1), Y(1))

LOOP
11113
END SUB

SUB SAVER2
'SCREEN 13: CLS
RANDOMIZE TIMER
ROY = 10
REDIM X(ROY), Y(ROY), A(ROY), COL(ROY), XXX(ROY), YYY(ROY), R1(ROY), R2(ROY), F(ROY), BACK(ROY), BACK2(ROY)
FOR T = 1 TO ROY
X(T) = INT(RND * 320) + 1
Y(T) = INT(RND * 200) + 1
A(T) = INT(RND * 4) + 1
COL(T) = INT(RND * 60) + 40
XXX(T) = INT(RND * 5) + 1
YYY(T) = INT(RND * 5) + 1
BACK(T) = X(T) + R1(T)
BACK2(T) = Y(T) + R2(T)
NEXT T
T = 0
DO
K$ = INKEY$
IF K$ <> "" THEN ERASE X, Y, A, COL, XXX, YYY, R1, R2, F, BACK, BACK2: GOTO 6767
T = T + 1
IF T > ROY THEN T = 1
IF PPP3 = 0 THEN COL(T) = COL(T) + 1
IF PPP3 = 1 THEN COL(T) = COL(T) - 1
IF COL(T) > 60 THEN PPP3 = 1: COL(T) = 60
IF COL(T) < 40 THEN PPP3 = 0: COL(T) = 40
IF A(T) = 1 THEN X(T) = (X(T) + XXX(T)): Y(T) = (Y(T) + YYY(T))
IF A(T) = 2 THEN X(T) = (X(T) - XXX(T)): Y(T) = (Y(T) - YYY(T))
IF A(T) = 3 THEN X(T) = (X(T) + XXX(T)): Y(T) = (Y(T) - YYY(T))
IF A(T) = 4 THEN X(T) = (X(T) - XXX(T)): Y(T) = (Y(T) + YYY(T))
IF X(T) > 320 AND A(T) = 1 THEN A(T) = 4: X(T) = 320
IF X(T) > 320 AND A(T) = 3 THEN A(T) = 2: X(T) = 320
IF X(T) < 0 AND A(T) = 4 THEN A(T) = 1:  X(T) = 0
IF X(T) < 0 AND A(T) = 2 THEN A(T) = 3:  X(T) = 0
IF Y(T) > 200 AND A(T) = 1 THEN A(T) = 3:  Y(T) = 200
IF Y(T) > 200 AND A(T) = 4 THEN A(T) = 2:  Y(T) = 200
IF Y(T) < 0 AND A(T) = 3 THEN A(T) = 1:  Y(T) = 0
IF Y(T) < 0 AND A(T) = 2 THEN A(T) = 4:  Y(T) = 0
F(T) = F(T) + .1
IF F(T) > 7.2 THEN F(T) = 1
R1(T) = COS(F(T)) * 15
R2(T) = SIN(F(T)) * 15
LINE (X(T) + R1(T), Y(T) + R2(T))-(BACK(T), BACK2(T)), COL(T)
BACK(T) = X(T) + R1(T)
BACK2(T) = Y(T) + R2(T)
FOR TRT = 1 TO 200: NEXT TRT
LOOP

6767
END SUB

SUB SAVER3
SCREEN 13: CLS
RANDOMIZE TIMER
ROY = 6
REDIM X(ROY), Y(ROY), A(ROY), COL(ROY), XXX(ROY), YYY(ROY), R1(ROY), R2(ROY), F(ROY), BACK(ROY), BACK2(ROY)
FOR T = 1 TO ROY
X(T) = INT(RND * 320) + 1
Y(T) = INT(RND * 200) + 1
A(T) = INT(RND * 4) + 1
COL(T) = INT(RND * 20) + 40
XXX(T) = INT(RND * 5) + 1
YYY(T) = INT(RND * 5) + 1
BACK(T) = X(T - 1) + R1(T - 1)
BACK2(T) = Y(T - 1) + R2(T - 1)
IF T = 1 THEN BACK(T) = X(ROY) + R1(ROY): BACK2(T) = Y(ROY) + R2(ROY)
NEXT T
T = 0
DO
K$ = INKEY$
IF K$ <> "" THEN ERASE X, Y, A, COL, XXX, YYY, R1, R2, F, BACK, BACK2: GOTO 77777
T = T + 1
IF T > ROY THEN T = 1
IF PPP3 = 0 THEN COL(T) = COL(T) + .1
IF PPP3 = 1 THEN COL(T) = COL(T) - .1
IF COL(T) < 40 THEN PPP3 = 0: COL(T) = 40
IF COL(T) > 60 THEN PPP3 = 1: COL(T) = 60
IF A(T) = 1 THEN X(T) = (X(T) + XXX(T)): Y(T) = (Y(T) + YYY(T))
IF A(T) = 2 THEN X(T) = (X(T) - XXX(T)): Y(T) = (Y(T) - YYY(T))
IF A(T) = 3 THEN X(T) = (X(T) + XXX(T)): Y(T) = (Y(T) - YYY(T))
IF A(T) = 4 THEN X(T) = (X(T) - XXX(T)): Y(T) = (Y(T) + YYY(T))
IF X(T) > 320 AND A(T) = 1 THEN A(T) = 4: X(T) = 320
IF X(T) > 320 AND A(T) = 3 THEN A(T) = 2: X(T) = 320
IF X(T) < 0 AND A(T) = 4 THEN A(T) = 1:  X(T) = 0
IF X(T) < 0 AND A(T) = 2 THEN A(T) = 3:  X(T) = 0
IF Y(T) > 200 AND A(T) = 1 THEN A(T) = 3:  Y(T) = 200
IF Y(T) > 200 AND A(T) = 4 THEN A(T) = 2:  Y(T) = 200
IF Y(T) < 0 AND A(T) = 3 THEN A(T) = 1:  Y(T) = 0
IF Y(T) < 0 AND A(T) = 2 THEN A(T) = 4:  Y(T) = 0
F(T) = F(T) + .1
IF F(T) > 7.2 THEN F(T) = 1
R1(T) = COS(F(T)) * 15
R2(T) = SIN(F(T)) * 15
LINE (X(T) + R1(T), Y(T) + R2(T))-(160, 100), COL(T)
FOR TOT = 1 TO 1000: NEXT TOT
LINE (160, 100)-(BACK(T), BACK2(T)), 0
BACK(T) = X(T - 1) + R1(T - 1)
BACK2(T) = Y(T - 1) + R2(T - 1)
IF T = 1 THEN BACK(T) = X(ROY) + R1(ROY): BACK2(T) = Y(ROY) + R2(ROY)
LOOP
77777
END SUB

SUB SHELLA
SCREEN 0: CLS
WIDTH 80, 25
LOCATE 3, 20: COLOR 10: PRINT "GRAVITY BY ROY MEGA GAMES"
1113 LOCATE 6, 20: COLOR 15: INPUT "CHOOSE A MODE (1-3)"; MD
IF MD <= 0 OR MD >= 4 THEN GOTO 1113
IF MD = 1 THEN GOTO 1010
IF MD = 2 THEN GOTO 1020
IF MD = 3 THEN GOTO 1030

1010 SCREEN 13: CLS
RANDOMIZE TIMER
REDIM QWE(100): REDIM ASD(100): REDIM ZXC(100)
D1 = INT(RND * 80) + 1
D2 = INT(RND * 80) + 1
D3 = INT(RND * 80) + 1
D4 = INT(RND * 80) + 1
DD1 = (INT(RND * 50) + 1) / 10
DD2 = (INT(RND * 50) + 1) / 10

AD1 = INT(RND * 80) + 1
AD2 = INT(RND * 80) + 1
AD3 = INT(RND * 80) + 1
AD4 = INT(RND * 80) + 1
ADD1 = (INT(RND * 50) + 1) / 10
ADD2 = (INT(RND * 50) + 1) / 10

BD1 = INT(RND * 80) + 1
BD2 = INT(RND * 80) + 1
BD3 = INT(RND * 80) + 1
BD4 = INT(RND * 80) + 1
BDD1 = (INT(RND * 50) + 1) / 10
BDD2 = (INT(RND * 50) + 1) / 10

FOR T = 1 TO 100
QWE(T) = INT(RND * 360) + 1
ASD(T) = INT(RND * 200) + 1
ZXC(T) = INT(RND * 10) + 20
NEXT T

DO
FOR X = 1 TO 7.25 STEP .01
K$ = INKEY$
IF K$ = CHR$(27) THEN ERASE QWE, ASD, ZXC: GOTO 23
IF K$ <> "" THEN ERASE QWE, ASD, ZXC: GOTO 1010
XX = COS(X) * D1
YY = SIN(X) * D2
XX2 = COS(X + DD1) * D3
YY2 = SIN(X + DD2) * D4

AXX = COS(X) * AD1
AYY = SIN(X) * AD2
AXX2 = COS(X + ADD1) * AD3
AYY2 = SIN(X + ADD2) * AD4

BXX = COS(X) * BD1
BYY = SIN(X) * BD2
BXX2 = COS(X + BDD1) * BD3
BYY2 = SIN(X + BDD2) * BD4

LINE (BXX + 160, BYY + 100)-(BXX2 + 160, BYY2 + 100), 13
LINE (AXX + 160, AYY + 100)-(AXX2 + 160, AYY2 + 100), 14
LINE (XX + 160, YY + 100)-(XX2 + 160, YY2 + 100), 10
FOR T = 1 TO 100
PSET (QWE(T), ASD(T)), ZXC(T)
NEXT T
FOR TOT = 1 TO 1000: NEXT TOT
LINE (XX + 160, YY + 100)-(XX2 + 160, YY2 + 100), 0
LINE (AXX + 160, AYY + 100)-(AXX2 + 160, AYY2 + 100), 0
LINE (BXX + 160, BYY + 100)-(BXX2 + 160, BYY2 + 100), 0

NEXT X
LOOP

1020 SCREEN 13: CLS
RANDOMIZE TIMER
DO
D1 = INT(RND * 80) + 1
D2 = INT(RND * 80) + 1
D3 = INT(RND * 80) + 1
D4 = INT(RND * 80) + 1
DD1 = (INT(RND * 50) + 1) / 10
DD2 = (INT(RND * 50) + 1) / 10

AD1 = INT(RND * 80) + 1
AD2 = INT(RND * 80) + 1
AD3 = INT(RND * 80) + 1
AD4 = INT(RND * 80) + 1
ADD1 = (INT(RND * 50) + 1) / 10
ADD2 = (INT(RND * 50) + 1) / 10

BD1 = INT(RND * 80) + 1
BD2 = INT(RND * 80) + 1
BD3 = INT(RND * 80) + 1
BD4 = INT(RND * 80) + 1
BDD1 = (INT(RND * 50) + 1) / 10
BDD2 = (INT(RND * 50) + 1) / 10

FOR X = 1 TO 30 STEP .01
K$ = INKEY$
IF K$ = CHR$(27) THEN GOTO 23
IF K$ <> "" THEN GOTO 1020
XX = COS(X) * D1
YY = SIN(X) * D2
XX2 = COS(X + DD1) * D3
YY2 = SIN(X + DD2) * D4

AXX = COS(X) * AD1
AYY = SIN(X) * AD2
AXX2 = COS(X + ADD1) * AD3
AYY2 = SIN(X + ADD2) * AD4

BXX = COS(X) * BD1
BYY = SIN(X) * BD2
BXX2 = COS(X + BDD1) * BD3
BYY2 = SIN(X + BDD2) * BD4
COC = COC + .1
LINE (BXX + 160, BYY + 100)-(BXX2 + 160, BYY2 + 100), 20 + COC
LINE (AXX + 160, AYY + 100)-(AXX2 + 160, AYY2 + 100), 30 + COC
LINE (XX + 160, YY + 100)-(XX2 + 160, YY2 + 100), 40 + COC
FOR T = 1 TO 1000: NEXT T
NEXT X
LOOP

1030 SCREEN 13: CLS
RANDOMIZE TIMER
DO
D1 = INT(RND * 80) + 1
D2 = INT(RND * 80) + 1
D3 = INT(RND * 80) + 1
D4 = INT(RND * 80) + 1
DD1 = (INT(RND * 50) + 1) / 10
DD2 = (INT(RND * 50) + 1) / 10

AD1 = INT(RND * 80) + 1
AD2 = INT(RND * 80) + 1
AD3 = INT(RND * 80) + 1
AD4 = INT(RND * 80) + 1
ADD1 = (INT(RND * 50) + 1) / 10
ADD2 = (INT(RND * 50) + 1) / 10

BD1 = INT(RND * 80) + 1
BD2 = INT(RND * 80) + 1
BD3 = INT(RND * 80) + 1
BD4 = INT(RND * 80) + 1
BDD1 = (INT(RND * 50) + 1) / 10
BDD2 = (INT(RND * 50) + 1) / 10

FOR X = 1 TO 300 STEP .01
K$ = INKEY$
IF K$ = CHR$(27) THEN GOTO 23
IF K$ <> "" THEN GOTO 1030
XX = COS(X) * D1
YY = SIN(X) * D2
XX2 = COS(X + DD1) * D3
YY2 = SIN(X + DD2) * D4

AXX = COS(X) * AD1
AYY = SIN(X) * AD2
AXX2 = COS(X + ADD1) * AD3
AYY2 = SIN(X + ADD2) * AD4

BXX = COS(X) * BD1
BYY = SIN(X) * BD2
BXX2 = COS(X + BDD1) * BD3
BYY2 = SIN(X + BDD2) * BD4

COC = COC + .1
LINE (BXX + 160, BYY + 100)-(BXX2 + 160, BYY2 + 100), 18 + COC
LINE (AXX + 160, AYY + 100)-(AXX2 + 160, AYY2 + 100), 19 + COC
LINE (XX + 160, YY + 100)-(XX2 + 160, YY2 + 100), 20 + COC
LINE (XX + 160, YY + 100)-(AXX2 + 160, AYY2 + 100), 21 + COC
LINE (XX + 160, YY + 100)-(BXX2 + 160, BYY2 + 100), 22 + COC
LINE (AXX + 160, AYY + 100)-(BXX2 + 160, BYY2 + 100), 23 + COC
LINE (BXX + 160, BYY + 100)-(AXX2 + 160, AYY2 + 100), 24 + COC
LINE (AXX + 160, AYY + 100)-(XX2 + 160, YY2 + 100), 25 + COC
LINE (BXX + 160, BYY + 100)-(XX2 + 160, YY2 + 100), 26 + COC

FOR T = 1 TO 1500: NEXT T
LINE (XX + 160, YY + 100)-(XX2 + 160, YY2 + 100), 0
LINE (AXX + 160, AYY + 100)-(AXX2 + 160, AYY2 + 100), 0
LINE (BXX + 160, BYY + 100)-(BXX2 + 160, BYY2 + 100), 0
LINE (BXX + 160, BYY + 100)-(AXX2 + 160, AYY2 + 100), 0
LINE (AXX + 160, AYY + 100)-(BXX2 + 160, BYY2 + 100), 0
LINE (XX + 160, YY + 100)-(BXX2 + 160, BYY2 + 100), 0
LINE (XX + 160, YY + 100)-(AXX2 + 160, AYY2 + 100), 0
LINE (AXX + 160, AYY + 100)-(XX2 + 160, YY2 + 100), 0
LINE (BXX + 160, BYY + 100)-(XX2 + 160, YY2 + 100), 0
NEXT X
LOOP

23
END SUB

SUB SHOW (AX$, BX, BY)
RANDOMIZE TIMER
REDIM B$(LEN(AX$))
REDIM F(1000)
FOR X = 1 TO LEN(AX$)
B$(X) = MID$(AX$, X, 1)
NEXT X
FOR X = 1 TO LEN(AX$)
K$ = INKEY$
IF K$ = CHR$(27) THEN SYSTEM
O = O + 1
111 C = INT(RND * LEN(AX$)) + 1
F(O) = C
FOR TC = 0 TO (O - 1)
IF F(TC) = F(O) THEN GOTO 111
NEXT TC
ROY$ = MID$(AX$, C, 1)
FOR G = 18 TO 30 STEP .03
LOCATE BX, BY + C
COLOR G
PRINT ROY$;
NEXT G
FOR T = 1 TO 1000: NEXT T
NEXT X
ERASE F, B$
END SUB

SUB SPHERES
SCREEN 13: CLS
RANDOMIZE TIMER
FOR GTS = 1 TO 150
XS = INT(RND * 318) + 1
YS = INT(RND * 198) + 1
COLS = INT(RND * 14) + 18
PSET (XS, YS), COLS
NEXT GTS
X = 150
Y = 100
Q1 = 1: Q2 = 2
WWW = 1
WIDE = 1
DO
K$ = INKEY$
IF K$ = CHR$(27) THEN GOTO 88
CHOOSE = INT(RND * 2)
IF CHOOSE = 0 THEN GOTO 1011
IF CHOOSE = 1 THEN GOTO 20
1011 Z = INT(RND * 311)
W = INT(RND * 2)
W = W * 260
GOTO 30
20 Z = INT(RND * 2)
W = INT(RND * 260)
Z = Z * 310
GOTO 30
30 IF X > Z THEN AF = -1
IF X < Z THEN AF = 1
SHIT = (W - Y)
SHIT2 = (Z - X)
IF SHIT2 = 0 THEN SHIT2 = .00000001#
M = SHIT / SHIT2
P = Y - (M * X)
FOR XX = X TO Z STEP AF
K$ = INKEY$
YY = (M * XX) + P
COL = COL + 1
IF COL > 300 THEN COL = 0
IF ACS = 0 THEN BUTT = BUTT + 1
IF ACS = 1 THEN BUTT = BUTT - 1
IF BUTT = 50 THEN ACS = 1
IF BUTT = 1 THEN ACS = 0
Q1 = Q1 + .5
IF Q1 > 6 THEN Q1 = 0
Q2 = Q2 + .5
IF Q2 > 6 THEN Q2 = 0
CIRCLE (XX, YY), BUTT, COL, Q1, Q2, WWW: PSET (XX, YY), 10
FOR HH = 1 TO 2500: NEXT HH
IF K$ = CHR$(27) THEN GOTO 88
NEXT XX
WWW = INT(RND * 30) + 1
WWW = (WWW / 10)
DUD = DUD + 1
IF DUD = 5 THEN DUD = 0: Q1 = INT(RND * 5) + 1: Q2 = INT(RND * 5) + 1: GOSUB 999
LOOP
999 CLS
FOR GTS = 1 TO 150
XS = INT(RND * 318) + 1
YS = INT(RND * 198) + 1
COLS = INT(RND * 14) + 18
PSET (XS, YS), COLS
NEXT GTS
RETURN
88
END SUB

SUB SPOTS
SCREEN 0: CLS
WIDTH 80, 25
LOCATE 3, 25: COLOR 10: PRINT "SPOTS BY ROY ROY MEGA GAMES 1997@. "
15675 LOCATE 6, 30: COLOR 15: INPUT "CHOOSE A MODE (1-9) "; DDD
IF DDD > 9 OR DDD < 1 THEN GOTO 15675
IF DDD = 1 THEN GOTO 1778
IF DDD = 2 THEN GOTO 2778
IF DDD = 3 THEN GOTO 3778
IF DDD = 4 THEN GOTO 1255
IF DDD = 5 THEN GOTO 4778
IF DDD = 6 THEN GOTO 5778
IF DDD = 7 THEN GOTO 6778
IF DDD = 8 THEN GOTO 8778
IF DDD = 9 THEN GOTO 9778

1778
SCREEN 13: CLS
RANDOMIZE TIMER
DO
K$ = INKEY$
IF K$ = CHR$(27) THEN GOTO 677
X = INT(RND * 320) + 1
Y = INT(RND * 200) + 1
Z = INT(RND * 50) + 1
C = INT(RND * 300) + 1
S = INT(RND * 6.2) + .1
S2 = INT(RND * 6.2) + .1
A = INT(RND * 20) - 10
FOR T = 1 TO Z
CIRCLE (X, Y), T, C + (T / 10), S, S2, A
NEXT T
LOOP
2778
SCREEN 13: CLS
RANDOMIZE TIMER
DO
K$ = INKEY$
IF K$ = CHR$(27) THEN GOTO 677
X = INT(RND * 320)
Y = INT(RND * 200)
C = INT(RND * 30) + 30
PSET (X, Y)
FOR T = 1 TO 30
C = C + .5
CIRCLE (X, Y), T, C
LINE (X, Y - T)-(X - T, Y), C
LINE (X, Y + T)-(X - T, Y), C
LINE (X, Y + T)-(X + T, Y), C
LINE (X, Y - T)-(X + T, Y), C
NEXT T
LOOP

3778
SCREEN 13: CLS
RANDOMIZE TIMER
DO
K$ = INKEY$
IF K$ = CHR$(27) THEN GOTO 677
X = INT(RND * 320)
Y = INT(RND * 200)
C = INT(RND * 30) + 30
PSET (X, Y)
FOR T = 1 TO 30
C = C + .5
CIRCLE (X, Y), T, C
LINE (X, Y - T)-(X - T, Y), C, B
LINE (X, Y + T)-(X - T, Y), C, B
LINE (X, Y + T)-(X + T, Y), C, B
LINE (X, Y - T)-(X + T, Y), C, B
NEXT T
LOOP

1255 E = 0
RANDOMIZE TIMER
C = INT(RND * 100) + 1
SCREEN 13: CLS
REDIM BOX%(1 TO 200)
X1% = 0: X2% = 10: Y1% = 0: Y2% = 10
LINE (X1%, Y1%)-(X2%, Y2%), C, BF
GET (X1%, Y1%)-(X2%, Y2%), BOX%
DO
K$ = INKEY$
E = E + 1
PUT (X1%, Y1%), BOX%, XOR
X1% = RND * 300
Y1% = RND * 180
IF E = 1500 THEN EXIT DO
IF K$ = CHR$(27) THEN GOTO 677
FOR T = 1 TO 10: NEXT T
LOOP
ERASE BOX%
GOTO 1255

4778
SCREEN 13: CLS
RANDOMIZE TIMER
DO
K$ = INKEY$
IF K$ = CHR$(27) THEN GOTO 677
X1 = INT(RND * 300) + 1
Y1 = INT(RND * 200) + 1
Y2 = INT(RND * (200 - Y1)) + Y1
FOR T = Y1 TO Y2 STEP .05
C = C + .01
PSET (X1, T), C
NEXT T
D = INT(RND * 40) + 1
FOR T = 1 TO D STEP .05
C = C + .01
CIRCLE (X1, Y2), T, C, 1.8, 1.3, .3
NEXT T
LOOP

5778
SCREEN 13: CLS
RANDOMIZE TIMER
REDIM X(100): REDIM Y(100): REDIM A(100): : REDIM TTT(100)
FFF = INT(RND * 3) + 1
FOR T = 1 TO 50
X(T) = INT(RND * 360) + 1
Y(T) = INT(RND * 200) + 1
NEXT T
DO
K$ = INKEY$
IF K$ = CHR$(27) THEN ERASE X, Y, A, TTT: GOTO 677
IF K$ <> "" THEN ERASE X, Y, A, TTT: GOTO 5778
TT = TT + 1
IF TT > 50 THEN TT = 1
XX = X(TT)
YY = Y(TT)
A(TT) = A(TT) + 1

IF FFF = 1 THEN TTT(TT) = TTT(TT) + 1
IF FFF = 1 THEN CIRCLE (X(TT), Y(TT)), A(TT), TTT(TT)

IF FFF = 2 THEN TTTT = TTTT + 1
IF FFF = 2 THEN CIRCLE (X(TT), Y(TT)), A(TT), TTTT

IF FFF = 3 THEN CIRCLE (X(TT), Y(TT)), A(TT), TT

QQQQ = QQQQ + 1
IF QQQQ > 20000 THEN ERASE X, Y, A, TTT: GOTO 5778
LOOP

6778
SCREEN 13: CLS
RANDOMIZE TIMER
AX = INT(RND * 320) + 1
AY = INT(RND * 200) + 1
BX = INT(RND * 320) + 1
BY = INT(RND * 200) + 1
AD = INT(RND * 15) + 40
BD = INT(RND * 15) + 40
A = INT(RND * 4) + 1
B = INT(RND * 4) + 1

DO
FAX = AX: FAY = AY: FBX = BX: FBY = BY
FD = FD + .05
IF A = 1 THEN AX = AX + 3: AY = AY + 3
IF A = 2 THEN AX = AX - 3: AY = AY - 3
IF A = 3 THEN AX = AX + 3: AY = AY - 3
IF A = 4 THEN AX = AX - 3: AY = AY + 3
IF AX > 320 AND A = 1 THEN A = 4: AX = 320
IF AX > 320 AND A = 3 THEN A = 2: AX = 320
IF AX < 0 AND A = 4 THEN A = 1:  AX = 0
IF AX < 0 AND A = 2 THEN A = 3:  AX = 0
IF AY > 200 AND A = 1 THEN A = 3: AY = 200
IF AY > 200 AND A = 4 THEN A = 2:  AY = 200
IF AY < 0 AND A = 3 THEN A = 1:  AY = 0
IF AY < 0 AND A = 2 THEN A = 4:  AY = 0

IF B = 1 THEN BX = BX + 3: BY = BY + 3
IF B = 2 THEN BX = BX - 3: BY = BY - 3
IF B = 3 THEN BX = BX + 3: BY = BY - 3
IF B = 4 THEN BX = BX - 3: BY = BY + 3
IF BX > 320 AND B = 1 THEN B = 4: BX = 320
IF BX > 320 AND B = 3 THEN B = 2: BX = 320
IF BX < 0 AND B = 4 THEN B = 1: BX = 0
IF BX < 0 AND B = 2 THEN B = 3: BX = 0
IF BY > 200 AND B = 1 THEN B = 3: BY = 200
IF BY > 200 AND B = 4 THEN B = 2:  BY = 200
IF BY < 0 AND B = 3 THEN B = 1: BY = 0
IF BY < 0 AND B = 2 THEN B = 4: BY = 0
IF INKEY$ = CHR$(27) THEN GOTO 677
CLS 1
FOR T = 1 TO 7.3 STEP .05
AAX = (COS(T) * AD) + AX
AAY = (SIN(T) * AD) + AY
D1 = INT(SQR(((BX - AAX) * (BX - AAX)) + ((BY - AAY) * (BY - AAY))))
IF D1 < BD THEN GOTO 1
PSET (AAX, AAY), 14 + FD
1
BBY = (SIN(T) * BD) + BY
BBX = (COS(T) * BD) + BX
D2 = INT(SQR(((AX - BBX) * (AX - BBX)) + ((AY - BBY) * (AY - BBY))))
IF D2 < AD THEN GOTO 24
PSET (BBX, BBY), 14 + FD
24
NEXT T

LOOP


8778
SCREEN 13: CLS
RANDOMIZE TIMER
ROY = 15
REDIM A(ROY), S(ROY), XB(ROY), YB(ROY), Y(ROY), X(ROY), D(ROY), C(ROY), DES(ROY), CC(ROY)
CCC = 160
CCC2 = 100
FOR T = 1 TO ROY
A(T) = (INT(RND * 73) + 1) / 10
S(T) = INT(RND * 95) + 5
D(T) = INT(RND * 5) + 1
Y(T) = CCC: X(T) = CCC2
C(T) = INT(RND * 100) + 15
DES(T) = INT(RND * 50) + 1
CC(T) = C(T)
NEXT T
DO
FOR T = 1 TO ROY
K$ = INKEY$
IF K$ = CHR$(27) THEN ERASE A, S, XB, YB, Y, X, D, C, DES, CC: GOTO 677
YB(T) = Y(T): XB(T) = X(T)
S(T) = S(T) + D(T)
X(T) = COS(A(T)) * S(T)
Y(T) = SIN(A(T)) * S(T)
COLOR C(T)
C(T) = C(T) + .5
IF C(T) > CC(T) + 30 THEN C(T) = CC(T) + 30
CIRCLE (X(T) + CCC, Y(T) + CCC2), DES(T)
CIRCLE (XB(T) + CCC, YB(T) + CCC2), DES(T), 0
IF (Y(T) + CCC2) < -50 OR (Y(T) + CCC2) > 250 OR (X(T) + CCC) < -50 OR (X(T) + CCC) > 370 THEN GOSUB 1078
NEXT T
LINE (0, 0)-(319, 199), 0, B

LOOP
1078
A(T) = (INT(RND * 73) + 1) / 10
S(T) = INT(RND * 95) + 5
D(T) = INT(RND * 5) + 1
Y(T) = CCC: X(T) = CCC2
C(T) = INT(RND * 100) + 15
DES(T) = INT(RND * 50) + 1
CC(T) = C(T)
RETURN


9778
SCREEN 13: CLS
RANDOMIZE TIMER
ROY = 20
REDIM A(ROY), DX(ROY), DY(ROY), XX(ROY), YY(ROY), S(ROY), G(ROY), X(ROY), Y(ROY), B(ROY), XC(ROY), YC(ROY), DD(ROY), SS(ROY)
FOR T = 1 TO ROY
M = 4.7
A(T) = 4.7
DX(T) = INT(RND * 35) + 35
DY(T) = 600
XX(T) = INT(RND * 300) + 10
YY(T) = DY(T)
S(T) = INT(RND * 2) + 1
G(T) = 30
X(T) = XX(T): Y(T) = -1
SS(T) = (INT(RND * 10) / 650) + .01
DD(T) = INT(RND * 17) + 5
NEXT T
DO
FOR T = 1 TO ROY
XC(T) = X(T): YC(T) = Y(T)
IF S(T) = 1 THEN A(T) = A(T) + SS(T)
IF S(T) = 2 THEN A(T) = A(T) - SS(T)

X(T) = (COS(A(T)) * DX(T)) + XX(T)
Y(T) = (SIN(A(T)) * DY(T)) + YY(T)

CIRCLE (XC(T), YC(T)), DD(T), 0
CIRCLE (X(T), Y(T)), DD(T), G(T)

FOR TOT = 1 TO 200: NEXT TOT

IF B(T) = 1 AND Y(T) < 200 THEN B(T) = 0

IF Y(T) > 200 AND B(T) = 0 AND S(T) = 1 THEN A(T) = M - (A(T) - M): DX(T) = DX(T) + 20: XX(T) = XX(T) + (DX(T) * 1.25): DY(T) = DY(T) - 20: B(T) = 1: SS(T) = SS(T) + .00001: GOTO 1167
IF Y(T) > 200 AND B(T) = 0 AND S(T) = 2 THEN A(T) = M + (M - A(T)): DX(T) = DX(T) + 20: XX(T) = XX(T) - (DX(T) * 1.25): DY(T) = DY(T) - 20: B(T) = 1: SS(T) = SS(T) + .00001: GOTO 1167

IF X(T) < 0 AND B(T) = 0 AND S(T) = 2 THEN S(T) = 1: DX(T) = DX(T) + 25: B(T) = 1: SS(T) = SS(T) + .00001: GOTO 1167
IF X(T) > 320 AND B(T) = 0 AND S(T) = 1 THEN S(T) = 2: DX(T) = DX(T) + 25: B(T) = 1: SS(T) = SS(T) + .00001: GOTO 1167

IF Y(T) > 300 THEN GOSUB 11166
1167
NEXT T
LOOP UNTIL INKEY$ = CHR$(27)
ERASE A, DX, DY, XX, YY, S, G, X, Y, B, XC, YC, DD, SS: GOTO 677
11166
A(T) = 4.7
DX(T) = INT(RND * 35) + 35
DY(T) = 600
XX(T) = INT(RND * 300) + 10
YY(T) = DY(T)
S(T) = INT(RND * 2) + 1
X(T) = XX(T): Y(T) = -1
G(T) = G(T) + 1
RETURN



677
END SUB

SUB TUNNELS
SCREEN 0: CLS
WIDTH 80, 25
LOCATE 3, 20: COLOR 10: PRINT "BUGS & WORMS BY ROY MEGA GAMES"
2223 LOCATE 6, 20: COLOR 15: INPUT "CHOOSE A MODE (1-3)"; MD
IF MD <= 0 OR MD >= 4 THEN GOTO 2223
IF MD = 1 THEN GOTO 2210
IF MD = 2 THEN GOTO 2220
IF MD = 3 THEN GOTO 2230

2210 SCREEN 13: CLS
RANDOMIZE TIMER
REDIM X(100): REDIM Y(100): REDIM A(100)
FOR T = 1 TO 100
X(T) = INT(RND * 360) + 1
Y(T) = INT(RND * 200) + 1
NEXT T
DO
K$ = INKEY$
IF K$ = CHR$(27) THEN ERASE X, Y, A: GOTO 34
TT = TT + 1
IF TT > 100 THEN TT = 1
XX = X(TT)
YY = Y(TT)
A(TT) = INT(RND * 4) + 1
IF A(TT) = 1 THEN X(TT) = X(TT) - 10
IF A(TT) = 2 THEN X(TT) = X(TT) + 10
IF A(TT) = 3 THEN Y(TT) = Y(TT) - 10
IF A(TT) = 4 THEN Y(TT) = Y(TT) + 10
LINE (XX, YY)-(X(TT), Y(TT)), TT
LOOP

2220 SCREEN 13: CLS
RANDOMIZE TIMER
REDIM X(100): REDIM Y(100): REDIM A(100): REDIM CCC(100)
RRR = INT(RND * 30) + 1
RRR2 = INT(RND * 50) + 33
RRR3 = INT(RND * 9) + 1
RRR4 = INT(RND * 9) + 1
FOR T = 1 TO 100
X(T) = 160
Y(T) = 100
CCC(T) = INT(RND * RRR) + RRR2
NEXT T
DO
K$ = INKEY$
IF K$ = CHR$(27) THEN ERASE X, Y, A, CCC: GOTO 34
IF K$ <> "" THEN ERASE X, Y, A, CCC: : GOTO 2220
TT = TT + 1
IF TT > 100 THEN TT = 1
XX = X(TT)
YY = Y(TT)
CCC(TT) = CCC(TT) + 1
IF CCC(TT) > (RRR + RRR2) THEN CCC(TT) = RRR2
A(TT) = INT(RND * 4) + 1
IF A(TT) = 1 THEN X(TT) = X(TT) - RRR3
IF A(TT) = 2 THEN X(TT) = X(TT) + RRR3
IF A(TT) = 3 THEN Y(TT) = Y(TT) - RRR3
IF A(TT) = 4 THEN Y(TT) = Y(TT) + RRR3
LINE (XX, YY)-(X(TT), Y(TT)), CCC(TT)

LOOP

2230
SCREEN 13: CLS
RANDOMIZE TIMER
REDIM X(100): REDIM Y(100): REDIM A(100): REDIM CCC(100)
RRR3 = 1
19999
DDDD = INT(RND * 10) + 1
X2 = INT(RND * 360) + 1
Y2 = INT(RND * 200) + 1
CCC2 = INT(RND * 60) + 20
FOR T = 1 TO DDDD
X(T) = X2
Y(T) = Y2
CCC(T) = INT(RND * 5) + CCC2
NEXT T
FFFF = INT(RND * 10000) + 1
DO
GGGG = GGGG + 1
K$ = INKEY$
IF K$ = CHR$(27) THEN ERASE X, Y, A, CCC: GOTO 34
IF GGGG = FFFF THEN GGGG = 0: GOTO 19999
TT = TT + 1
IF TT > DDDD THEN TT = 1
XX = X(TT)
YY = Y(TT)
CCC(TT) = CCC(TT) + 1
IF CCC(TT) > (CCC2 + 5) THEN CCC(TT) = CCC2
A(TT) = INT(RND * 8) + 1
IF A(TT) = 1 THEN X(TT) = X(TT) - RRR3
IF A(TT) = 2 THEN X(TT) = X(TT) + RRR3
IF A(TT) = 3 THEN Y(TT) = Y(TT) - RRR3
IF A(TT) = 4 THEN Y(TT) = Y(TT) + RRR3
IF A(TT) = 5 THEN X(TT) = X(TT) - RRR3: Y(TT) = Y(TT) - RRR3
IF A(TT) = 6 THEN X(TT) = X(TT) + RRR3: Y(TT) = Y(TT) + RRR3
IF A(TT) = 7 THEN Y(TT) = Y(TT) - RRR3: X(TT) = X(TT) + RRR3
IF A(TT) = 8 THEN Y(TT) = Y(TT) + RRR3: X(TT) = X(TT) - RRR3

LINE (XX, YY)-(X(TT), Y(TT)), CCC(TT)

LOOP



34
END SUB

SUB TYPE1
SCREEN 13: CLS
DO
FOR X = 5 TO 100
K$ = INKEY$
IF K$ = CHR$(27) THEN GOTO 114
FOR S = 1 TO 100 STEP 20
D = D + .1
CIRCLE (150, 100), (X + S) - 1, 0, , , .5
CIRCLE (150, 100), (X + S), D, , , .9
NEXT S
FOR T = 1 TO 100: NEXT T
NEXT X
LOOP
114
END SUB

SUB TYPE2
1234 SCREEN 13: CLS
R = INT(RND * 100) + 1
R2 = INT(RND * 100) + 1
R1 = INT(RND * 100) + 1
R21 = INT(RND * 100) + 1
C = 18
DO
K = (INT(RND * 700) + 1) / 10
C = C + .01
IF C > 300 THEN C = 18
X = COS(K) * R
Y = SIN(K) * R2
G = G + .01
X2 = COS(K + G) * R1
Y2 = SIN(K + G) * R21
LINE (X + 150, Y + 100)-(X2 + 150, Y2 + 100), C
K$ = INKEY$
IF K$ = CHR$(27) THEN GOTO 31
IF K$ <> "" THEN GOTO 1234
FOR TOT = 1 TO 500: NEXT TOT
LOOP
31
END SUB

`,ls={DATA:Zo(g_),DATA2:Zo(__),DATA3:Zo(v_),DATA4:Zo(A_),DATA5:Zo(x_)},pR=N_.split(/\r?\n/);function Zo(r){const t=r.trim().split(/\s+/).map(s=>Number(s)).filter(s=>Number.isFinite(s)),i=[];for(let s=0;s<t.length-1;s+=2)i.push({x:t[s],y:t[s+1]});return i}const n0="184",M_=0,fm=1,R_=2,kc=1,AE=2,al=3,Es=0,ti=1,Zi=2,Da=0,Vr=1,hm=2,dm=3,pm=4,C_=5,Vs=100,y_=101,D_=102,O_=103,b_=104,I_=200,L_=201,U_=202,F_=203,sd=204,rd=205,w_=206,B_=207,X_=208,P_=209,H_=210,Y_=211,G_=212,z_=213,V_=214,od=0,ld=1,cd=2,kr=3,ud=4,fd=5,hd=6,dd=7,i0=0,W_=1,k_=2,Qi=0,xE=1,NE=2,ME=3,RE=4,CE=5,yE=6,DE=7,OE=300,Zs=301,Kr=302,_h=303,vh=304,ru=306,pd=1e3,ya=1001,Td=1002,In=1003,K_=1004,Ac=1005,Nn=1006,Ah=1007,ks=1008,di=1009,bE=1010,IE=1011,rl=1012,a0=1013,ta=1014,qi=1015,ba=1016,s0=1017,r0=1018,ol=1020,LE=35902,UE=35899,FE=1021,wE=1022,Fi=1023,Ia=1026,Ks=1027,BE=1028,o0=1029,qs=1030,l0=1031,c0=1033,Kc=33776,Zc=33777,qc=33778,$c=33779,md=35840,Ed=35841,Sd=35842,gd=35843,_d=36196,vd=37492,Ad=37496,xd=37488,Nd=37489,Jc=37490,Md=37491,Rd=37808,Cd=37809,yd=37810,Dd=37811,Od=37812,bd=37813,Id=37814,Ld=37815,Ud=37816,Fd=37817,wd=37818,Bd=37819,Xd=37820,Pd=37821,Hd=36492,Yd=36494,Gd=36495,zd=36283,Vd=36284,tu=36285,Wd=36286,Z_=3200,kd=0,q_=1,Ts="",Jn="srgb",eu="srgb-linear",nu="linear",Xe="srgb",Dr=7680,Tm=519,$_=512,Q_=513,j_=514,u0=515,J_=516,t2=517,f0=518,e2=519,mm=35044,Em="300 es",$i=2e3,ll=2001;function n2(r){for(let t=r.length-1;t>=0;--t)if(r[t]>=65535)return!0;return!1}function iu(r){return document.createElementNS("http://www.w3.org/1999/xhtml",r)}function i2(){const r=iu("canvas");return r.style.display="block",r}const Sm={};function gm(...r){const t="THREE."+r.shift();console.log(t,...r)}function XE(r){const t=r[0];if(typeof t=="string"&&t.startsWith("TSL:")){const i=r[1];i&&i.isStackTrace?r[0]+=" "+i.getLocation():r[1]='Stack trace not available. Enable "THREE.Node.captureStackTrace" to capture stack traces.'}return r}function ee(...r){r=XE(r);const t="THREE."+r.shift();{const i=r[0];i&&i.isStackTrace?console.warn(i.getError(t)):console.warn(t,...r)}}function Ne(...r){r=XE(r);const t="THREE."+r.shift();{const i=r[0];i&&i.isStackTrace?console.error(i.getError(t)):console.error(t,...r)}}function Kd(...r){const t=r.join(" ");t in Sm||(Sm[t]=!0,ee(...r))}function a2(r,t,i){return new Promise(function(s,l){function c(){switch(r.clientWaitSync(t,r.SYNC_FLUSH_COMMANDS_BIT,0)){case r.WAIT_FAILED:l();break;case r.TIMEOUT_EXPIRED:setTimeout(c,i);break;default:s()}}setTimeout(c,i)})}const s2={[od]:ld,[cd]:hd,[ud]:dd,[kr]:fd,[ld]:od,[hd]:cd,[dd]:ud,[fd]:kr};class $s{addEventListener(t,i){this._listeners===void 0&&(this._listeners={});const s=this._listeners;s[t]===void 0&&(s[t]=[]),s[t].indexOf(i)===-1&&s[t].push(i)}hasEventListener(t,i){const s=this._listeners;return s===void 0?!1:s[t]!==void 0&&s[t].indexOf(i)!==-1}removeEventListener(t,i){const s=this._listeners;if(s===void 0)return;const l=s[t];if(l!==void 0){const c=l.indexOf(i);c!==-1&&l.splice(c,1)}}dispatchEvent(t){const i=this._listeners;if(i===void 0)return;const s=i[t.type];if(s!==void 0){t.target=this;const l=s.slice(0);for(let c=0,f=l.length;c<f;c++)l[c].call(this,t);t.target=null}}}const wn=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"],xh=Math.PI/180,Zd=180/Math.PI;function cl(){const r=Math.random()*4294967295|0,t=Math.random()*4294967295|0,i=Math.random()*4294967295|0,s=Math.random()*4294967295|0;return(wn[r&255]+wn[r>>8&255]+wn[r>>16&255]+wn[r>>24&255]+"-"+wn[t&255]+wn[t>>8&255]+"-"+wn[t>>16&15|64]+wn[t>>24&255]+"-"+wn[i&63|128]+wn[i>>8&255]+"-"+wn[i>>16&255]+wn[i>>24&255]+wn[s&255]+wn[s>>8&255]+wn[s>>16&255]+wn[s>>24&255]).toLowerCase()}function xe(r,t,i){return Math.max(t,Math.min(i,r))}function r2(r,t){return(r%t+t)%t}function Nh(r,t,i){return(1-i)*r+i*t}function qo(r,t){switch(t.constructor){case Float32Array:return r;case Uint32Array:return r/4294967295;case Uint16Array:return r/65535;case Uint8Array:return r/255;case Int32Array:return Math.max(r/2147483647,-1);case Int16Array:return Math.max(r/32767,-1);case Int8Array:return Math.max(r/127,-1);default:throw new Error("Invalid component type.")}}function $n(r,t){switch(t.constructor){case Float32Array:return r;case Uint32Array:return Math.round(r*4294967295);case Uint16Array:return Math.round(r*65535);case Uint8Array:return Math.round(r*255);case Int32Array:return Math.round(r*2147483647);case Int16Array:return Math.round(r*32767);case Int8Array:return Math.round(r*127);default:throw new Error("Invalid component type.")}}const S0=class S0{constructor(t=0,i=0){this.x=t,this.y=i}get width(){return this.x}set width(t){this.x=t}get height(){return this.y}set height(t){this.y=t}set(t,i){return this.x=t,this.y=i,this}setScalar(t){return this.x=t,this.y=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setComponent(t,i){switch(t){case 0:this.x=i;break;case 1:this.y=i;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y)}copy(t){return this.x=t.x,this.y=t.y,this}add(t){return this.x+=t.x,this.y+=t.y,this}addScalar(t){return this.x+=t,this.y+=t,this}addVectors(t,i){return this.x=t.x+i.x,this.y=t.y+i.y,this}addScaledVector(t,i){return this.x+=t.x*i,this.y+=t.y*i,this}sub(t){return this.x-=t.x,this.y-=t.y,this}subScalar(t){return this.x-=t,this.y-=t,this}subVectors(t,i){return this.x=t.x-i.x,this.y=t.y-i.y,this}multiply(t){return this.x*=t.x,this.y*=t.y,this}multiplyScalar(t){return this.x*=t,this.y*=t,this}divide(t){return this.x/=t.x,this.y/=t.y,this}divideScalar(t){return this.multiplyScalar(1/t)}applyMatrix3(t){const i=this.x,s=this.y,l=t.elements;return this.x=l[0]*i+l[3]*s+l[6],this.y=l[1]*i+l[4]*s+l[7],this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this}clamp(t,i){return this.x=xe(this.x,t.x,i.x),this.y=xe(this.y,t.y,i.y),this}clampScalar(t,i){return this.x=xe(this.x,t,i),this.y=xe(this.y,t,i),this}clampLength(t,i){const s=this.length();return this.divideScalar(s||1).multiplyScalar(xe(s,t,i))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(t){return this.x*t.x+this.y*t.y}cross(t){return this.x*t.y-this.y*t.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(t){const i=Math.sqrt(this.lengthSq()*t.lengthSq());if(i===0)return Math.PI/2;const s=this.dot(t)/i;return Math.acos(xe(s,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){const i=this.x-t.x,s=this.y-t.y;return i*i+s*s}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,i){return this.x+=(t.x-this.x)*i,this.y+=(t.y-this.y)*i,this}lerpVectors(t,i,s){return this.x=t.x+(i.x-t.x)*s,this.y=t.y+(i.y-t.y)*s,this}equals(t){return t.x===this.x&&t.y===this.y}fromArray(t,i=0){return this.x=t[i],this.y=t[i+1],this}toArray(t=[],i=0){return t[i]=this.x,t[i+1]=this.y,t}fromBufferAttribute(t,i){return this.x=t.getX(i),this.y=t.getY(i),this}rotateAround(t,i){const s=Math.cos(i),l=Math.sin(i),c=this.x-t.x,f=this.y-t.y;return this.x=c*s-f*l+t.x,this.y=c*l+f*s+t.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}};S0.prototype.isVector2=!0;let Oe=S0;class $r{constructor(t=0,i=0,s=0,l=1){this.isQuaternion=!0,this._x=t,this._y=i,this._z=s,this._w=l}static slerpFlat(t,i,s,l,c,f,T){let p=s[l+0],h=s[l+1],m=s[l+2],E=s[l+3],S=c[f+0],g=c[f+1],A=c[f+2],M=c[f+3];if(E!==M||p!==S||h!==g||m!==A){let x=p*S+h*g+m*A+E*M;x<0&&(S=-S,g=-g,A=-A,M=-M,x=-x);let v=1-T;if(x<.9995){const D=Math.acos(x),I=Math.sin(D);v=Math.sin(v*D)/I,T=Math.sin(T*D)/I,p=p*v+S*T,h=h*v+g*T,m=m*v+A*T,E=E*v+M*T}else{p=p*v+S*T,h=h*v+g*T,m=m*v+A*T,E=E*v+M*T;const D=1/Math.sqrt(p*p+h*h+m*m+E*E);p*=D,h*=D,m*=D,E*=D}}t[i]=p,t[i+1]=h,t[i+2]=m,t[i+3]=E}static multiplyQuaternionsFlat(t,i,s,l,c,f){const T=s[l],p=s[l+1],h=s[l+2],m=s[l+3],E=c[f],S=c[f+1],g=c[f+2],A=c[f+3];return t[i]=T*A+m*E+p*g-h*S,t[i+1]=p*A+m*S+h*E-T*g,t[i+2]=h*A+m*g+T*S-p*E,t[i+3]=m*A-T*E-p*S-h*g,t}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get w(){return this._w}set w(t){this._w=t,this._onChangeCallback()}set(t,i,s,l){return this._x=t,this._y=i,this._z=s,this._w=l,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(t){return this._x=t.x,this._y=t.y,this._z=t.z,this._w=t.w,this._onChangeCallback(),this}setFromEuler(t,i=!0){const s=t._x,l=t._y,c=t._z,f=t._order,T=Math.cos,p=Math.sin,h=T(s/2),m=T(l/2),E=T(c/2),S=p(s/2),g=p(l/2),A=p(c/2);switch(f){case"XYZ":this._x=S*m*E+h*g*A,this._y=h*g*E-S*m*A,this._z=h*m*A+S*g*E,this._w=h*m*E-S*g*A;break;case"YXZ":this._x=S*m*E+h*g*A,this._y=h*g*E-S*m*A,this._z=h*m*A-S*g*E,this._w=h*m*E+S*g*A;break;case"ZXY":this._x=S*m*E-h*g*A,this._y=h*g*E+S*m*A,this._z=h*m*A+S*g*E,this._w=h*m*E-S*g*A;break;case"ZYX":this._x=S*m*E-h*g*A,this._y=h*g*E+S*m*A,this._z=h*m*A-S*g*E,this._w=h*m*E+S*g*A;break;case"YZX":this._x=S*m*E+h*g*A,this._y=h*g*E+S*m*A,this._z=h*m*A-S*g*E,this._w=h*m*E-S*g*A;break;case"XZY":this._x=S*m*E-h*g*A,this._y=h*g*E-S*m*A,this._z=h*m*A+S*g*E,this._w=h*m*E+S*g*A;break;default:ee("Quaternion: .setFromEuler() encountered an unknown order: "+f)}return i===!0&&this._onChangeCallback(),this}setFromAxisAngle(t,i){const s=i/2,l=Math.sin(s);return this._x=t.x*l,this._y=t.y*l,this._z=t.z*l,this._w=Math.cos(s),this._onChangeCallback(),this}setFromRotationMatrix(t){const i=t.elements,s=i[0],l=i[4],c=i[8],f=i[1],T=i[5],p=i[9],h=i[2],m=i[6],E=i[10],S=s+T+E;if(S>0){const g=.5/Math.sqrt(S+1);this._w=.25/g,this._x=(m-p)*g,this._y=(c-h)*g,this._z=(f-l)*g}else if(s>T&&s>E){const g=2*Math.sqrt(1+s-T-E);this._w=(m-p)/g,this._x=.25*g,this._y=(l+f)/g,this._z=(c+h)/g}else if(T>E){const g=2*Math.sqrt(1+T-s-E);this._w=(c-h)/g,this._x=(l+f)/g,this._y=.25*g,this._z=(p+m)/g}else{const g=2*Math.sqrt(1+E-s-T);this._w=(f-l)/g,this._x=(c+h)/g,this._y=(p+m)/g,this._z=.25*g}return this._onChangeCallback(),this}setFromUnitVectors(t,i){let s=t.dot(i)+1;return s<1e-8?(s=0,Math.abs(t.x)>Math.abs(t.z)?(this._x=-t.y,this._y=t.x,this._z=0,this._w=s):(this._x=0,this._y=-t.z,this._z=t.y,this._w=s)):(this._x=t.y*i.z-t.z*i.y,this._y=t.z*i.x-t.x*i.z,this._z=t.x*i.y-t.y*i.x,this._w=s),this.normalize()}angleTo(t){return 2*Math.acos(Math.abs(xe(this.dot(t),-1,1)))}rotateTowards(t,i){const s=this.angleTo(t);if(s===0)return this;const l=Math.min(1,i/s);return this.slerp(t,l),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(t){return this._x*t._x+this._y*t._y+this._z*t._z+this._w*t._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let t=this.length();return t===0?(this._x=0,this._y=0,this._z=0,this._w=1):(t=1/t,this._x=this._x*t,this._y=this._y*t,this._z=this._z*t,this._w=this._w*t),this._onChangeCallback(),this}multiply(t){return this.multiplyQuaternions(this,t)}premultiply(t){return this.multiplyQuaternions(t,this)}multiplyQuaternions(t,i){const s=t._x,l=t._y,c=t._z,f=t._w,T=i._x,p=i._y,h=i._z,m=i._w;return this._x=s*m+f*T+l*h-c*p,this._y=l*m+f*p+c*T-s*h,this._z=c*m+f*h+s*p-l*T,this._w=f*m-s*T-l*p-c*h,this._onChangeCallback(),this}slerp(t,i){let s=t._x,l=t._y,c=t._z,f=t._w,T=this.dot(t);T<0&&(s=-s,l=-l,c=-c,f=-f,T=-T);let p=1-i;if(T<.9995){const h=Math.acos(T),m=Math.sin(h);p=Math.sin(p*h)/m,i=Math.sin(i*h)/m,this._x=this._x*p+s*i,this._y=this._y*p+l*i,this._z=this._z*p+c*i,this._w=this._w*p+f*i,this._onChangeCallback()}else this._x=this._x*p+s*i,this._y=this._y*p+l*i,this._z=this._z*p+c*i,this._w=this._w*p+f*i,this.normalize();return this}slerpQuaternions(t,i,s){return this.copy(t).slerp(i,s)}random(){const t=2*Math.PI*Math.random(),i=2*Math.PI*Math.random(),s=Math.random(),l=Math.sqrt(1-s),c=Math.sqrt(s);return this.set(l*Math.sin(t),l*Math.cos(t),c*Math.sin(i),c*Math.cos(i))}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._w===this._w}fromArray(t,i=0){return this._x=t[i],this._y=t[i+1],this._z=t[i+2],this._w=t[i+3],this._onChangeCallback(),this}toArray(t=[],i=0){return t[i]=this._x,t[i+1]=this._y,t[i+2]=this._z,t[i+3]=this._w,t}fromBufferAttribute(t,i){return this._x=t.getX(i),this._y=t.getY(i),this._z=t.getZ(i),this._w=t.getW(i),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}}const g0=class g0{constructor(t=0,i=0,s=0){this.x=t,this.y=i,this.z=s}set(t,i,s){return s===void 0&&(s=this.z),this.x=t,this.y=i,this.z=s,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setComponent(t,i){switch(t){case 0:this.x=i;break;case 1:this.y=i;break;case 2:this.z=i;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this}addVectors(t,i){return this.x=t.x+i.x,this.y=t.y+i.y,this.z=t.z+i.z,this}addScaledVector(t,i){return this.x+=t.x*i,this.y+=t.y*i,this.z+=t.z*i,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this}subVectors(t,i){return this.x=t.x-i.x,this.y=t.y-i.y,this.z=t.z-i.z,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this}multiplyVectors(t,i){return this.x=t.x*i.x,this.y=t.y*i.y,this.z=t.z*i.z,this}applyEuler(t){return this.applyQuaternion(_m.setFromEuler(t))}applyAxisAngle(t,i){return this.applyQuaternion(_m.setFromAxisAngle(t,i))}applyMatrix3(t){const i=this.x,s=this.y,l=this.z,c=t.elements;return this.x=c[0]*i+c[3]*s+c[6]*l,this.y=c[1]*i+c[4]*s+c[7]*l,this.z=c[2]*i+c[5]*s+c[8]*l,this}applyNormalMatrix(t){return this.applyMatrix3(t).normalize()}applyMatrix4(t){const i=this.x,s=this.y,l=this.z,c=t.elements,f=1/(c[3]*i+c[7]*s+c[11]*l+c[15]);return this.x=(c[0]*i+c[4]*s+c[8]*l+c[12])*f,this.y=(c[1]*i+c[5]*s+c[9]*l+c[13])*f,this.z=(c[2]*i+c[6]*s+c[10]*l+c[14])*f,this}applyQuaternion(t){const i=this.x,s=this.y,l=this.z,c=t.x,f=t.y,T=t.z,p=t.w,h=2*(f*l-T*s),m=2*(T*i-c*l),E=2*(c*s-f*i);return this.x=i+p*h+f*E-T*m,this.y=s+p*m+T*h-c*E,this.z=l+p*E+c*m-f*h,this}project(t){return this.applyMatrix4(t.matrixWorldInverse).applyMatrix4(t.projectionMatrix)}unproject(t){return this.applyMatrix4(t.projectionMatrixInverse).applyMatrix4(t.matrixWorld)}transformDirection(t){const i=this.x,s=this.y,l=this.z,c=t.elements;return this.x=c[0]*i+c[4]*s+c[8]*l,this.y=c[1]*i+c[5]*s+c[9]*l,this.z=c[2]*i+c[6]*s+c[10]*l,this.normalize()}divide(t){return this.x/=t.x,this.y/=t.y,this.z/=t.z,this}divideScalar(t){return this.multiplyScalar(1/t)}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this}clamp(t,i){return this.x=xe(this.x,t.x,i.x),this.y=xe(this.y,t.y,i.y),this.z=xe(this.z,t.z,i.z),this}clampScalar(t,i){return this.x=xe(this.x,t,i),this.y=xe(this.y,t,i),this.z=xe(this.z,t,i),this}clampLength(t,i){const s=this.length();return this.divideScalar(s||1).multiplyScalar(xe(s,t,i))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,i){return this.x+=(t.x-this.x)*i,this.y+=(t.y-this.y)*i,this.z+=(t.z-this.z)*i,this}lerpVectors(t,i,s){return this.x=t.x+(i.x-t.x)*s,this.y=t.y+(i.y-t.y)*s,this.z=t.z+(i.z-t.z)*s,this}cross(t){return this.crossVectors(this,t)}crossVectors(t,i){const s=t.x,l=t.y,c=t.z,f=i.x,T=i.y,p=i.z;return this.x=l*p-c*T,this.y=c*f-s*p,this.z=s*T-l*f,this}projectOnVector(t){const i=t.lengthSq();if(i===0)return this.set(0,0,0);const s=t.dot(this)/i;return this.copy(t).multiplyScalar(s)}projectOnPlane(t){return Mh.copy(this).projectOnVector(t),this.sub(Mh)}reflect(t){return this.sub(Mh.copy(t).multiplyScalar(2*this.dot(t)))}angleTo(t){const i=Math.sqrt(this.lengthSq()*t.lengthSq());if(i===0)return Math.PI/2;const s=this.dot(t)/i;return Math.acos(xe(s,-1,1))}distanceTo(t){return Math.sqrt(this.distanceToSquared(t))}distanceToSquared(t){const i=this.x-t.x,s=this.y-t.y,l=this.z-t.z;return i*i+s*s+l*l}manhattanDistanceTo(t){return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)+Math.abs(this.z-t.z)}setFromSpherical(t){return this.setFromSphericalCoords(t.radius,t.phi,t.theta)}setFromSphericalCoords(t,i,s){const l=Math.sin(i)*t;return this.x=l*Math.sin(s),this.y=Math.cos(i)*t,this.z=l*Math.cos(s),this}setFromCylindrical(t){return this.setFromCylindricalCoords(t.radius,t.theta,t.y)}setFromCylindricalCoords(t,i,s){return this.x=t*Math.sin(i),this.y=s,this.z=t*Math.cos(i),this}setFromMatrixPosition(t){const i=t.elements;return this.x=i[12],this.y=i[13],this.z=i[14],this}setFromMatrixScale(t){const i=this.setFromMatrixColumn(t,0).length(),s=this.setFromMatrixColumn(t,1).length(),l=this.setFromMatrixColumn(t,2).length();return this.x=i,this.y=s,this.z=l,this}setFromMatrixColumn(t,i){return this.fromArray(t.elements,i*4)}setFromMatrix3Column(t,i){return this.fromArray(t.elements,i*3)}setFromEuler(t){return this.x=t._x,this.y=t._y,this.z=t._z,this}setFromColor(t){return this.x=t.r,this.y=t.g,this.z=t.b,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z}fromArray(t,i=0){return this.x=t[i],this.y=t[i+1],this.z=t[i+2],this}toArray(t=[],i=0){return t[i]=this.x,t[i+1]=this.y,t[i+2]=this.z,t}fromBufferAttribute(t,i){return this.x=t.getX(i),this.y=t.getY(i),this.z=t.getZ(i),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){const t=Math.random()*Math.PI*2,i=Math.random()*2-1,s=Math.sqrt(1-i*i);return this.x=s*Math.cos(t),this.y=i,this.z=s*Math.sin(t),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}};g0.prototype.isVector3=!0;let nt=g0;const Mh=new nt,_m=new $r,_0=class _0{constructor(t,i,s,l,c,f,T,p,h){this.elements=[1,0,0,0,1,0,0,0,1],t!==void 0&&this.set(t,i,s,l,c,f,T,p,h)}set(t,i,s,l,c,f,T,p,h){const m=this.elements;return m[0]=t,m[1]=l,m[2]=T,m[3]=i,m[4]=c,m[5]=p,m[6]=s,m[7]=f,m[8]=h,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(t){const i=this.elements,s=t.elements;return i[0]=s[0],i[1]=s[1],i[2]=s[2],i[3]=s[3],i[4]=s[4],i[5]=s[5],i[6]=s[6],i[7]=s[7],i[8]=s[8],this}extractBasis(t,i,s){return t.setFromMatrix3Column(this,0),i.setFromMatrix3Column(this,1),s.setFromMatrix3Column(this,2),this}setFromMatrix4(t){const i=t.elements;return this.set(i[0],i[4],i[8],i[1],i[5],i[9],i[2],i[6],i[10]),this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,i){const s=t.elements,l=i.elements,c=this.elements,f=s[0],T=s[3],p=s[6],h=s[1],m=s[4],E=s[7],S=s[2],g=s[5],A=s[8],M=l[0],x=l[3],v=l[6],D=l[1],I=l[4],U=l[7],Y=l[2],F=l[5],B=l[8];return c[0]=f*M+T*D+p*Y,c[3]=f*x+T*I+p*F,c[6]=f*v+T*U+p*B,c[1]=h*M+m*D+E*Y,c[4]=h*x+m*I+E*F,c[7]=h*v+m*U+E*B,c[2]=S*M+g*D+A*Y,c[5]=S*x+g*I+A*F,c[8]=S*v+g*U+A*B,this}multiplyScalar(t){const i=this.elements;return i[0]*=t,i[3]*=t,i[6]*=t,i[1]*=t,i[4]*=t,i[7]*=t,i[2]*=t,i[5]*=t,i[8]*=t,this}determinant(){const t=this.elements,i=t[0],s=t[1],l=t[2],c=t[3],f=t[4],T=t[5],p=t[6],h=t[7],m=t[8];return i*f*m-i*T*h-s*c*m+s*T*p+l*c*h-l*f*p}invert(){const t=this.elements,i=t[0],s=t[1],l=t[2],c=t[3],f=t[4],T=t[5],p=t[6],h=t[7],m=t[8],E=m*f-T*h,S=T*p-m*c,g=h*c-f*p,A=i*E+s*S+l*g;if(A===0)return this.set(0,0,0,0,0,0,0,0,0);const M=1/A;return t[0]=E*M,t[1]=(l*h-m*s)*M,t[2]=(T*s-l*f)*M,t[3]=S*M,t[4]=(m*i-l*p)*M,t[5]=(l*c-T*i)*M,t[6]=g*M,t[7]=(s*p-h*i)*M,t[8]=(f*i-s*c)*M,this}transpose(){let t;const i=this.elements;return t=i[1],i[1]=i[3],i[3]=t,t=i[2],i[2]=i[6],i[6]=t,t=i[5],i[5]=i[7],i[7]=t,this}getNormalMatrix(t){return this.setFromMatrix4(t).invert().transpose()}transposeIntoArray(t){const i=this.elements;return t[0]=i[0],t[1]=i[3],t[2]=i[6],t[3]=i[1],t[4]=i[4],t[5]=i[7],t[6]=i[2],t[7]=i[5],t[8]=i[8],this}setUvTransform(t,i,s,l,c,f,T){const p=Math.cos(c),h=Math.sin(c);return this.set(s*p,s*h,-s*(p*f+h*T)+f+t,-l*h,l*p,-l*(-h*f+p*T)+T+i,0,0,1),this}scale(t,i){return this.premultiply(Rh.makeScale(t,i)),this}rotate(t){return this.premultiply(Rh.makeRotation(-t)),this}translate(t,i){return this.premultiply(Rh.makeTranslation(t,i)),this}makeTranslation(t,i){return t.isVector2?this.set(1,0,t.x,0,1,t.y,0,0,1):this.set(1,0,t,0,1,i,0,0,1),this}makeRotation(t){const i=Math.cos(t),s=Math.sin(t);return this.set(i,-s,0,s,i,0,0,0,1),this}makeScale(t,i){return this.set(t,0,0,0,i,0,0,0,1),this}equals(t){const i=this.elements,s=t.elements;for(let l=0;l<9;l++)if(i[l]!==s[l])return!1;return!0}fromArray(t,i=0){for(let s=0;s<9;s++)this.elements[s]=t[s+i];return this}toArray(t=[],i=0){const s=this.elements;return t[i]=s[0],t[i+1]=s[1],t[i+2]=s[2],t[i+3]=s[3],t[i+4]=s[4],t[i+5]=s[5],t[i+6]=s[6],t[i+7]=s[7],t[i+8]=s[8],t}clone(){return new this.constructor().fromArray(this.elements)}};_0.prototype.isMatrix3=!0;let se=_0;const Rh=new se,vm=new se().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),Am=new se().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);function o2(){const r={enabled:!0,workingColorSpace:eu,spaces:{},convert:function(l,c,f){return this.enabled===!1||c===f||!c||!f||(this.spaces[c].transfer===Xe&&(l.r=Oa(l.r),l.g=Oa(l.g),l.b=Oa(l.b)),this.spaces[c].primaries!==this.spaces[f].primaries&&(l.applyMatrix3(this.spaces[c].toXYZ),l.applyMatrix3(this.spaces[f].fromXYZ)),this.spaces[f].transfer===Xe&&(l.r=Wr(l.r),l.g=Wr(l.g),l.b=Wr(l.b))),l},workingToColorSpace:function(l,c){return this.convert(l,this.workingColorSpace,c)},colorSpaceToWorking:function(l,c){return this.convert(l,c,this.workingColorSpace)},getPrimaries:function(l){return this.spaces[l].primaries},getTransfer:function(l){return l===Ts?nu:this.spaces[l].transfer},getToneMappingMode:function(l){return this.spaces[l].outputColorSpaceConfig.toneMappingMode||"standard"},getLuminanceCoefficients:function(l,c=this.workingColorSpace){return l.fromArray(this.spaces[c].luminanceCoefficients)},define:function(l){Object.assign(this.spaces,l)},_getMatrix:function(l,c,f){return l.copy(this.spaces[c].toXYZ).multiply(this.spaces[f].fromXYZ)},_getDrawingBufferColorSpace:function(l){return this.spaces[l].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(l=this.workingColorSpace){return this.spaces[l].workingColorSpaceConfig.unpackColorSpace},fromWorkingColorSpace:function(l,c){return Kd("ColorManagement: .fromWorkingColorSpace() has been renamed to .workingToColorSpace()."),r.workingToColorSpace(l,c)},toWorkingColorSpace:function(l,c){return Kd("ColorManagement: .toWorkingColorSpace() has been renamed to .colorSpaceToWorking()."),r.colorSpaceToWorking(l,c)}},t=[.64,.33,.3,.6,.15,.06],i=[.2126,.7152,.0722],s=[.3127,.329];return r.define({[eu]:{primaries:t,whitePoint:s,transfer:nu,toXYZ:vm,fromXYZ:Am,luminanceCoefficients:i,workingColorSpaceConfig:{unpackColorSpace:Jn},outputColorSpaceConfig:{drawingBufferColorSpace:Jn}},[Jn]:{primaries:t,whitePoint:s,transfer:Xe,toXYZ:vm,fromXYZ:Am,luminanceCoefficients:i,outputColorSpaceConfig:{drawingBufferColorSpace:Jn}}}),r}const Ae=o2();function Oa(r){return r<.04045?r*.0773993808:Math.pow(r*.9478672986+.0521327014,2.4)}function Wr(r){return r<.0031308?r*12.92:1.055*Math.pow(r,.41666)-.055}let Or;class l2{static getDataURL(t,i="image/png"){if(/^data:/i.test(t.src)||typeof HTMLCanvasElement>"u")return t.src;let s;if(t instanceof HTMLCanvasElement)s=t;else{Or===void 0&&(Or=iu("canvas")),Or.width=t.width,Or.height=t.height;const l=Or.getContext("2d");t instanceof ImageData?l.putImageData(t,0,0):l.drawImage(t,0,0,t.width,t.height),s=Or}return s.toDataURL(i)}static sRGBToLinear(t){if(typeof HTMLImageElement<"u"&&t instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&t instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&t instanceof ImageBitmap){const i=iu("canvas");i.width=t.width,i.height=t.height;const s=i.getContext("2d");s.drawImage(t,0,0,t.width,t.height);const l=s.getImageData(0,0,t.width,t.height),c=l.data;for(let f=0;f<c.length;f++)c[f]=Oa(c[f]/255)*255;return s.putImageData(l,0,0),i}else if(t.data){const i=t.data.slice(0);for(let s=0;s<i.length;s++)i instanceof Uint8Array||i instanceof Uint8ClampedArray?i[s]=Math.floor(Oa(i[s]/255)*255):i[s]=Oa(i[s]);return{data:i,width:t.width,height:t.height}}else return ee("ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),t}}let c2=0;class h0{constructor(t=null){this.isSource=!0,Object.defineProperty(this,"id",{value:c2++}),this.uuid=cl(),this.data=t,this.dataReady=!0,this.version=0}getSize(t){const i=this.data;return typeof HTMLVideoElement<"u"&&i instanceof HTMLVideoElement?t.set(i.videoWidth,i.videoHeight,0):typeof VideoFrame<"u"&&i instanceof VideoFrame?t.set(i.displayWidth,i.displayHeight,0):i!==null?t.set(i.width,i.height,i.depth||0):t.set(0,0,0),t}set needsUpdate(t){t===!0&&this.version++}toJSON(t){const i=t===void 0||typeof t=="string";if(!i&&t.images[this.uuid]!==void 0)return t.images[this.uuid];const s={uuid:this.uuid,url:""},l=this.data;if(l!==null){let c;if(Array.isArray(l)){c=[];for(let f=0,T=l.length;f<T;f++)l[f].isDataTexture?c.push(Ch(l[f].image)):c.push(Ch(l[f]))}else c=Ch(l);s.url=c}return i||(t.images[this.uuid]=s),s}}function Ch(r){return typeof HTMLImageElement<"u"&&r instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&r instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&r instanceof ImageBitmap?l2.getDataURL(r):r.data?{data:Array.from(r.data),width:r.width,height:r.height,type:r.data.constructor.name}:(ee("Texture: Unable to serialize Texture."),{})}let u2=0;const yh=new nt;class Pn extends $s{constructor(t=Pn.DEFAULT_IMAGE,i=Pn.DEFAULT_MAPPING,s=ya,l=ya,c=Nn,f=ks,T=Fi,p=di,h=Pn.DEFAULT_ANISOTROPY,m=Ts){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:u2++}),this.uuid=cl(),this.name="",this.source=new h0(t),this.mipmaps=[],this.mapping=i,this.channel=0,this.wrapS=s,this.wrapT=l,this.magFilter=c,this.minFilter=f,this.anisotropy=h,this.format=T,this.internalFormat=null,this.type=p,this.offset=new Oe(0,0),this.repeat=new Oe(1,1),this.center=new Oe(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new se,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=m,this.userData={},this.updateRanges=[],this.version=0,this.onUpdate=null,this.renderTarget=null,this.isRenderTargetTexture=!1,this.isArrayTexture=!!(t&&t.depth&&t.depth>1),this.pmremVersion=0,this.normalized=!1}get width(){return this.source.getSize(yh).x}get height(){return this.source.getSize(yh).y}get depth(){return this.source.getSize(yh).z}get image(){return this.source.data}set image(t){this.source.data=t}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}addUpdateRange(t,i){this.updateRanges.push({start:t,count:i})}clearUpdateRanges(){this.updateRanges.length=0}clone(){return new this.constructor().copy(this)}copy(t){return this.name=t.name,this.source=t.source,this.mipmaps=t.mipmaps.slice(0),this.mapping=t.mapping,this.channel=t.channel,this.wrapS=t.wrapS,this.wrapT=t.wrapT,this.magFilter=t.magFilter,this.minFilter=t.minFilter,this.anisotropy=t.anisotropy,this.format=t.format,this.internalFormat=t.internalFormat,this.type=t.type,this.normalized=t.normalized,this.offset.copy(t.offset),this.repeat.copy(t.repeat),this.center.copy(t.center),this.rotation=t.rotation,this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrix.copy(t.matrix),this.generateMipmaps=t.generateMipmaps,this.premultiplyAlpha=t.premultiplyAlpha,this.flipY=t.flipY,this.unpackAlignment=t.unpackAlignment,this.colorSpace=t.colorSpace,this.renderTarget=t.renderTarget,this.isRenderTargetTexture=t.isRenderTargetTexture,this.isArrayTexture=t.isArrayTexture,this.userData=JSON.parse(JSON.stringify(t.userData)),this.needsUpdate=!0,this}setValues(t){for(const i in t){const s=t[i];if(s===void 0){ee(`Texture.setValues(): parameter '${i}' has value of undefined.`);continue}const l=this[i];if(l===void 0){ee(`Texture.setValues(): property '${i}' does not exist.`);continue}l&&s&&l.isVector2&&s.isVector2||l&&s&&l.isVector3&&s.isVector3||l&&s&&l.isMatrix3&&s.isMatrix3?l.copy(s):this[i]=s}}toJSON(t){const i=t===void 0||typeof t=="string";if(!i&&t.textures[this.uuid]!==void 0)return t.textures[this.uuid];const s={metadata:{version:4.7,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(t).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,normalized:this.normalized,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(s.userData=this.userData),i||(t.textures[this.uuid]=s),s}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(t){if(this.mapping!==OE)return t;if(t.applyMatrix3(this.matrix),t.x<0||t.x>1)switch(this.wrapS){case pd:t.x=t.x-Math.floor(t.x);break;case ya:t.x=t.x<0?0:1;break;case Td:Math.abs(Math.floor(t.x)%2)===1?t.x=Math.ceil(t.x)-t.x:t.x=t.x-Math.floor(t.x);break}if(t.y<0||t.y>1)switch(this.wrapT){case pd:t.y=t.y-Math.floor(t.y);break;case ya:t.y=t.y<0?0:1;break;case Td:Math.abs(Math.floor(t.y)%2)===1?t.y=Math.ceil(t.y)-t.y:t.y=t.y-Math.floor(t.y);break}return this.flipY&&(t.y=1-t.y),t}set needsUpdate(t){t===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(t){t===!0&&this.pmremVersion++}}Pn.DEFAULT_IMAGE=null;Pn.DEFAULT_MAPPING=OE;Pn.DEFAULT_ANISOTROPY=1;const v0=class v0{constructor(t=0,i=0,s=0,l=1){this.x=t,this.y=i,this.z=s,this.w=l}get width(){return this.z}set width(t){this.z=t}get height(){return this.w}set height(t){this.w=t}set(t,i,s,l){return this.x=t,this.y=i,this.z=s,this.w=l,this}setScalar(t){return this.x=t,this.y=t,this.z=t,this.w=t,this}setX(t){return this.x=t,this}setY(t){return this.y=t,this}setZ(t){return this.z=t,this}setW(t){return this.w=t,this}setComponent(t,i){switch(t){case 0:this.x=i;break;case 1:this.y=i;break;case 2:this.z=i;break;case 3:this.w=i;break;default:throw new Error("index is out of range: "+t)}return this}getComponent(t){switch(t){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+t)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(t){return this.x=t.x,this.y=t.y,this.z=t.z,this.w=t.w!==void 0?t.w:1,this}add(t){return this.x+=t.x,this.y+=t.y,this.z+=t.z,this.w+=t.w,this}addScalar(t){return this.x+=t,this.y+=t,this.z+=t,this.w+=t,this}addVectors(t,i){return this.x=t.x+i.x,this.y=t.y+i.y,this.z=t.z+i.z,this.w=t.w+i.w,this}addScaledVector(t,i){return this.x+=t.x*i,this.y+=t.y*i,this.z+=t.z*i,this.w+=t.w*i,this}sub(t){return this.x-=t.x,this.y-=t.y,this.z-=t.z,this.w-=t.w,this}subScalar(t){return this.x-=t,this.y-=t,this.z-=t,this.w-=t,this}subVectors(t,i){return this.x=t.x-i.x,this.y=t.y-i.y,this.z=t.z-i.z,this.w=t.w-i.w,this}multiply(t){return this.x*=t.x,this.y*=t.y,this.z*=t.z,this.w*=t.w,this}multiplyScalar(t){return this.x*=t,this.y*=t,this.z*=t,this.w*=t,this}applyMatrix4(t){const i=this.x,s=this.y,l=this.z,c=this.w,f=t.elements;return this.x=f[0]*i+f[4]*s+f[8]*l+f[12]*c,this.y=f[1]*i+f[5]*s+f[9]*l+f[13]*c,this.z=f[2]*i+f[6]*s+f[10]*l+f[14]*c,this.w=f[3]*i+f[7]*s+f[11]*l+f[15]*c,this}divide(t){return this.x/=t.x,this.y/=t.y,this.z/=t.z,this.w/=t.w,this}divideScalar(t){return this.multiplyScalar(1/t)}setAxisAngleFromQuaternion(t){this.w=2*Math.acos(t.w);const i=Math.sqrt(1-t.w*t.w);return i<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=t.x/i,this.y=t.y/i,this.z=t.z/i),this}setAxisAngleFromRotationMatrix(t){let i,s,l,c;const p=t.elements,h=p[0],m=p[4],E=p[8],S=p[1],g=p[5],A=p[9],M=p[2],x=p[6],v=p[10];if(Math.abs(m-S)<.01&&Math.abs(E-M)<.01&&Math.abs(A-x)<.01){if(Math.abs(m+S)<.1&&Math.abs(E+M)<.1&&Math.abs(A+x)<.1&&Math.abs(h+g+v-3)<.1)return this.set(1,0,0,0),this;i=Math.PI;const I=(h+1)/2,U=(g+1)/2,Y=(v+1)/2,F=(m+S)/4,B=(E+M)/4,R=(A+x)/4;return I>U&&I>Y?I<.01?(s=0,l=.707106781,c=.707106781):(s=Math.sqrt(I),l=F/s,c=B/s):U>Y?U<.01?(s=.707106781,l=0,c=.707106781):(l=Math.sqrt(U),s=F/l,c=R/l):Y<.01?(s=.707106781,l=.707106781,c=0):(c=Math.sqrt(Y),s=B/c,l=R/c),this.set(s,l,c,i),this}let D=Math.sqrt((x-A)*(x-A)+(E-M)*(E-M)+(S-m)*(S-m));return Math.abs(D)<.001&&(D=1),this.x=(x-A)/D,this.y=(E-M)/D,this.z=(S-m)/D,this.w=Math.acos((h+g+v-1)/2),this}setFromMatrixPosition(t){const i=t.elements;return this.x=i[12],this.y=i[13],this.z=i[14],this.w=i[15],this}min(t){return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this.w=Math.min(this.w,t.w),this}max(t){return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this.w=Math.max(this.w,t.w),this}clamp(t,i){return this.x=xe(this.x,t.x,i.x),this.y=xe(this.y,t.y,i.y),this.z=xe(this.z,t.z,i.z),this.w=xe(this.w,t.w,i.w),this}clampScalar(t,i){return this.x=xe(this.x,t,i),this.y=xe(this.y,t,i),this.z=xe(this.z,t,i),this.w=xe(this.w,t,i),this}clampLength(t,i){const s=this.length();return this.divideScalar(s||1).multiplyScalar(xe(s,t,i))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(t){return this.x*t.x+this.y*t.y+this.z*t.z+this.w*t.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(t){return this.normalize().multiplyScalar(t)}lerp(t,i){return this.x+=(t.x-this.x)*i,this.y+=(t.y-this.y)*i,this.z+=(t.z-this.z)*i,this.w+=(t.w-this.w)*i,this}lerpVectors(t,i,s){return this.x=t.x+(i.x-t.x)*s,this.y=t.y+(i.y-t.y)*s,this.z=t.z+(i.z-t.z)*s,this.w=t.w+(i.w-t.w)*s,this}equals(t){return t.x===this.x&&t.y===this.y&&t.z===this.z&&t.w===this.w}fromArray(t,i=0){return this.x=t[i],this.y=t[i+1],this.z=t[i+2],this.w=t[i+3],this}toArray(t=[],i=0){return t[i]=this.x,t[i+1]=this.y,t[i+2]=this.z,t[i+3]=this.w,t}fromBufferAttribute(t,i){return this.x=t.getX(i),this.y=t.getY(i),this.z=t.getZ(i),this.w=t.getW(i),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}};v0.prototype.isVector4=!0;let an=v0;class f2 extends $s{constructor(t=1,i=1,s={}){super(),s=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:Nn,depthBuffer:!0,stencilBuffer:!1,resolveDepthBuffer:!0,resolveStencilBuffer:!0,depthTexture:null,samples:0,count:1,depth:1,multiview:!1},s),this.isRenderTarget=!0,this.width=t,this.height=i,this.depth=s.depth,this.scissor=new an(0,0,t,i),this.scissorTest=!1,this.viewport=new an(0,0,t,i),this.textures=[];const l={width:t,height:i,depth:s.depth},c=new Pn(l),f=s.count;for(let T=0;T<f;T++)this.textures[T]=c.clone(),this.textures[T].isRenderTargetTexture=!0,this.textures[T].renderTarget=this;this._setTextureOptions(s),this.depthBuffer=s.depthBuffer,this.stencilBuffer=s.stencilBuffer,this.resolveDepthBuffer=s.resolveDepthBuffer,this.resolveStencilBuffer=s.resolveStencilBuffer,this._depthTexture=null,this.depthTexture=s.depthTexture,this.samples=s.samples,this.multiview=s.multiview}_setTextureOptions(t={}){const i={minFilter:Nn,generateMipmaps:!1,flipY:!1,internalFormat:null};t.mapping!==void 0&&(i.mapping=t.mapping),t.wrapS!==void 0&&(i.wrapS=t.wrapS),t.wrapT!==void 0&&(i.wrapT=t.wrapT),t.wrapR!==void 0&&(i.wrapR=t.wrapR),t.magFilter!==void 0&&(i.magFilter=t.magFilter),t.minFilter!==void 0&&(i.minFilter=t.minFilter),t.format!==void 0&&(i.format=t.format),t.type!==void 0&&(i.type=t.type),t.anisotropy!==void 0&&(i.anisotropy=t.anisotropy),t.colorSpace!==void 0&&(i.colorSpace=t.colorSpace),t.flipY!==void 0&&(i.flipY=t.flipY),t.generateMipmaps!==void 0&&(i.generateMipmaps=t.generateMipmaps),t.internalFormat!==void 0&&(i.internalFormat=t.internalFormat);for(let s=0;s<this.textures.length;s++)this.textures[s].setValues(i)}get texture(){return this.textures[0]}set texture(t){this.textures[0]=t}set depthTexture(t){this._depthTexture!==null&&(this._depthTexture.renderTarget=null),t!==null&&(t.renderTarget=this),this._depthTexture=t}get depthTexture(){return this._depthTexture}setSize(t,i,s=1){if(this.width!==t||this.height!==i||this.depth!==s){this.width=t,this.height=i,this.depth=s;for(let l=0,c=this.textures.length;l<c;l++)this.textures[l].image.width=t,this.textures[l].image.height=i,this.textures[l].image.depth=s,this.textures[l].isData3DTexture!==!0&&(this.textures[l].isArrayTexture=this.textures[l].image.depth>1);this.dispose()}this.viewport.set(0,0,t,i),this.scissor.set(0,0,t,i)}clone(){return new this.constructor().copy(this)}copy(t){this.width=t.width,this.height=t.height,this.depth=t.depth,this.scissor.copy(t.scissor),this.scissorTest=t.scissorTest,this.viewport.copy(t.viewport),this.textures.length=0;for(let i=0,s=t.textures.length;i<s;i++){this.textures[i]=t.textures[i].clone(),this.textures[i].isRenderTargetTexture=!0,this.textures[i].renderTarget=this;const l=Object.assign({},t.textures[i].image);this.textures[i].source=new h0(l)}return this.depthBuffer=t.depthBuffer,this.stencilBuffer=t.stencilBuffer,this.resolveDepthBuffer=t.resolveDepthBuffer,this.resolveStencilBuffer=t.resolveStencilBuffer,t.depthTexture!==null&&(this.depthTexture=t.depthTexture.clone()),this.samples=t.samples,this.multiview=t.multiview,this}dispose(){this.dispatchEvent({type:"dispose"})}}class ji extends f2{constructor(t=1,i=1,s={}){super(t,i,s),this.isWebGLRenderTarget=!0}}class PE extends Pn{constructor(t=null,i=1,s=1,l=1){super(null),this.isDataArrayTexture=!0,this.image={data:t,width:i,height:s,depth:l},this.magFilter=In,this.minFilter=In,this.wrapR=ya,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}addLayerUpdate(t){this.layerUpdates.add(t)}clearLayerUpdates(){this.layerUpdates.clear()}}class h2 extends Pn{constructor(t=null,i=1,s=1,l=1){super(null),this.isData3DTexture=!0,this.image={data:t,width:i,height:s,depth:l},this.magFilter=In,this.minFilter=In,this.wrapR=ya,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}const su=class su{constructor(t,i,s,l,c,f,T,p,h,m,E,S,g,A,M,x){this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],t!==void 0&&this.set(t,i,s,l,c,f,T,p,h,m,E,S,g,A,M,x)}set(t,i,s,l,c,f,T,p,h,m,E,S,g,A,M,x){const v=this.elements;return v[0]=t,v[4]=i,v[8]=s,v[12]=l,v[1]=c,v[5]=f,v[9]=T,v[13]=p,v[2]=h,v[6]=m,v[10]=E,v[14]=S,v[3]=g,v[7]=A,v[11]=M,v[15]=x,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new su().fromArray(this.elements)}copy(t){const i=this.elements,s=t.elements;return i[0]=s[0],i[1]=s[1],i[2]=s[2],i[3]=s[3],i[4]=s[4],i[5]=s[5],i[6]=s[6],i[7]=s[7],i[8]=s[8],i[9]=s[9],i[10]=s[10],i[11]=s[11],i[12]=s[12],i[13]=s[13],i[14]=s[14],i[15]=s[15],this}copyPosition(t){const i=this.elements,s=t.elements;return i[12]=s[12],i[13]=s[13],i[14]=s[14],this}setFromMatrix3(t){const i=t.elements;return this.set(i[0],i[3],i[6],0,i[1],i[4],i[7],0,i[2],i[5],i[8],0,0,0,0,1),this}extractBasis(t,i,s){return this.determinant()===0?(t.set(1,0,0),i.set(0,1,0),s.set(0,0,1),this):(t.setFromMatrixColumn(this,0),i.setFromMatrixColumn(this,1),s.setFromMatrixColumn(this,2),this)}makeBasis(t,i,s){return this.set(t.x,i.x,s.x,0,t.y,i.y,s.y,0,t.z,i.z,s.z,0,0,0,0,1),this}extractRotation(t){if(t.determinant()===0)return this.identity();const i=this.elements,s=t.elements,l=1/br.setFromMatrixColumn(t,0).length(),c=1/br.setFromMatrixColumn(t,1).length(),f=1/br.setFromMatrixColumn(t,2).length();return i[0]=s[0]*l,i[1]=s[1]*l,i[2]=s[2]*l,i[3]=0,i[4]=s[4]*c,i[5]=s[5]*c,i[6]=s[6]*c,i[7]=0,i[8]=s[8]*f,i[9]=s[9]*f,i[10]=s[10]*f,i[11]=0,i[12]=0,i[13]=0,i[14]=0,i[15]=1,this}makeRotationFromEuler(t){const i=this.elements,s=t.x,l=t.y,c=t.z,f=Math.cos(s),T=Math.sin(s),p=Math.cos(l),h=Math.sin(l),m=Math.cos(c),E=Math.sin(c);if(t.order==="XYZ"){const S=f*m,g=f*E,A=T*m,M=T*E;i[0]=p*m,i[4]=-p*E,i[8]=h,i[1]=g+A*h,i[5]=S-M*h,i[9]=-T*p,i[2]=M-S*h,i[6]=A+g*h,i[10]=f*p}else if(t.order==="YXZ"){const S=p*m,g=p*E,A=h*m,M=h*E;i[0]=S+M*T,i[4]=A*T-g,i[8]=f*h,i[1]=f*E,i[5]=f*m,i[9]=-T,i[2]=g*T-A,i[6]=M+S*T,i[10]=f*p}else if(t.order==="ZXY"){const S=p*m,g=p*E,A=h*m,M=h*E;i[0]=S-M*T,i[4]=-f*E,i[8]=A+g*T,i[1]=g+A*T,i[5]=f*m,i[9]=M-S*T,i[2]=-f*h,i[6]=T,i[10]=f*p}else if(t.order==="ZYX"){const S=f*m,g=f*E,A=T*m,M=T*E;i[0]=p*m,i[4]=A*h-g,i[8]=S*h+M,i[1]=p*E,i[5]=M*h+S,i[9]=g*h-A,i[2]=-h,i[6]=T*p,i[10]=f*p}else if(t.order==="YZX"){const S=f*p,g=f*h,A=T*p,M=T*h;i[0]=p*m,i[4]=M-S*E,i[8]=A*E+g,i[1]=E,i[5]=f*m,i[9]=-T*m,i[2]=-h*m,i[6]=g*E+A,i[10]=S-M*E}else if(t.order==="XZY"){const S=f*p,g=f*h,A=T*p,M=T*h;i[0]=p*m,i[4]=-E,i[8]=h*m,i[1]=S*E+M,i[5]=f*m,i[9]=g*E-A,i[2]=A*E-g,i[6]=T*m,i[10]=M*E+S}return i[3]=0,i[7]=0,i[11]=0,i[12]=0,i[13]=0,i[14]=0,i[15]=1,this}makeRotationFromQuaternion(t){return this.compose(d2,t,p2)}lookAt(t,i,s){const l=this.elements;return fi.subVectors(t,i),fi.lengthSq()===0&&(fi.z=1),fi.normalize(),cs.crossVectors(s,fi),cs.lengthSq()===0&&(Math.abs(s.z)===1?fi.x+=1e-4:fi.z+=1e-4,fi.normalize(),cs.crossVectors(s,fi)),cs.normalize(),xc.crossVectors(fi,cs),l[0]=cs.x,l[4]=xc.x,l[8]=fi.x,l[1]=cs.y,l[5]=xc.y,l[9]=fi.y,l[2]=cs.z,l[6]=xc.z,l[10]=fi.z,this}multiply(t){return this.multiplyMatrices(this,t)}premultiply(t){return this.multiplyMatrices(t,this)}multiplyMatrices(t,i){const s=t.elements,l=i.elements,c=this.elements,f=s[0],T=s[4],p=s[8],h=s[12],m=s[1],E=s[5],S=s[9],g=s[13],A=s[2],M=s[6],x=s[10],v=s[14],D=s[3],I=s[7],U=s[11],Y=s[15],F=l[0],B=l[4],R=l[8],w=l[12],Z=l[1],H=l[5],$=l[9],ct=l[13],lt=l[2],W=l[6],L=l[10],P=l[14],it=l[3],mt=l[7],ft=l[11],O=l[15];return c[0]=f*F+T*Z+p*lt+h*it,c[4]=f*B+T*H+p*W+h*mt,c[8]=f*R+T*$+p*L+h*ft,c[12]=f*w+T*ct+p*P+h*O,c[1]=m*F+E*Z+S*lt+g*it,c[5]=m*B+E*H+S*W+g*mt,c[9]=m*R+E*$+S*L+g*ft,c[13]=m*w+E*ct+S*P+g*O,c[2]=A*F+M*Z+x*lt+v*it,c[6]=A*B+M*H+x*W+v*mt,c[10]=A*R+M*$+x*L+v*ft,c[14]=A*w+M*ct+x*P+v*O,c[3]=D*F+I*Z+U*lt+Y*it,c[7]=D*B+I*H+U*W+Y*mt,c[11]=D*R+I*$+U*L+Y*ft,c[15]=D*w+I*ct+U*P+Y*O,this}multiplyScalar(t){const i=this.elements;return i[0]*=t,i[4]*=t,i[8]*=t,i[12]*=t,i[1]*=t,i[5]*=t,i[9]*=t,i[13]*=t,i[2]*=t,i[6]*=t,i[10]*=t,i[14]*=t,i[3]*=t,i[7]*=t,i[11]*=t,i[15]*=t,this}determinant(){const t=this.elements,i=t[0],s=t[4],l=t[8],c=t[12],f=t[1],T=t[5],p=t[9],h=t[13],m=t[2],E=t[6],S=t[10],g=t[14],A=t[3],M=t[7],x=t[11],v=t[15],D=p*g-h*S,I=T*g-h*E,U=T*S-p*E,Y=f*g-h*m,F=f*S-p*m,B=f*E-T*m;return i*(M*D-x*I+v*U)-s*(A*D-x*Y+v*F)+l*(A*I-M*Y+v*B)-c*(A*U-M*F+x*B)}transpose(){const t=this.elements;let i;return i=t[1],t[1]=t[4],t[4]=i,i=t[2],t[2]=t[8],t[8]=i,i=t[6],t[6]=t[9],t[9]=i,i=t[3],t[3]=t[12],t[12]=i,i=t[7],t[7]=t[13],t[13]=i,i=t[11],t[11]=t[14],t[14]=i,this}setPosition(t,i,s){const l=this.elements;return t.isVector3?(l[12]=t.x,l[13]=t.y,l[14]=t.z):(l[12]=t,l[13]=i,l[14]=s),this}invert(){const t=this.elements,i=t[0],s=t[1],l=t[2],c=t[3],f=t[4],T=t[5],p=t[6],h=t[7],m=t[8],E=t[9],S=t[10],g=t[11],A=t[12],M=t[13],x=t[14],v=t[15],D=i*T-s*f,I=i*p-l*f,U=i*h-c*f,Y=s*p-l*T,F=s*h-c*T,B=l*h-c*p,R=m*M-E*A,w=m*x-S*A,Z=m*v-g*A,H=E*x-S*M,$=E*v-g*M,ct=S*v-g*x,lt=D*ct-I*$+U*H+Y*Z-F*w+B*R;if(lt===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);const W=1/lt;return t[0]=(T*ct-p*$+h*H)*W,t[1]=(l*$-s*ct-c*H)*W,t[2]=(M*B-x*F+v*Y)*W,t[3]=(S*F-E*B-g*Y)*W,t[4]=(p*Z-f*ct-h*w)*W,t[5]=(i*ct-l*Z+c*w)*W,t[6]=(x*U-A*B-v*I)*W,t[7]=(m*B-S*U+g*I)*W,t[8]=(f*$-T*Z+h*R)*W,t[9]=(s*Z-i*$-c*R)*W,t[10]=(A*F-M*U+v*D)*W,t[11]=(E*U-m*F-g*D)*W,t[12]=(T*w-f*H-p*R)*W,t[13]=(i*H-s*w+l*R)*W,t[14]=(M*I-A*Y-x*D)*W,t[15]=(m*Y-E*I+S*D)*W,this}scale(t){const i=this.elements,s=t.x,l=t.y,c=t.z;return i[0]*=s,i[4]*=l,i[8]*=c,i[1]*=s,i[5]*=l,i[9]*=c,i[2]*=s,i[6]*=l,i[10]*=c,i[3]*=s,i[7]*=l,i[11]*=c,this}getMaxScaleOnAxis(){const t=this.elements,i=t[0]*t[0]+t[1]*t[1]+t[2]*t[2],s=t[4]*t[4]+t[5]*t[5]+t[6]*t[6],l=t[8]*t[8]+t[9]*t[9]+t[10]*t[10];return Math.sqrt(Math.max(i,s,l))}makeTranslation(t,i,s){return t.isVector3?this.set(1,0,0,t.x,0,1,0,t.y,0,0,1,t.z,0,0,0,1):this.set(1,0,0,t,0,1,0,i,0,0,1,s,0,0,0,1),this}makeRotationX(t){const i=Math.cos(t),s=Math.sin(t);return this.set(1,0,0,0,0,i,-s,0,0,s,i,0,0,0,0,1),this}makeRotationY(t){const i=Math.cos(t),s=Math.sin(t);return this.set(i,0,s,0,0,1,0,0,-s,0,i,0,0,0,0,1),this}makeRotationZ(t){const i=Math.cos(t),s=Math.sin(t);return this.set(i,-s,0,0,s,i,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(t,i){const s=Math.cos(i),l=Math.sin(i),c=1-s,f=t.x,T=t.y,p=t.z,h=c*f,m=c*T;return this.set(h*f+s,h*T-l*p,h*p+l*T,0,h*T+l*p,m*T+s,m*p-l*f,0,h*p-l*T,m*p+l*f,c*p*p+s,0,0,0,0,1),this}makeScale(t,i,s){return this.set(t,0,0,0,0,i,0,0,0,0,s,0,0,0,0,1),this}makeShear(t,i,s,l,c,f){return this.set(1,s,c,0,t,1,f,0,i,l,1,0,0,0,0,1),this}compose(t,i,s){const l=this.elements,c=i._x,f=i._y,T=i._z,p=i._w,h=c+c,m=f+f,E=T+T,S=c*h,g=c*m,A=c*E,M=f*m,x=f*E,v=T*E,D=p*h,I=p*m,U=p*E,Y=s.x,F=s.y,B=s.z;return l[0]=(1-(M+v))*Y,l[1]=(g+U)*Y,l[2]=(A-I)*Y,l[3]=0,l[4]=(g-U)*F,l[5]=(1-(S+v))*F,l[6]=(x+D)*F,l[7]=0,l[8]=(A+I)*B,l[9]=(x-D)*B,l[10]=(1-(S+M))*B,l[11]=0,l[12]=t.x,l[13]=t.y,l[14]=t.z,l[15]=1,this}decompose(t,i,s){const l=this.elements;t.x=l[12],t.y=l[13],t.z=l[14];const c=this.determinant();if(c===0)return s.set(1,1,1),i.identity(),this;let f=br.set(l[0],l[1],l[2]).length();const T=br.set(l[4],l[5],l[6]).length(),p=br.set(l[8],l[9],l[10]).length();c<0&&(f=-f),Oi.copy(this);const h=1/f,m=1/T,E=1/p;return Oi.elements[0]*=h,Oi.elements[1]*=h,Oi.elements[2]*=h,Oi.elements[4]*=m,Oi.elements[5]*=m,Oi.elements[6]*=m,Oi.elements[8]*=E,Oi.elements[9]*=E,Oi.elements[10]*=E,i.setFromRotationMatrix(Oi),s.x=f,s.y=T,s.z=p,this}makePerspective(t,i,s,l,c,f,T=$i,p=!1){const h=this.elements,m=2*c/(i-t),E=2*c/(s-l),S=(i+t)/(i-t),g=(s+l)/(s-l);let A,M;if(p)A=c/(f-c),M=f*c/(f-c);else if(T===$i)A=-(f+c)/(f-c),M=-2*f*c/(f-c);else if(T===ll)A=-f/(f-c),M=-f*c/(f-c);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+T);return h[0]=m,h[4]=0,h[8]=S,h[12]=0,h[1]=0,h[5]=E,h[9]=g,h[13]=0,h[2]=0,h[6]=0,h[10]=A,h[14]=M,h[3]=0,h[7]=0,h[11]=-1,h[15]=0,this}makeOrthographic(t,i,s,l,c,f,T=$i,p=!1){const h=this.elements,m=2/(i-t),E=2/(s-l),S=-(i+t)/(i-t),g=-(s+l)/(s-l);let A,M;if(p)A=1/(f-c),M=f/(f-c);else if(T===$i)A=-2/(f-c),M=-(f+c)/(f-c);else if(T===ll)A=-1/(f-c),M=-c/(f-c);else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+T);return h[0]=m,h[4]=0,h[8]=0,h[12]=S,h[1]=0,h[5]=E,h[9]=0,h[13]=g,h[2]=0,h[6]=0,h[10]=A,h[14]=M,h[3]=0,h[7]=0,h[11]=0,h[15]=1,this}equals(t){const i=this.elements,s=t.elements;for(let l=0;l<16;l++)if(i[l]!==s[l])return!1;return!0}fromArray(t,i=0){for(let s=0;s<16;s++)this.elements[s]=t[s+i];return this}toArray(t=[],i=0){const s=this.elements;return t[i]=s[0],t[i+1]=s[1],t[i+2]=s[2],t[i+3]=s[3],t[i+4]=s[4],t[i+5]=s[5],t[i+6]=s[6],t[i+7]=s[7],t[i+8]=s[8],t[i+9]=s[9],t[i+10]=s[10],t[i+11]=s[11],t[i+12]=s[12],t[i+13]=s[13],t[i+14]=s[14],t[i+15]=s[15],t}};su.prototype.isMatrix4=!0;let cn=su;const br=new nt,Oi=new cn,d2=new nt(0,0,0),p2=new nt(1,1,1),cs=new nt,xc=new nt,fi=new nt,xm=new cn,Nm=new $r;class Ss{constructor(t=0,i=0,s=0,l=Ss.DEFAULT_ORDER){this.isEuler=!0,this._x=t,this._y=i,this._z=s,this._order=l}get x(){return this._x}set x(t){this._x=t,this._onChangeCallback()}get y(){return this._y}set y(t){this._y=t,this._onChangeCallback()}get z(){return this._z}set z(t){this._z=t,this._onChangeCallback()}get order(){return this._order}set order(t){this._order=t,this._onChangeCallback()}set(t,i,s,l=this._order){return this._x=t,this._y=i,this._z=s,this._order=l,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(t){return this._x=t._x,this._y=t._y,this._z=t._z,this._order=t._order,this._onChangeCallback(),this}setFromRotationMatrix(t,i=this._order,s=!0){const l=t.elements,c=l[0],f=l[4],T=l[8],p=l[1],h=l[5],m=l[9],E=l[2],S=l[6],g=l[10];switch(i){case"XYZ":this._y=Math.asin(xe(T,-1,1)),Math.abs(T)<.9999999?(this._x=Math.atan2(-m,g),this._z=Math.atan2(-f,c)):(this._x=Math.atan2(S,h),this._z=0);break;case"YXZ":this._x=Math.asin(-xe(m,-1,1)),Math.abs(m)<.9999999?(this._y=Math.atan2(T,g),this._z=Math.atan2(p,h)):(this._y=Math.atan2(-E,c),this._z=0);break;case"ZXY":this._x=Math.asin(xe(S,-1,1)),Math.abs(S)<.9999999?(this._y=Math.atan2(-E,g),this._z=Math.atan2(-f,h)):(this._y=0,this._z=Math.atan2(p,c));break;case"ZYX":this._y=Math.asin(-xe(E,-1,1)),Math.abs(E)<.9999999?(this._x=Math.atan2(S,g),this._z=Math.atan2(p,c)):(this._x=0,this._z=Math.atan2(-f,h));break;case"YZX":this._z=Math.asin(xe(p,-1,1)),Math.abs(p)<.9999999?(this._x=Math.atan2(-m,h),this._y=Math.atan2(-E,c)):(this._x=0,this._y=Math.atan2(T,g));break;case"XZY":this._z=Math.asin(-xe(f,-1,1)),Math.abs(f)<.9999999?(this._x=Math.atan2(S,h),this._y=Math.atan2(T,c)):(this._x=Math.atan2(-m,g),this._y=0);break;default:ee("Euler: .setFromRotationMatrix() encountered an unknown order: "+i)}return this._order=i,s===!0&&this._onChangeCallback(),this}setFromQuaternion(t,i,s){return xm.makeRotationFromQuaternion(t),this.setFromRotationMatrix(xm,i,s)}setFromVector3(t,i=this._order){return this.set(t.x,t.y,t.z,i)}reorder(t){return Nm.setFromEuler(this),this.setFromQuaternion(Nm,t)}equals(t){return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._order===this._order}fromArray(t){return this._x=t[0],this._y=t[1],this._z=t[2],t[3]!==void 0&&(this._order=t[3]),this._onChangeCallback(),this}toArray(t=[],i=0){return t[i]=this._x,t[i+1]=this._y,t[i+2]=this._z,t[i+3]=this._order,t}_onChange(t){return this._onChangeCallback=t,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}}Ss.DEFAULT_ORDER="XYZ";class HE{constructor(){this.mask=1}set(t){this.mask=(1<<t|0)>>>0}enable(t){this.mask|=1<<t|0}enableAll(){this.mask=-1}toggle(t){this.mask^=1<<t|0}disable(t){this.mask&=~(1<<t|0)}disableAll(){this.mask=0}test(t){return(this.mask&t.mask)!==0}isEnabled(t){return(this.mask&(1<<t|0))!==0}}let T2=0;const Mm=new nt,Ir=new $r,va=new cn,Nc=new nt,$o=new nt,m2=new nt,E2=new $r,Rm=new nt(1,0,0),Cm=new nt(0,1,0),ym=new nt(0,0,1),Dm={type:"added"},S2={type:"removed"},Lr={type:"childadded",child:null},Dh={type:"childremoved",child:null};class Hn extends $s{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:T2++}),this.uuid=cl(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=Hn.DEFAULT_UP.clone();const t=new nt,i=new Ss,s=new $r,l=new nt(1,1,1);function c(){s.setFromEuler(i,!1)}function f(){i.setFromQuaternion(s,void 0,!1)}i._onChange(c),s._onChange(f),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:t},rotation:{configurable:!0,enumerable:!0,value:i},quaternion:{configurable:!0,enumerable:!0,value:s},scale:{configurable:!0,enumerable:!0,value:l},modelViewMatrix:{value:new cn},normalMatrix:{value:new se}}),this.matrix=new cn,this.matrixWorld=new cn,this.matrixAutoUpdate=Hn.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=Hn.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new HE,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.customDepthMaterial=void 0,this.customDistanceMaterial=void 0,this.static=!1,this.userData={},this.pivot=null}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(t){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(t),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(t){return this.quaternion.premultiply(t),this}setRotationFromAxisAngle(t,i){this.quaternion.setFromAxisAngle(t,i)}setRotationFromEuler(t){this.quaternion.setFromEuler(t,!0)}setRotationFromMatrix(t){this.quaternion.setFromRotationMatrix(t)}setRotationFromQuaternion(t){this.quaternion.copy(t)}rotateOnAxis(t,i){return Ir.setFromAxisAngle(t,i),this.quaternion.multiply(Ir),this}rotateOnWorldAxis(t,i){return Ir.setFromAxisAngle(t,i),this.quaternion.premultiply(Ir),this}rotateX(t){return this.rotateOnAxis(Rm,t)}rotateY(t){return this.rotateOnAxis(Cm,t)}rotateZ(t){return this.rotateOnAxis(ym,t)}translateOnAxis(t,i){return Mm.copy(t).applyQuaternion(this.quaternion),this.position.add(Mm.multiplyScalar(i)),this}translateX(t){return this.translateOnAxis(Rm,t)}translateY(t){return this.translateOnAxis(Cm,t)}translateZ(t){return this.translateOnAxis(ym,t)}localToWorld(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(this.matrixWorld)}worldToLocal(t){return this.updateWorldMatrix(!0,!1),t.applyMatrix4(va.copy(this.matrixWorld).invert())}lookAt(t,i,s){t.isVector3?Nc.copy(t):Nc.set(t,i,s);const l=this.parent;this.updateWorldMatrix(!0,!1),$o.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?va.lookAt($o,Nc,this.up):va.lookAt(Nc,$o,this.up),this.quaternion.setFromRotationMatrix(va),l&&(va.extractRotation(l.matrixWorld),Ir.setFromRotationMatrix(va),this.quaternion.premultiply(Ir.invert()))}add(t){if(arguments.length>1){for(let i=0;i<arguments.length;i++)this.add(arguments[i]);return this}return t===this?(Ne("Object3D.add: object can't be added as a child of itself.",t),this):(t&&t.isObject3D?(t.removeFromParent(),t.parent=this,this.children.push(t),t.dispatchEvent(Dm),Lr.child=t,this.dispatchEvent(Lr),Lr.child=null):Ne("Object3D.add: object not an instance of THREE.Object3D.",t),this)}remove(t){if(arguments.length>1){for(let s=0;s<arguments.length;s++)this.remove(arguments[s]);return this}const i=this.children.indexOf(t);return i!==-1&&(t.parent=null,this.children.splice(i,1),t.dispatchEvent(S2),Dh.child=t,this.dispatchEvent(Dh),Dh.child=null),this}removeFromParent(){const t=this.parent;return t!==null&&t.remove(this),this}clear(){return this.remove(...this.children)}attach(t){return this.updateWorldMatrix(!0,!1),va.copy(this.matrixWorld).invert(),t.parent!==null&&(t.parent.updateWorldMatrix(!0,!1),va.multiply(t.parent.matrixWorld)),t.applyMatrix4(va),t.removeFromParent(),t.parent=this,this.children.push(t),t.updateWorldMatrix(!1,!0),t.dispatchEvent(Dm),Lr.child=t,this.dispatchEvent(Lr),Lr.child=null,this}getObjectById(t){return this.getObjectByProperty("id",t)}getObjectByName(t){return this.getObjectByProperty("name",t)}getObjectByProperty(t,i){if(this[t]===i)return this;for(let s=0,l=this.children.length;s<l;s++){const f=this.children[s].getObjectByProperty(t,i);if(f!==void 0)return f}}getObjectsByProperty(t,i,s=[]){this[t]===i&&s.push(this);const l=this.children;for(let c=0,f=l.length;c<f;c++)l[c].getObjectsByProperty(t,i,s);return s}getWorldPosition(t){return this.updateWorldMatrix(!0,!1),t.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose($o,t,m2),t}getWorldScale(t){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose($o,E2,t),t}getWorldDirection(t){this.updateWorldMatrix(!0,!1);const i=this.matrixWorld.elements;return t.set(i[8],i[9],i[10]).normalize()}raycast(){}traverse(t){t(this);const i=this.children;for(let s=0,l=i.length;s<l;s++)i[s].traverse(t)}traverseVisible(t){if(this.visible===!1)return;t(this);const i=this.children;for(let s=0,l=i.length;s<l;s++)i[s].traverseVisible(t)}traverseAncestors(t){const i=this.parent;i!==null&&(t(i),i.traverseAncestors(t))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale);const t=this.pivot;if(t!==null){const i=t.x,s=t.y,l=t.z,c=this.matrix.elements;c[12]+=i-c[0]*i-c[4]*s-c[8]*l,c[13]+=s-c[1]*i-c[5]*s-c[9]*l,c[14]+=l-c[2]*i-c[6]*s-c[10]*l}this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(t){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||t)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,t=!0);const i=this.children;for(let s=0,l=i.length;s<l;s++)i[s].updateMatrixWorld(t)}updateWorldMatrix(t,i){const s=this.parent;if(t===!0&&s!==null&&s.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),i===!0){const l=this.children;for(let c=0,f=l.length;c<f;c++)l[c].updateWorldMatrix(!1,!0)}}toJSON(t){const i=t===void 0||typeof t=="string",s={};i&&(t={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},s.metadata={version:4.7,type:"Object",generator:"Object3D.toJSON"});const l={};l.uuid=this.uuid,l.type=this.type,this.name!==""&&(l.name=this.name),this.castShadow===!0&&(l.castShadow=!0),this.receiveShadow===!0&&(l.receiveShadow=!0),this.visible===!1&&(l.visible=!1),this.frustumCulled===!1&&(l.frustumCulled=!1),this.renderOrder!==0&&(l.renderOrder=this.renderOrder),this.static!==!1&&(l.static=this.static),Object.keys(this.userData).length>0&&(l.userData=this.userData),l.layers=this.layers.mask,l.matrix=this.matrix.toArray(),l.up=this.up.toArray(),this.pivot!==null&&(l.pivot=this.pivot.toArray()),this.matrixAutoUpdate===!1&&(l.matrixAutoUpdate=!1),this.morphTargetDictionary!==void 0&&(l.morphTargetDictionary=Object.assign({},this.morphTargetDictionary)),this.morphTargetInfluences!==void 0&&(l.morphTargetInfluences=this.morphTargetInfluences.slice()),this.isInstancedMesh&&(l.type="InstancedMesh",l.count=this.count,l.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(l.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(l.type="BatchedMesh",l.perObjectFrustumCulled=this.perObjectFrustumCulled,l.sortObjects=this.sortObjects,l.drawRanges=this._drawRanges,l.reservedRanges=this._reservedRanges,l.geometryInfo=this._geometryInfo.map(T=>({...T,boundingBox:T.boundingBox?T.boundingBox.toJSON():void 0,boundingSphere:T.boundingSphere?T.boundingSphere.toJSON():void 0})),l.instanceInfo=this._instanceInfo.map(T=>({...T})),l.availableInstanceIds=this._availableInstanceIds.slice(),l.availableGeometryIds=this._availableGeometryIds.slice(),l.nextIndexStart=this._nextIndexStart,l.nextVertexStart=this._nextVertexStart,l.geometryCount=this._geometryCount,l.maxInstanceCount=this._maxInstanceCount,l.maxVertexCount=this._maxVertexCount,l.maxIndexCount=this._maxIndexCount,l.geometryInitialized=this._geometryInitialized,l.matricesTexture=this._matricesTexture.toJSON(t),l.indirectTexture=this._indirectTexture.toJSON(t),this._colorsTexture!==null&&(l.colorsTexture=this._colorsTexture.toJSON(t)),this.boundingSphere!==null&&(l.boundingSphere=this.boundingSphere.toJSON()),this.boundingBox!==null&&(l.boundingBox=this.boundingBox.toJSON()));function c(T,p){return T[p.uuid]===void 0&&(T[p.uuid]=p.toJSON(t)),p.uuid}if(this.isScene)this.background&&(this.background.isColor?l.background=this.background.toJSON():this.background.isTexture&&(l.background=this.background.toJSON(t).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(l.environment=this.environment.toJSON(t).uuid);else if(this.isMesh||this.isLine||this.isPoints){l.geometry=c(t.geometries,this.geometry);const T=this.geometry.parameters;if(T!==void 0&&T.shapes!==void 0){const p=T.shapes;if(Array.isArray(p))for(let h=0,m=p.length;h<m;h++){const E=p[h];c(t.shapes,E)}else c(t.shapes,p)}}if(this.isSkinnedMesh&&(l.bindMode=this.bindMode,l.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(c(t.skeletons,this.skeleton),l.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){const T=[];for(let p=0,h=this.material.length;p<h;p++)T.push(c(t.materials,this.material[p]));l.material=T}else l.material=c(t.materials,this.material);if(this.children.length>0){l.children=[];for(let T=0;T<this.children.length;T++)l.children.push(this.children[T].toJSON(t).object)}if(this.animations.length>0){l.animations=[];for(let T=0;T<this.animations.length;T++){const p=this.animations[T];l.animations.push(c(t.animations,p))}}if(i){const T=f(t.geometries),p=f(t.materials),h=f(t.textures),m=f(t.images),E=f(t.shapes),S=f(t.skeletons),g=f(t.animations),A=f(t.nodes);T.length>0&&(s.geometries=T),p.length>0&&(s.materials=p),h.length>0&&(s.textures=h),m.length>0&&(s.images=m),E.length>0&&(s.shapes=E),S.length>0&&(s.skeletons=S),g.length>0&&(s.animations=g),A.length>0&&(s.nodes=A)}return s.object=l,s;function f(T){const p=[];for(const h in T){const m=T[h];delete m.metadata,p.push(m)}return p}}clone(t){return new this.constructor().copy(this,t)}copy(t,i=!0){if(this.name=t.name,this.up.copy(t.up),this.position.copy(t.position),this.rotation.order=t.rotation.order,this.quaternion.copy(t.quaternion),this.scale.copy(t.scale),this.pivot=t.pivot!==null?t.pivot.clone():null,this.matrix.copy(t.matrix),this.matrixWorld.copy(t.matrixWorld),this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrixWorldAutoUpdate=t.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=t.matrixWorldNeedsUpdate,this.layers.mask=t.layers.mask,this.visible=t.visible,this.castShadow=t.castShadow,this.receiveShadow=t.receiveShadow,this.frustumCulled=t.frustumCulled,this.renderOrder=t.renderOrder,this.static=t.static,this.animations=t.animations.slice(),this.userData=JSON.parse(JSON.stringify(t.userData)),i===!0)for(let s=0;s<t.children.length;s++){const l=t.children[s];this.add(l.clone())}return this}}Hn.DEFAULT_UP=new nt(0,1,0);Hn.DEFAULT_MATRIX_AUTO_UPDATE=!0;Hn.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;class zr extends Hn{constructor(){super(),this.isGroup=!0,this.type="Group"}}const g2={type:"move"};class Oh{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new zr,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new zr,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new nt,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new nt),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new zr,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new nt,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new nt,this._grip.eventsEnabled=!1),this._grip}dispatchEvent(t){return this._targetRay!==null&&this._targetRay.dispatchEvent(t),this._grip!==null&&this._grip.dispatchEvent(t),this._hand!==null&&this._hand.dispatchEvent(t),this}connect(t){if(t&&t.hand){const i=this._hand;if(i)for(const s of t.hand.values())this._getHandJoint(i,s)}return this.dispatchEvent({type:"connected",data:t}),this}disconnect(t){return this.dispatchEvent({type:"disconnected",data:t}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(t,i,s){let l=null,c=null,f=null;const T=this._targetRay,p=this._grip,h=this._hand;if(t&&i.session.visibilityState!=="visible-blurred"){if(h&&t.hand){f=!0;for(const M of t.hand.values()){const x=i.getJointPose(M,s),v=this._getHandJoint(h,M);x!==null&&(v.matrix.fromArray(x.transform.matrix),v.matrix.decompose(v.position,v.rotation,v.scale),v.matrixWorldNeedsUpdate=!0,v.jointRadius=x.radius),v.visible=x!==null}const m=h.joints["index-finger-tip"],E=h.joints["thumb-tip"],S=m.position.distanceTo(E.position),g=.02,A=.005;h.inputState.pinching&&S>g+A?(h.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:t.handedness,target:this})):!h.inputState.pinching&&S<=g-A&&(h.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:t.handedness,target:this}))}else p!==null&&t.gripSpace&&(c=i.getPose(t.gripSpace,s),c!==null&&(p.matrix.fromArray(c.transform.matrix),p.matrix.decompose(p.position,p.rotation,p.scale),p.matrixWorldNeedsUpdate=!0,c.linearVelocity?(p.hasLinearVelocity=!0,p.linearVelocity.copy(c.linearVelocity)):p.hasLinearVelocity=!1,c.angularVelocity?(p.hasAngularVelocity=!0,p.angularVelocity.copy(c.angularVelocity)):p.hasAngularVelocity=!1,p.eventsEnabled&&p.dispatchEvent({type:"gripUpdated",data:t,target:this})));T!==null&&(l=i.getPose(t.targetRaySpace,s),l===null&&c!==null&&(l=c),l!==null&&(T.matrix.fromArray(l.transform.matrix),T.matrix.decompose(T.position,T.rotation,T.scale),T.matrixWorldNeedsUpdate=!0,l.linearVelocity?(T.hasLinearVelocity=!0,T.linearVelocity.copy(l.linearVelocity)):T.hasLinearVelocity=!1,l.angularVelocity?(T.hasAngularVelocity=!0,T.angularVelocity.copy(l.angularVelocity)):T.hasAngularVelocity=!1,this.dispatchEvent(g2)))}return T!==null&&(T.visible=l!==null),p!==null&&(p.visible=c!==null),h!==null&&(h.visible=f!==null),this}_getHandJoint(t,i){if(t.joints[i.jointName]===void 0){const s=new zr;s.matrixAutoUpdate=!1,s.visible=!1,t.joints[i.jointName]=s,t.add(s)}return t.joints[i.jointName]}}const YE={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},us={h:0,s:0,l:0},Mc={h:0,s:0,l:0};function bh(r,t,i){return i<0&&(i+=1),i>1&&(i-=1),i<1/6?r+(t-r)*6*i:i<1/2?t:i<2/3?r+(t-r)*6*(2/3-i):r}class _e{constructor(t,i,s){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(t,i,s)}set(t,i,s){if(i===void 0&&s===void 0){const l=t;l&&l.isColor?this.copy(l):typeof l=="number"?this.setHex(l):typeof l=="string"&&this.setStyle(l)}else this.setRGB(t,i,s);return this}setScalar(t){return this.r=t,this.g=t,this.b=t,this}setHex(t,i=Jn){return t=Math.floor(t),this.r=(t>>16&255)/255,this.g=(t>>8&255)/255,this.b=(t&255)/255,Ae.colorSpaceToWorking(this,i),this}setRGB(t,i,s,l=Ae.workingColorSpace){return this.r=t,this.g=i,this.b=s,Ae.colorSpaceToWorking(this,l),this}setHSL(t,i,s,l=Ae.workingColorSpace){if(t=r2(t,1),i=xe(i,0,1),s=xe(s,0,1),i===0)this.r=this.g=this.b=s;else{const c=s<=.5?s*(1+i):s+i-s*i,f=2*s-c;this.r=bh(f,c,t+1/3),this.g=bh(f,c,t),this.b=bh(f,c,t-1/3)}return Ae.colorSpaceToWorking(this,l),this}setStyle(t,i=Jn){function s(c){c!==void 0&&parseFloat(c)<1&&ee("Color: Alpha component of "+t+" will be ignored.")}let l;if(l=/^(\w+)\(([^\)]*)\)/.exec(t)){let c;const f=l[1],T=l[2];switch(f){case"rgb":case"rgba":if(c=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(T))return s(c[4]),this.setRGB(Math.min(255,parseInt(c[1],10))/255,Math.min(255,parseInt(c[2],10))/255,Math.min(255,parseInt(c[3],10))/255,i);if(c=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(T))return s(c[4]),this.setRGB(Math.min(100,parseInt(c[1],10))/100,Math.min(100,parseInt(c[2],10))/100,Math.min(100,parseInt(c[3],10))/100,i);break;case"hsl":case"hsla":if(c=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(T))return s(c[4]),this.setHSL(parseFloat(c[1])/360,parseFloat(c[2])/100,parseFloat(c[3])/100,i);break;default:ee("Color: Unknown color model "+t)}}else if(l=/^\#([A-Fa-f\d]+)$/.exec(t)){const c=l[1],f=c.length;if(f===3)return this.setRGB(parseInt(c.charAt(0),16)/15,parseInt(c.charAt(1),16)/15,parseInt(c.charAt(2),16)/15,i);if(f===6)return this.setHex(parseInt(c,16),i);ee("Color: Invalid hex color "+t)}else if(t&&t.length>0)return this.setColorName(t,i);return this}setColorName(t,i=Jn){const s=YE[t.toLowerCase()];return s!==void 0?this.setHex(s,i):ee("Color: Unknown color "+t),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(t){return this.r=t.r,this.g=t.g,this.b=t.b,this}copySRGBToLinear(t){return this.r=Oa(t.r),this.g=Oa(t.g),this.b=Oa(t.b),this}copyLinearToSRGB(t){return this.r=Wr(t.r),this.g=Wr(t.g),this.b=Wr(t.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(t=Jn){return Ae.workingToColorSpace(Bn.copy(this),t),Math.round(xe(Bn.r*255,0,255))*65536+Math.round(xe(Bn.g*255,0,255))*256+Math.round(xe(Bn.b*255,0,255))}getHexString(t=Jn){return("000000"+this.getHex(t).toString(16)).slice(-6)}getHSL(t,i=Ae.workingColorSpace){Ae.workingToColorSpace(Bn.copy(this),i);const s=Bn.r,l=Bn.g,c=Bn.b,f=Math.max(s,l,c),T=Math.min(s,l,c);let p,h;const m=(T+f)/2;if(T===f)p=0,h=0;else{const E=f-T;switch(h=m<=.5?E/(f+T):E/(2-f-T),f){case s:p=(l-c)/E+(l<c?6:0);break;case l:p=(c-s)/E+2;break;case c:p=(s-l)/E+4;break}p/=6}return t.h=p,t.s=h,t.l=m,t}getRGB(t,i=Ae.workingColorSpace){return Ae.workingToColorSpace(Bn.copy(this),i),t.r=Bn.r,t.g=Bn.g,t.b=Bn.b,t}getStyle(t=Jn){Ae.workingToColorSpace(Bn.copy(this),t);const i=Bn.r,s=Bn.g,l=Bn.b;return t!==Jn?`color(${t} ${i.toFixed(3)} ${s.toFixed(3)} ${l.toFixed(3)})`:`rgb(${Math.round(i*255)},${Math.round(s*255)},${Math.round(l*255)})`}offsetHSL(t,i,s){return this.getHSL(us),this.setHSL(us.h+t,us.s+i,us.l+s)}add(t){return this.r+=t.r,this.g+=t.g,this.b+=t.b,this}addColors(t,i){return this.r=t.r+i.r,this.g=t.g+i.g,this.b=t.b+i.b,this}addScalar(t){return this.r+=t,this.g+=t,this.b+=t,this}sub(t){return this.r=Math.max(0,this.r-t.r),this.g=Math.max(0,this.g-t.g),this.b=Math.max(0,this.b-t.b),this}multiply(t){return this.r*=t.r,this.g*=t.g,this.b*=t.b,this}multiplyScalar(t){return this.r*=t,this.g*=t,this.b*=t,this}lerp(t,i){return this.r+=(t.r-this.r)*i,this.g+=(t.g-this.g)*i,this.b+=(t.b-this.b)*i,this}lerpColors(t,i,s){return this.r=t.r+(i.r-t.r)*s,this.g=t.g+(i.g-t.g)*s,this.b=t.b+(i.b-t.b)*s,this}lerpHSL(t,i){this.getHSL(us),t.getHSL(Mc);const s=Nh(us.h,Mc.h,i),l=Nh(us.s,Mc.s,i),c=Nh(us.l,Mc.l,i);return this.setHSL(s,l,c),this}setFromVector3(t){return this.r=t.x,this.g=t.y,this.b=t.z,this}applyMatrix3(t){const i=this.r,s=this.g,l=this.b,c=t.elements;return this.r=c[0]*i+c[3]*s+c[6]*l,this.g=c[1]*i+c[4]*s+c[7]*l,this.b=c[2]*i+c[5]*s+c[8]*l,this}equals(t){return t.r===this.r&&t.g===this.g&&t.b===this.b}fromArray(t,i=0){return this.r=t[i],this.g=t[i+1],this.b=t[i+2],this}toArray(t=[],i=0){return t[i]=this.r,t[i+1]=this.g,t[i+2]=this.b,t}fromBufferAttribute(t,i){return this.r=t.getX(i),this.g=t.getY(i),this.b=t.getZ(i),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}}const Bn=new _e;_e.NAMES=YE;class au{constructor(t,i=1,s=1e3){this.isFog=!0,this.name="",this.color=new _e(t),this.near=i,this.far=s}clone(){return new au(this.color,this.near,this.far)}toJSON(){return{type:"Fog",name:this.name,color:this.color.getHex(),near:this.near,far:this.far}}}class _2 extends Hn{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new Ss,this.environmentIntensity=1,this.environmentRotation=new Ss,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(t,i){return super.copy(t,i),t.background!==null&&(this.background=t.background.clone()),t.environment!==null&&(this.environment=t.environment.clone()),t.fog!==null&&(this.fog=t.fog.clone()),this.backgroundBlurriness=t.backgroundBlurriness,this.backgroundIntensity=t.backgroundIntensity,this.backgroundRotation.copy(t.backgroundRotation),this.environmentIntensity=t.environmentIntensity,this.environmentRotation.copy(t.environmentRotation),t.overrideMaterial!==null&&(this.overrideMaterial=t.overrideMaterial.clone()),this.matrixAutoUpdate=t.matrixAutoUpdate,this}toJSON(t){const i=super.toJSON(t);return this.fog!==null&&(i.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(i.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(i.object.backgroundIntensity=this.backgroundIntensity),i.object.backgroundRotation=this.backgroundRotation.toArray(),this.environmentIntensity!==1&&(i.object.environmentIntensity=this.environmentIntensity),i.object.environmentRotation=this.environmentRotation.toArray(),i}}const bi=new nt,Aa=new nt,Ih=new nt,xa=new nt,Ur=new nt,Fr=new nt,Om=new nt,Lh=new nt,Uh=new nt,Fh=new nt,wh=new an,Bh=new an,Xh=new an;class Ui{constructor(t=new nt,i=new nt,s=new nt){this.a=t,this.b=i,this.c=s}static getNormal(t,i,s,l){l.subVectors(s,i),bi.subVectors(t,i),l.cross(bi);const c=l.lengthSq();return c>0?l.multiplyScalar(1/Math.sqrt(c)):l.set(0,0,0)}static getBarycoord(t,i,s,l,c){bi.subVectors(l,i),Aa.subVectors(s,i),Ih.subVectors(t,i);const f=bi.dot(bi),T=bi.dot(Aa),p=bi.dot(Ih),h=Aa.dot(Aa),m=Aa.dot(Ih),E=f*h-T*T;if(E===0)return c.set(0,0,0),null;const S=1/E,g=(h*p-T*m)*S,A=(f*m-T*p)*S;return c.set(1-g-A,A,g)}static containsPoint(t,i,s,l){return this.getBarycoord(t,i,s,l,xa)===null?!1:xa.x>=0&&xa.y>=0&&xa.x+xa.y<=1}static getInterpolation(t,i,s,l,c,f,T,p){return this.getBarycoord(t,i,s,l,xa)===null?(p.x=0,p.y=0,"z"in p&&(p.z=0),"w"in p&&(p.w=0),null):(p.setScalar(0),p.addScaledVector(c,xa.x),p.addScaledVector(f,xa.y),p.addScaledVector(T,xa.z),p)}static getInterpolatedAttribute(t,i,s,l,c,f){return wh.setScalar(0),Bh.setScalar(0),Xh.setScalar(0),wh.fromBufferAttribute(t,i),Bh.fromBufferAttribute(t,s),Xh.fromBufferAttribute(t,l),f.setScalar(0),f.addScaledVector(wh,c.x),f.addScaledVector(Bh,c.y),f.addScaledVector(Xh,c.z),f}static isFrontFacing(t,i,s,l){return bi.subVectors(s,i),Aa.subVectors(t,i),bi.cross(Aa).dot(l)<0}set(t,i,s){return this.a.copy(t),this.b.copy(i),this.c.copy(s),this}setFromPointsAndIndices(t,i,s,l){return this.a.copy(t[i]),this.b.copy(t[s]),this.c.copy(t[l]),this}setFromAttributeAndIndices(t,i,s,l){return this.a.fromBufferAttribute(t,i),this.b.fromBufferAttribute(t,s),this.c.fromBufferAttribute(t,l),this}clone(){return new this.constructor().copy(this)}copy(t){return this.a.copy(t.a),this.b.copy(t.b),this.c.copy(t.c),this}getArea(){return bi.subVectors(this.c,this.b),Aa.subVectors(this.a,this.b),bi.cross(Aa).length()*.5}getMidpoint(t){return t.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(t){return Ui.getNormal(this.a,this.b,this.c,t)}getPlane(t){return t.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(t,i){return Ui.getBarycoord(t,this.a,this.b,this.c,i)}getInterpolation(t,i,s,l,c){return Ui.getInterpolation(t,this.a,this.b,this.c,i,s,l,c)}containsPoint(t){return Ui.containsPoint(t,this.a,this.b,this.c)}isFrontFacing(t){return Ui.isFrontFacing(this.a,this.b,this.c,t)}intersectsBox(t){return t.intersectsTriangle(this)}closestPointToPoint(t,i){const s=this.a,l=this.b,c=this.c;let f,T;Ur.subVectors(l,s),Fr.subVectors(c,s),Lh.subVectors(t,s);const p=Ur.dot(Lh),h=Fr.dot(Lh);if(p<=0&&h<=0)return i.copy(s);Uh.subVectors(t,l);const m=Ur.dot(Uh),E=Fr.dot(Uh);if(m>=0&&E<=m)return i.copy(l);const S=p*E-m*h;if(S<=0&&p>=0&&m<=0)return f=p/(p-m),i.copy(s).addScaledVector(Ur,f);Fh.subVectors(t,c);const g=Ur.dot(Fh),A=Fr.dot(Fh);if(A>=0&&g<=A)return i.copy(c);const M=g*h-p*A;if(M<=0&&h>=0&&A<=0)return T=h/(h-A),i.copy(s).addScaledVector(Fr,T);const x=m*A-g*E;if(x<=0&&E-m>=0&&g-A>=0)return Om.subVectors(c,l),T=(E-m)/(E-m+(g-A)),i.copy(l).addScaledVector(Om,T);const v=1/(x+M+S);return f=M*v,T=S*v,i.copy(s).addScaledVector(Ur,f).addScaledVector(Fr,T)}equals(t){return t.a.equals(this.a)&&t.b.equals(this.b)&&t.c.equals(this.c)}}class ul{constructor(t=new nt(1/0,1/0,1/0),i=new nt(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=t,this.max=i}set(t,i){return this.min.copy(t),this.max.copy(i),this}setFromArray(t){this.makeEmpty();for(let i=0,s=t.length;i<s;i+=3)this.expandByPoint(Ii.fromArray(t,i));return this}setFromBufferAttribute(t){this.makeEmpty();for(let i=0,s=t.count;i<s;i++)this.expandByPoint(Ii.fromBufferAttribute(t,i));return this}setFromPoints(t){this.makeEmpty();for(let i=0,s=t.length;i<s;i++)this.expandByPoint(t[i]);return this}setFromCenterAndSize(t,i){const s=Ii.copy(i).multiplyScalar(.5);return this.min.copy(t).sub(s),this.max.copy(t).add(s),this}setFromObject(t,i=!1){return this.makeEmpty(),this.expandByObject(t,i)}clone(){return new this.constructor().copy(this)}copy(t){return this.min.copy(t.min),this.max.copy(t.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(t){return this.isEmpty()?t.set(0,0,0):t.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(t){return this.isEmpty()?t.set(0,0,0):t.subVectors(this.max,this.min)}expandByPoint(t){return this.min.min(t),this.max.max(t),this}expandByVector(t){return this.min.sub(t),this.max.add(t),this}expandByScalar(t){return this.min.addScalar(-t),this.max.addScalar(t),this}expandByObject(t,i=!1){t.updateWorldMatrix(!1,!1);const s=t.geometry;if(s!==void 0){const c=s.getAttribute("position");if(i===!0&&c!==void 0&&t.isInstancedMesh!==!0)for(let f=0,T=c.count;f<T;f++)t.isMesh===!0?t.getVertexPosition(f,Ii):Ii.fromBufferAttribute(c,f),Ii.applyMatrix4(t.matrixWorld),this.expandByPoint(Ii);else t.boundingBox!==void 0?(t.boundingBox===null&&t.computeBoundingBox(),Rc.copy(t.boundingBox)):(s.boundingBox===null&&s.computeBoundingBox(),Rc.copy(s.boundingBox)),Rc.applyMatrix4(t.matrixWorld),this.union(Rc)}const l=t.children;for(let c=0,f=l.length;c<f;c++)this.expandByObject(l[c],i);return this}containsPoint(t){return t.x>=this.min.x&&t.x<=this.max.x&&t.y>=this.min.y&&t.y<=this.max.y&&t.z>=this.min.z&&t.z<=this.max.z}containsBox(t){return this.min.x<=t.min.x&&t.max.x<=this.max.x&&this.min.y<=t.min.y&&t.max.y<=this.max.y&&this.min.z<=t.min.z&&t.max.z<=this.max.z}getParameter(t,i){return i.set((t.x-this.min.x)/(this.max.x-this.min.x),(t.y-this.min.y)/(this.max.y-this.min.y),(t.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(t){return t.max.x>=this.min.x&&t.min.x<=this.max.x&&t.max.y>=this.min.y&&t.min.y<=this.max.y&&t.max.z>=this.min.z&&t.min.z<=this.max.z}intersectsSphere(t){return this.clampPoint(t.center,Ii),Ii.distanceToSquared(t.center)<=t.radius*t.radius}intersectsPlane(t){let i,s;return t.normal.x>0?(i=t.normal.x*this.min.x,s=t.normal.x*this.max.x):(i=t.normal.x*this.max.x,s=t.normal.x*this.min.x),t.normal.y>0?(i+=t.normal.y*this.min.y,s+=t.normal.y*this.max.y):(i+=t.normal.y*this.max.y,s+=t.normal.y*this.min.y),t.normal.z>0?(i+=t.normal.z*this.min.z,s+=t.normal.z*this.max.z):(i+=t.normal.z*this.max.z,s+=t.normal.z*this.min.z),i<=-t.constant&&s>=-t.constant}intersectsTriangle(t){if(this.isEmpty())return!1;this.getCenter(Qo),Cc.subVectors(this.max,Qo),wr.subVectors(t.a,Qo),Br.subVectors(t.b,Qo),Xr.subVectors(t.c,Qo),fs.subVectors(Br,wr),hs.subVectors(Xr,Br),Xs.subVectors(wr,Xr);let i=[0,-fs.z,fs.y,0,-hs.z,hs.y,0,-Xs.z,Xs.y,fs.z,0,-fs.x,hs.z,0,-hs.x,Xs.z,0,-Xs.x,-fs.y,fs.x,0,-hs.y,hs.x,0,-Xs.y,Xs.x,0];return!Ph(i,wr,Br,Xr,Cc)||(i=[1,0,0,0,1,0,0,0,1],!Ph(i,wr,Br,Xr,Cc))?!1:(yc.crossVectors(fs,hs),i=[yc.x,yc.y,yc.z],Ph(i,wr,Br,Xr,Cc))}clampPoint(t,i){return i.copy(t).clamp(this.min,this.max)}distanceToPoint(t){return this.clampPoint(t,Ii).distanceTo(t)}getBoundingSphere(t){return this.isEmpty()?t.makeEmpty():(this.getCenter(t.center),t.radius=this.getSize(Ii).length()*.5),t}intersect(t){return this.min.max(t.min),this.max.min(t.max),this.isEmpty()&&this.makeEmpty(),this}union(t){return this.min.min(t.min),this.max.max(t.max),this}applyMatrix4(t){return this.isEmpty()?this:(Na[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(t),Na[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(t),Na[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(t),Na[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(t),Na[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(t),Na[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(t),Na[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(t),Na[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(t),this.setFromPoints(Na),this)}translate(t){return this.min.add(t),this.max.add(t),this}equals(t){return t.min.equals(this.min)&&t.max.equals(this.max)}toJSON(){return{min:this.min.toArray(),max:this.max.toArray()}}fromJSON(t){return this.min.fromArray(t.min),this.max.fromArray(t.max),this}}const Na=[new nt,new nt,new nt,new nt,new nt,new nt,new nt,new nt],Ii=new nt,Rc=new ul,wr=new nt,Br=new nt,Xr=new nt,fs=new nt,hs=new nt,Xs=new nt,Qo=new nt,Cc=new nt,yc=new nt,Ps=new nt;function Ph(r,t,i,s,l){for(let c=0,f=r.length-3;c<=f;c+=3){Ps.fromArray(r,c);const T=l.x*Math.abs(Ps.x)+l.y*Math.abs(Ps.y)+l.z*Math.abs(Ps.z),p=t.dot(Ps),h=i.dot(Ps),m=s.dot(Ps);if(Math.max(-Math.max(p,h,m),Math.min(p,h,m))>T)return!1}return!0}const Tn=new nt,Dc=new Oe;let v2=0;class Ji extends $s{constructor(t,i,s=!1){if(super(),Array.isArray(t))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,Object.defineProperty(this,"id",{value:v2++}),this.name="",this.array=t,this.itemSize=i,this.count=t!==void 0?t.length/i:0,this.normalized=s,this.usage=mm,this.updateRanges=[],this.gpuType=qi,this.version=0}onUploadCallback(){}set needsUpdate(t){t===!0&&this.version++}setUsage(t){return this.usage=t,this}addUpdateRange(t,i){this.updateRanges.push({start:t,count:i})}clearUpdateRanges(){this.updateRanges.length=0}copy(t){return this.name=t.name,this.array=new t.array.constructor(t.array),this.itemSize=t.itemSize,this.count=t.count,this.normalized=t.normalized,this.usage=t.usage,this.gpuType=t.gpuType,this}copyAt(t,i,s){t*=this.itemSize,s*=i.itemSize;for(let l=0,c=this.itemSize;l<c;l++)this.array[t+l]=i.array[s+l];return this}copyArray(t){return this.array.set(t),this}applyMatrix3(t){if(this.itemSize===2)for(let i=0,s=this.count;i<s;i++)Dc.fromBufferAttribute(this,i),Dc.applyMatrix3(t),this.setXY(i,Dc.x,Dc.y);else if(this.itemSize===3)for(let i=0,s=this.count;i<s;i++)Tn.fromBufferAttribute(this,i),Tn.applyMatrix3(t),this.setXYZ(i,Tn.x,Tn.y,Tn.z);return this}applyMatrix4(t){for(let i=0,s=this.count;i<s;i++)Tn.fromBufferAttribute(this,i),Tn.applyMatrix4(t),this.setXYZ(i,Tn.x,Tn.y,Tn.z);return this}applyNormalMatrix(t){for(let i=0,s=this.count;i<s;i++)Tn.fromBufferAttribute(this,i),Tn.applyNormalMatrix(t),this.setXYZ(i,Tn.x,Tn.y,Tn.z);return this}transformDirection(t){for(let i=0,s=this.count;i<s;i++)Tn.fromBufferAttribute(this,i),Tn.transformDirection(t),this.setXYZ(i,Tn.x,Tn.y,Tn.z);return this}set(t,i=0){return this.array.set(t,i),this}getComponent(t,i){let s=this.array[t*this.itemSize+i];return this.normalized&&(s=qo(s,this.array)),s}setComponent(t,i,s){return this.normalized&&(s=$n(s,this.array)),this.array[t*this.itemSize+i]=s,this}getX(t){let i=this.array[t*this.itemSize];return this.normalized&&(i=qo(i,this.array)),i}setX(t,i){return this.normalized&&(i=$n(i,this.array)),this.array[t*this.itemSize]=i,this}getY(t){let i=this.array[t*this.itemSize+1];return this.normalized&&(i=qo(i,this.array)),i}setY(t,i){return this.normalized&&(i=$n(i,this.array)),this.array[t*this.itemSize+1]=i,this}getZ(t){let i=this.array[t*this.itemSize+2];return this.normalized&&(i=qo(i,this.array)),i}setZ(t,i){return this.normalized&&(i=$n(i,this.array)),this.array[t*this.itemSize+2]=i,this}getW(t){let i=this.array[t*this.itemSize+3];return this.normalized&&(i=qo(i,this.array)),i}setW(t,i){return this.normalized&&(i=$n(i,this.array)),this.array[t*this.itemSize+3]=i,this}setXY(t,i,s){return t*=this.itemSize,this.normalized&&(i=$n(i,this.array),s=$n(s,this.array)),this.array[t+0]=i,this.array[t+1]=s,this}setXYZ(t,i,s,l){return t*=this.itemSize,this.normalized&&(i=$n(i,this.array),s=$n(s,this.array),l=$n(l,this.array)),this.array[t+0]=i,this.array[t+1]=s,this.array[t+2]=l,this}setXYZW(t,i,s,l,c){return t*=this.itemSize,this.normalized&&(i=$n(i,this.array),s=$n(s,this.array),l=$n(l,this.array),c=$n(c,this.array)),this.array[t+0]=i,this.array[t+1]=s,this.array[t+2]=l,this.array[t+3]=c,this}onUpload(t){return this.onUploadCallback=t,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){const t={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(t.name=this.name),this.usage!==mm&&(t.usage=this.usage),t}dispose(){this.dispatchEvent({type:"dispose"})}}class GE extends Ji{constructor(t,i,s){super(new Uint16Array(t),i,s)}}class zE extends Ji{constructor(t,i,s){super(new Uint32Array(t),i,s)}}class wi extends Ji{constructor(t,i,s){super(new Float32Array(t),i,s)}}const A2=new ul,jo=new nt,Hh=new nt;class d0{constructor(t=new nt,i=-1){this.isSphere=!0,this.center=t,this.radius=i}set(t,i){return this.center.copy(t),this.radius=i,this}setFromPoints(t,i){const s=this.center;i!==void 0?s.copy(i):A2.setFromPoints(t).getCenter(s);let l=0;for(let c=0,f=t.length;c<f;c++)l=Math.max(l,s.distanceToSquared(t[c]));return this.radius=Math.sqrt(l),this}copy(t){return this.center.copy(t.center),this.radius=t.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(t){return t.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(t){return t.distanceTo(this.center)-this.radius}intersectsSphere(t){const i=this.radius+t.radius;return t.center.distanceToSquared(this.center)<=i*i}intersectsBox(t){return t.intersectsSphere(this)}intersectsPlane(t){return Math.abs(t.distanceToPoint(this.center))<=this.radius}clampPoint(t,i){const s=this.center.distanceToSquared(t);return i.copy(t),s>this.radius*this.radius&&(i.sub(this.center).normalize(),i.multiplyScalar(this.radius).add(this.center)),i}getBoundingBox(t){return this.isEmpty()?(t.makeEmpty(),t):(t.set(this.center,this.center),t.expandByScalar(this.radius),t)}applyMatrix4(t){return this.center.applyMatrix4(t),this.radius=this.radius*t.getMaxScaleOnAxis(),this}translate(t){return this.center.add(t),this}expandByPoint(t){if(this.isEmpty())return this.center.copy(t),this.radius=0,this;jo.subVectors(t,this.center);const i=jo.lengthSq();if(i>this.radius*this.radius){const s=Math.sqrt(i),l=(s-this.radius)*.5;this.center.addScaledVector(jo,l/s),this.radius+=l}return this}union(t){return t.isEmpty()?this:this.isEmpty()?(this.copy(t),this):(this.center.equals(t.center)===!0?this.radius=Math.max(this.radius,t.radius):(Hh.subVectors(t.center,this.center).setLength(t.radius),this.expandByPoint(jo.copy(t.center).add(Hh)),this.expandByPoint(jo.copy(t.center).sub(Hh))),this)}equals(t){return t.center.equals(this.center)&&t.radius===this.radius}clone(){return new this.constructor().copy(this)}toJSON(){return{radius:this.radius,center:this.center.toArray()}}fromJSON(t){return this.radius=t.radius,this.center.fromArray(t.center),this}}let x2=0;const xi=new cn,Yh=new Hn,Pr=new nt,hi=new ul,Jo=new ul,xn=new nt;class na extends $s{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:x2++}),this.uuid=cl(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.indirectOffset=0,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(t){return Array.isArray(t)?this.index=new(n2(t)?zE:GE)(t,1):this.index=t,this}setIndirect(t,i=0){return this.indirect=t,this.indirectOffset=i,this}getIndirect(){return this.indirect}getAttribute(t){return this.attributes[t]}setAttribute(t,i){return this.attributes[t]=i,this}deleteAttribute(t){return delete this.attributes[t],this}hasAttribute(t){return this.attributes[t]!==void 0}addGroup(t,i,s=0){this.groups.push({start:t,count:i,materialIndex:s})}clearGroups(){this.groups=[]}setDrawRange(t,i){this.drawRange.start=t,this.drawRange.count=i}applyMatrix4(t){const i=this.attributes.position;i!==void 0&&(i.applyMatrix4(t),i.needsUpdate=!0);const s=this.attributes.normal;if(s!==void 0){const c=new se().getNormalMatrix(t);s.applyNormalMatrix(c),s.needsUpdate=!0}const l=this.attributes.tangent;return l!==void 0&&(l.transformDirection(t),l.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(t){return xi.makeRotationFromQuaternion(t),this.applyMatrix4(xi),this}rotateX(t){return xi.makeRotationX(t),this.applyMatrix4(xi),this}rotateY(t){return xi.makeRotationY(t),this.applyMatrix4(xi),this}rotateZ(t){return xi.makeRotationZ(t),this.applyMatrix4(xi),this}translate(t,i,s){return xi.makeTranslation(t,i,s),this.applyMatrix4(xi),this}scale(t,i,s){return xi.makeScale(t,i,s),this.applyMatrix4(xi),this}lookAt(t){return Yh.lookAt(t),Yh.updateMatrix(),this.applyMatrix4(Yh.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(Pr).negate(),this.translate(Pr.x,Pr.y,Pr.z),this}setFromPoints(t){const i=this.getAttribute("position");if(i===void 0){const s=[];for(let l=0,c=t.length;l<c;l++){const f=t[l];s.push(f.x,f.y,f.z||0)}this.setAttribute("position",new wi(s,3))}else{const s=Math.min(t.length,i.count);for(let l=0;l<s;l++){const c=t[l];i.setXYZ(l,c.x,c.y,c.z||0)}t.length>i.count&&ee("BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),i.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new ul);const t=this.attributes.position,i=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){Ne("BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new nt(-1/0,-1/0,-1/0),new nt(1/0,1/0,1/0));return}if(t!==void 0){if(this.boundingBox.setFromBufferAttribute(t),i)for(let s=0,l=i.length;s<l;s++){const c=i[s];hi.setFromBufferAttribute(c),this.morphTargetsRelative?(xn.addVectors(this.boundingBox.min,hi.min),this.boundingBox.expandByPoint(xn),xn.addVectors(this.boundingBox.max,hi.max),this.boundingBox.expandByPoint(xn)):(this.boundingBox.expandByPoint(hi.min),this.boundingBox.expandByPoint(hi.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&Ne('BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new d0);const t=this.attributes.position,i=this.morphAttributes.position;if(t&&t.isGLBufferAttribute){Ne("BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new nt,1/0);return}if(t){const s=this.boundingSphere.center;if(hi.setFromBufferAttribute(t),i)for(let c=0,f=i.length;c<f;c++){const T=i[c];Jo.setFromBufferAttribute(T),this.morphTargetsRelative?(xn.addVectors(hi.min,Jo.min),hi.expandByPoint(xn),xn.addVectors(hi.max,Jo.max),hi.expandByPoint(xn)):(hi.expandByPoint(Jo.min),hi.expandByPoint(Jo.max))}hi.getCenter(s);let l=0;for(let c=0,f=t.count;c<f;c++)xn.fromBufferAttribute(t,c),l=Math.max(l,s.distanceToSquared(xn));if(i)for(let c=0,f=i.length;c<f;c++){const T=i[c],p=this.morphTargetsRelative;for(let h=0,m=T.count;h<m;h++)xn.fromBufferAttribute(T,h),p&&(Pr.fromBufferAttribute(t,h),xn.add(Pr)),l=Math.max(l,s.distanceToSquared(xn))}this.boundingSphere.radius=Math.sqrt(l),isNaN(this.boundingSphere.radius)&&Ne('BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){const t=this.index,i=this.attributes;if(t===null||i.position===void 0||i.normal===void 0||i.uv===void 0){Ne("BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}const s=i.position,l=i.normal,c=i.uv;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new Ji(new Float32Array(4*s.count),4));const f=this.getAttribute("tangent"),T=[],p=[];for(let R=0;R<s.count;R++)T[R]=new nt,p[R]=new nt;const h=new nt,m=new nt,E=new nt,S=new Oe,g=new Oe,A=new Oe,M=new nt,x=new nt;function v(R,w,Z){h.fromBufferAttribute(s,R),m.fromBufferAttribute(s,w),E.fromBufferAttribute(s,Z),S.fromBufferAttribute(c,R),g.fromBufferAttribute(c,w),A.fromBufferAttribute(c,Z),m.sub(h),E.sub(h),g.sub(S),A.sub(S);const H=1/(g.x*A.y-A.x*g.y);isFinite(H)&&(M.copy(m).multiplyScalar(A.y).addScaledVector(E,-g.y).multiplyScalar(H),x.copy(E).multiplyScalar(g.x).addScaledVector(m,-A.x).multiplyScalar(H),T[R].add(M),T[w].add(M),T[Z].add(M),p[R].add(x),p[w].add(x),p[Z].add(x))}let D=this.groups;D.length===0&&(D=[{start:0,count:t.count}]);for(let R=0,w=D.length;R<w;++R){const Z=D[R],H=Z.start,$=Z.count;for(let ct=H,lt=H+$;ct<lt;ct+=3)v(t.getX(ct+0),t.getX(ct+1),t.getX(ct+2))}const I=new nt,U=new nt,Y=new nt,F=new nt;function B(R){Y.fromBufferAttribute(l,R),F.copy(Y);const w=T[R];I.copy(w),I.sub(Y.multiplyScalar(Y.dot(w))).normalize(),U.crossVectors(F,w);const H=U.dot(p[R])<0?-1:1;f.setXYZW(R,I.x,I.y,I.z,H)}for(let R=0,w=D.length;R<w;++R){const Z=D[R],H=Z.start,$=Z.count;for(let ct=H,lt=H+$;ct<lt;ct+=3)B(t.getX(ct+0)),B(t.getX(ct+1)),B(t.getX(ct+2))}}computeVertexNormals(){const t=this.index,i=this.getAttribute("position");if(i!==void 0){let s=this.getAttribute("normal");if(s===void 0)s=new Ji(new Float32Array(i.count*3),3),this.setAttribute("normal",s);else for(let S=0,g=s.count;S<g;S++)s.setXYZ(S,0,0,0);const l=new nt,c=new nt,f=new nt,T=new nt,p=new nt,h=new nt,m=new nt,E=new nt;if(t)for(let S=0,g=t.count;S<g;S+=3){const A=t.getX(S+0),M=t.getX(S+1),x=t.getX(S+2);l.fromBufferAttribute(i,A),c.fromBufferAttribute(i,M),f.fromBufferAttribute(i,x),m.subVectors(f,c),E.subVectors(l,c),m.cross(E),T.fromBufferAttribute(s,A),p.fromBufferAttribute(s,M),h.fromBufferAttribute(s,x),T.add(m),p.add(m),h.add(m),s.setXYZ(A,T.x,T.y,T.z),s.setXYZ(M,p.x,p.y,p.z),s.setXYZ(x,h.x,h.y,h.z)}else for(let S=0,g=i.count;S<g;S+=3)l.fromBufferAttribute(i,S+0),c.fromBufferAttribute(i,S+1),f.fromBufferAttribute(i,S+2),m.subVectors(f,c),E.subVectors(l,c),m.cross(E),s.setXYZ(S+0,m.x,m.y,m.z),s.setXYZ(S+1,m.x,m.y,m.z),s.setXYZ(S+2,m.x,m.y,m.z);this.normalizeNormals(),s.needsUpdate=!0}}normalizeNormals(){const t=this.attributes.normal;for(let i=0,s=t.count;i<s;i++)xn.fromBufferAttribute(t,i),xn.normalize(),t.setXYZ(i,xn.x,xn.y,xn.z)}toNonIndexed(){function t(T,p){const h=T.array,m=T.itemSize,E=T.normalized,S=new h.constructor(p.length*m);let g=0,A=0;for(let M=0,x=p.length;M<x;M++){T.isInterleavedBufferAttribute?g=p[M]*T.data.stride+T.offset:g=p[M]*m;for(let v=0;v<m;v++)S[A++]=h[g++]}return new Ji(S,m,E)}if(this.index===null)return ee("BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;const i=new na,s=this.index.array,l=this.attributes;for(const T in l){const p=l[T],h=t(p,s);i.setAttribute(T,h)}const c=this.morphAttributes;for(const T in c){const p=[],h=c[T];for(let m=0,E=h.length;m<E;m++){const S=h[m],g=t(S,s);p.push(g)}i.morphAttributes[T]=p}i.morphTargetsRelative=this.morphTargetsRelative;const f=this.groups;for(let T=0,p=f.length;T<p;T++){const h=f[T];i.addGroup(h.start,h.count,h.materialIndex)}return i}toJSON(){const t={metadata:{version:4.7,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(t.uuid=this.uuid,t.type=this.type,this.name!==""&&(t.name=this.name),Object.keys(this.userData).length>0&&(t.userData=this.userData),this.parameters!==void 0){const p=this.parameters;for(const h in p)p[h]!==void 0&&(t[h]=p[h]);return t}t.data={attributes:{}};const i=this.index;i!==null&&(t.data.index={type:i.array.constructor.name,array:Array.prototype.slice.call(i.array)});const s=this.attributes;for(const p in s){const h=s[p];t.data.attributes[p]=h.toJSON(t.data)}const l={};let c=!1;for(const p in this.morphAttributes){const h=this.morphAttributes[p],m=[];for(let E=0,S=h.length;E<S;E++){const g=h[E];m.push(g.toJSON(t.data))}m.length>0&&(l[p]=m,c=!0)}c&&(t.data.morphAttributes=l,t.data.morphTargetsRelative=this.morphTargetsRelative);const f=this.groups;f.length>0&&(t.data.groups=JSON.parse(JSON.stringify(f)));const T=this.boundingSphere;return T!==null&&(t.data.boundingSphere=T.toJSON()),t}clone(){return new this.constructor().copy(this)}copy(t){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;const i={};this.name=t.name;const s=t.index;s!==null&&this.setIndex(s.clone());const l=t.attributes;for(const h in l){const m=l[h];this.setAttribute(h,m.clone(i))}const c=t.morphAttributes;for(const h in c){const m=[],E=c[h];for(let S=0,g=E.length;S<g;S++)m.push(E[S].clone(i));this.morphAttributes[h]=m}this.morphTargetsRelative=t.morphTargetsRelative;const f=t.groups;for(let h=0,m=f.length;h<m;h++){const E=f[h];this.addGroup(E.start,E.count,E.materialIndex)}const T=t.boundingBox;T!==null&&(this.boundingBox=T.clone());const p=t.boundingSphere;return p!==null&&(this.boundingSphere=p.clone()),this.drawRange.start=t.drawRange.start,this.drawRange.count=t.drawRange.count,this.userData=t.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}}let N2=0;class fl extends $s{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:N2++}),this.uuid=cl(),this.name="",this.type="Material",this.blending=Vr,this.side=Es,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=sd,this.blendDst=rd,this.blendEquation=Vs,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new _e(0,0,0),this.blendAlpha=0,this.depthFunc=kr,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=Tm,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=Dr,this.stencilZFail=Dr,this.stencilZPass=Dr,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.allowOverride=!0,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(t){this._alphaTest>0!=t>0&&this.version++,this._alphaTest=t}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(t){if(t!==void 0)for(const i in t){const s=t[i];if(s===void 0){ee(`Material: parameter '${i}' has value of undefined.`);continue}const l=this[i];if(l===void 0){ee(`Material: '${i}' is not a property of THREE.${this.type}.`);continue}l&&l.isColor?l.set(s):l&&l.isVector3&&s&&s.isVector3?l.copy(s):this[i]=s}}toJSON(t){const i=t===void 0||typeof t=="string";i&&(t={textures:{},images:{}});const s={metadata:{version:4.7,type:"Material",generator:"Material.toJSON"}};s.uuid=this.uuid,s.type=this.type,this.name!==""&&(s.name=this.name),this.color&&this.color.isColor&&(s.color=this.color.getHex()),this.roughness!==void 0&&(s.roughness=this.roughness),this.metalness!==void 0&&(s.metalness=this.metalness),this.sheen!==void 0&&(s.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(s.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(s.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(s.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&this.emissiveIntensity!==1&&(s.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(s.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(s.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(s.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(s.shininess=this.shininess),this.clearcoat!==void 0&&(s.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(s.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(s.clearcoatMap=this.clearcoatMap.toJSON(t).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(s.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(t).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(s.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(t).uuid,s.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.sheenColorMap&&this.sheenColorMap.isTexture&&(s.sheenColorMap=this.sheenColorMap.toJSON(t).uuid),this.sheenRoughnessMap&&this.sheenRoughnessMap.isTexture&&(s.sheenRoughnessMap=this.sheenRoughnessMap.toJSON(t).uuid),this.dispersion!==void 0&&(s.dispersion=this.dispersion),this.iridescence!==void 0&&(s.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(s.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(s.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(s.iridescenceMap=this.iridescenceMap.toJSON(t).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(s.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(t).uuid),this.anisotropy!==void 0&&(s.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(s.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(s.anisotropyMap=this.anisotropyMap.toJSON(t).uuid),this.map&&this.map.isTexture&&(s.map=this.map.toJSON(t).uuid),this.matcap&&this.matcap.isTexture&&(s.matcap=this.matcap.toJSON(t).uuid),this.alphaMap&&this.alphaMap.isTexture&&(s.alphaMap=this.alphaMap.toJSON(t).uuid),this.lightMap&&this.lightMap.isTexture&&(s.lightMap=this.lightMap.toJSON(t).uuid,s.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(s.aoMap=this.aoMap.toJSON(t).uuid,s.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(s.bumpMap=this.bumpMap.toJSON(t).uuid,s.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(s.normalMap=this.normalMap.toJSON(t).uuid,s.normalMapType=this.normalMapType,s.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(s.displacementMap=this.displacementMap.toJSON(t).uuid,s.displacementScale=this.displacementScale,s.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(s.roughnessMap=this.roughnessMap.toJSON(t).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(s.metalnessMap=this.metalnessMap.toJSON(t).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(s.emissiveMap=this.emissiveMap.toJSON(t).uuid),this.specularMap&&this.specularMap.isTexture&&(s.specularMap=this.specularMap.toJSON(t).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(s.specularIntensityMap=this.specularIntensityMap.toJSON(t).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(s.specularColorMap=this.specularColorMap.toJSON(t).uuid),this.envMap&&this.envMap.isTexture&&(s.envMap=this.envMap.toJSON(t).uuid,this.combine!==void 0&&(s.combine=this.combine)),this.envMapRotation!==void 0&&(s.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(s.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(s.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(s.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(s.gradientMap=this.gradientMap.toJSON(t).uuid),this.transmission!==void 0&&(s.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(s.transmissionMap=this.transmissionMap.toJSON(t).uuid),this.thickness!==void 0&&(s.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(s.thicknessMap=this.thicknessMap.toJSON(t).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(s.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(s.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(s.size=this.size),this.shadowSide!==null&&(s.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(s.sizeAttenuation=this.sizeAttenuation),this.blending!==Vr&&(s.blending=this.blending),this.side!==Es&&(s.side=this.side),this.vertexColors===!0&&(s.vertexColors=!0),this.opacity<1&&(s.opacity=this.opacity),this.transparent===!0&&(s.transparent=!0),this.blendSrc!==sd&&(s.blendSrc=this.blendSrc),this.blendDst!==rd&&(s.blendDst=this.blendDst),this.blendEquation!==Vs&&(s.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(s.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(s.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(s.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(s.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(s.blendAlpha=this.blendAlpha),this.depthFunc!==kr&&(s.depthFunc=this.depthFunc),this.depthTest===!1&&(s.depthTest=this.depthTest),this.depthWrite===!1&&(s.depthWrite=this.depthWrite),this.colorWrite===!1&&(s.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(s.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==Tm&&(s.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(s.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(s.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==Dr&&(s.stencilFail=this.stencilFail),this.stencilZFail!==Dr&&(s.stencilZFail=this.stencilZFail),this.stencilZPass!==Dr&&(s.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(s.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(s.rotation=this.rotation),this.polygonOffset===!0&&(s.polygonOffset=!0),this.polygonOffsetFactor!==0&&(s.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(s.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(s.linewidth=this.linewidth),this.dashSize!==void 0&&(s.dashSize=this.dashSize),this.gapSize!==void 0&&(s.gapSize=this.gapSize),this.scale!==void 0&&(s.scale=this.scale),this.dithering===!0&&(s.dithering=!0),this.alphaTest>0&&(s.alphaTest=this.alphaTest),this.alphaHash===!0&&(s.alphaHash=!0),this.alphaToCoverage===!0&&(s.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(s.premultipliedAlpha=!0),this.forceSinglePass===!0&&(s.forceSinglePass=!0),this.allowOverride===!1&&(s.allowOverride=!1),this.wireframe===!0&&(s.wireframe=!0),this.wireframeLinewidth>1&&(s.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(s.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(s.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(s.flatShading=!0),this.visible===!1&&(s.visible=!1),this.toneMapped===!1&&(s.toneMapped=!1),this.fog===!1&&(s.fog=!1),Object.keys(this.userData).length>0&&(s.userData=this.userData);function l(c){const f=[];for(const T in c){const p=c[T];delete p.metadata,f.push(p)}return f}if(i){const c=l(t.textures),f=l(t.images);c.length>0&&(s.textures=c),f.length>0&&(s.images=f)}return s}clone(){return new this.constructor().copy(this)}copy(t){this.name=t.name,this.blending=t.blending,this.side=t.side,this.vertexColors=t.vertexColors,this.opacity=t.opacity,this.transparent=t.transparent,this.blendSrc=t.blendSrc,this.blendDst=t.blendDst,this.blendEquation=t.blendEquation,this.blendSrcAlpha=t.blendSrcAlpha,this.blendDstAlpha=t.blendDstAlpha,this.blendEquationAlpha=t.blendEquationAlpha,this.blendColor.copy(t.blendColor),this.blendAlpha=t.blendAlpha,this.depthFunc=t.depthFunc,this.depthTest=t.depthTest,this.depthWrite=t.depthWrite,this.stencilWriteMask=t.stencilWriteMask,this.stencilFunc=t.stencilFunc,this.stencilRef=t.stencilRef,this.stencilFuncMask=t.stencilFuncMask,this.stencilFail=t.stencilFail,this.stencilZFail=t.stencilZFail,this.stencilZPass=t.stencilZPass,this.stencilWrite=t.stencilWrite;const i=t.clippingPlanes;let s=null;if(i!==null){const l=i.length;s=new Array(l);for(let c=0;c!==l;++c)s[c]=i[c].clone()}return this.clippingPlanes=s,this.clipIntersection=t.clipIntersection,this.clipShadows=t.clipShadows,this.shadowSide=t.shadowSide,this.colorWrite=t.colorWrite,this.precision=t.precision,this.polygonOffset=t.polygonOffset,this.polygonOffsetFactor=t.polygonOffsetFactor,this.polygonOffsetUnits=t.polygonOffsetUnits,this.dithering=t.dithering,this.alphaTest=t.alphaTest,this.alphaHash=t.alphaHash,this.alphaToCoverage=t.alphaToCoverage,this.premultipliedAlpha=t.premultipliedAlpha,this.forceSinglePass=t.forceSinglePass,this.allowOverride=t.allowOverride,this.visible=t.visible,this.toneMapped=t.toneMapped,this.userData=JSON.parse(JSON.stringify(t.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(t){t===!0&&this.version++}}const Ma=new nt,Gh=new nt,Oc=new nt,ds=new nt,zh=new nt,bc=new nt,Vh=new nt;class M2{constructor(t=new nt,i=new nt(0,0,-1)){this.origin=t,this.direction=i}set(t,i){return this.origin.copy(t),this.direction.copy(i),this}copy(t){return this.origin.copy(t.origin),this.direction.copy(t.direction),this}at(t,i){return i.copy(this.origin).addScaledVector(this.direction,t)}lookAt(t){return this.direction.copy(t).sub(this.origin).normalize(),this}recast(t){return this.origin.copy(this.at(t,Ma)),this}closestPointToPoint(t,i){i.subVectors(t,this.origin);const s=i.dot(this.direction);return s<0?i.copy(this.origin):i.copy(this.origin).addScaledVector(this.direction,s)}distanceToPoint(t){return Math.sqrt(this.distanceSqToPoint(t))}distanceSqToPoint(t){const i=Ma.subVectors(t,this.origin).dot(this.direction);return i<0?this.origin.distanceToSquared(t):(Ma.copy(this.origin).addScaledVector(this.direction,i),Ma.distanceToSquared(t))}distanceSqToSegment(t,i,s,l){Gh.copy(t).add(i).multiplyScalar(.5),Oc.copy(i).sub(t).normalize(),ds.copy(this.origin).sub(Gh);const c=t.distanceTo(i)*.5,f=-this.direction.dot(Oc),T=ds.dot(this.direction),p=-ds.dot(Oc),h=ds.lengthSq(),m=Math.abs(1-f*f);let E,S,g,A;if(m>0)if(E=f*p-T,S=f*T-p,A=c*m,E>=0)if(S>=-A)if(S<=A){const M=1/m;E*=M,S*=M,g=E*(E+f*S+2*T)+S*(f*E+S+2*p)+h}else S=c,E=Math.max(0,-(f*S+T)),g=-E*E+S*(S+2*p)+h;else S=-c,E=Math.max(0,-(f*S+T)),g=-E*E+S*(S+2*p)+h;else S<=-A?(E=Math.max(0,-(-f*c+T)),S=E>0?-c:Math.min(Math.max(-c,-p),c),g=-E*E+S*(S+2*p)+h):S<=A?(E=0,S=Math.min(Math.max(-c,-p),c),g=S*(S+2*p)+h):(E=Math.max(0,-(f*c+T)),S=E>0?c:Math.min(Math.max(-c,-p),c),g=-E*E+S*(S+2*p)+h);else S=f>0?-c:c,E=Math.max(0,-(f*S+T)),g=-E*E+S*(S+2*p)+h;return s&&s.copy(this.origin).addScaledVector(this.direction,E),l&&l.copy(Gh).addScaledVector(Oc,S),g}intersectSphere(t,i){Ma.subVectors(t.center,this.origin);const s=Ma.dot(this.direction),l=Ma.dot(Ma)-s*s,c=t.radius*t.radius;if(l>c)return null;const f=Math.sqrt(c-l),T=s-f,p=s+f;return p<0?null:T<0?this.at(p,i):this.at(T,i)}intersectsSphere(t){return t.radius<0?!1:this.distanceSqToPoint(t.center)<=t.radius*t.radius}distanceToPlane(t){const i=t.normal.dot(this.direction);if(i===0)return t.distanceToPoint(this.origin)===0?0:null;const s=-(this.origin.dot(t.normal)+t.constant)/i;return s>=0?s:null}intersectPlane(t,i){const s=this.distanceToPlane(t);return s===null?null:this.at(s,i)}intersectsPlane(t){const i=t.distanceToPoint(this.origin);return i===0||t.normal.dot(this.direction)*i<0}intersectBox(t,i){let s,l,c,f,T,p;const h=1/this.direction.x,m=1/this.direction.y,E=1/this.direction.z,S=this.origin;return h>=0?(s=(t.min.x-S.x)*h,l=(t.max.x-S.x)*h):(s=(t.max.x-S.x)*h,l=(t.min.x-S.x)*h),m>=0?(c=(t.min.y-S.y)*m,f=(t.max.y-S.y)*m):(c=(t.max.y-S.y)*m,f=(t.min.y-S.y)*m),s>f||c>l||((c>s||isNaN(s))&&(s=c),(f<l||isNaN(l))&&(l=f),E>=0?(T=(t.min.z-S.z)*E,p=(t.max.z-S.z)*E):(T=(t.max.z-S.z)*E,p=(t.min.z-S.z)*E),s>p||T>l)||((T>s||s!==s)&&(s=T),(p<l||l!==l)&&(l=p),l<0)?null:this.at(s>=0?s:l,i)}intersectsBox(t){return this.intersectBox(t,Ma)!==null}intersectTriangle(t,i,s,l,c){zh.subVectors(i,t),bc.subVectors(s,t),Vh.crossVectors(zh,bc);let f=this.direction.dot(Vh),T;if(f>0){if(l)return null;T=1}else if(f<0)T=-1,f=-f;else return null;ds.subVectors(this.origin,t);const p=T*this.direction.dot(bc.crossVectors(ds,bc));if(p<0)return null;const h=T*this.direction.dot(zh.cross(ds));if(h<0||p+h>f)return null;const m=-T*ds.dot(Vh);return m<0?null:this.at(m/f,c)}applyMatrix4(t){return this.origin.applyMatrix4(t),this.direction.transformDirection(t),this}equals(t){return t.origin.equals(this.origin)&&t.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}}class VE extends fl{constructor(t){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new _e(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new Ss,this.combine=i0,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.specularMap=t.specularMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.envMapRotation.copy(t.envMapRotation),this.combine=t.combine,this.reflectivity=t.reflectivity,this.refractionRatio=t.refractionRatio,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.fog=t.fog,this}}const bm=new cn,Hs=new M2,Ic=new d0,Im=new nt,Lc=new nt,Uc=new nt,Fc=new nt,Wh=new nt,wc=new nt,Lm=new nt,Bc=new nt;class Bi extends Hn{constructor(t=new na,i=new VE){super(),this.isMesh=!0,this.type="Mesh",this.geometry=t,this.material=i,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.count=1,this.updateMorphTargets()}copy(t,i){return super.copy(t,i),t.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=t.morphTargetInfluences.slice()),t.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},t.morphTargetDictionary)),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this}updateMorphTargets(){const i=this.geometry.morphAttributes,s=Object.keys(i);if(s.length>0){const l=i[s[0]];if(l!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let c=0,f=l.length;c<f;c++){const T=l[c].name||String(c);this.morphTargetInfluences.push(0),this.morphTargetDictionary[T]=c}}}}getVertexPosition(t,i){const s=this.geometry,l=s.attributes.position,c=s.morphAttributes.position,f=s.morphTargetsRelative;i.fromBufferAttribute(l,t);const T=this.morphTargetInfluences;if(c&&T){wc.set(0,0,0);for(let p=0,h=c.length;p<h;p++){const m=T[p],E=c[p];m!==0&&(Wh.fromBufferAttribute(E,t),f?wc.addScaledVector(Wh,m):wc.addScaledVector(Wh.sub(i),m))}i.add(wc)}return i}raycast(t,i){const s=this.geometry,l=this.material,c=this.matrixWorld;l!==void 0&&(s.boundingSphere===null&&s.computeBoundingSphere(),Ic.copy(s.boundingSphere),Ic.applyMatrix4(c),Hs.copy(t.ray).recast(t.near),!(Ic.containsPoint(Hs.origin)===!1&&(Hs.intersectSphere(Ic,Im)===null||Hs.origin.distanceToSquared(Im)>(t.far-t.near)**2))&&(bm.copy(c).invert(),Hs.copy(t.ray).applyMatrix4(bm),!(s.boundingBox!==null&&Hs.intersectsBox(s.boundingBox)===!1)&&this._computeIntersections(t,i,Hs)))}_computeIntersections(t,i,s){let l;const c=this.geometry,f=this.material,T=c.index,p=c.attributes.position,h=c.attributes.uv,m=c.attributes.uv1,E=c.attributes.normal,S=c.groups,g=c.drawRange;if(T!==null)if(Array.isArray(f))for(let A=0,M=S.length;A<M;A++){const x=S[A],v=f[x.materialIndex],D=Math.max(x.start,g.start),I=Math.min(T.count,Math.min(x.start+x.count,g.start+g.count));for(let U=D,Y=I;U<Y;U+=3){const F=T.getX(U),B=T.getX(U+1),R=T.getX(U+2);l=Xc(this,v,t,s,h,m,E,F,B,R),l&&(l.faceIndex=Math.floor(U/3),l.face.materialIndex=x.materialIndex,i.push(l))}}else{const A=Math.max(0,g.start),M=Math.min(T.count,g.start+g.count);for(let x=A,v=M;x<v;x+=3){const D=T.getX(x),I=T.getX(x+1),U=T.getX(x+2);l=Xc(this,f,t,s,h,m,E,D,I,U),l&&(l.faceIndex=Math.floor(x/3),i.push(l))}}else if(p!==void 0)if(Array.isArray(f))for(let A=0,M=S.length;A<M;A++){const x=S[A],v=f[x.materialIndex],D=Math.max(x.start,g.start),I=Math.min(p.count,Math.min(x.start+x.count,g.start+g.count));for(let U=D,Y=I;U<Y;U+=3){const F=U,B=U+1,R=U+2;l=Xc(this,v,t,s,h,m,E,F,B,R),l&&(l.faceIndex=Math.floor(U/3),l.face.materialIndex=x.materialIndex,i.push(l))}}else{const A=Math.max(0,g.start),M=Math.min(p.count,g.start+g.count);for(let x=A,v=M;x<v;x+=3){const D=x,I=x+1,U=x+2;l=Xc(this,f,t,s,h,m,E,D,I,U),l&&(l.faceIndex=Math.floor(x/3),i.push(l))}}}}function R2(r,t,i,s,l,c,f,T){let p;if(t.side===ti?p=s.intersectTriangle(f,c,l,!0,T):p=s.intersectTriangle(l,c,f,t.side===Es,T),p===null)return null;Bc.copy(T),Bc.applyMatrix4(r.matrixWorld);const h=i.ray.origin.distanceTo(Bc);return h<i.near||h>i.far?null:{distance:h,point:Bc.clone(),object:r}}function Xc(r,t,i,s,l,c,f,T,p,h){r.getVertexPosition(T,Lc),r.getVertexPosition(p,Uc),r.getVertexPosition(h,Fc);const m=R2(r,t,i,s,Lc,Uc,Fc,Lm);if(m){const E=new nt;Ui.getBarycoord(Lm,Lc,Uc,Fc,E),l&&(m.uv=Ui.getInterpolatedAttribute(l,T,p,h,E,new Oe)),c&&(m.uv1=Ui.getInterpolatedAttribute(c,T,p,h,E,new Oe)),f&&(m.normal=Ui.getInterpolatedAttribute(f,T,p,h,E,new nt),m.normal.dot(s.direction)>0&&m.normal.multiplyScalar(-1));const S={a:T,b:p,c:h,normal:new nt,materialIndex:0};Ui.getNormal(Lc,Uc,Fc,S.normal),m.face=S,m.barycoord=E}return m}class C2 extends Pn{constructor(t=null,i=1,s=1,l,c,f,T,p,h=In,m=In,E,S){super(null,f,T,p,h,m,l,c,E,S),this.isDataTexture=!0,this.image={data:t,width:i,height:s},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}const kh=new nt,y2=new nt,D2=new se;class zs{constructor(t=new nt(1,0,0),i=0){this.isPlane=!0,this.normal=t,this.constant=i}set(t,i){return this.normal.copy(t),this.constant=i,this}setComponents(t,i,s,l){return this.normal.set(t,i,s),this.constant=l,this}setFromNormalAndCoplanarPoint(t,i){return this.normal.copy(t),this.constant=-i.dot(this.normal),this}setFromCoplanarPoints(t,i,s){const l=kh.subVectors(s,i).cross(y2.subVectors(t,i)).normalize();return this.setFromNormalAndCoplanarPoint(l,t),this}copy(t){return this.normal.copy(t.normal),this.constant=t.constant,this}normalize(){const t=1/this.normal.length();return this.normal.multiplyScalar(t),this.constant*=t,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(t){return this.normal.dot(t)+this.constant}distanceToSphere(t){return this.distanceToPoint(t.center)-t.radius}projectPoint(t,i){return i.copy(t).addScaledVector(this.normal,-this.distanceToPoint(t))}intersectLine(t,i,s=!0){const l=t.delta(kh),c=this.normal.dot(l);if(c===0)return this.distanceToPoint(t.start)===0?i.copy(t.start):null;const f=-(t.start.dot(this.normal)+this.constant)/c;return s===!0&&(f<0||f>1)?null:i.copy(t.start).addScaledVector(l,f)}intersectsLine(t){const i=this.distanceToPoint(t.start),s=this.distanceToPoint(t.end);return i<0&&s>0||s<0&&i>0}intersectsBox(t){return t.intersectsPlane(this)}intersectsSphere(t){return t.intersectsPlane(this)}coplanarPoint(t){return t.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(t,i){const s=i||D2.getNormalMatrix(t),l=this.coplanarPoint(kh).applyMatrix4(t),c=this.normal.applyMatrix3(s).normalize();return this.constant=-l.dot(c),this}translate(t){return this.constant-=t.dot(this.normal),this}equals(t){return t.normal.equals(this.normal)&&t.constant===this.constant}clone(){return new this.constructor().copy(this)}}const Ys=new d0,O2=new Oe(.5,.5),Pc=new nt;class p0{constructor(t=new zs,i=new zs,s=new zs,l=new zs,c=new zs,f=new zs){this.planes=[t,i,s,l,c,f]}set(t,i,s,l,c,f){const T=this.planes;return T[0].copy(t),T[1].copy(i),T[2].copy(s),T[3].copy(l),T[4].copy(c),T[5].copy(f),this}copy(t){const i=this.planes;for(let s=0;s<6;s++)i[s].copy(t.planes[s]);return this}setFromProjectionMatrix(t,i=$i,s=!1){const l=this.planes,c=t.elements,f=c[0],T=c[1],p=c[2],h=c[3],m=c[4],E=c[5],S=c[6],g=c[7],A=c[8],M=c[9],x=c[10],v=c[11],D=c[12],I=c[13],U=c[14],Y=c[15];if(l[0].setComponents(h-f,g-m,v-A,Y-D).normalize(),l[1].setComponents(h+f,g+m,v+A,Y+D).normalize(),l[2].setComponents(h+T,g+E,v+M,Y+I).normalize(),l[3].setComponents(h-T,g-E,v-M,Y-I).normalize(),s)l[4].setComponents(p,S,x,U).normalize(),l[5].setComponents(h-p,g-S,v-x,Y-U).normalize();else if(l[4].setComponents(h-p,g-S,v-x,Y-U).normalize(),i===$i)l[5].setComponents(h+p,g+S,v+x,Y+U).normalize();else if(i===ll)l[5].setComponents(p,S,x,U).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+i);return this}intersectsObject(t){if(t.boundingSphere!==void 0)t.boundingSphere===null&&t.computeBoundingSphere(),Ys.copy(t.boundingSphere).applyMatrix4(t.matrixWorld);else{const i=t.geometry;i.boundingSphere===null&&i.computeBoundingSphere(),Ys.copy(i.boundingSphere).applyMatrix4(t.matrixWorld)}return this.intersectsSphere(Ys)}intersectsSprite(t){Ys.center.set(0,0,0);const i=O2.distanceTo(t.center);return Ys.radius=.7071067811865476+i,Ys.applyMatrix4(t.matrixWorld),this.intersectsSphere(Ys)}intersectsSphere(t){const i=this.planes,s=t.center,l=-t.radius;for(let c=0;c<6;c++)if(i[c].distanceToPoint(s)<l)return!1;return!0}intersectsBox(t){const i=this.planes;for(let s=0;s<6;s++){const l=i[s];if(Pc.x=l.normal.x>0?t.max.x:t.min.x,Pc.y=l.normal.y>0?t.max.y:t.min.y,Pc.z=l.normal.z>0?t.max.z:t.min.z,l.distanceToPoint(Pc)<0)return!1}return!0}containsPoint(t){const i=this.planes;for(let s=0;s<6;s++)if(i[s].distanceToPoint(t)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}}class WE extends Pn{constructor(t=[],i=Zs,s,l,c,f,T,p,h,m){super(t,i,s,l,c,f,T,p,h,m),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(t){this.image=t}}class b2 extends Pn{constructor(t,i,s,l,c,f,T,p,h){super(t,i,s,l,c,f,T,p,h),this.isCanvasTexture=!0,this.needsUpdate=!0}}class Zr extends Pn{constructor(t,i,s=ta,l,c,f,T=In,p=In,h,m=Ia,E=1){if(m!==Ia&&m!==Ks)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");const S={width:t,height:i,depth:E};super(S,l,c,f,T,p,m,s,h),this.isDepthTexture=!0,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(t){return super.copy(t),this.source=new h0(Object.assign({},t.image)),this.compareFunction=t.compareFunction,this}toJSON(t){const i=super.toJSON(t);return this.compareFunction!==null&&(i.compareFunction=this.compareFunction),i}}class I2 extends Zr{constructor(t,i=ta,s=Zs,l,c,f=In,T=In,p,h=Ia){const m={width:t,height:t,depth:1},E=[m,m,m,m,m,m];super(t,t,i,s,l,c,f,T,p,h),this.image=E,this.isCubeDepthTexture=!0,this.isCubeTexture=!0}get images(){return this.image}set images(t){this.image=t}}class kE extends Pn{constructor(t=null){super(),this.sourceTexture=t,this.isExternalTexture=!0}copy(t){return super.copy(t),this.sourceTexture=t.sourceTexture,this}}class Qr extends na{constructor(t=1,i=1,s=1,l=1,c=1,f=1){super(),this.type="BoxGeometry",this.parameters={width:t,height:i,depth:s,widthSegments:l,heightSegments:c,depthSegments:f};const T=this;l=Math.floor(l),c=Math.floor(c),f=Math.floor(f);const p=[],h=[],m=[],E=[];let S=0,g=0;A("z","y","x",-1,-1,s,i,t,f,c,0),A("z","y","x",1,-1,s,i,-t,f,c,1),A("x","z","y",1,1,t,s,i,l,f,2),A("x","z","y",1,-1,t,s,-i,l,f,3),A("x","y","z",1,-1,t,i,s,l,c,4),A("x","y","z",-1,-1,t,i,-s,l,c,5),this.setIndex(p),this.setAttribute("position",new wi(h,3)),this.setAttribute("normal",new wi(m,3)),this.setAttribute("uv",new wi(E,2));function A(M,x,v,D,I,U,Y,F,B,R,w){const Z=U/B,H=Y/R,$=U/2,ct=Y/2,lt=F/2,W=B+1,L=R+1;let P=0,it=0;const mt=new nt;for(let ft=0;ft<L;ft++){const O=ft*H-ct;for(let V=0;V<W;V++){const dt=V*Z-$;mt[M]=dt*D,mt[x]=O*I,mt[v]=lt,h.push(mt.x,mt.y,mt.z),mt[M]=0,mt[x]=0,mt[v]=F>0?1:-1,m.push(mt.x,mt.y,mt.z),E.push(V/B),E.push(1-ft/R),P+=1}}for(let ft=0;ft<R;ft++)for(let O=0;O<B;O++){const V=S+O+W*ft,dt=S+O+W*(ft+1),gt=S+(O+1)+W*(ft+1),Mt=S+(O+1)+W*ft;p.push(V,dt,Mt),p.push(dt,gt,Mt),it+=6}T.addGroup(g,it,w),g+=it,S+=P}}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new Qr(t.width,t.height,t.depth,t.widthSegments,t.heightSegments,t.depthSegments)}}class ou extends na{constructor(t=1,i=1,s=1,l=1){super(),this.type="PlaneGeometry",this.parameters={width:t,height:i,widthSegments:s,heightSegments:l};const c=t/2,f=i/2,T=Math.floor(s),p=Math.floor(l),h=T+1,m=p+1,E=t/T,S=i/p,g=[],A=[],M=[],x=[];for(let v=0;v<m;v++){const D=v*S-f;for(let I=0;I<h;I++){const U=I*E-c;A.push(U,-D,0),M.push(0,0,1),x.push(I/T),x.push(1-v/p)}}for(let v=0;v<p;v++)for(let D=0;D<T;D++){const I=D+h*v,U=D+h*(v+1),Y=D+1+h*(v+1),F=D+1+h*v;g.push(I,U,F),g.push(U,Y,F)}this.setIndex(g),this.setAttribute("position",new wi(A,3)),this.setAttribute("normal",new wi(M,3)),this.setAttribute("uv",new wi(x,2))}copy(t){return super.copy(t),this.parameters=Object.assign({},t.parameters),this}static fromJSON(t){return new ou(t.width,t.height,t.widthSegments,t.heightSegments)}}function qr(r){const t={};for(const i in r){t[i]={};for(const s in r[i]){const l=r[i][s];if(Um(l))l.isRenderTargetTexture?(ee("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),t[i][s]=null):t[i][s]=l.clone();else if(Array.isArray(l))if(Um(l[0])){const c=[];for(let f=0,T=l.length;f<T;f++)c[f]=l[f].clone();t[i][s]=c}else t[i][s]=l.slice();else t[i][s]=l}}return t}function Gn(r){const t={};for(let i=0;i<r.length;i++){const s=qr(r[i]);for(const l in s)t[l]=s[l]}return t}function Um(r){return r&&(r.isColor||r.isMatrix3||r.isMatrix4||r.isVector2||r.isVector3||r.isVector4||r.isTexture||r.isQuaternion)}function L2(r){const t=[];for(let i=0;i<r.length;i++)t.push(r[i].clone());return t}function KE(r){const t=r.getRenderTarget();return t===null?r.outputColorSpace:t.isXRRenderTarget===!0?t.texture.colorSpace:Ae.workingColorSpace}const U2={clone:qr,merge:Gn};var F2=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,w2=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`;class ea extends fl{constructor(t){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=F2,this.fragmentShader=w2,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,t!==void 0&&this.setValues(t)}copy(t){return super.copy(t),this.fragmentShader=t.fragmentShader,this.vertexShader=t.vertexShader,this.uniforms=qr(t.uniforms),this.uniformsGroups=L2(t.uniformsGroups),this.defines=Object.assign({},t.defines),this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.fog=t.fog,this.lights=t.lights,this.clipping=t.clipping,this.extensions=Object.assign({},t.extensions),this.glslVersion=t.glslVersion,this.defaultAttributeValues=Object.assign({},t.defaultAttributeValues),this.index0AttributeName=t.index0AttributeName,this.uniformsNeedUpdate=t.uniformsNeedUpdate,this}toJSON(t){const i=super.toJSON(t);i.glslVersion=this.glslVersion,i.uniforms={};for(const l in this.uniforms){const f=this.uniforms[l].value;f&&f.isTexture?i.uniforms[l]={type:"t",value:f.toJSON(t).uuid}:f&&f.isColor?i.uniforms[l]={type:"c",value:f.getHex()}:f&&f.isVector2?i.uniforms[l]={type:"v2",value:f.toArray()}:f&&f.isVector3?i.uniforms[l]={type:"v3",value:f.toArray()}:f&&f.isVector4?i.uniforms[l]={type:"v4",value:f.toArray()}:f&&f.isMatrix3?i.uniforms[l]={type:"m3",value:f.toArray()}:f&&f.isMatrix4?i.uniforms[l]={type:"m4",value:f.toArray()}:i.uniforms[l]={value:f}}Object.keys(this.defines).length>0&&(i.defines=this.defines),i.vertexShader=this.vertexShader,i.fragmentShader=this.fragmentShader,i.lights=this.lights,i.clipping=this.clipping;const s={};for(const l in this.extensions)this.extensions[l]===!0&&(s[l]=!0);return Object.keys(s).length>0&&(i.extensions=s),i}}class B2 extends ea{constructor(t){super(t),this.isRawShaderMaterial=!0,this.type="RawShaderMaterial"}}class Fm extends fl{constructor(t){super(),this.isMeshLambertMaterial=!0,this.type="MeshLambertMaterial",this.color=new _e(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new _e(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=kd,this.normalScale=new Oe(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new Ss,this.combine=i0,this.reflectivity=1,this.envMapIntensity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(t)}copy(t){return super.copy(t),this.color.copy(t.color),this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.emissive.copy(t.emissive),this.emissiveMap=t.emissiveMap,this.emissiveIntensity=t.emissiveIntensity,this.bumpMap=t.bumpMap,this.bumpScale=t.bumpScale,this.normalMap=t.normalMap,this.normalMapType=t.normalMapType,this.normalScale.copy(t.normalScale),this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.specularMap=t.specularMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.envMapRotation.copy(t.envMapRotation),this.combine=t.combine,this.reflectivity=t.reflectivity,this.envMapIntensity=t.envMapIntensity,this.refractionRatio=t.refractionRatio,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.flatShading=t.flatShading,this.fog=t.fog,this}}class X2 extends fl{constructor(t){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=Z_,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(t)}copy(t){return super.copy(t),this.depthPacking=t.depthPacking,this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this}}class P2 extends fl{constructor(t){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(t)}copy(t){return super.copy(t),this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this}}class ZE extends Hn{constructor(t,i=1){super(),this.isLight=!0,this.type="Light",this.color=new _e(t),this.intensity=i}dispose(){this.dispatchEvent({type:"dispose"})}copy(t,i){return super.copy(t,i),this.color.copy(t.color),this.intensity=t.intensity,this}toJSON(t){const i=super.toJSON(t);return i.object.color=this.color.getHex(),i.object.intensity=this.intensity,i}}const Kh=new cn,wm=new nt,Bm=new nt;class H2{constructor(t){this.camera=t,this.intensity=1,this.bias=0,this.biasNode=null,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new Oe(512,512),this.mapType=di,this.map=null,this.mapPass=null,this.matrix=new cn,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new p0,this._frameExtents=new Oe(1,1),this._viewportCount=1,this._viewports=[new an(0,0,1,1)]}getViewportCount(){return this._viewportCount}getFrustum(){return this._frustum}updateMatrices(t){const i=this.camera,s=this.matrix;wm.setFromMatrixPosition(t.matrixWorld),i.position.copy(wm),Bm.setFromMatrixPosition(t.target.matrixWorld),i.lookAt(Bm),i.updateMatrixWorld(),Kh.multiplyMatrices(i.projectionMatrix,i.matrixWorldInverse),this._frustum.setFromProjectionMatrix(Kh,i.coordinateSystem,i.reversedDepth),i.coordinateSystem===ll||i.reversedDepth?s.set(.5,0,0,.5,0,.5,0,.5,0,0,1,0,0,0,0,1):s.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),s.multiply(Kh)}getViewport(t){return this._viewports[t]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(t){return this.camera=t.camera.clone(),this.intensity=t.intensity,this.bias=t.bias,this.radius=t.radius,this.autoUpdate=t.autoUpdate,this.needsUpdate=t.needsUpdate,this.normalBias=t.normalBias,this.blurSamples=t.blurSamples,this.mapSize.copy(t.mapSize),this.biasNode=t.biasNode,this}clone(){return new this.constructor().copy(this)}toJSON(){const t={};return this.intensity!==1&&(t.intensity=this.intensity),this.bias!==0&&(t.bias=this.bias),this.normalBias!==0&&(t.normalBias=this.normalBias),this.radius!==1&&(t.radius=this.radius),(this.mapSize.x!==512||this.mapSize.y!==512)&&(t.mapSize=this.mapSize.toArray()),t.camera=this.camera.toJSON(!1).object,delete t.camera.matrix,t}}const Hc=new nt,Yc=new $r,zi=new nt;class qE extends Hn{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new cn,this.projectionMatrix=new cn,this.projectionMatrixInverse=new cn,this.coordinateSystem=$i,this._reversedDepth=!1}get reversedDepth(){return this._reversedDepth}copy(t,i){return super.copy(t,i),this.matrixWorldInverse.copy(t.matrixWorldInverse),this.projectionMatrix.copy(t.projectionMatrix),this.projectionMatrixInverse.copy(t.projectionMatrixInverse),this.coordinateSystem=t.coordinateSystem,this}getWorldDirection(t){return super.getWorldDirection(t).negate()}updateMatrixWorld(t){super.updateMatrixWorld(t),this.matrixWorld.decompose(Hc,Yc,zi),zi.x===1&&zi.y===1&&zi.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(Hc,Yc,zi.set(1,1,1)).invert()}updateWorldMatrix(t,i){super.updateWorldMatrix(t,i),this.matrixWorld.decompose(Hc,Yc,zi),zi.x===1&&zi.y===1&&zi.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(Hc,Yc,zi.set(1,1,1)).invert()}clone(){return new this.constructor().copy(this)}}const ps=new nt,Xm=new Oe,Pm=new Oe;class Ni extends qE{constructor(t=50,i=1,s=.1,l=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=t,this.zoom=1,this.near=s,this.far=l,this.focus=10,this.aspect=i,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(t,i){return super.copy(t,i),this.fov=t.fov,this.zoom=t.zoom,this.near=t.near,this.far=t.far,this.focus=t.focus,this.aspect=t.aspect,this.view=t.view===null?null:Object.assign({},t.view),this.filmGauge=t.filmGauge,this.filmOffset=t.filmOffset,this}setFocalLength(t){const i=.5*this.getFilmHeight()/t;this.fov=Zd*2*Math.atan(i),this.updateProjectionMatrix()}getFocalLength(){const t=Math.tan(xh*.5*this.fov);return .5*this.getFilmHeight()/t}getEffectiveFOV(){return Zd*2*Math.atan(Math.tan(xh*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(t,i,s){ps.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),i.set(ps.x,ps.y).multiplyScalar(-t/ps.z),ps.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),s.set(ps.x,ps.y).multiplyScalar(-t/ps.z)}getViewSize(t,i){return this.getViewBounds(t,Xm,Pm),i.subVectors(Pm,Xm)}setViewOffset(t,i,s,l,c,f){this.aspect=t/i,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=i,this.view.offsetX=s,this.view.offsetY=l,this.view.width=c,this.view.height=f,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const t=this.near;let i=t*Math.tan(xh*.5*this.fov)/this.zoom,s=2*i,l=this.aspect*s,c=-.5*l;const f=this.view;if(this.view!==null&&this.view.enabled){const p=f.fullWidth,h=f.fullHeight;c+=f.offsetX*l/p,i-=f.offsetY*s/h,l*=f.width/p,s*=f.height/h}const T=this.filmOffset;T!==0&&(c+=t*T/this.getFilmWidth()),this.projectionMatrix.makePerspective(c,c+l,i,i-s,t,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){const i=super.toJSON(t);return i.object.fov=this.fov,i.object.zoom=this.zoom,i.object.near=this.near,i.object.far=this.far,i.object.focus=this.focus,i.object.aspect=this.aspect,this.view!==null&&(i.object.view=Object.assign({},this.view)),i.object.filmGauge=this.filmGauge,i.object.filmOffset=this.filmOffset,i}}class T0 extends qE{constructor(t=-1,i=1,s=1,l=-1,c=.1,f=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=t,this.right=i,this.top=s,this.bottom=l,this.near=c,this.far=f,this.updateProjectionMatrix()}copy(t,i){return super.copy(t,i),this.left=t.left,this.right=t.right,this.top=t.top,this.bottom=t.bottom,this.near=t.near,this.far=t.far,this.zoom=t.zoom,this.view=t.view===null?null:Object.assign({},t.view),this}setViewOffset(t,i,s,l,c,f){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=i,this.view.offsetX=s,this.view.offsetY=l,this.view.width=c,this.view.height=f,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const t=(this.right-this.left)/(2*this.zoom),i=(this.top-this.bottom)/(2*this.zoom),s=(this.right+this.left)/2,l=(this.top+this.bottom)/2;let c=s-t,f=s+t,T=l+i,p=l-i;if(this.view!==null&&this.view.enabled){const h=(this.right-this.left)/this.view.fullWidth/this.zoom,m=(this.top-this.bottom)/this.view.fullHeight/this.zoom;c+=h*this.view.offsetX,f=c+h*this.view.width,T-=m*this.view.offsetY,p=T-m*this.view.height}this.projectionMatrix.makeOrthographic(c,f,T,p,this.near,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(t){const i=super.toJSON(t);return i.object.zoom=this.zoom,i.object.left=this.left,i.object.right=this.right,i.object.top=this.top,i.object.bottom=this.bottom,i.object.near=this.near,i.object.far=this.far,this.view!==null&&(i.object.view=Object.assign({},this.view)),i}}class Y2 extends H2{constructor(){super(new T0(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}}class G2 extends ZE{constructor(t,i){super(t,i),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(Hn.DEFAULT_UP),this.updateMatrix(),this.target=new Hn,this.shadow=new Y2}dispose(){super.dispose(),this.shadow.dispose()}copy(t){return super.copy(t),this.target=t.target.clone(),this.shadow=t.shadow.clone(),this}toJSON(t){const i=super.toJSON(t);return i.object.shadow=this.shadow.toJSON(),i.object.target=this.target.uuid,i}}class z2 extends ZE{constructor(t,i){super(t,i),this.isAmbientLight=!0,this.type="AmbientLight"}}const Hr=-90,Yr=1;class V2 extends Hn{constructor(t,i,s){super(),this.type="CubeCamera",this.renderTarget=s,this.coordinateSystem=null,this.activeMipmapLevel=0;const l=new Ni(Hr,Yr,t,i);l.layers=this.layers,this.add(l);const c=new Ni(Hr,Yr,t,i);c.layers=this.layers,this.add(c);const f=new Ni(Hr,Yr,t,i);f.layers=this.layers,this.add(f);const T=new Ni(Hr,Yr,t,i);T.layers=this.layers,this.add(T);const p=new Ni(Hr,Yr,t,i);p.layers=this.layers,this.add(p);const h=new Ni(Hr,Yr,t,i);h.layers=this.layers,this.add(h)}updateCoordinateSystem(){const t=this.coordinateSystem,i=this.children.concat(),[s,l,c,f,T,p]=i;for(const h of i)this.remove(h);if(t===$i)s.up.set(0,1,0),s.lookAt(1,0,0),l.up.set(0,1,0),l.lookAt(-1,0,0),c.up.set(0,0,-1),c.lookAt(0,1,0),f.up.set(0,0,1),f.lookAt(0,-1,0),T.up.set(0,1,0),T.lookAt(0,0,1),p.up.set(0,1,0),p.lookAt(0,0,-1);else if(t===ll)s.up.set(0,-1,0),s.lookAt(-1,0,0),l.up.set(0,-1,0),l.lookAt(1,0,0),c.up.set(0,0,1),c.lookAt(0,1,0),f.up.set(0,0,-1),f.lookAt(0,-1,0),T.up.set(0,-1,0),T.lookAt(0,0,1),p.up.set(0,-1,0),p.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+t);for(const h of i)this.add(h),h.updateMatrixWorld()}update(t,i){this.parent===null&&this.updateMatrixWorld();const{renderTarget:s,activeMipmapLevel:l}=this;this.coordinateSystem!==t.coordinateSystem&&(this.coordinateSystem=t.coordinateSystem,this.updateCoordinateSystem());const[c,f,T,p,h,m]=this.children,E=t.getRenderTarget(),S=t.getActiveCubeFace(),g=t.getActiveMipmapLevel(),A=t.xr.enabled;t.xr.enabled=!1;const M=s.texture.generateMipmaps;s.texture.generateMipmaps=!1;let x=!1;t.isWebGLRenderer===!0?x=t.state.buffers.depth.getReversed():x=t.reversedDepthBuffer,t.setRenderTarget(s,0,l),x&&t.autoClear===!1&&t.clearDepth(),t.render(i,c),t.setRenderTarget(s,1,l),x&&t.autoClear===!1&&t.clearDepth(),t.render(i,f),t.setRenderTarget(s,2,l),x&&t.autoClear===!1&&t.clearDepth(),t.render(i,T),t.setRenderTarget(s,3,l),x&&t.autoClear===!1&&t.clearDepth(),t.render(i,p),t.setRenderTarget(s,4,l),x&&t.autoClear===!1&&t.clearDepth(),t.render(i,h),s.texture.generateMipmaps=M,t.setRenderTarget(s,5,l),x&&t.autoClear===!1&&t.clearDepth(),t.render(i,m),t.setRenderTarget(E,S,g),t.xr.enabled=A,s.texture.needsPMREMUpdate=!0}}class W2 extends Ni{constructor(t=[]){super(),this.isArrayCamera=!0,this.isMultiViewCamera=!1,this.cameras=t}}const A0=class A0{constructor(t,i,s,l){this.elements=[1,0,0,1],t!==void 0&&this.set(t,i,s,l)}identity(){return this.set(1,0,0,1),this}fromArray(t,i=0){for(let s=0;s<4;s++)this.elements[s]=t[s+i];return this}set(t,i,s,l){const c=this.elements;return c[0]=t,c[2]=i,c[1]=s,c[3]=l,this}};A0.prototype.isMatrix2=!0;let Hm=A0;function Ym(r,t,i,s){const l=k2(s);switch(i){case FE:return r*t;case BE:return r*t/l.components*l.byteLength;case o0:return r*t/l.components*l.byteLength;case qs:return r*t*2/l.components*l.byteLength;case l0:return r*t*2/l.components*l.byteLength;case wE:return r*t*3/l.components*l.byteLength;case Fi:return r*t*4/l.components*l.byteLength;case c0:return r*t*4/l.components*l.byteLength;case Kc:case Zc:return Math.floor((r+3)/4)*Math.floor((t+3)/4)*8;case qc:case $c:return Math.floor((r+3)/4)*Math.floor((t+3)/4)*16;case Ed:case gd:return Math.max(r,16)*Math.max(t,8)/4;case md:case Sd:return Math.max(r,8)*Math.max(t,8)/2;case _d:case vd:case xd:case Nd:return Math.floor((r+3)/4)*Math.floor((t+3)/4)*8;case Ad:case Jc:case Md:return Math.floor((r+3)/4)*Math.floor((t+3)/4)*16;case Rd:return Math.floor((r+3)/4)*Math.floor((t+3)/4)*16;case Cd:return Math.floor((r+4)/5)*Math.floor((t+3)/4)*16;case yd:return Math.floor((r+4)/5)*Math.floor((t+4)/5)*16;case Dd:return Math.floor((r+5)/6)*Math.floor((t+4)/5)*16;case Od:return Math.floor((r+5)/6)*Math.floor((t+5)/6)*16;case bd:return Math.floor((r+7)/8)*Math.floor((t+4)/5)*16;case Id:return Math.floor((r+7)/8)*Math.floor((t+5)/6)*16;case Ld:return Math.floor((r+7)/8)*Math.floor((t+7)/8)*16;case Ud:return Math.floor((r+9)/10)*Math.floor((t+4)/5)*16;case Fd:return Math.floor((r+9)/10)*Math.floor((t+5)/6)*16;case wd:return Math.floor((r+9)/10)*Math.floor((t+7)/8)*16;case Bd:return Math.floor((r+9)/10)*Math.floor((t+9)/10)*16;case Xd:return Math.floor((r+11)/12)*Math.floor((t+9)/10)*16;case Pd:return Math.floor((r+11)/12)*Math.floor((t+11)/12)*16;case Hd:case Yd:case Gd:return Math.ceil(r/4)*Math.ceil(t/4)*16;case zd:case Vd:return Math.ceil(r/4)*Math.ceil(t/4)*8;case tu:case Wd:return Math.ceil(r/4)*Math.ceil(t/4)*16}throw new Error(`Unable to determine texture byte length for ${i} format.`)}function k2(r){switch(r){case di:case bE:return{byteLength:1,components:1};case rl:case IE:case ba:return{byteLength:2,components:1};case s0:case r0:return{byteLength:2,components:4};case ta:case a0:case qi:return{byteLength:4,components:1};case LE:case UE:return{byteLength:4,components:3}}throw new Error(`Unknown texture type ${r}.`)}typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:n0}}));typeof window<"u"&&(window.__THREE__?ee("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=n0);function $E(){let r=null,t=!1,i=null,s=null;function l(c,f){i(c,f),s=r.requestAnimationFrame(l)}return{start:function(){t!==!0&&i!==null&&r!==null&&(s=r.requestAnimationFrame(l),t=!0)},stop:function(){r!==null&&r.cancelAnimationFrame(s),t=!1},setAnimationLoop:function(c){i=c},setContext:function(c){r=c}}}function K2(r){const t=new WeakMap;function i(T,p){const h=T.array,m=T.usage,E=h.byteLength,S=r.createBuffer();r.bindBuffer(p,S),r.bufferData(p,h,m),T.onUploadCallback();let g;if(h instanceof Float32Array)g=r.FLOAT;else if(typeof Float16Array<"u"&&h instanceof Float16Array)g=r.HALF_FLOAT;else if(h instanceof Uint16Array)T.isFloat16BufferAttribute?g=r.HALF_FLOAT:g=r.UNSIGNED_SHORT;else if(h instanceof Int16Array)g=r.SHORT;else if(h instanceof Uint32Array)g=r.UNSIGNED_INT;else if(h instanceof Int32Array)g=r.INT;else if(h instanceof Int8Array)g=r.BYTE;else if(h instanceof Uint8Array)g=r.UNSIGNED_BYTE;else if(h instanceof Uint8ClampedArray)g=r.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+h);return{buffer:S,type:g,bytesPerElement:h.BYTES_PER_ELEMENT,version:T.version,size:E}}function s(T,p,h){const m=p.array,E=p.updateRanges;if(r.bindBuffer(h,T),E.length===0)r.bufferSubData(h,0,m);else{E.sort((g,A)=>g.start-A.start);let S=0;for(let g=1;g<E.length;g++){const A=E[S],M=E[g];M.start<=A.start+A.count+1?A.count=Math.max(A.count,M.start+M.count-A.start):(++S,E[S]=M)}E.length=S+1;for(let g=0,A=E.length;g<A;g++){const M=E[g];r.bufferSubData(h,M.start*m.BYTES_PER_ELEMENT,m,M.start,M.count)}p.clearUpdateRanges()}p.onUploadCallback()}function l(T){return T.isInterleavedBufferAttribute&&(T=T.data),t.get(T)}function c(T){T.isInterleavedBufferAttribute&&(T=T.data);const p=t.get(T);p&&(r.deleteBuffer(p.buffer),t.delete(T))}function f(T,p){if(T.isInterleavedBufferAttribute&&(T=T.data),T.isGLBufferAttribute){const m=t.get(T);(!m||m.version<T.version)&&t.set(T,{buffer:T.buffer,type:T.type,bytesPerElement:T.elementSize,version:T.version});return}const h=t.get(T);if(h===void 0)t.set(T,i(T,p));else if(h.version<T.version){if(h.size!==T.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");s(h.buffer,T,p),h.version=T.version}}return{get:l,remove:c,update:f}}var Z2=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,q2=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,$2=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,Q2=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,j2=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,J2=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,tv=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,ev=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,nv=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec4 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 );
	}
#endif`,iv=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,av=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,sv=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,rv=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,ov=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,lv=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,cv=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,uv=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,fv=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,hv=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,dv=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#endif`,pv=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#endif`,Tv=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec4 vColor;
#endif`,mv=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec4( 1.0 );
#endif
#ifdef USE_COLOR_ALPHA
	vColor *= color;
#elif defined( USE_COLOR )
	vColor.rgb *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.rgb *= instanceColor.rgb;
#endif
#ifdef USE_BATCHING_COLOR
	vColor *= getBatchingColor( getIndirectIndex( gl_DrawID ) );
#endif`,Ev=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,Sv=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,gv=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,_v=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,vv=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,Av=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,xv=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,Nv="gl_FragColor = linearToOutputTexel( gl_FragColor );",Mv=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,Rv=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * reflectVec );
		#ifdef ENVMAP_BLENDING_MULTIPLY
			outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_MIX )
			outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_ADD )
			outgoingLight += envColor.xyz * specularStrength * reflectivity;
		#endif
	#endif
#endif`,Cv=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
#endif`,yv=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,Dv=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,Ov=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,bv=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,Iv=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,Lv=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,Uv=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,Fv=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,wv=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,Bv=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,Xv=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,Pv=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif
#include <lightprobes_pars_fragment>`,Hv=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, pow4( roughness ) ) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,Yv=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,Gv=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,zv=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,Vv=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,Wv=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.diffuseContribution = diffuseColor.rgb * ( 1.0 - metalnessFactor );
material.metalness = metalnessFactor;
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor;
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = vec3( 0.04 );
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.0001, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,kv=`uniform sampler2D dfgLUT;
struct PhysicalMaterial {
	vec3 diffuseColor;
	vec3 diffuseContribution;
	vec3 specularColor;
	vec3 specularColorBlended;
	float roughness;
	float metalness;
	float specularF90;
	float dispersion;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
		vec3 iridescenceFresnelDielectric;
		vec3 iridescenceFresnelMetallic;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		return 0.5 / max( gv + gl, EPSILON );
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColorBlended;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transpose( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float rInv = 1.0 / ( roughness + 0.1 );
	float a = -1.9362 + 1.0678 * roughness + 0.4573 * r2 - 0.8469 * rInv;
	float b = -0.6014 + 0.5538 * roughness - 0.4670 * r2 - 0.1255 * rInv;
	float DG = exp( a * dotNV + b );
	return saturate( DG );
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
vec3 BRDF_GGX_Multiscatter( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 singleScatter = BRDF_GGX( lightDir, viewDir, normal, material );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 dfgV = texture2D( dfgLUT, vec2( material.roughness, dotNV ) ).rg;
	vec2 dfgL = texture2D( dfgLUT, vec2( material.roughness, dotNL ) ).rg;
	vec3 FssEss_V = material.specularColorBlended * dfgV.x + material.specularF90 * dfgV.y;
	vec3 FssEss_L = material.specularColorBlended * dfgL.x + material.specularF90 * dfgL.y;
	float Ess_V = dfgV.x + dfgV.y;
	float Ess_L = dfgL.x + dfgL.y;
	float Ems_V = 1.0 - Ess_V;
	float Ems_L = 1.0 - Ess_L;
	vec3 Favg = material.specularColorBlended + ( 1.0 - material.specularColorBlended ) * 0.047619;
	vec3 Fms = FssEss_V * FssEss_L * Favg / ( 1.0 - Ems_V * Ems_L * Favg + EPSILON );
	float compensationFactor = Ems_V * Ems_L;
	vec3 multiScatter = Fms * compensationFactor;
	return singleScatter + multiScatter;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColorBlended * t2.x + ( material.specularF90 - material.specularColorBlended ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseContribution * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
		#ifdef USE_CLEARCOAT
			vec3 Ncc = geometryClearcoatNormal;
			vec2 uvClearcoat = LTC_Uv( Ncc, viewDir, material.clearcoatRoughness );
			vec4 t1Clearcoat = texture2D( ltc_1, uvClearcoat );
			vec4 t2Clearcoat = texture2D( ltc_2, uvClearcoat );
			mat3 mInvClearcoat = mat3(
				vec3( t1Clearcoat.x, 0, t1Clearcoat.y ),
				vec3(             0, 1,             0 ),
				vec3( t1Clearcoat.z, 0, t1Clearcoat.w )
			);
			vec3 fresnelClearcoat = material.clearcoatF0 * t2Clearcoat.x + ( material.clearcoatF90 - material.clearcoatF0 ) * t2Clearcoat.y;
			clearcoatSpecularDirect += lightColor * fresnelClearcoat * LTC_Evaluate( Ncc, viewDir, position, mInvClearcoat, rectCoords );
		#endif
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
 
 		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
 
 		float sheenAlbedoV = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
 		float sheenAlbedoL = IBLSheenBRDF( geometryNormal, directLight.direction, material.sheenRoughness );
 
 		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * max( sheenAlbedoV, sheenAlbedoL );
 
 		irradiance *= sheenEnergyComp;
 
 	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX_Multiscatter( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseContribution );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 diffuse = irradiance * BRDF_Lambert( material.diffuseContribution );
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		diffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectDiffuse += diffuse;
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness ) * RECIPROCAL_PI;
 	#endif
	vec3 singleScatteringDielectric = vec3( 0.0 );
	vec3 multiScatteringDielectric = vec3( 0.0 );
	vec3 singleScatteringMetallic = vec3( 0.0 );
	vec3 multiScatteringMetallic = vec3( 0.0 );
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnelDielectric, material.roughness, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.diffuseColor, material.specularF90, material.iridescence, material.iridescenceFresnelMetallic, material.roughness, singleScatteringMetallic, multiScatteringMetallic );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscattering( geometryNormal, geometryViewDir, material.diffuseColor, material.specularF90, material.roughness, singleScatteringMetallic, multiScatteringMetallic );
	#endif
	vec3 singleScattering = mix( singleScatteringDielectric, singleScatteringMetallic, material.metalness );
	vec3 multiScattering = mix( multiScatteringDielectric, multiScatteringMetallic, material.metalness );
	vec3 totalScatteringDielectric = singleScatteringDielectric + multiScatteringDielectric;
	vec3 diffuse = material.diffuseContribution * ( 1.0 - totalScatteringDielectric );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	vec3 indirectSpecular = radiance * singleScattering;
	indirectSpecular += multiScattering * cosineWeightedIrradiance;
	vec3 indirectDiffuse = diffuse * cosineWeightedIrradiance;
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		indirectSpecular *= sheenEnergyComp;
		indirectDiffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectSpecular += indirectSpecular;
	reflectedLight.indirectDiffuse += indirectDiffuse;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,Kv=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnelDielectric = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceFresnelMetallic = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.diffuseColor );
		material.iridescenceFresnel = mix( material.iridescenceFresnelDielectric, material.iridescenceFresnelMetallic, material.metalness );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS ) && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
	#ifdef USE_LIGHT_PROBES_GRID
		vec3 probeWorldPos = ( ( vec4( geometryPosition, 1.0 ) - viewMatrix[ 3 ] ) * viewMatrix ).xyz;
		vec3 probeWorldNormal = inverseTransformDirection( geometryNormal, viewMatrix );
		irradiance += getLightProbeGridIrradiance( probeWorldPos, probeWorldNormal );
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,Zv=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( ENVMAP_TYPE_CUBE_UV )
		#if defined( STANDARD ) || defined( LAMBERT ) || defined( PHONG )
			iblIrradiance += getIBLIrradiance( geometryNormal );
		#endif
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,qv=`#if defined( RE_IndirectDiffuse )
	#if defined( LAMBERT ) || defined( PHONG )
		irradiance += iblIrradiance;
	#endif
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,$v=`#ifdef USE_LIGHT_PROBES_GRID
uniform highp sampler3D probesSH;
uniform vec3 probesMin;
uniform vec3 probesMax;
uniform vec3 probesResolution;
vec3 getLightProbeGridIrradiance( vec3 worldPos, vec3 worldNormal ) {
	vec3 res = probesResolution;
	vec3 gridRange = probesMax - probesMin;
	vec3 resMinusOne = res - 1.0;
	vec3 probeSpacing = gridRange / resMinusOne;
	vec3 samplePos = worldPos + worldNormal * probeSpacing * 0.5;
	vec3 uvw = clamp( ( samplePos - probesMin ) / gridRange, 0.0, 1.0 );
	uvw = uvw * resMinusOne / res + 0.5 / res;
	float nz          = res.z;
	float paddedSlices = nz + 2.0;
	float atlasDepth  = 7.0 * paddedSlices;
	float uvZBase     = uvw.z * nz + 1.0;
	vec4 s0 = texture( probesSH, vec3( uvw.xy, ( uvZBase                       ) / atlasDepth ) );
	vec4 s1 = texture( probesSH, vec3( uvw.xy, ( uvZBase +       paddedSlices   ) / atlasDepth ) );
	vec4 s2 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 2.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s3 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 3.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s4 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 4.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s5 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 5.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s6 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 6.0 * paddedSlices   ) / atlasDepth ) );
	vec3 c0 = s0.xyz;
	vec3 c1 = vec3( s0.w, s1.xy );
	vec3 c2 = vec3( s1.zw, s2.x );
	vec3 c3 = s2.yzw;
	vec3 c4 = s3.xyz;
	vec3 c5 = vec3( s3.w, s4.xy );
	vec3 c6 = vec3( s4.zw, s5.x );
	vec3 c7 = s5.yzw;
	vec3 c8 = s6.xyz;
	float x = worldNormal.x, y = worldNormal.y, z = worldNormal.z;
	vec3 result = c0 * 0.886227;
	result += c1 * 2.0 * 0.511664 * y;
	result += c2 * 2.0 * 0.511664 * z;
	result += c3 * 2.0 * 0.511664 * x;
	result += c4 * 2.0 * 0.429043 * x * y;
	result += c5 * 2.0 * 0.429043 * y * z;
	result += c6 * ( 0.743125 * z * z - 0.247708 );
	result += c7 * 2.0 * 0.429043 * x * z;
	result += c8 * 0.429043 * ( x * x - y * y );
	return max( result, vec3( 0.0 ) );
}
#endif`,Qv=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,jv=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,Jv=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,tA=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,eA=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,nA=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,iA=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,aA=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,sA=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,rA=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,oA=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,lA=`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,cA=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,uA=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,fA=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,hA=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,dA=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#if defined( USE_PACKED_NORMALMAP )
		mapN = vec3( mapN.xy, sqrt( saturate( 1.0 - dot( mapN.xy, mapN.xy ) ) ) );
	#endif
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,pA=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,TA=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,mA=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,EA=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,SA=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,gA=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,_A=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,vA=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,AA=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,xA=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	#ifdef USE_REVERSED_DEPTH_BUFFER
	
		return depth * ( far - near ) - far;
	#else
		return depth * ( near - far ) - near;
	#endif
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	
	#ifdef USE_REVERSED_DEPTH_BUFFER
		return ( near * far ) / ( ( near - far ) * depth - near );
	#else
		return ( near * far ) / ( ( far - near ) * depth - far );
	#endif
}`,NA=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,MA=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,RA=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,CA=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,yA=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,DA=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,OA=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#else
			uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#endif
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#else
			uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#endif
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform samplerCubeShadow pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#elif defined( SHADOWMAP_TYPE_BASIC )
			uniform samplerCube pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#endif
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float interleavedGradientNoise( vec2 position ) {
			return fract( 52.9829189 * fract( dot( position, vec2( 0.06711056, 0.00583715 ) ) ) );
		}
		vec2 vogelDiskSample( int sampleIndex, int samplesCount, float phi ) {
			const float goldenAngle = 2.399963229728653;
			float r = sqrt( ( float( sampleIndex ) + 0.5 ) / float( samplesCount ) );
			float theta = float( sampleIndex ) * goldenAngle + phi;
			return vec2( cos( theta ), sin( theta ) ) * r;
		}
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float getShadow( sampler2DShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			shadowCoord.z += shadowBias;
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
				float radius = shadowRadius * texelSize.x;
				float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
				shadow = (
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 0, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 1, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 2, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 3, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 4, 5, phi ) * radius, shadowCoord.z ) )
				) * 0.2;
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#elif defined( SHADOWMAP_TYPE_VSM )
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 distribution = texture2D( shadowMap, shadowCoord.xy ).rg;
				float mean = distribution.x;
				float variance = distribution.y * distribution.y;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					float hard_shadow = step( mean, shadowCoord.z );
				#else
					float hard_shadow = step( shadowCoord.z, mean );
				#endif
				
				if ( hard_shadow == 1.0 ) {
					shadow = 1.0;
				} else {
					variance = max( variance, 0.0000001 );
					float d = shadowCoord.z - mean;
					float p_max = variance / ( variance + d * d );
					p_max = clamp( ( p_max - 0.3 ) / 0.65, 0.0, 1.0 );
					shadow = max( hard_shadow, p_max );
				}
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#else
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				float depth = texture2D( shadowMap, shadowCoord.xy ).r;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					shadow = step( depth, shadowCoord.z );
				#else
					shadow = step( shadowCoord.z, depth );
				#endif
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	#if defined( SHADOWMAP_TYPE_PCF )
	float getPointShadow( samplerCubeShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 bd3D = normalize( lightToPosition );
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			#ifdef USE_REVERSED_DEPTH_BUFFER
				float dp = ( shadowCameraNear * ( shadowCameraFar - viewSpaceZ ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
				dp -= shadowBias;
			#else
				float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
				dp += shadowBias;
			#endif
			float texelSize = shadowRadius / shadowMapSize.x;
			vec3 absDir = abs( bd3D );
			vec3 tangent = absDir.x > absDir.z ? vec3( 0.0, 1.0, 0.0 ) : vec3( 1.0, 0.0, 0.0 );
			tangent = normalize( cross( bd3D, tangent ) );
			vec3 bitangent = cross( bd3D, tangent );
			float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
			vec2 sample0 = vogelDiskSample( 0, 5, phi );
			vec2 sample1 = vogelDiskSample( 1, 5, phi );
			vec2 sample2 = vogelDiskSample( 2, 5, phi );
			vec2 sample3 = vogelDiskSample( 3, 5, phi );
			vec2 sample4 = vogelDiskSample( 4, 5, phi );
			shadow = (
				texture( shadowMap, vec4( bd3D + ( tangent * sample0.x + bitangent * sample0.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample1.x + bitangent * sample1.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample2.x + bitangent * sample2.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample3.x + bitangent * sample3.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample4.x + bitangent * sample4.y ) * texelSize, dp ) )
			) * 0.2;
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#elif defined( SHADOWMAP_TYPE_BASIC )
	float getPointShadow( samplerCube shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			float depth = textureCube( shadowMap, bd3D ).r;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				depth = 1.0 - depth;
			#endif
			shadow = step( dp, depth );
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#endif
	#endif
#endif`,bA=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,IA=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	#ifdef HAS_NORMAL
		vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	#else
		vec3 shadowWorldNormal = vec3( 0.0 );
	#endif
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,LA=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0 && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,UA=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,FA=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,wA=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,BA=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,XA=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,PA=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,HA=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,YA=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,GA=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseContribution, material.specularColorBlended, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,zA=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		#else
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,VA=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,WA=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,kA=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,KA=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`;const ZA=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,qA=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,$A=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,QA=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vWorldDirection );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,jA=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,JA=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,tx=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,ex=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	#ifdef USE_REVERSED_DEPTH_BUFFER
		float fragCoordZ = vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ];
	#else
		float fragCoordZ = 0.5 * vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ] + 0.5;
	#endif
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,nx=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,ix=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = vec4( dist, 0.0, 0.0, 1.0 );
}`,ax=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,sx=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,rx=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,ox=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,lx=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,cx=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,ux=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,fx=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,hx=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,dx=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,px=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,Tx=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( normalize( normal ) * 0.5 + 0.5, diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,mx=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Ex=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Sx=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,gx=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
 
		outgoingLight = outgoingLight + sheenSpecularDirect + sheenSpecularIndirect;
 
 	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,_x=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,vx=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Ax=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,xx=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Nx=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Mx=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Rx=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,Cx=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,ue={alphahash_fragment:Z2,alphahash_pars_fragment:q2,alphamap_fragment:$2,alphamap_pars_fragment:Q2,alphatest_fragment:j2,alphatest_pars_fragment:J2,aomap_fragment:tv,aomap_pars_fragment:ev,batching_pars_vertex:nv,batching_vertex:iv,begin_vertex:av,beginnormal_vertex:sv,bsdfs:rv,iridescence_fragment:ov,bumpmap_pars_fragment:lv,clipping_planes_fragment:cv,clipping_planes_pars_fragment:uv,clipping_planes_pars_vertex:fv,clipping_planes_vertex:hv,color_fragment:dv,color_pars_fragment:pv,color_pars_vertex:Tv,color_vertex:mv,common:Ev,cube_uv_reflection_fragment:Sv,defaultnormal_vertex:gv,displacementmap_pars_vertex:_v,displacementmap_vertex:vv,emissivemap_fragment:Av,emissivemap_pars_fragment:xv,colorspace_fragment:Nv,colorspace_pars_fragment:Mv,envmap_fragment:Rv,envmap_common_pars_fragment:Cv,envmap_pars_fragment:yv,envmap_pars_vertex:Dv,envmap_physical_pars_fragment:Hv,envmap_vertex:Ov,fog_vertex:bv,fog_pars_vertex:Iv,fog_fragment:Lv,fog_pars_fragment:Uv,gradientmap_pars_fragment:Fv,lightmap_pars_fragment:wv,lights_lambert_fragment:Bv,lights_lambert_pars_fragment:Xv,lights_pars_begin:Pv,lights_toon_fragment:Yv,lights_toon_pars_fragment:Gv,lights_phong_fragment:zv,lights_phong_pars_fragment:Vv,lights_physical_fragment:Wv,lights_physical_pars_fragment:kv,lights_fragment_begin:Kv,lights_fragment_maps:Zv,lights_fragment_end:qv,lightprobes_pars_fragment:$v,logdepthbuf_fragment:Qv,logdepthbuf_pars_fragment:jv,logdepthbuf_pars_vertex:Jv,logdepthbuf_vertex:tA,map_fragment:eA,map_pars_fragment:nA,map_particle_fragment:iA,map_particle_pars_fragment:aA,metalnessmap_fragment:sA,metalnessmap_pars_fragment:rA,morphinstance_vertex:oA,morphcolor_vertex:lA,morphnormal_vertex:cA,morphtarget_pars_vertex:uA,morphtarget_vertex:fA,normal_fragment_begin:hA,normal_fragment_maps:dA,normal_pars_fragment:pA,normal_pars_vertex:TA,normal_vertex:mA,normalmap_pars_fragment:EA,clearcoat_normal_fragment_begin:SA,clearcoat_normal_fragment_maps:gA,clearcoat_pars_fragment:_A,iridescence_pars_fragment:vA,opaque_fragment:AA,packing:xA,premultiplied_alpha_fragment:NA,project_vertex:MA,dithering_fragment:RA,dithering_pars_fragment:CA,roughnessmap_fragment:yA,roughnessmap_pars_fragment:DA,shadowmap_pars_fragment:OA,shadowmap_pars_vertex:bA,shadowmap_vertex:IA,shadowmask_pars_fragment:LA,skinbase_vertex:UA,skinning_pars_vertex:FA,skinning_vertex:wA,skinnormal_vertex:BA,specularmap_fragment:XA,specularmap_pars_fragment:PA,tonemapping_fragment:HA,tonemapping_pars_fragment:YA,transmission_fragment:GA,transmission_pars_fragment:zA,uv_pars_fragment:VA,uv_pars_vertex:WA,uv_vertex:kA,worldpos_vertex:KA,background_vert:ZA,background_frag:qA,backgroundCube_vert:$A,backgroundCube_frag:QA,cube_vert:jA,cube_frag:JA,depth_vert:tx,depth_frag:ex,distance_vert:nx,distance_frag:ix,equirect_vert:ax,equirect_frag:sx,linedashed_vert:rx,linedashed_frag:ox,meshbasic_vert:lx,meshbasic_frag:cx,meshlambert_vert:ux,meshlambert_frag:fx,meshmatcap_vert:hx,meshmatcap_frag:dx,meshnormal_vert:px,meshnormal_frag:Tx,meshphong_vert:mx,meshphong_frag:Ex,meshphysical_vert:Sx,meshphysical_frag:gx,meshtoon_vert:_x,meshtoon_frag:vx,points_vert:Ax,points_frag:xx,shadow_vert:Nx,shadow_frag:Mx,sprite_vert:Rx,sprite_frag:Cx},Xt={common:{diffuse:{value:new _e(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new se},alphaMap:{value:null},alphaMapTransform:{value:new se},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new se}},envmap:{envMap:{value:null},envMapRotation:{value:new se},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98},dfgLUT:{value:null}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new se}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new se}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new se},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new se},normalScale:{value:new Oe(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new se},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new se}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new se}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new se}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new _e(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null},probesSH:{value:null},probesMin:{value:new nt},probesMax:{value:new nt},probesResolution:{value:new nt}},points:{diffuse:{value:new _e(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new se},alphaTest:{value:0},uvTransform:{value:new se}},sprite:{diffuse:{value:new _e(16777215)},opacity:{value:1},center:{value:new Oe(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new se},alphaMap:{value:null},alphaMapTransform:{value:new se},alphaTest:{value:0}}},ki={basic:{uniforms:Gn([Xt.common,Xt.specularmap,Xt.envmap,Xt.aomap,Xt.lightmap,Xt.fog]),vertexShader:ue.meshbasic_vert,fragmentShader:ue.meshbasic_frag},lambert:{uniforms:Gn([Xt.common,Xt.specularmap,Xt.envmap,Xt.aomap,Xt.lightmap,Xt.emissivemap,Xt.bumpmap,Xt.normalmap,Xt.displacementmap,Xt.fog,Xt.lights,{emissive:{value:new _e(0)},envMapIntensity:{value:1}}]),vertexShader:ue.meshlambert_vert,fragmentShader:ue.meshlambert_frag},phong:{uniforms:Gn([Xt.common,Xt.specularmap,Xt.envmap,Xt.aomap,Xt.lightmap,Xt.emissivemap,Xt.bumpmap,Xt.normalmap,Xt.displacementmap,Xt.fog,Xt.lights,{emissive:{value:new _e(0)},specular:{value:new _e(1118481)},shininess:{value:30},envMapIntensity:{value:1}}]),vertexShader:ue.meshphong_vert,fragmentShader:ue.meshphong_frag},standard:{uniforms:Gn([Xt.common,Xt.envmap,Xt.aomap,Xt.lightmap,Xt.emissivemap,Xt.bumpmap,Xt.normalmap,Xt.displacementmap,Xt.roughnessmap,Xt.metalnessmap,Xt.fog,Xt.lights,{emissive:{value:new _e(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:ue.meshphysical_vert,fragmentShader:ue.meshphysical_frag},toon:{uniforms:Gn([Xt.common,Xt.aomap,Xt.lightmap,Xt.emissivemap,Xt.bumpmap,Xt.normalmap,Xt.displacementmap,Xt.gradientmap,Xt.fog,Xt.lights,{emissive:{value:new _e(0)}}]),vertexShader:ue.meshtoon_vert,fragmentShader:ue.meshtoon_frag},matcap:{uniforms:Gn([Xt.common,Xt.bumpmap,Xt.normalmap,Xt.displacementmap,Xt.fog,{matcap:{value:null}}]),vertexShader:ue.meshmatcap_vert,fragmentShader:ue.meshmatcap_frag},points:{uniforms:Gn([Xt.points,Xt.fog]),vertexShader:ue.points_vert,fragmentShader:ue.points_frag},dashed:{uniforms:Gn([Xt.common,Xt.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:ue.linedashed_vert,fragmentShader:ue.linedashed_frag},depth:{uniforms:Gn([Xt.common,Xt.displacementmap]),vertexShader:ue.depth_vert,fragmentShader:ue.depth_frag},normal:{uniforms:Gn([Xt.common,Xt.bumpmap,Xt.normalmap,Xt.displacementmap,{opacity:{value:1}}]),vertexShader:ue.meshnormal_vert,fragmentShader:ue.meshnormal_frag},sprite:{uniforms:Gn([Xt.sprite,Xt.fog]),vertexShader:ue.sprite_vert,fragmentShader:ue.sprite_frag},background:{uniforms:{uvTransform:{value:new se},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:ue.background_vert,fragmentShader:ue.background_frag},backgroundCube:{uniforms:{envMap:{value:null},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new se}},vertexShader:ue.backgroundCube_vert,fragmentShader:ue.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:ue.cube_vert,fragmentShader:ue.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:ue.equirect_vert,fragmentShader:ue.equirect_frag},distance:{uniforms:Gn([Xt.common,Xt.displacementmap,{referencePosition:{value:new nt},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:ue.distance_vert,fragmentShader:ue.distance_frag},shadow:{uniforms:Gn([Xt.lights,Xt.fog,{color:{value:new _e(0)},opacity:{value:1}}]),vertexShader:ue.shadow_vert,fragmentShader:ue.shadow_frag}};ki.physical={uniforms:Gn([ki.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new se},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new se},clearcoatNormalScale:{value:new Oe(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new se},dispersion:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new se},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new se},sheen:{value:0},sheenColor:{value:new _e(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new se},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new se},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new se},transmissionSamplerSize:{value:new Oe},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new se},attenuationDistance:{value:0},attenuationColor:{value:new _e(0)},specularColor:{value:new _e(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new se},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new se},anisotropyVector:{value:new Oe},anisotropyMap:{value:null},anisotropyMapTransform:{value:new se}}]),vertexShader:ue.meshphysical_vert,fragmentShader:ue.meshphysical_frag};const Gc={r:0,b:0,g:0},yx=new cn,QE=new se;QE.set(-1,0,0,0,1,0,0,0,1);function Dx(r,t,i,s,l,c){const f=new _e(0);let T=l===!0?0:1,p,h,m=null,E=0,S=null;function g(D){let I=D.isScene===!0?D.background:null;if(I&&I.isTexture){const U=D.backgroundBlurriness>0;I=t.get(I,U)}return I}function A(D){let I=!1;const U=g(D);U===null?x(f,T):U&&U.isColor&&(x(U,1),I=!0);const Y=r.xr.getEnvironmentBlendMode();Y==="additive"?i.buffers.color.setClear(0,0,0,1,c):Y==="alpha-blend"&&i.buffers.color.setClear(0,0,0,0,c),(r.autoClear||I)&&(i.buffers.depth.setTest(!0),i.buffers.depth.setMask(!0),i.buffers.color.setMask(!0),r.clear(r.autoClearColor,r.autoClearDepth,r.autoClearStencil))}function M(D,I){const U=g(I);U&&(U.isCubeTexture||U.mapping===ru)?(h===void 0&&(h=new Bi(new Qr(1,1,1),new ea({name:"BackgroundCubeMaterial",uniforms:qr(ki.backgroundCube.uniforms),vertexShader:ki.backgroundCube.vertexShader,fragmentShader:ki.backgroundCube.fragmentShader,side:ti,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),h.geometry.deleteAttribute("normal"),h.geometry.deleteAttribute("uv"),h.onBeforeRender=function(Y,F,B){this.matrixWorld.copyPosition(B.matrixWorld)},Object.defineProperty(h.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),s.update(h)),h.material.uniforms.envMap.value=U,h.material.uniforms.backgroundBlurriness.value=I.backgroundBlurriness,h.material.uniforms.backgroundIntensity.value=I.backgroundIntensity,h.material.uniforms.backgroundRotation.value.setFromMatrix4(yx.makeRotationFromEuler(I.backgroundRotation)).transpose(),U.isCubeTexture&&U.isRenderTargetTexture===!1&&h.material.uniforms.backgroundRotation.value.premultiply(QE),h.material.toneMapped=Ae.getTransfer(U.colorSpace)!==Xe,(m!==U||E!==U.version||S!==r.toneMapping)&&(h.material.needsUpdate=!0,m=U,E=U.version,S=r.toneMapping),h.layers.enableAll(),D.unshift(h,h.geometry,h.material,0,0,null)):U&&U.isTexture&&(p===void 0&&(p=new Bi(new ou(2,2),new ea({name:"BackgroundMaterial",uniforms:qr(ki.background.uniforms),vertexShader:ki.background.vertexShader,fragmentShader:ki.background.fragmentShader,side:Es,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),p.geometry.deleteAttribute("normal"),Object.defineProperty(p.material,"map",{get:function(){return this.uniforms.t2D.value}}),s.update(p)),p.material.uniforms.t2D.value=U,p.material.uniforms.backgroundIntensity.value=I.backgroundIntensity,p.material.toneMapped=Ae.getTransfer(U.colorSpace)!==Xe,U.matrixAutoUpdate===!0&&U.updateMatrix(),p.material.uniforms.uvTransform.value.copy(U.matrix),(m!==U||E!==U.version||S!==r.toneMapping)&&(p.material.needsUpdate=!0,m=U,E=U.version,S=r.toneMapping),p.layers.enableAll(),D.unshift(p,p.geometry,p.material,0,0,null))}function x(D,I){D.getRGB(Gc,KE(r)),i.buffers.color.setClear(Gc.r,Gc.g,Gc.b,I,c)}function v(){h!==void 0&&(h.geometry.dispose(),h.material.dispose(),h=void 0),p!==void 0&&(p.geometry.dispose(),p.material.dispose(),p=void 0)}return{getClearColor:function(){return f},setClearColor:function(D,I=1){f.set(D),T=I,x(f,T)},getClearAlpha:function(){return T},setClearAlpha:function(D){T=D,x(f,T)},render:A,addToRenderList:M,dispose:v}}function Ox(r,t){const i=r.getParameter(r.MAX_VERTEX_ATTRIBS),s={},l=S(null);let c=l,f=!1;function T(H,$,ct,lt,W){let L=!1;const P=E(H,lt,ct,$);c!==P&&(c=P,h(c.object)),L=g(H,lt,ct,W),L&&A(H,lt,ct,W),W!==null&&t.update(W,r.ELEMENT_ARRAY_BUFFER),(L||f)&&(f=!1,U(H,$,ct,lt),W!==null&&r.bindBuffer(r.ELEMENT_ARRAY_BUFFER,t.get(W).buffer))}function p(){return r.createVertexArray()}function h(H){return r.bindVertexArray(H)}function m(H){return r.deleteVertexArray(H)}function E(H,$,ct,lt){const W=lt.wireframe===!0;let L=s[$.id];L===void 0&&(L={},s[$.id]=L);const P=H.isInstancedMesh===!0?H.id:0;let it=L[P];it===void 0&&(it={},L[P]=it);let mt=it[ct.id];mt===void 0&&(mt={},it[ct.id]=mt);let ft=mt[W];return ft===void 0&&(ft=S(p()),mt[W]=ft),ft}function S(H){const $=[],ct=[],lt=[];for(let W=0;W<i;W++)$[W]=0,ct[W]=0,lt[W]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:$,enabledAttributes:ct,attributeDivisors:lt,object:H,attributes:{},index:null}}function g(H,$,ct,lt){const W=c.attributes,L=$.attributes;let P=0;const it=ct.getAttributes();for(const mt in it)if(it[mt].location>=0){const O=W[mt];let V=L[mt];if(V===void 0&&(mt==="instanceMatrix"&&H.instanceMatrix&&(V=H.instanceMatrix),mt==="instanceColor"&&H.instanceColor&&(V=H.instanceColor)),O===void 0||O.attribute!==V||V&&O.data!==V.data)return!0;P++}return c.attributesNum!==P||c.index!==lt}function A(H,$,ct,lt){const W={},L=$.attributes;let P=0;const it=ct.getAttributes();for(const mt in it)if(it[mt].location>=0){let O=L[mt];O===void 0&&(mt==="instanceMatrix"&&H.instanceMatrix&&(O=H.instanceMatrix),mt==="instanceColor"&&H.instanceColor&&(O=H.instanceColor));const V={};V.attribute=O,O&&O.data&&(V.data=O.data),W[mt]=V,P++}c.attributes=W,c.attributesNum=P,c.index=lt}function M(){const H=c.newAttributes;for(let $=0,ct=H.length;$<ct;$++)H[$]=0}function x(H){v(H,0)}function v(H,$){const ct=c.newAttributes,lt=c.enabledAttributes,W=c.attributeDivisors;ct[H]=1,lt[H]===0&&(r.enableVertexAttribArray(H),lt[H]=1),W[H]!==$&&(r.vertexAttribDivisor(H,$),W[H]=$)}function D(){const H=c.newAttributes,$=c.enabledAttributes;for(let ct=0,lt=$.length;ct<lt;ct++)$[ct]!==H[ct]&&(r.disableVertexAttribArray(ct),$[ct]=0)}function I(H,$,ct,lt,W,L,P){P===!0?r.vertexAttribIPointer(H,$,ct,W,L):r.vertexAttribPointer(H,$,ct,lt,W,L)}function U(H,$,ct,lt){M();const W=lt.attributes,L=ct.getAttributes(),P=$.defaultAttributeValues;for(const it in L){const mt=L[it];if(mt.location>=0){let ft=W[it];if(ft===void 0&&(it==="instanceMatrix"&&H.instanceMatrix&&(ft=H.instanceMatrix),it==="instanceColor"&&H.instanceColor&&(ft=H.instanceColor)),ft!==void 0){const O=ft.normalized,V=ft.itemSize,dt=t.get(ft);if(dt===void 0)continue;const gt=dt.buffer,Mt=dt.type,rt=dt.bytesPerElement,vt=Mt===r.INT||Mt===r.UNSIGNED_INT||ft.gpuType===a0;if(ft.isInterleavedBufferAttribute){const Nt=ft.data,Pt=Nt.stride,Jt=ft.offset;if(Nt.isInstancedInterleavedBuffer){for(let Qt=0;Qt<mt.locationSize;Qt++)v(mt.location+Qt,Nt.meshPerAttribute);H.isInstancedMesh!==!0&&lt._maxInstanceCount===void 0&&(lt._maxInstanceCount=Nt.meshPerAttribute*Nt.count)}else for(let Qt=0;Qt<mt.locationSize;Qt++)x(mt.location+Qt);r.bindBuffer(r.ARRAY_BUFFER,gt);for(let Qt=0;Qt<mt.locationSize;Qt++)I(mt.location+Qt,V/mt.locationSize,Mt,O,Pt*rt,(Jt+V/mt.locationSize*Qt)*rt,vt)}else{if(ft.isInstancedBufferAttribute){for(let Nt=0;Nt<mt.locationSize;Nt++)v(mt.location+Nt,ft.meshPerAttribute);H.isInstancedMesh!==!0&&lt._maxInstanceCount===void 0&&(lt._maxInstanceCount=ft.meshPerAttribute*ft.count)}else for(let Nt=0;Nt<mt.locationSize;Nt++)x(mt.location+Nt);r.bindBuffer(r.ARRAY_BUFFER,gt);for(let Nt=0;Nt<mt.locationSize;Nt++)I(mt.location+Nt,V/mt.locationSize,Mt,O,V*rt,V/mt.locationSize*Nt*rt,vt)}}else if(P!==void 0){const O=P[it];if(O!==void 0)switch(O.length){case 2:r.vertexAttrib2fv(mt.location,O);break;case 3:r.vertexAttrib3fv(mt.location,O);break;case 4:r.vertexAttrib4fv(mt.location,O);break;default:r.vertexAttrib1fv(mt.location,O)}}}}D()}function Y(){w();for(const H in s){const $=s[H];for(const ct in $){const lt=$[ct];for(const W in lt){const L=lt[W];for(const P in L)m(L[P].object),delete L[P];delete lt[W]}}delete s[H]}}function F(H){if(s[H.id]===void 0)return;const $=s[H.id];for(const ct in $){const lt=$[ct];for(const W in lt){const L=lt[W];for(const P in L)m(L[P].object),delete L[P];delete lt[W]}}delete s[H.id]}function B(H){for(const $ in s){const ct=s[$];for(const lt in ct){const W=ct[lt];if(W[H.id]===void 0)continue;const L=W[H.id];for(const P in L)m(L[P].object),delete L[P];delete W[H.id]}}}function R(H){for(const $ in s){const ct=s[$],lt=H.isInstancedMesh===!0?H.id:0,W=ct[lt];if(W!==void 0){for(const L in W){const P=W[L];for(const it in P)m(P[it].object),delete P[it];delete W[L]}delete ct[lt],Object.keys(ct).length===0&&delete s[$]}}}function w(){Z(),f=!0,c!==l&&(c=l,h(c.object))}function Z(){l.geometry=null,l.program=null,l.wireframe=!1}return{setup:T,reset:w,resetDefaultState:Z,dispose:Y,releaseStatesOfGeometry:F,releaseStatesOfObject:R,releaseStatesOfProgram:B,initAttributes:M,enableAttribute:x,disableUnusedAttributes:D}}function bx(r,t,i){let s;function l(p){s=p}function c(p,h){r.drawArrays(s,p,h),i.update(h,s,1)}function f(p,h,m){m!==0&&(r.drawArraysInstanced(s,p,h,m),i.update(h,s,m))}function T(p,h,m){if(m===0)return;t.get("WEBGL_multi_draw").multiDrawArraysWEBGL(s,p,0,h,0,m);let S=0;for(let g=0;g<m;g++)S+=h[g];i.update(S,s,1)}this.setMode=l,this.render=c,this.renderInstances=f,this.renderMultiDraw=T}function Ix(r,t,i,s){let l;function c(){if(l!==void 0)return l;if(t.has("EXT_texture_filter_anisotropic")===!0){const B=t.get("EXT_texture_filter_anisotropic");l=r.getParameter(B.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else l=0;return l}function f(B){return!(B!==Fi&&s.convert(B)!==r.getParameter(r.IMPLEMENTATION_COLOR_READ_FORMAT))}function T(B){const R=B===ba&&(t.has("EXT_color_buffer_half_float")||t.has("EXT_color_buffer_float"));return!(B!==di&&s.convert(B)!==r.getParameter(r.IMPLEMENTATION_COLOR_READ_TYPE)&&B!==qi&&!R)}function p(B){if(B==="highp"){if(r.getShaderPrecisionFormat(r.VERTEX_SHADER,r.HIGH_FLOAT).precision>0&&r.getShaderPrecisionFormat(r.FRAGMENT_SHADER,r.HIGH_FLOAT).precision>0)return"highp";B="mediump"}return B==="mediump"&&r.getShaderPrecisionFormat(r.VERTEX_SHADER,r.MEDIUM_FLOAT).precision>0&&r.getShaderPrecisionFormat(r.FRAGMENT_SHADER,r.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let h=i.precision!==void 0?i.precision:"highp";const m=p(h);m!==h&&(ee("WebGLRenderer:",h,"not supported, using",m,"instead."),h=m);const E=i.logarithmicDepthBuffer===!0,S=i.reversedDepthBuffer===!0&&t.has("EXT_clip_control");i.reversedDepthBuffer===!0&&S===!1&&ee("WebGLRenderer: Unable to use reversed depth buffer due to missing EXT_clip_control extension. Fallback to default depth buffer.");const g=r.getParameter(r.MAX_TEXTURE_IMAGE_UNITS),A=r.getParameter(r.MAX_VERTEX_TEXTURE_IMAGE_UNITS),M=r.getParameter(r.MAX_TEXTURE_SIZE),x=r.getParameter(r.MAX_CUBE_MAP_TEXTURE_SIZE),v=r.getParameter(r.MAX_VERTEX_ATTRIBS),D=r.getParameter(r.MAX_VERTEX_UNIFORM_VECTORS),I=r.getParameter(r.MAX_VARYING_VECTORS),U=r.getParameter(r.MAX_FRAGMENT_UNIFORM_VECTORS),Y=r.getParameter(r.MAX_SAMPLES),F=r.getParameter(r.SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:c,getMaxPrecision:p,textureFormatReadable:f,textureTypeReadable:T,precision:h,logarithmicDepthBuffer:E,reversedDepthBuffer:S,maxTextures:g,maxVertexTextures:A,maxTextureSize:M,maxCubemapSize:x,maxAttributes:v,maxVertexUniforms:D,maxVaryings:I,maxFragmentUniforms:U,maxSamples:Y,samples:F}}function Lx(r){const t=this;let i=null,s=0,l=!1,c=!1;const f=new zs,T=new se,p={value:null,needsUpdate:!1};this.uniform=p,this.numPlanes=0,this.numIntersection=0,this.init=function(E,S){const g=E.length!==0||S||s!==0||l;return l=S,s=E.length,g},this.beginShadows=function(){c=!0,m(null)},this.endShadows=function(){c=!1},this.setGlobalState=function(E,S){i=m(E,S,0)},this.setState=function(E,S,g){const A=E.clippingPlanes,M=E.clipIntersection,x=E.clipShadows,v=r.get(E);if(!l||A===null||A.length===0||c&&!x)c?m(null):h();else{const D=c?0:s,I=D*4;let U=v.clippingState||null;p.value=U,U=m(A,S,I,g);for(let Y=0;Y!==I;++Y)U[Y]=i[Y];v.clippingState=U,this.numIntersection=M?this.numPlanes:0,this.numPlanes+=D}};function h(){p.value!==i&&(p.value=i,p.needsUpdate=s>0),t.numPlanes=s,t.numIntersection=0}function m(E,S,g,A){const M=E!==null?E.length:0;let x=null;if(M!==0){if(x=p.value,A!==!0||x===null){const v=g+M*4,D=S.matrixWorldInverse;T.getNormalMatrix(D),(x===null||x.length<v)&&(x=new Float32Array(v));for(let I=0,U=g;I!==M;++I,U+=4)f.copy(E[I]).applyMatrix4(D,T),f.normal.toArray(x,U),x[U+3]=f.constant}p.value=x,p.needsUpdate=!0}return t.numPlanes=M,t.numIntersection=0,x}}const ms=4,Gm=[.125,.215,.35,.446,.526,.582],Ws=20,Ux=256,tl=new T0,zm=new _e;let Zh=null,qh=0,$h=0,Qh=!1;const Fx=new nt;class Vm{constructor(t){this._renderer=t,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._sizeLods=[],this._sigmas=[],this._lodMeshes=[],this._backgroundBox=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._blurMaterial=null,this._ggxMaterial=null}fromScene(t,i=0,s=.1,l=100,c={}){const{size:f=256,position:T=Fx}=c;Zh=this._renderer.getRenderTarget(),qh=this._renderer.getActiveCubeFace(),$h=this._renderer.getActiveMipmapLevel(),Qh=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(f);const p=this._allocateTargets();return p.depthBuffer=!0,this._sceneToCubeUV(t,s,l,p,T),i>0&&this._blur(p,0,0,i),this._applyPMREM(p),this._cleanup(p),p}fromEquirectangular(t,i=null){return this._fromTexture(t,i)}fromCubemap(t,i=null){return this._fromTexture(t,i)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=Km(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=km(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose(),this._backgroundBox!==null&&(this._backgroundBox.geometry.dispose(),this._backgroundBox.material.dispose())}_setSize(t){this._lodMax=Math.floor(Math.log2(t)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._ggxMaterial!==null&&this._ggxMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let t=0;t<this._lodMeshes.length;t++)this._lodMeshes[t].geometry.dispose()}_cleanup(t){this._renderer.setRenderTarget(Zh,qh,$h),this._renderer.xr.enabled=Qh,t.scissorTest=!1,Gr(t,0,0,t.width,t.height)}_fromTexture(t,i){t.mapping===Zs||t.mapping===Kr?this._setSize(t.image.length===0?16:t.image[0].width||t.image[0].image.width):this._setSize(t.image.width/4),Zh=this._renderer.getRenderTarget(),qh=this._renderer.getActiveCubeFace(),$h=this._renderer.getActiveMipmapLevel(),Qh=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;const s=i||this._allocateTargets();return this._textureToCubeUV(t,s),this._applyPMREM(s),this._cleanup(s),s}_allocateTargets(){const t=3*Math.max(this._cubeSize,112),i=4*this._cubeSize,s={magFilter:Nn,minFilter:Nn,generateMipmaps:!1,type:ba,format:Fi,colorSpace:eu,depthBuffer:!1},l=Wm(t,i,s);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==t||this._pingPongRenderTarget.height!==i){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=Wm(t,i,s);const{_lodMax:c}=this;({lodMeshes:this._lodMeshes,sizeLods:this._sizeLods,sigmas:this._sigmas}=wx(c)),this._blurMaterial=Xx(c,t,i),this._ggxMaterial=Bx(c,t,i)}return l}_compileMaterial(t){const i=new Bi(new na,t);this._renderer.compile(i,tl)}_sceneToCubeUV(t,i,s,l,c){const p=new Ni(90,1,i,s),h=[1,-1,1,1,1,1],m=[1,1,1,-1,-1,-1],E=this._renderer,S=E.autoClear,g=E.toneMapping;E.getClearColor(zm),E.toneMapping=Qi,E.autoClear=!1,E.state.buffers.depth.getReversed()&&(E.setRenderTarget(l),E.clearDepth(),E.setRenderTarget(null)),this._backgroundBox===null&&(this._backgroundBox=new Bi(new Qr,new VE({name:"PMREM.Background",side:ti,depthWrite:!1,depthTest:!1})));const M=this._backgroundBox,x=M.material;let v=!1;const D=t.background;D?D.isColor&&(x.color.copy(D),t.background=null,v=!0):(x.color.copy(zm),v=!0);for(let I=0;I<6;I++){const U=I%3;U===0?(p.up.set(0,h[I],0),p.position.set(c.x,c.y,c.z),p.lookAt(c.x+m[I],c.y,c.z)):U===1?(p.up.set(0,0,h[I]),p.position.set(c.x,c.y,c.z),p.lookAt(c.x,c.y+m[I],c.z)):(p.up.set(0,h[I],0),p.position.set(c.x,c.y,c.z),p.lookAt(c.x,c.y,c.z+m[I]));const Y=this._cubeSize;Gr(l,U*Y,I>2?Y:0,Y,Y),E.setRenderTarget(l),v&&E.render(M,p),E.render(t,p)}E.toneMapping=g,E.autoClear=S,t.background=D}_textureToCubeUV(t,i){const s=this._renderer,l=t.mapping===Zs||t.mapping===Kr;l?(this._cubemapMaterial===null&&(this._cubemapMaterial=Km()),this._cubemapMaterial.uniforms.flipEnvMap.value=t.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=km());const c=l?this._cubemapMaterial:this._equirectMaterial,f=this._lodMeshes[0];f.material=c;const T=c.uniforms;T.envMap.value=t;const p=this._cubeSize;Gr(i,0,0,3*p,2*p),s.setRenderTarget(i),s.render(f,tl)}_applyPMREM(t){const i=this._renderer,s=i.autoClear;i.autoClear=!1;const l=this._lodMeshes.length;for(let c=1;c<l;c++)this._applyGGXFilter(t,c-1,c);i.autoClear=s}_applyGGXFilter(t,i,s){const l=this._renderer,c=this._pingPongRenderTarget,f=this._ggxMaterial,T=this._lodMeshes[s];T.material=f;const p=f.uniforms,h=s/(this._lodMeshes.length-1),m=i/(this._lodMeshes.length-1),E=Math.sqrt(h*h-m*m),S=0+h*1.25,g=E*S,{_lodMax:A}=this,M=this._sizeLods[s],x=3*M*(s>A-ms?s-A+ms:0),v=4*(this._cubeSize-M);p.envMap.value=t.texture,p.roughness.value=g,p.mipInt.value=A-i,Gr(c,x,v,3*M,2*M),l.setRenderTarget(c),l.render(T,tl),p.envMap.value=c.texture,p.roughness.value=0,p.mipInt.value=A-s,Gr(t,x,v,3*M,2*M),l.setRenderTarget(t),l.render(T,tl)}_blur(t,i,s,l,c){const f=this._pingPongRenderTarget;this._halfBlur(t,f,i,s,l,"latitudinal",c),this._halfBlur(f,t,s,s,l,"longitudinal",c)}_halfBlur(t,i,s,l,c,f,T){const p=this._renderer,h=this._blurMaterial;f!=="latitudinal"&&f!=="longitudinal"&&Ne("blur direction must be either latitudinal or longitudinal!");const m=3,E=this._lodMeshes[l];E.material=h;const S=h.uniforms,g=this._sizeLods[s]-1,A=isFinite(c)?Math.PI/(2*g):2*Math.PI/(2*Ws-1),M=c/A,x=isFinite(c)?1+Math.floor(m*M):Ws;x>Ws&&ee(`sigmaRadians, ${c}, is too large and will clip, as it requested ${x} samples when the maximum is set to ${Ws}`);const v=[];let D=0;for(let B=0;B<Ws;++B){const R=B/M,w=Math.exp(-R*R/2);v.push(w),B===0?D+=w:B<x&&(D+=2*w)}for(let B=0;B<v.length;B++)v[B]=v[B]/D;S.envMap.value=t.texture,S.samples.value=x,S.weights.value=v,S.latitudinal.value=f==="latitudinal",T&&(S.poleAxis.value=T);const{_lodMax:I}=this;S.dTheta.value=A,S.mipInt.value=I-s;const U=this._sizeLods[l],Y=3*U*(l>I-ms?l-I+ms:0),F=4*(this._cubeSize-U);Gr(i,Y,F,3*U,2*U),p.setRenderTarget(i),p.render(E,tl)}}function wx(r){const t=[],i=[],s=[];let l=r;const c=r-ms+1+Gm.length;for(let f=0;f<c;f++){const T=Math.pow(2,l);t.push(T);let p=1/T;f>r-ms?p=Gm[f-r+ms-1]:f===0&&(p=0),i.push(p);const h=1/(T-2),m=-h,E=1+h,S=[m,m,E,m,E,E,m,m,E,E,m,E],g=6,A=6,M=3,x=2,v=1,D=new Float32Array(M*A*g),I=new Float32Array(x*A*g),U=new Float32Array(v*A*g);for(let F=0;F<g;F++){const B=F%3*2/3-1,R=F>2?0:-1,w=[B,R,0,B+2/3,R,0,B+2/3,R+1,0,B,R,0,B+2/3,R+1,0,B,R+1,0];D.set(w,M*A*F),I.set(S,x*A*F);const Z=[F,F,F,F,F,F];U.set(Z,v*A*F)}const Y=new na;Y.setAttribute("position",new Ji(D,M)),Y.setAttribute("uv",new Ji(I,x)),Y.setAttribute("faceIndex",new Ji(U,v)),s.push(new Bi(Y,null)),l>ms&&l--}return{lodMeshes:s,sizeLods:t,sigmas:i}}function Wm(r,t,i){const s=new ji(r,t,i);return s.texture.mapping=ru,s.texture.name="PMREM.cubeUv",s.scissorTest=!0,s}function Gr(r,t,i,s,l){r.viewport.set(t,i,s,l),r.scissor.set(t,i,s,l)}function Bx(r,t,i){return new ea({name:"PMREMGGXConvolution",defines:{GGX_SAMPLES:Ux,CUBEUV_TEXEL_WIDTH:1/t,CUBEUV_TEXEL_HEIGHT:1/i,CUBEUV_MAX_MIP:`${r}.0`},uniforms:{envMap:{value:null},roughness:{value:0},mipInt:{value:0}},vertexShader:lu(),fragmentShader:`

			precision highp float;
			precision highp int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform float roughness;
			uniform float mipInt;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			#define PI 3.14159265359

			// Van der Corput radical inverse
			float radicalInverse_VdC(uint bits) {
				bits = (bits << 16u) | (bits >> 16u);
				bits = ((bits & 0x55555555u) << 1u) | ((bits & 0xAAAAAAAAu) >> 1u);
				bits = ((bits & 0x33333333u) << 2u) | ((bits & 0xCCCCCCCCu) >> 2u);
				bits = ((bits & 0x0F0F0F0Fu) << 4u) | ((bits & 0xF0F0F0F0u) >> 4u);
				bits = ((bits & 0x00FF00FFu) << 8u) | ((bits & 0xFF00FF00u) >> 8u);
				return float(bits) * 2.3283064365386963e-10; // / 0x100000000
			}

			// Hammersley sequence
			vec2 hammersley(uint i, uint N) {
				return vec2(float(i) / float(N), radicalInverse_VdC(i));
			}

			// GGX VNDF importance sampling (Eric Heitz 2018)
			// "Sampling the GGX Distribution of Visible Normals"
			// https://jcgt.org/published/0007/04/01/
			vec3 importanceSampleGGX_VNDF(vec2 Xi, vec3 V, float roughness) {
				float alpha = roughness * roughness;

				// Section 4.1: Orthonormal basis
				vec3 T1 = vec3(1.0, 0.0, 0.0);
				vec3 T2 = cross(V, T1);

				// Section 4.2: Parameterization of projected area
				float r = sqrt(Xi.x);
				float phi = 2.0 * PI * Xi.y;
				float t1 = r * cos(phi);
				float t2 = r * sin(phi);
				float s = 0.5 * (1.0 + V.z);
				t2 = (1.0 - s) * sqrt(1.0 - t1 * t1) + s * t2;

				// Section 4.3: Reprojection onto hemisphere
				vec3 Nh = t1 * T1 + t2 * T2 + sqrt(max(0.0, 1.0 - t1 * t1 - t2 * t2)) * V;

				// Section 3.4: Transform back to ellipsoid configuration
				return normalize(vec3(alpha * Nh.x, alpha * Nh.y, max(0.0, Nh.z)));
			}

			void main() {
				vec3 N = normalize(vOutputDirection);
				vec3 V = N; // Assume view direction equals normal for pre-filtering

				vec3 prefilteredColor = vec3(0.0);
				float totalWeight = 0.0;

				// For very low roughness, just sample the environment directly
				if (roughness < 0.001) {
					gl_FragColor = vec4(bilinearCubeUV(envMap, N, mipInt), 1.0);
					return;
				}

				// Tangent space basis for VNDF sampling
				vec3 up = abs(N.z) < 0.999 ? vec3(0.0, 0.0, 1.0) : vec3(1.0, 0.0, 0.0);
				vec3 tangent = normalize(cross(up, N));
				vec3 bitangent = cross(N, tangent);

				for(uint i = 0u; i < uint(GGX_SAMPLES); i++) {
					vec2 Xi = hammersley(i, uint(GGX_SAMPLES));

					// For PMREM, V = N, so in tangent space V is always (0, 0, 1)
					vec3 H_tangent = importanceSampleGGX_VNDF(Xi, vec3(0.0, 0.0, 1.0), roughness);

					// Transform H back to world space
					vec3 H = normalize(tangent * H_tangent.x + bitangent * H_tangent.y + N * H_tangent.z);
					vec3 L = normalize(2.0 * dot(V, H) * H - V);

					float NdotL = max(dot(N, L), 0.0);

					if(NdotL > 0.0) {
						// Sample environment at fixed mip level
						// VNDF importance sampling handles the distribution filtering
						vec3 sampleColor = bilinearCubeUV(envMap, L, mipInt);

						// Weight by NdotL for the split-sum approximation
						// VNDF PDF naturally accounts for the visible microfacet distribution
						prefilteredColor += sampleColor * NdotL;
						totalWeight += NdotL;
					}
				}

				if (totalWeight > 0.0) {
					prefilteredColor = prefilteredColor / totalWeight;
				}

				gl_FragColor = vec4(prefilteredColor, 1.0);
			}
		`,blending:Da,depthTest:!1,depthWrite:!1})}function Xx(r,t,i){const s=new Float32Array(Ws),l=new nt(0,1,0);return new ea({name:"SphericalGaussianBlur",defines:{n:Ws,CUBEUV_TEXEL_WIDTH:1/t,CUBEUV_TEXEL_HEIGHT:1/i,CUBEUV_MAX_MIP:`${r}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:s},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:l}},vertexShader:lu(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:Da,depthTest:!1,depthWrite:!1})}function km(){return new ea({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:lu(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:Da,depthTest:!1,depthWrite:!1})}function Km(){return new ea({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:lu(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:Da,depthTest:!1,depthWrite:!1})}function lu(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}class jE extends ji{constructor(t=1,i={}){super(t,t,i),this.isWebGLCubeRenderTarget=!0;const s={width:t,height:t,depth:1},l=[s,s,s,s,s,s];this.texture=new WE(l),this._setTextureOptions(i),this.texture.isRenderTargetTexture=!0}fromEquirectangularTexture(t,i){this.texture.type=i.type,this.texture.colorSpace=i.colorSpace,this.texture.generateMipmaps=i.generateMipmaps,this.texture.minFilter=i.minFilter,this.texture.magFilter=i.magFilter;const s={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},l=new Qr(5,5,5),c=new ea({name:"CubemapFromEquirect",uniforms:qr(s.uniforms),vertexShader:s.vertexShader,fragmentShader:s.fragmentShader,side:ti,blending:Da});c.uniforms.tEquirect.value=i;const f=new Bi(l,c),T=i.minFilter;return i.minFilter===ks&&(i.minFilter=Nn),new V2(1,10,this).update(t,f),i.minFilter=T,f.geometry.dispose(),f.material.dispose(),this}clear(t,i=!0,s=!0,l=!0){const c=t.getRenderTarget();for(let f=0;f<6;f++)t.setRenderTarget(this,f),t.clear(i,s,l);t.setRenderTarget(c)}}function Px(r){let t=new WeakMap,i=new WeakMap,s=null;function l(S,g=!1){return S==null?null:g?f(S):c(S)}function c(S){if(S&&S.isTexture){const g=S.mapping;if(g===_h||g===vh)if(t.has(S)){const A=t.get(S).texture;return T(A,S.mapping)}else{const A=S.image;if(A&&A.height>0){const M=new jE(A.height);return M.fromEquirectangularTexture(r,S),t.set(S,M),S.addEventListener("dispose",h),T(M.texture,S.mapping)}else return null}}return S}function f(S){if(S&&S.isTexture){const g=S.mapping,A=g===_h||g===vh,M=g===Zs||g===Kr;if(A||M){let x=i.get(S);const v=x!==void 0?x.texture.pmremVersion:0;if(S.isRenderTargetTexture&&S.pmremVersion!==v)return s===null&&(s=new Vm(r)),x=A?s.fromEquirectangular(S,x):s.fromCubemap(S,x),x.texture.pmremVersion=S.pmremVersion,i.set(S,x),x.texture;if(x!==void 0)return x.texture;{const D=S.image;return A&&D&&D.height>0||M&&D&&p(D)?(s===null&&(s=new Vm(r)),x=A?s.fromEquirectangular(S):s.fromCubemap(S),x.texture.pmremVersion=S.pmremVersion,i.set(S,x),S.addEventListener("dispose",m),x.texture):null}}}return S}function T(S,g){return g===_h?S.mapping=Zs:g===vh&&(S.mapping=Kr),S}function p(S){let g=0;const A=6;for(let M=0;M<A;M++)S[M]!==void 0&&g++;return g===A}function h(S){const g=S.target;g.removeEventListener("dispose",h);const A=t.get(g);A!==void 0&&(t.delete(g),A.dispose())}function m(S){const g=S.target;g.removeEventListener("dispose",m);const A=i.get(g);A!==void 0&&(i.delete(g),A.dispose())}function E(){t=new WeakMap,i=new WeakMap,s!==null&&(s.dispose(),s=null)}return{get:l,dispose:E}}function Hx(r){const t={};function i(s){if(t[s]!==void 0)return t[s];const l=r.getExtension(s);return t[s]=l,l}return{has:function(s){return i(s)!==null},init:function(){i("EXT_color_buffer_float"),i("WEBGL_clip_cull_distance"),i("OES_texture_float_linear"),i("EXT_color_buffer_half_float"),i("WEBGL_multisampled_render_to_texture"),i("WEBGL_render_shared_exponent")},get:function(s){const l=i(s);return l===null&&Kd("WebGLRenderer: "+s+" extension not supported."),l}}}function Yx(r,t,i,s){const l={},c=new WeakMap;function f(E){const S=E.target;S.index!==null&&t.remove(S.index);for(const A in S.attributes)t.remove(S.attributes[A]);S.removeEventListener("dispose",f),delete l[S.id];const g=c.get(S);g&&(t.remove(g),c.delete(S)),s.releaseStatesOfGeometry(S),S.isInstancedBufferGeometry===!0&&delete S._maxInstanceCount,i.memory.geometries--}function T(E,S){return l[S.id]===!0||(S.addEventListener("dispose",f),l[S.id]=!0,i.memory.geometries++),S}function p(E){const S=E.attributes;for(const g in S)t.update(S[g],r.ARRAY_BUFFER)}function h(E){const S=[],g=E.index,A=E.attributes.position;let M=0;if(A===void 0)return;if(g!==null){const D=g.array;M=g.version;for(let I=0,U=D.length;I<U;I+=3){const Y=D[I+0],F=D[I+1],B=D[I+2];S.push(Y,F,F,B,B,Y)}}else{const D=A.array;M=A.version;for(let I=0,U=D.length/3-1;I<U;I+=3){const Y=I+0,F=I+1,B=I+2;S.push(Y,F,F,B,B,Y)}}const x=new(A.count>=65535?zE:GE)(S,1);x.version=M;const v=c.get(E);v&&t.remove(v),c.set(E,x)}function m(E){const S=c.get(E);if(S){const g=E.index;g!==null&&S.version<g.version&&h(E)}else h(E);return c.get(E)}return{get:T,update:p,getWireframeAttribute:m}}function Gx(r,t,i){let s;function l(E){s=E}let c,f;function T(E){c=E.type,f=E.bytesPerElement}function p(E,S){r.drawElements(s,S,c,E*f),i.update(S,s,1)}function h(E,S,g){g!==0&&(r.drawElementsInstanced(s,S,c,E*f,g),i.update(S,s,g))}function m(E,S,g){if(g===0)return;t.get("WEBGL_multi_draw").multiDrawElementsWEBGL(s,S,0,c,E,0,g);let M=0;for(let x=0;x<g;x++)M+=S[x];i.update(M,s,1)}this.setMode=l,this.setIndex=T,this.render=p,this.renderInstances=h,this.renderMultiDraw=m}function zx(r){const t={geometries:0,textures:0},i={frame:0,calls:0,triangles:0,points:0,lines:0};function s(c,f,T){switch(i.calls++,f){case r.TRIANGLES:i.triangles+=T*(c/3);break;case r.LINES:i.lines+=T*(c/2);break;case r.LINE_STRIP:i.lines+=T*(c-1);break;case r.LINE_LOOP:i.lines+=T*c;break;case r.POINTS:i.points+=T*c;break;default:Ne("WebGLInfo: Unknown draw mode:",f);break}}function l(){i.calls=0,i.triangles=0,i.points=0,i.lines=0}return{memory:t,render:i,programs:null,autoReset:!0,reset:l,update:s}}function Vx(r,t,i){const s=new WeakMap,l=new an;function c(f,T,p){const h=f.morphTargetInfluences,m=T.morphAttributes.position||T.morphAttributes.normal||T.morphAttributes.color,E=m!==void 0?m.length:0;let S=s.get(T);if(S===void 0||S.count!==E){let w=function(){B.dispose(),s.delete(T),T.removeEventListener("dispose",w)};S!==void 0&&S.texture.dispose();const g=T.morphAttributes.position!==void 0,A=T.morphAttributes.normal!==void 0,M=T.morphAttributes.color!==void 0,x=T.morphAttributes.position||[],v=T.morphAttributes.normal||[],D=T.morphAttributes.color||[];let I=0;g===!0&&(I=1),A===!0&&(I=2),M===!0&&(I=3);let U=T.attributes.position.count*I,Y=1;U>t.maxTextureSize&&(Y=Math.ceil(U/t.maxTextureSize),U=t.maxTextureSize);const F=new Float32Array(U*Y*4*E),B=new PE(F,U,Y,E);B.type=qi,B.needsUpdate=!0;const R=I*4;for(let Z=0;Z<E;Z++){const H=x[Z],$=v[Z],ct=D[Z],lt=U*Y*4*Z;for(let W=0;W<H.count;W++){const L=W*R;g===!0&&(l.fromBufferAttribute(H,W),F[lt+L+0]=l.x,F[lt+L+1]=l.y,F[lt+L+2]=l.z,F[lt+L+3]=0),A===!0&&(l.fromBufferAttribute($,W),F[lt+L+4]=l.x,F[lt+L+5]=l.y,F[lt+L+6]=l.z,F[lt+L+7]=0),M===!0&&(l.fromBufferAttribute(ct,W),F[lt+L+8]=l.x,F[lt+L+9]=l.y,F[lt+L+10]=l.z,F[lt+L+11]=ct.itemSize===4?l.w:1)}}S={count:E,texture:B,size:new Oe(U,Y)},s.set(T,S),T.addEventListener("dispose",w)}if(f.isInstancedMesh===!0&&f.morphTexture!==null)p.getUniforms().setValue(r,"morphTexture",f.morphTexture,i);else{let g=0;for(let M=0;M<h.length;M++)g+=h[M];const A=T.morphTargetsRelative?1:1-g;p.getUniforms().setValue(r,"morphTargetBaseInfluence",A),p.getUniforms().setValue(r,"morphTargetInfluences",h)}p.getUniforms().setValue(r,"morphTargetsTexture",S.texture,i),p.getUniforms().setValue(r,"morphTargetsTextureSize",S.size)}return{update:c}}function Wx(r,t,i,s,l){let c=new WeakMap;function f(h){const m=l.render.frame,E=h.geometry,S=t.get(h,E);if(c.get(S)!==m&&(t.update(S),c.set(S,m)),h.isInstancedMesh&&(h.hasEventListener("dispose",p)===!1&&h.addEventListener("dispose",p),c.get(h)!==m&&(i.update(h.instanceMatrix,r.ARRAY_BUFFER),h.instanceColor!==null&&i.update(h.instanceColor,r.ARRAY_BUFFER),c.set(h,m))),h.isSkinnedMesh){const g=h.skeleton;c.get(g)!==m&&(g.update(),c.set(g,m))}return S}function T(){c=new WeakMap}function p(h){const m=h.target;m.removeEventListener("dispose",p),s.releaseStatesOfObject(m),i.remove(m.instanceMatrix),m.instanceColor!==null&&i.remove(m.instanceColor)}return{update:f,dispose:T}}const kx={[xE]:"LINEAR_TONE_MAPPING",[NE]:"REINHARD_TONE_MAPPING",[ME]:"CINEON_TONE_MAPPING",[RE]:"ACES_FILMIC_TONE_MAPPING",[yE]:"AGX_TONE_MAPPING",[DE]:"NEUTRAL_TONE_MAPPING",[CE]:"CUSTOM_TONE_MAPPING"};function Kx(r,t,i,s,l){const c=new ji(t,i,{type:r,depthBuffer:s,stencilBuffer:l,depthTexture:s?new Zr(t,i):void 0}),f=new ji(t,i,{type:ba,depthBuffer:!1,stencilBuffer:!1}),T=new na;T.setAttribute("position",new wi([-1,3,0,-1,-1,0,3,-1,0],3)),T.setAttribute("uv",new wi([0,2,0,0,2,0],2));const p=new B2({uniforms:{tDiffuse:{value:null}},vertexShader:`
			precision highp float;

			uniform mat4 modelViewMatrix;
			uniform mat4 projectionMatrix;

			attribute vec3 position;
			attribute vec2 uv;

			varying vec2 vUv;

			void main() {
				vUv = uv;
				gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
			}`,fragmentShader:`
			precision highp float;

			uniform sampler2D tDiffuse;

			varying vec2 vUv;

			#include <tonemapping_pars_fragment>
			#include <colorspace_pars_fragment>

			void main() {
				gl_FragColor = texture2D( tDiffuse, vUv );

				#ifdef LINEAR_TONE_MAPPING
					gl_FragColor.rgb = LinearToneMapping( gl_FragColor.rgb );
				#elif defined( REINHARD_TONE_MAPPING )
					gl_FragColor.rgb = ReinhardToneMapping( gl_FragColor.rgb );
				#elif defined( CINEON_TONE_MAPPING )
					gl_FragColor.rgb = CineonToneMapping( gl_FragColor.rgb );
				#elif defined( ACES_FILMIC_TONE_MAPPING )
					gl_FragColor.rgb = ACESFilmicToneMapping( gl_FragColor.rgb );
				#elif defined( AGX_TONE_MAPPING )
					gl_FragColor.rgb = AgXToneMapping( gl_FragColor.rgb );
				#elif defined( NEUTRAL_TONE_MAPPING )
					gl_FragColor.rgb = NeutralToneMapping( gl_FragColor.rgb );
				#elif defined( CUSTOM_TONE_MAPPING )
					gl_FragColor.rgb = CustomToneMapping( gl_FragColor.rgb );
				#endif

				#ifdef SRGB_TRANSFER
					gl_FragColor = sRGBTransferOETF( gl_FragColor );
				#endif
			}`,depthTest:!1,depthWrite:!1}),h=new Bi(T,p),m=new T0(-1,1,1,-1,0,1);let E=null,S=null,g=!1,A,M=null,x=[],v=!1;this.setSize=function(D,I){c.setSize(D,I),f.setSize(D,I);for(let U=0;U<x.length;U++){const Y=x[U];Y.setSize&&Y.setSize(D,I)}},this.setEffects=function(D){x=D,v=x.length>0&&x[0].isRenderPass===!0;const I=c.width,U=c.height;for(let Y=0;Y<x.length;Y++){const F=x[Y];F.setSize&&F.setSize(I,U)}},this.begin=function(D,I){if(g||D.toneMapping===Qi&&x.length===0)return!1;if(M=I,I!==null){const U=I.width,Y=I.height;(c.width!==U||c.height!==Y)&&this.setSize(U,Y)}return v===!1&&D.setRenderTarget(c),A=D.toneMapping,D.toneMapping=Qi,!0},this.hasRenderPass=function(){return v},this.end=function(D,I){D.toneMapping=A,g=!0;let U=c,Y=f;for(let F=0;F<x.length;F++){const B=x[F];if(B.enabled!==!1&&(B.render(D,Y,U,I),B.needsSwap!==!1)){const R=U;U=Y,Y=R}}if(E!==D.outputColorSpace||S!==D.toneMapping){E=D.outputColorSpace,S=D.toneMapping,p.defines={},Ae.getTransfer(E)===Xe&&(p.defines.SRGB_TRANSFER="");const F=kx[S];F&&(p.defines[F]=""),p.needsUpdate=!0}p.uniforms.tDiffuse.value=U.texture,D.setRenderTarget(M),D.render(h,m),M=null,g=!1},this.isCompositing=function(){return g},this.dispose=function(){c.depthTexture&&c.depthTexture.dispose(),c.dispose(),f.dispose(),T.dispose(),p.dispose()}}const JE=new Pn,qd=new Zr(1,1),tS=new PE,eS=new h2,nS=new WE,Zm=[],qm=[],$m=new Float32Array(16),Qm=new Float32Array(9),jm=new Float32Array(4);function jr(r,t,i){const s=r[0];if(s<=0||s>0)return r;const l=t*i;let c=Zm[l];if(c===void 0&&(c=new Float32Array(l),Zm[l]=c),t!==0){s.toArray(c,0);for(let f=1,T=0;f!==t;++f)T+=i,r[f].toArray(c,T)}return c}function _n(r,t){if(r.length!==t.length)return!1;for(let i=0,s=r.length;i<s;i++)if(r[i]!==t[i])return!1;return!0}function vn(r,t){for(let i=0,s=t.length;i<s;i++)r[i]=t[i]}function cu(r,t){let i=qm[t];i===void 0&&(i=new Int32Array(t),qm[t]=i);for(let s=0;s!==t;++s)i[s]=r.allocateTextureUnit();return i}function Zx(r,t){const i=this.cache;i[0]!==t&&(r.uniform1f(this.addr,t),i[0]=t)}function qx(r,t){const i=this.cache;if(t.x!==void 0)(i[0]!==t.x||i[1]!==t.y)&&(r.uniform2f(this.addr,t.x,t.y),i[0]=t.x,i[1]=t.y);else{if(_n(i,t))return;r.uniform2fv(this.addr,t),vn(i,t)}}function $x(r,t){const i=this.cache;if(t.x!==void 0)(i[0]!==t.x||i[1]!==t.y||i[2]!==t.z)&&(r.uniform3f(this.addr,t.x,t.y,t.z),i[0]=t.x,i[1]=t.y,i[2]=t.z);else if(t.r!==void 0)(i[0]!==t.r||i[1]!==t.g||i[2]!==t.b)&&(r.uniform3f(this.addr,t.r,t.g,t.b),i[0]=t.r,i[1]=t.g,i[2]=t.b);else{if(_n(i,t))return;r.uniform3fv(this.addr,t),vn(i,t)}}function Qx(r,t){const i=this.cache;if(t.x!==void 0)(i[0]!==t.x||i[1]!==t.y||i[2]!==t.z||i[3]!==t.w)&&(r.uniform4f(this.addr,t.x,t.y,t.z,t.w),i[0]=t.x,i[1]=t.y,i[2]=t.z,i[3]=t.w);else{if(_n(i,t))return;r.uniform4fv(this.addr,t),vn(i,t)}}function jx(r,t){const i=this.cache,s=t.elements;if(s===void 0){if(_n(i,t))return;r.uniformMatrix2fv(this.addr,!1,t),vn(i,t)}else{if(_n(i,s))return;jm.set(s),r.uniformMatrix2fv(this.addr,!1,jm),vn(i,s)}}function Jx(r,t){const i=this.cache,s=t.elements;if(s===void 0){if(_n(i,t))return;r.uniformMatrix3fv(this.addr,!1,t),vn(i,t)}else{if(_n(i,s))return;Qm.set(s),r.uniformMatrix3fv(this.addr,!1,Qm),vn(i,s)}}function tN(r,t){const i=this.cache,s=t.elements;if(s===void 0){if(_n(i,t))return;r.uniformMatrix4fv(this.addr,!1,t),vn(i,t)}else{if(_n(i,s))return;$m.set(s),r.uniformMatrix4fv(this.addr,!1,$m),vn(i,s)}}function eN(r,t){const i=this.cache;i[0]!==t&&(r.uniform1i(this.addr,t),i[0]=t)}function nN(r,t){const i=this.cache;if(t.x!==void 0)(i[0]!==t.x||i[1]!==t.y)&&(r.uniform2i(this.addr,t.x,t.y),i[0]=t.x,i[1]=t.y);else{if(_n(i,t))return;r.uniform2iv(this.addr,t),vn(i,t)}}function iN(r,t){const i=this.cache;if(t.x!==void 0)(i[0]!==t.x||i[1]!==t.y||i[2]!==t.z)&&(r.uniform3i(this.addr,t.x,t.y,t.z),i[0]=t.x,i[1]=t.y,i[2]=t.z);else{if(_n(i,t))return;r.uniform3iv(this.addr,t),vn(i,t)}}function aN(r,t){const i=this.cache;if(t.x!==void 0)(i[0]!==t.x||i[1]!==t.y||i[2]!==t.z||i[3]!==t.w)&&(r.uniform4i(this.addr,t.x,t.y,t.z,t.w),i[0]=t.x,i[1]=t.y,i[2]=t.z,i[3]=t.w);else{if(_n(i,t))return;r.uniform4iv(this.addr,t),vn(i,t)}}function sN(r,t){const i=this.cache;i[0]!==t&&(r.uniform1ui(this.addr,t),i[0]=t)}function rN(r,t){const i=this.cache;if(t.x!==void 0)(i[0]!==t.x||i[1]!==t.y)&&(r.uniform2ui(this.addr,t.x,t.y),i[0]=t.x,i[1]=t.y);else{if(_n(i,t))return;r.uniform2uiv(this.addr,t),vn(i,t)}}function oN(r,t){const i=this.cache;if(t.x!==void 0)(i[0]!==t.x||i[1]!==t.y||i[2]!==t.z)&&(r.uniform3ui(this.addr,t.x,t.y,t.z),i[0]=t.x,i[1]=t.y,i[2]=t.z);else{if(_n(i,t))return;r.uniform3uiv(this.addr,t),vn(i,t)}}function lN(r,t){const i=this.cache;if(t.x!==void 0)(i[0]!==t.x||i[1]!==t.y||i[2]!==t.z||i[3]!==t.w)&&(r.uniform4ui(this.addr,t.x,t.y,t.z,t.w),i[0]=t.x,i[1]=t.y,i[2]=t.z,i[3]=t.w);else{if(_n(i,t))return;r.uniform4uiv(this.addr,t),vn(i,t)}}function cN(r,t,i){const s=this.cache,l=i.allocateTextureUnit();s[0]!==l&&(r.uniform1i(this.addr,l),s[0]=l);let c;this.type===r.SAMPLER_2D_SHADOW?(qd.compareFunction=i.isReversedDepthBuffer()?f0:u0,c=qd):c=JE,i.setTexture2D(t||c,l)}function uN(r,t,i){const s=this.cache,l=i.allocateTextureUnit();s[0]!==l&&(r.uniform1i(this.addr,l),s[0]=l),i.setTexture3D(t||eS,l)}function fN(r,t,i){const s=this.cache,l=i.allocateTextureUnit();s[0]!==l&&(r.uniform1i(this.addr,l),s[0]=l),i.setTextureCube(t||nS,l)}function hN(r,t,i){const s=this.cache,l=i.allocateTextureUnit();s[0]!==l&&(r.uniform1i(this.addr,l),s[0]=l),i.setTexture2DArray(t||tS,l)}function dN(r){switch(r){case 5126:return Zx;case 35664:return qx;case 35665:return $x;case 35666:return Qx;case 35674:return jx;case 35675:return Jx;case 35676:return tN;case 5124:case 35670:return eN;case 35667:case 35671:return nN;case 35668:case 35672:return iN;case 35669:case 35673:return aN;case 5125:return sN;case 36294:return rN;case 36295:return oN;case 36296:return lN;case 35678:case 36198:case 36298:case 36306:case 35682:return cN;case 35679:case 36299:case 36307:return uN;case 35680:case 36300:case 36308:case 36293:return fN;case 36289:case 36303:case 36311:case 36292:return hN}}function pN(r,t){r.uniform1fv(this.addr,t)}function TN(r,t){const i=jr(t,this.size,2);r.uniform2fv(this.addr,i)}function mN(r,t){const i=jr(t,this.size,3);r.uniform3fv(this.addr,i)}function EN(r,t){const i=jr(t,this.size,4);r.uniform4fv(this.addr,i)}function SN(r,t){const i=jr(t,this.size,4);r.uniformMatrix2fv(this.addr,!1,i)}function gN(r,t){const i=jr(t,this.size,9);r.uniformMatrix3fv(this.addr,!1,i)}function _N(r,t){const i=jr(t,this.size,16);r.uniformMatrix4fv(this.addr,!1,i)}function vN(r,t){r.uniform1iv(this.addr,t)}function AN(r,t){r.uniform2iv(this.addr,t)}function xN(r,t){r.uniform3iv(this.addr,t)}function NN(r,t){r.uniform4iv(this.addr,t)}function MN(r,t){r.uniform1uiv(this.addr,t)}function RN(r,t){r.uniform2uiv(this.addr,t)}function CN(r,t){r.uniform3uiv(this.addr,t)}function yN(r,t){r.uniform4uiv(this.addr,t)}function DN(r,t,i){const s=this.cache,l=t.length,c=cu(i,l);_n(s,c)||(r.uniform1iv(this.addr,c),vn(s,c));let f;this.type===r.SAMPLER_2D_SHADOW?f=qd:f=JE;for(let T=0;T!==l;++T)i.setTexture2D(t[T]||f,c[T])}function ON(r,t,i){const s=this.cache,l=t.length,c=cu(i,l);_n(s,c)||(r.uniform1iv(this.addr,c),vn(s,c));for(let f=0;f!==l;++f)i.setTexture3D(t[f]||eS,c[f])}function bN(r,t,i){const s=this.cache,l=t.length,c=cu(i,l);_n(s,c)||(r.uniform1iv(this.addr,c),vn(s,c));for(let f=0;f!==l;++f)i.setTextureCube(t[f]||nS,c[f])}function IN(r,t,i){const s=this.cache,l=t.length,c=cu(i,l);_n(s,c)||(r.uniform1iv(this.addr,c),vn(s,c));for(let f=0;f!==l;++f)i.setTexture2DArray(t[f]||tS,c[f])}function LN(r){switch(r){case 5126:return pN;case 35664:return TN;case 35665:return mN;case 35666:return EN;case 35674:return SN;case 35675:return gN;case 35676:return _N;case 5124:case 35670:return vN;case 35667:case 35671:return AN;case 35668:case 35672:return xN;case 35669:case 35673:return NN;case 5125:return MN;case 36294:return RN;case 36295:return CN;case 36296:return yN;case 35678:case 36198:case 36298:case 36306:case 35682:return DN;case 35679:case 36299:case 36307:return ON;case 35680:case 36300:case 36308:case 36293:return bN;case 36289:case 36303:case 36311:case 36292:return IN}}class UN{constructor(t,i,s){this.id=t,this.addr=s,this.cache=[],this.type=i.type,this.setValue=dN(i.type)}}class FN{constructor(t,i,s){this.id=t,this.addr=s,this.cache=[],this.type=i.type,this.size=i.size,this.setValue=LN(i.type)}}class wN{constructor(t){this.id=t,this.seq=[],this.map={}}setValue(t,i,s){const l=this.seq;for(let c=0,f=l.length;c!==f;++c){const T=l[c];T.setValue(t,i[T.id],s)}}}const jh=/(\w+)(\])?(\[|\.)?/g;function Jm(r,t){r.seq.push(t),r.map[t.id]=t}function BN(r,t,i){const s=r.name,l=s.length;for(jh.lastIndex=0;;){const c=jh.exec(s),f=jh.lastIndex;let T=c[1];const p=c[2]==="]",h=c[3];if(p&&(T=T|0),h===void 0||h==="["&&f+2===l){Jm(i,h===void 0?new UN(T,r,t):new FN(T,r,t));break}else{let E=i.map[T];E===void 0&&(E=new wN(T),Jm(i,E)),i=E}}}class Qc{constructor(t,i){this.seq=[],this.map={};const s=t.getProgramParameter(i,t.ACTIVE_UNIFORMS);for(let f=0;f<s;++f){const T=t.getActiveUniform(i,f),p=t.getUniformLocation(i,T.name);BN(T,p,this)}const l=[],c=[];for(const f of this.seq)f.type===t.SAMPLER_2D_SHADOW||f.type===t.SAMPLER_CUBE_SHADOW||f.type===t.SAMPLER_2D_ARRAY_SHADOW?l.push(f):c.push(f);l.length>0&&(this.seq=l.concat(c))}setValue(t,i,s,l){const c=this.map[i];c!==void 0&&c.setValue(t,s,l)}setOptional(t,i,s){const l=i[s];l!==void 0&&this.setValue(t,s,l)}static upload(t,i,s,l){for(let c=0,f=i.length;c!==f;++c){const T=i[c],p=s[T.id];p.needsUpdate!==!1&&T.setValue(t,p.value,l)}}static seqWithValue(t,i){const s=[];for(let l=0,c=t.length;l!==c;++l){const f=t[l];f.id in i&&s.push(f)}return s}}function tE(r,t,i){const s=r.createShader(t);return r.shaderSource(s,i),r.compileShader(s),s}const XN=37297;let PN=0;function HN(r,t){const i=r.split(`
`),s=[],l=Math.max(t-6,0),c=Math.min(t+6,i.length);for(let f=l;f<c;f++){const T=f+1;s.push(`${T===t?">":" "} ${T}: ${i[f]}`)}return s.join(`
`)}const eE=new se;function YN(r){Ae._getMatrix(eE,Ae.workingColorSpace,r);const t=`mat3( ${eE.elements.map(i=>i.toFixed(4))} )`;switch(Ae.getTransfer(r)){case nu:return[t,"LinearTransferOETF"];case Xe:return[t,"sRGBTransferOETF"];default:return ee("WebGLProgram: Unsupported color space: ",r),[t,"LinearTransferOETF"]}}function nE(r,t,i){const s=r.getShaderParameter(t,r.COMPILE_STATUS),c=(r.getShaderInfoLog(t)||"").trim();if(s&&c==="")return"";const f=/ERROR: 0:(\d+)/.exec(c);if(f){const T=parseInt(f[1]);return i.toUpperCase()+`

`+c+`

`+HN(r.getShaderSource(t),T)}else return c}function GN(r,t){const i=YN(t);return[`vec4 ${r}( vec4 value ) {`,`	return ${i[1]}( vec4( value.rgb * ${i[0]}, value.a ) );`,"}"].join(`
`)}const zN={[xE]:"Linear",[NE]:"Reinhard",[ME]:"Cineon",[RE]:"ACESFilmic",[yE]:"AgX",[DE]:"Neutral",[CE]:"Custom"};function VN(r,t){const i=zN[t];return i===void 0?(ee("WebGLProgram: Unsupported toneMapping:",t),"vec3 "+r+"( vec3 color ) { return LinearToneMapping( color ); }"):"vec3 "+r+"( vec3 color ) { return "+i+"ToneMapping( color ); }"}const zc=new nt;function WN(){Ae.getLuminanceCoefficients(zc);const r=zc.x.toFixed(4),t=zc.y.toFixed(4),i=zc.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${r}, ${t}, ${i} );`,"	return dot( weights, rgb );","}"].join(`
`)}function kN(r){return[r.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",r.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(sl).join(`
`)}function KN(r){const t=[];for(const i in r){const s=r[i];s!==!1&&t.push("#define "+i+" "+s)}return t.join(`
`)}function ZN(r,t){const i={},s=r.getProgramParameter(t,r.ACTIVE_ATTRIBUTES);for(let l=0;l<s;l++){const c=r.getActiveAttrib(t,l),f=c.name;let T=1;c.type===r.FLOAT_MAT2&&(T=2),c.type===r.FLOAT_MAT3&&(T=3),c.type===r.FLOAT_MAT4&&(T=4),i[f]={type:c.type,location:r.getAttribLocation(t,f),locationSize:T}}return i}function sl(r){return r!==""}function iE(r,t){const i=t.numSpotLightShadows+t.numSpotLightMaps-t.numSpotLightShadowsWithMaps;return r.replace(/NUM_DIR_LIGHTS/g,t.numDirLights).replace(/NUM_SPOT_LIGHTS/g,t.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,t.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,i).replace(/NUM_RECT_AREA_LIGHTS/g,t.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,t.numPointLights).replace(/NUM_HEMI_LIGHTS/g,t.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,t.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,t.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,t.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,t.numPointLightShadows)}function aE(r,t){return r.replace(/NUM_CLIPPING_PLANES/g,t.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,t.numClippingPlanes-t.numClipIntersection)}const qN=/^[ \t]*#include +<([\w\d./]+)>/gm;function $d(r){return r.replace(qN,QN)}const $N=new Map;function QN(r,t){let i=ue[t];if(i===void 0){const s=$N.get(t);if(s!==void 0)i=ue[s],ee('WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',t,s);else throw new Error("Can not resolve #include <"+t+">")}return $d(i)}const jN=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function sE(r){return r.replace(jN,JN)}function JN(r,t,i,s){let l="";for(let c=parseInt(t);c<parseInt(i);c++)l+=s.replace(/\[\s*i\s*\]/g,"[ "+c+" ]").replace(/UNROLLED_LOOP_INDEX/g,c);return l}function rE(r){let t=`precision ${r.precision} float;
	precision ${r.precision} int;
	precision ${r.precision} sampler2D;
	precision ${r.precision} samplerCube;
	precision ${r.precision} sampler3D;
	precision ${r.precision} sampler2DArray;
	precision ${r.precision} sampler2DShadow;
	precision ${r.precision} samplerCubeShadow;
	precision ${r.precision} sampler2DArrayShadow;
	precision ${r.precision} isampler2D;
	precision ${r.precision} isampler3D;
	precision ${r.precision} isamplerCube;
	precision ${r.precision} isampler2DArray;
	precision ${r.precision} usampler2D;
	precision ${r.precision} usampler3D;
	precision ${r.precision} usamplerCube;
	precision ${r.precision} usampler2DArray;
	`;return r.precision==="highp"?t+=`
#define HIGH_PRECISION`:r.precision==="mediump"?t+=`
#define MEDIUM_PRECISION`:r.precision==="lowp"&&(t+=`
#define LOW_PRECISION`),t}const tM={[kc]:"SHADOWMAP_TYPE_PCF",[al]:"SHADOWMAP_TYPE_VSM"};function eM(r){return tM[r.shadowMapType]||"SHADOWMAP_TYPE_BASIC"}const nM={[Zs]:"ENVMAP_TYPE_CUBE",[Kr]:"ENVMAP_TYPE_CUBE",[ru]:"ENVMAP_TYPE_CUBE_UV"};function iM(r){return r.envMap===!1?"ENVMAP_TYPE_CUBE":nM[r.envMapMode]||"ENVMAP_TYPE_CUBE"}const aM={[Kr]:"ENVMAP_MODE_REFRACTION"};function sM(r){return r.envMap===!1?"ENVMAP_MODE_REFLECTION":aM[r.envMapMode]||"ENVMAP_MODE_REFLECTION"}const rM={[i0]:"ENVMAP_BLENDING_MULTIPLY",[W_]:"ENVMAP_BLENDING_MIX",[k_]:"ENVMAP_BLENDING_ADD"};function oM(r){return r.envMap===!1?"ENVMAP_BLENDING_NONE":rM[r.combine]||"ENVMAP_BLENDING_NONE"}function lM(r){const t=r.envMapCubeUVHeight;if(t===null)return null;const i=Math.log2(t)-2,s=1/t;return{texelWidth:1/(3*Math.max(Math.pow(2,i),112)),texelHeight:s,maxMip:i}}function cM(r,t,i,s){const l=r.getContext(),c=i.defines;let f=i.vertexShader,T=i.fragmentShader;const p=eM(i),h=iM(i),m=sM(i),E=oM(i),S=lM(i),g=kN(i),A=KN(c),M=l.createProgram();let x,v,D=i.glslVersion?"#version "+i.glslVersion+`
`:"";i.isRawShaderMaterial?(x=["#define SHADER_TYPE "+i.shaderType,"#define SHADER_NAME "+i.shaderName,A].filter(sl).join(`
`),x.length>0&&(x+=`
`),v=["#define SHADER_TYPE "+i.shaderType,"#define SHADER_NAME "+i.shaderName,A].filter(sl).join(`
`),v.length>0&&(v+=`
`)):(x=[rE(i),"#define SHADER_TYPE "+i.shaderType,"#define SHADER_NAME "+i.shaderName,A,i.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",i.batching?"#define USE_BATCHING":"",i.batchingColor?"#define USE_BATCHING_COLOR":"",i.instancing?"#define USE_INSTANCING":"",i.instancingColor?"#define USE_INSTANCING_COLOR":"",i.instancingMorph?"#define USE_INSTANCING_MORPH":"",i.useFog&&i.fog?"#define USE_FOG":"",i.useFog&&i.fogExp2?"#define FOG_EXP2":"",i.map?"#define USE_MAP":"",i.envMap?"#define USE_ENVMAP":"",i.envMap?"#define "+m:"",i.lightMap?"#define USE_LIGHTMAP":"",i.aoMap?"#define USE_AOMAP":"",i.bumpMap?"#define USE_BUMPMAP":"",i.normalMap?"#define USE_NORMALMAP":"",i.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",i.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",i.displacementMap?"#define USE_DISPLACEMENTMAP":"",i.emissiveMap?"#define USE_EMISSIVEMAP":"",i.anisotropy?"#define USE_ANISOTROPY":"",i.anisotropyMap?"#define USE_ANISOTROPYMAP":"",i.clearcoatMap?"#define USE_CLEARCOATMAP":"",i.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",i.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",i.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",i.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",i.specularMap?"#define USE_SPECULARMAP":"",i.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",i.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",i.roughnessMap?"#define USE_ROUGHNESSMAP":"",i.metalnessMap?"#define USE_METALNESSMAP":"",i.alphaMap?"#define USE_ALPHAMAP":"",i.alphaHash?"#define USE_ALPHAHASH":"",i.transmission?"#define USE_TRANSMISSION":"",i.transmissionMap?"#define USE_TRANSMISSIONMAP":"",i.thicknessMap?"#define USE_THICKNESSMAP":"",i.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",i.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",i.mapUv?"#define MAP_UV "+i.mapUv:"",i.alphaMapUv?"#define ALPHAMAP_UV "+i.alphaMapUv:"",i.lightMapUv?"#define LIGHTMAP_UV "+i.lightMapUv:"",i.aoMapUv?"#define AOMAP_UV "+i.aoMapUv:"",i.emissiveMapUv?"#define EMISSIVEMAP_UV "+i.emissiveMapUv:"",i.bumpMapUv?"#define BUMPMAP_UV "+i.bumpMapUv:"",i.normalMapUv?"#define NORMALMAP_UV "+i.normalMapUv:"",i.displacementMapUv?"#define DISPLACEMENTMAP_UV "+i.displacementMapUv:"",i.metalnessMapUv?"#define METALNESSMAP_UV "+i.metalnessMapUv:"",i.roughnessMapUv?"#define ROUGHNESSMAP_UV "+i.roughnessMapUv:"",i.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+i.anisotropyMapUv:"",i.clearcoatMapUv?"#define CLEARCOATMAP_UV "+i.clearcoatMapUv:"",i.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+i.clearcoatNormalMapUv:"",i.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+i.clearcoatRoughnessMapUv:"",i.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+i.iridescenceMapUv:"",i.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+i.iridescenceThicknessMapUv:"",i.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+i.sheenColorMapUv:"",i.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+i.sheenRoughnessMapUv:"",i.specularMapUv?"#define SPECULARMAP_UV "+i.specularMapUv:"",i.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+i.specularColorMapUv:"",i.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+i.specularIntensityMapUv:"",i.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+i.transmissionMapUv:"",i.thicknessMapUv?"#define THICKNESSMAP_UV "+i.thicknessMapUv:"",i.vertexTangents&&i.flatShading===!1?"#define USE_TANGENT":"",i.vertexNormals?"#define HAS_NORMAL":"",i.vertexColors?"#define USE_COLOR":"",i.vertexAlphas?"#define USE_COLOR_ALPHA":"",i.vertexUv1s?"#define USE_UV1":"",i.vertexUv2s?"#define USE_UV2":"",i.vertexUv3s?"#define USE_UV3":"",i.pointsUvs?"#define USE_POINTS_UV":"",i.flatShading?"#define FLAT_SHADED":"",i.skinning?"#define USE_SKINNING":"",i.morphTargets?"#define USE_MORPHTARGETS":"",i.morphNormals&&i.flatShading===!1?"#define USE_MORPHNORMALS":"",i.morphColors?"#define USE_MORPHCOLORS":"",i.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+i.morphTextureStride:"",i.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+i.morphTargetsCount:"",i.doubleSided?"#define DOUBLE_SIDED":"",i.flipSided?"#define FLIP_SIDED":"",i.shadowMapEnabled?"#define USE_SHADOWMAP":"",i.shadowMapEnabled?"#define "+p:"",i.sizeAttenuation?"#define USE_SIZEATTENUATION":"",i.numLightProbes>0?"#define USE_LIGHT_PROBES":"",i.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",i.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(sl).join(`
`),v=[rE(i),"#define SHADER_TYPE "+i.shaderType,"#define SHADER_NAME "+i.shaderName,A,i.useFog&&i.fog?"#define USE_FOG":"",i.useFog&&i.fogExp2?"#define FOG_EXP2":"",i.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",i.map?"#define USE_MAP":"",i.matcap?"#define USE_MATCAP":"",i.envMap?"#define USE_ENVMAP":"",i.envMap?"#define "+h:"",i.envMap?"#define "+m:"",i.envMap?"#define "+E:"",S?"#define CUBEUV_TEXEL_WIDTH "+S.texelWidth:"",S?"#define CUBEUV_TEXEL_HEIGHT "+S.texelHeight:"",S?"#define CUBEUV_MAX_MIP "+S.maxMip+".0":"",i.lightMap?"#define USE_LIGHTMAP":"",i.aoMap?"#define USE_AOMAP":"",i.bumpMap?"#define USE_BUMPMAP":"",i.normalMap?"#define USE_NORMALMAP":"",i.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",i.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",i.packedNormalMap?"#define USE_PACKED_NORMALMAP":"",i.emissiveMap?"#define USE_EMISSIVEMAP":"",i.anisotropy?"#define USE_ANISOTROPY":"",i.anisotropyMap?"#define USE_ANISOTROPYMAP":"",i.clearcoat?"#define USE_CLEARCOAT":"",i.clearcoatMap?"#define USE_CLEARCOATMAP":"",i.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",i.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",i.dispersion?"#define USE_DISPERSION":"",i.iridescence?"#define USE_IRIDESCENCE":"",i.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",i.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",i.specularMap?"#define USE_SPECULARMAP":"",i.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",i.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",i.roughnessMap?"#define USE_ROUGHNESSMAP":"",i.metalnessMap?"#define USE_METALNESSMAP":"",i.alphaMap?"#define USE_ALPHAMAP":"",i.alphaTest?"#define USE_ALPHATEST":"",i.alphaHash?"#define USE_ALPHAHASH":"",i.sheen?"#define USE_SHEEN":"",i.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",i.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",i.transmission?"#define USE_TRANSMISSION":"",i.transmissionMap?"#define USE_TRANSMISSIONMAP":"",i.thicknessMap?"#define USE_THICKNESSMAP":"",i.vertexTangents&&i.flatShading===!1?"#define USE_TANGENT":"",i.vertexColors||i.instancingColor?"#define USE_COLOR":"",i.vertexAlphas||i.batchingColor?"#define USE_COLOR_ALPHA":"",i.vertexUv1s?"#define USE_UV1":"",i.vertexUv2s?"#define USE_UV2":"",i.vertexUv3s?"#define USE_UV3":"",i.pointsUvs?"#define USE_POINTS_UV":"",i.gradientMap?"#define USE_GRADIENTMAP":"",i.flatShading?"#define FLAT_SHADED":"",i.doubleSided?"#define DOUBLE_SIDED":"",i.flipSided?"#define FLIP_SIDED":"",i.shadowMapEnabled?"#define USE_SHADOWMAP":"",i.shadowMapEnabled?"#define "+p:"",i.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",i.numLightProbes>0?"#define USE_LIGHT_PROBES":"",i.numLightProbeGrids>0?"#define USE_LIGHT_PROBES_GRID":"",i.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",i.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",i.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",i.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",i.toneMapping!==Qi?"#define TONE_MAPPING":"",i.toneMapping!==Qi?ue.tonemapping_pars_fragment:"",i.toneMapping!==Qi?VN("toneMapping",i.toneMapping):"",i.dithering?"#define DITHERING":"",i.opaque?"#define OPAQUE":"",ue.colorspace_pars_fragment,GN("linearToOutputTexel",i.outputColorSpace),WN(),i.useDepthPacking?"#define DEPTH_PACKING "+i.depthPacking:"",`
`].filter(sl).join(`
`)),f=$d(f),f=iE(f,i),f=aE(f,i),T=$d(T),T=iE(T,i),T=aE(T,i),f=sE(f),T=sE(T),i.isRawShaderMaterial!==!0&&(D=`#version 300 es
`,x=[g,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+x,v=["#define varying in",i.glslVersion===Em?"":"layout(location = 0) out highp vec4 pc_fragColor;",i.glslVersion===Em?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+v);const I=D+x+f,U=D+v+T,Y=tE(l,l.VERTEX_SHADER,I),F=tE(l,l.FRAGMENT_SHADER,U);l.attachShader(M,Y),l.attachShader(M,F),i.index0AttributeName!==void 0?l.bindAttribLocation(M,0,i.index0AttributeName):i.morphTargets===!0&&l.bindAttribLocation(M,0,"position"),l.linkProgram(M);function B(H){if(r.debug.checkShaderErrors){const $=l.getProgramInfoLog(M)||"",ct=l.getShaderInfoLog(Y)||"",lt=l.getShaderInfoLog(F)||"",W=$.trim(),L=ct.trim(),P=lt.trim();let it=!0,mt=!0;if(l.getProgramParameter(M,l.LINK_STATUS)===!1)if(it=!1,typeof r.debug.onShaderError=="function")r.debug.onShaderError(l,M,Y,F);else{const ft=nE(l,Y,"vertex"),O=nE(l,F,"fragment");Ne("THREE.WebGLProgram: Shader Error "+l.getError()+" - VALIDATE_STATUS "+l.getProgramParameter(M,l.VALIDATE_STATUS)+`

Material Name: `+H.name+`
Material Type: `+H.type+`

Program Info Log: `+W+`
`+ft+`
`+O)}else W!==""?ee("WebGLProgram: Program Info Log:",W):(L===""||P==="")&&(mt=!1);mt&&(H.diagnostics={runnable:it,programLog:W,vertexShader:{log:L,prefix:x},fragmentShader:{log:P,prefix:v}})}l.deleteShader(Y),l.deleteShader(F),R=new Qc(l,M),w=ZN(l,M)}let R;this.getUniforms=function(){return R===void 0&&B(this),R};let w;this.getAttributes=function(){return w===void 0&&B(this),w};let Z=i.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return Z===!1&&(Z=l.getProgramParameter(M,XN)),Z},this.destroy=function(){s.releaseStatesOfProgram(this),l.deleteProgram(M),this.program=void 0},this.type=i.shaderType,this.name=i.shaderName,this.id=PN++,this.cacheKey=t,this.usedTimes=1,this.program=M,this.vertexShader=Y,this.fragmentShader=F,this}let uM=0;class fM{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(t){const i=t.vertexShader,s=t.fragmentShader,l=this._getShaderStage(i),c=this._getShaderStage(s),f=this._getShaderCacheForMaterial(t);return f.has(l)===!1&&(f.add(l),l.usedTimes++),f.has(c)===!1&&(f.add(c),c.usedTimes++),this}remove(t){const i=this.materialCache.get(t);for(const s of i)s.usedTimes--,s.usedTimes===0&&this.shaderCache.delete(s.code);return this.materialCache.delete(t),this}getVertexShaderID(t){return this._getShaderStage(t.vertexShader).id}getFragmentShaderID(t){return this._getShaderStage(t.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(t){const i=this.materialCache;let s=i.get(t);return s===void 0&&(s=new Set,i.set(t,s)),s}_getShaderStage(t){const i=this.shaderCache;let s=i.get(t);return s===void 0&&(s=new hM(t),i.set(t,s)),s}}class hM{constructor(t){this.id=uM++,this.code=t,this.usedTimes=0}}function dM(r){return r===qs||r===Jc||r===tu}function pM(r,t,i,s,l,c){const f=new HE,T=new fM,p=new Set,h=[],m=new Map,E=s.logarithmicDepthBuffer;let S=s.precision;const g={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distance",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function A(R){return p.add(R),R===0?"uv":`uv${R}`}function M(R,w,Z,H,$,ct){const lt=H.fog,W=$.geometry,L=R.isMeshStandardMaterial||R.isMeshLambertMaterial||R.isMeshPhongMaterial?H.environment:null,P=R.isMeshStandardMaterial||R.isMeshLambertMaterial&&!R.envMap||R.isMeshPhongMaterial&&!R.envMap,it=t.get(R.envMap||L,P),mt=it&&it.mapping===ru?it.image.height:null,ft=g[R.type];R.precision!==null&&(S=s.getMaxPrecision(R.precision),S!==R.precision&&ee("WebGLProgram.getParameters:",R.precision,"not supported, using",S,"instead."));const O=W.morphAttributes.position||W.morphAttributes.normal||W.morphAttributes.color,V=O!==void 0?O.length:0;let dt=0;W.morphAttributes.position!==void 0&&(dt=1),W.morphAttributes.normal!==void 0&&(dt=2),W.morphAttributes.color!==void 0&&(dt=3);let gt,Mt,rt,vt;if(ft){const te=ki[ft];gt=te.vertexShader,Mt=te.fragmentShader}else gt=R.vertexShader,Mt=R.fragmentShader,T.update(R),rt=T.getVertexShaderID(R),vt=T.getFragmentShaderID(R);const Nt=r.getRenderTarget(),Pt=r.state.buffers.depth.getReversed(),Jt=$.isInstancedMesh===!0,Qt=$.isBatchedMesh===!0,ze=!!R.map,fe=!!R.matcap,Ee=!!it,Ie=!!R.aoMap,le=!!R.lightMap,sn=!!R.bumpMap,ke=!!R.normalMap,Mn=!!R.displacementMap,k=!!R.emissiveMap,Je=!!R.metalnessMap,he=!!R.roughnessMap,Pe=R.anisotropy>0,Ct=R.clearcoat>0,qe=R.dispersion>0,b=R.iridescence>0,N=R.sheen>0,Q=R.transmission>0,St=Pe&&!!R.anisotropyMap,xt=Ct&&!!R.clearcoatMap,yt=Ct&&!!R.clearcoatNormalMap,It=Ct&&!!R.clearcoatRoughnessMap,ut=b&&!!R.iridescenceMap,ht=b&&!!R.iridescenceThicknessMap,Lt=N&&!!R.sheenColorMap,Ut=N&&!!R.sheenRoughnessMap,Ot=!!R.specularMap,Dt=!!R.specularColorMap,ne=!!R.specularIntensityMap,ie=Q&&!!R.transmissionMap,de=Q&&!!R.thicknessMap,G=!!R.gradientMap,Rt=!!R.alphaMap,Tt=R.alphaTest>0,Bt=!!R.alphaHash,bt=!!R.extensions;let At=Qi;R.toneMapped&&(Nt===null||Nt.isXRRenderTarget===!0)&&(At=r.toneMapping);const Wt={shaderID:ft,shaderType:R.type,shaderName:R.name,vertexShader:gt,fragmentShader:Mt,defines:R.defines,customVertexShaderID:rt,customFragmentShaderID:vt,isRawShaderMaterial:R.isRawShaderMaterial===!0,glslVersion:R.glslVersion,precision:S,batching:Qt,batchingColor:Qt&&$._colorsTexture!==null,instancing:Jt,instancingColor:Jt&&$.instanceColor!==null,instancingMorph:Jt&&$.morphTexture!==null,outputColorSpace:Nt===null?r.outputColorSpace:Nt.isXRRenderTarget===!0?Nt.texture.colorSpace:Ae.workingColorSpace,alphaToCoverage:!!R.alphaToCoverage,map:ze,matcap:fe,envMap:Ee,envMapMode:Ee&&it.mapping,envMapCubeUVHeight:mt,aoMap:Ie,lightMap:le,bumpMap:sn,normalMap:ke,displacementMap:Mn,emissiveMap:k,normalMapObjectSpace:ke&&R.normalMapType===q_,normalMapTangentSpace:ke&&R.normalMapType===kd,packedNormalMap:ke&&R.normalMapType===kd&&dM(R.normalMap.format),metalnessMap:Je,roughnessMap:he,anisotropy:Pe,anisotropyMap:St,clearcoat:Ct,clearcoatMap:xt,clearcoatNormalMap:yt,clearcoatRoughnessMap:It,dispersion:qe,iridescence:b,iridescenceMap:ut,iridescenceThicknessMap:ht,sheen:N,sheenColorMap:Lt,sheenRoughnessMap:Ut,specularMap:Ot,specularColorMap:Dt,specularIntensityMap:ne,transmission:Q,transmissionMap:ie,thicknessMap:de,gradientMap:G,opaque:R.transparent===!1&&R.blending===Vr&&R.alphaToCoverage===!1,alphaMap:Rt,alphaTest:Tt,alphaHash:Bt,combine:R.combine,mapUv:ze&&A(R.map.channel),aoMapUv:Ie&&A(R.aoMap.channel),lightMapUv:le&&A(R.lightMap.channel),bumpMapUv:sn&&A(R.bumpMap.channel),normalMapUv:ke&&A(R.normalMap.channel),displacementMapUv:Mn&&A(R.displacementMap.channel),emissiveMapUv:k&&A(R.emissiveMap.channel),metalnessMapUv:Je&&A(R.metalnessMap.channel),roughnessMapUv:he&&A(R.roughnessMap.channel),anisotropyMapUv:St&&A(R.anisotropyMap.channel),clearcoatMapUv:xt&&A(R.clearcoatMap.channel),clearcoatNormalMapUv:yt&&A(R.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:It&&A(R.clearcoatRoughnessMap.channel),iridescenceMapUv:ut&&A(R.iridescenceMap.channel),iridescenceThicknessMapUv:ht&&A(R.iridescenceThicknessMap.channel),sheenColorMapUv:Lt&&A(R.sheenColorMap.channel),sheenRoughnessMapUv:Ut&&A(R.sheenRoughnessMap.channel),specularMapUv:Ot&&A(R.specularMap.channel),specularColorMapUv:Dt&&A(R.specularColorMap.channel),specularIntensityMapUv:ne&&A(R.specularIntensityMap.channel),transmissionMapUv:ie&&A(R.transmissionMap.channel),thicknessMapUv:de&&A(R.thicknessMap.channel),alphaMapUv:Rt&&A(R.alphaMap.channel),vertexTangents:!!W.attributes.tangent&&(ke||Pe),vertexNormals:!!W.attributes.normal,vertexColors:R.vertexColors,vertexAlphas:R.vertexColors===!0&&!!W.attributes.color&&W.attributes.color.itemSize===4,pointsUvs:$.isPoints===!0&&!!W.attributes.uv&&(ze||Rt),fog:!!lt,useFog:R.fog===!0,fogExp2:!!lt&&lt.isFogExp2,flatShading:R.wireframe===!1&&(R.flatShading===!0||W.attributes.normal===void 0&&ke===!1&&(R.isMeshLambertMaterial||R.isMeshPhongMaterial||R.isMeshStandardMaterial||R.isMeshPhysicalMaterial)),sizeAttenuation:R.sizeAttenuation===!0,logarithmicDepthBuffer:E,reversedDepthBuffer:Pt,skinning:$.isSkinnedMesh===!0,morphTargets:W.morphAttributes.position!==void 0,morphNormals:W.morphAttributes.normal!==void 0,morphColors:W.morphAttributes.color!==void 0,morphTargetsCount:V,morphTextureStride:dt,numDirLights:w.directional.length,numPointLights:w.point.length,numSpotLights:w.spot.length,numSpotLightMaps:w.spotLightMap.length,numRectAreaLights:w.rectArea.length,numHemiLights:w.hemi.length,numDirLightShadows:w.directionalShadowMap.length,numPointLightShadows:w.pointShadowMap.length,numSpotLightShadows:w.spotShadowMap.length,numSpotLightShadowsWithMaps:w.numSpotLightShadowsWithMaps,numLightProbes:w.numLightProbes,numLightProbeGrids:ct.length,numClippingPlanes:c.numPlanes,numClipIntersection:c.numIntersection,dithering:R.dithering,shadowMapEnabled:r.shadowMap.enabled&&Z.length>0,shadowMapType:r.shadowMap.type,toneMapping:At,decodeVideoTexture:ze&&R.map.isVideoTexture===!0&&Ae.getTransfer(R.map.colorSpace)===Xe,decodeVideoTextureEmissive:k&&R.emissiveMap.isVideoTexture===!0&&Ae.getTransfer(R.emissiveMap.colorSpace)===Xe,premultipliedAlpha:R.premultipliedAlpha,doubleSided:R.side===Zi,flipSided:R.side===ti,useDepthPacking:R.depthPacking>=0,depthPacking:R.depthPacking||0,index0AttributeName:R.index0AttributeName,extensionClipCullDistance:bt&&R.extensions.clipCullDistance===!0&&i.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(bt&&R.extensions.multiDraw===!0||Qt)&&i.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:i.has("KHR_parallel_shader_compile"),customProgramCacheKey:R.customProgramCacheKey()};return Wt.vertexUv1s=p.has(1),Wt.vertexUv2s=p.has(2),Wt.vertexUv3s=p.has(3),p.clear(),Wt}function x(R){const w=[];if(R.shaderID?w.push(R.shaderID):(w.push(R.customVertexShaderID),w.push(R.customFragmentShaderID)),R.defines!==void 0)for(const Z in R.defines)w.push(Z),w.push(R.defines[Z]);return R.isRawShaderMaterial===!1&&(v(w,R),D(w,R),w.push(r.outputColorSpace)),w.push(R.customProgramCacheKey),w.join()}function v(R,w){R.push(w.precision),R.push(w.outputColorSpace),R.push(w.envMapMode),R.push(w.envMapCubeUVHeight),R.push(w.mapUv),R.push(w.alphaMapUv),R.push(w.lightMapUv),R.push(w.aoMapUv),R.push(w.bumpMapUv),R.push(w.normalMapUv),R.push(w.displacementMapUv),R.push(w.emissiveMapUv),R.push(w.metalnessMapUv),R.push(w.roughnessMapUv),R.push(w.anisotropyMapUv),R.push(w.clearcoatMapUv),R.push(w.clearcoatNormalMapUv),R.push(w.clearcoatRoughnessMapUv),R.push(w.iridescenceMapUv),R.push(w.iridescenceThicknessMapUv),R.push(w.sheenColorMapUv),R.push(w.sheenRoughnessMapUv),R.push(w.specularMapUv),R.push(w.specularColorMapUv),R.push(w.specularIntensityMapUv),R.push(w.transmissionMapUv),R.push(w.thicknessMapUv),R.push(w.combine),R.push(w.fogExp2),R.push(w.sizeAttenuation),R.push(w.morphTargetsCount),R.push(w.morphAttributeCount),R.push(w.numDirLights),R.push(w.numPointLights),R.push(w.numSpotLights),R.push(w.numSpotLightMaps),R.push(w.numHemiLights),R.push(w.numRectAreaLights),R.push(w.numDirLightShadows),R.push(w.numPointLightShadows),R.push(w.numSpotLightShadows),R.push(w.numSpotLightShadowsWithMaps),R.push(w.numLightProbes),R.push(w.shadowMapType),R.push(w.toneMapping),R.push(w.numClippingPlanes),R.push(w.numClipIntersection),R.push(w.depthPacking)}function D(R,w){f.disableAll(),w.instancing&&f.enable(0),w.instancingColor&&f.enable(1),w.instancingMorph&&f.enable(2),w.matcap&&f.enable(3),w.envMap&&f.enable(4),w.normalMapObjectSpace&&f.enable(5),w.normalMapTangentSpace&&f.enable(6),w.clearcoat&&f.enable(7),w.iridescence&&f.enable(8),w.alphaTest&&f.enable(9),w.vertexColors&&f.enable(10),w.vertexAlphas&&f.enable(11),w.vertexUv1s&&f.enable(12),w.vertexUv2s&&f.enable(13),w.vertexUv3s&&f.enable(14),w.vertexTangents&&f.enable(15),w.anisotropy&&f.enable(16),w.alphaHash&&f.enable(17),w.batching&&f.enable(18),w.dispersion&&f.enable(19),w.batchingColor&&f.enable(20),w.gradientMap&&f.enable(21),w.packedNormalMap&&f.enable(22),w.vertexNormals&&f.enable(23),R.push(f.mask),f.disableAll(),w.fog&&f.enable(0),w.useFog&&f.enable(1),w.flatShading&&f.enable(2),w.logarithmicDepthBuffer&&f.enable(3),w.reversedDepthBuffer&&f.enable(4),w.skinning&&f.enable(5),w.morphTargets&&f.enable(6),w.morphNormals&&f.enable(7),w.morphColors&&f.enable(8),w.premultipliedAlpha&&f.enable(9),w.shadowMapEnabled&&f.enable(10),w.doubleSided&&f.enable(11),w.flipSided&&f.enable(12),w.useDepthPacking&&f.enable(13),w.dithering&&f.enable(14),w.transmission&&f.enable(15),w.sheen&&f.enable(16),w.opaque&&f.enable(17),w.pointsUvs&&f.enable(18),w.decodeVideoTexture&&f.enable(19),w.decodeVideoTextureEmissive&&f.enable(20),w.alphaToCoverage&&f.enable(21),w.numLightProbeGrids>0&&f.enable(22),R.push(f.mask)}function I(R){const w=g[R.type];let Z;if(w){const H=ki[w];Z=U2.clone(H.uniforms)}else Z=R.uniforms;return Z}function U(R,w){let Z=m.get(w);return Z!==void 0?++Z.usedTimes:(Z=new cM(r,w,R,l),h.push(Z),m.set(w,Z)),Z}function Y(R){if(--R.usedTimes===0){const w=h.indexOf(R);h[w]=h[h.length-1],h.pop(),m.delete(R.cacheKey),R.destroy()}}function F(R){T.remove(R)}function B(){T.dispose()}return{getParameters:M,getProgramCacheKey:x,getUniforms:I,acquireProgram:U,releaseProgram:Y,releaseShaderCache:F,programs:h,dispose:B}}function TM(){let r=new WeakMap;function t(f){return r.has(f)}function i(f){let T=r.get(f);return T===void 0&&(T={},r.set(f,T)),T}function s(f){r.delete(f)}function l(f,T,p){r.get(f)[T]=p}function c(){r=new WeakMap}return{has:t,get:i,remove:s,update:l,dispose:c}}function mM(r,t){return r.groupOrder!==t.groupOrder?r.groupOrder-t.groupOrder:r.renderOrder!==t.renderOrder?r.renderOrder-t.renderOrder:r.material.id!==t.material.id?r.material.id-t.material.id:r.materialVariant!==t.materialVariant?r.materialVariant-t.materialVariant:r.z!==t.z?r.z-t.z:r.id-t.id}function oE(r,t){return r.groupOrder!==t.groupOrder?r.groupOrder-t.groupOrder:r.renderOrder!==t.renderOrder?r.renderOrder-t.renderOrder:r.z!==t.z?t.z-r.z:r.id-t.id}function lE(){const r=[];let t=0;const i=[],s=[],l=[];function c(){t=0,i.length=0,s.length=0,l.length=0}function f(S){let g=0;return S.isInstancedMesh&&(g+=2),S.isSkinnedMesh&&(g+=1),g}function T(S,g,A,M,x,v){let D=r[t];return D===void 0?(D={id:S.id,object:S,geometry:g,material:A,materialVariant:f(S),groupOrder:M,renderOrder:S.renderOrder,z:x,group:v},r[t]=D):(D.id=S.id,D.object=S,D.geometry=g,D.material=A,D.materialVariant=f(S),D.groupOrder=M,D.renderOrder=S.renderOrder,D.z=x,D.group=v),t++,D}function p(S,g,A,M,x,v){const D=T(S,g,A,M,x,v);A.transmission>0?s.push(D):A.transparent===!0?l.push(D):i.push(D)}function h(S,g,A,M,x,v){const D=T(S,g,A,M,x,v);A.transmission>0?s.unshift(D):A.transparent===!0?l.unshift(D):i.unshift(D)}function m(S,g){i.length>1&&i.sort(S||mM),s.length>1&&s.sort(g||oE),l.length>1&&l.sort(g||oE)}function E(){for(let S=t,g=r.length;S<g;S++){const A=r[S];if(A.id===null)break;A.id=null,A.object=null,A.geometry=null,A.material=null,A.group=null}}return{opaque:i,transmissive:s,transparent:l,init:c,push:p,unshift:h,finish:E,sort:m}}function EM(){let r=new WeakMap;function t(s,l){const c=r.get(s);let f;return c===void 0?(f=new lE,r.set(s,[f])):l>=c.length?(f=new lE,c.push(f)):f=c[l],f}function i(){r=new WeakMap}return{get:t,dispose:i}}function SM(){const r={};return{get:function(t){if(r[t.id]!==void 0)return r[t.id];let i;switch(t.type){case"DirectionalLight":i={direction:new nt,color:new _e};break;case"SpotLight":i={position:new nt,direction:new nt,color:new _e,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":i={position:new nt,color:new _e,distance:0,decay:0};break;case"HemisphereLight":i={direction:new nt,skyColor:new _e,groundColor:new _e};break;case"RectAreaLight":i={color:new _e,position:new nt,halfWidth:new nt,halfHeight:new nt};break}return r[t.id]=i,i}}}function gM(){const r={};return{get:function(t){if(r[t.id]!==void 0)return r[t.id];let i;switch(t.type){case"DirectionalLight":i={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Oe};break;case"SpotLight":i={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Oe};break;case"PointLight":i={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Oe,shadowCameraNear:1,shadowCameraFar:1e3};break}return r[t.id]=i,i}}}let _M=0;function vM(r,t){return(t.castShadow?2:0)-(r.castShadow?2:0)+(t.map?1:0)-(r.map?1:0)}function AM(r){const t=new SM,i=gM(),s={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let h=0;h<9;h++)s.probe.push(new nt);const l=new nt,c=new cn,f=new cn;function T(h){let m=0,E=0,S=0;for(let w=0;w<9;w++)s.probe[w].set(0,0,0);let g=0,A=0,M=0,x=0,v=0,D=0,I=0,U=0,Y=0,F=0,B=0;h.sort(vM);for(let w=0,Z=h.length;w<Z;w++){const H=h[w],$=H.color,ct=H.intensity,lt=H.distance;let W=null;if(H.shadow&&H.shadow.map&&(H.shadow.map.texture.format===qs?W=H.shadow.map.texture:W=H.shadow.map.depthTexture||H.shadow.map.texture),H.isAmbientLight)m+=$.r*ct,E+=$.g*ct,S+=$.b*ct;else if(H.isLightProbe){for(let L=0;L<9;L++)s.probe[L].addScaledVector(H.sh.coefficients[L],ct);B++}else if(H.isDirectionalLight){const L=t.get(H);if(L.color.copy(H.color).multiplyScalar(H.intensity),H.castShadow){const P=H.shadow,it=i.get(H);it.shadowIntensity=P.intensity,it.shadowBias=P.bias,it.shadowNormalBias=P.normalBias,it.shadowRadius=P.radius,it.shadowMapSize=P.mapSize,s.directionalShadow[g]=it,s.directionalShadowMap[g]=W,s.directionalShadowMatrix[g]=H.shadow.matrix,D++}s.directional[g]=L,g++}else if(H.isSpotLight){const L=t.get(H);L.position.setFromMatrixPosition(H.matrixWorld),L.color.copy($).multiplyScalar(ct),L.distance=lt,L.coneCos=Math.cos(H.angle),L.penumbraCos=Math.cos(H.angle*(1-H.penumbra)),L.decay=H.decay,s.spot[M]=L;const P=H.shadow;if(H.map&&(s.spotLightMap[Y]=H.map,Y++,P.updateMatrices(H),H.castShadow&&F++),s.spotLightMatrix[M]=P.matrix,H.castShadow){const it=i.get(H);it.shadowIntensity=P.intensity,it.shadowBias=P.bias,it.shadowNormalBias=P.normalBias,it.shadowRadius=P.radius,it.shadowMapSize=P.mapSize,s.spotShadow[M]=it,s.spotShadowMap[M]=W,U++}M++}else if(H.isRectAreaLight){const L=t.get(H);L.color.copy($).multiplyScalar(ct),L.halfWidth.set(H.width*.5,0,0),L.halfHeight.set(0,H.height*.5,0),s.rectArea[x]=L,x++}else if(H.isPointLight){const L=t.get(H);if(L.color.copy(H.color).multiplyScalar(H.intensity),L.distance=H.distance,L.decay=H.decay,H.castShadow){const P=H.shadow,it=i.get(H);it.shadowIntensity=P.intensity,it.shadowBias=P.bias,it.shadowNormalBias=P.normalBias,it.shadowRadius=P.radius,it.shadowMapSize=P.mapSize,it.shadowCameraNear=P.camera.near,it.shadowCameraFar=P.camera.far,s.pointShadow[A]=it,s.pointShadowMap[A]=W,s.pointShadowMatrix[A]=H.shadow.matrix,I++}s.point[A]=L,A++}else if(H.isHemisphereLight){const L=t.get(H);L.skyColor.copy(H.color).multiplyScalar(ct),L.groundColor.copy(H.groundColor).multiplyScalar(ct),s.hemi[v]=L,v++}}x>0&&(r.has("OES_texture_float_linear")===!0?(s.rectAreaLTC1=Xt.LTC_FLOAT_1,s.rectAreaLTC2=Xt.LTC_FLOAT_2):(s.rectAreaLTC1=Xt.LTC_HALF_1,s.rectAreaLTC2=Xt.LTC_HALF_2)),s.ambient[0]=m,s.ambient[1]=E,s.ambient[2]=S;const R=s.hash;(R.directionalLength!==g||R.pointLength!==A||R.spotLength!==M||R.rectAreaLength!==x||R.hemiLength!==v||R.numDirectionalShadows!==D||R.numPointShadows!==I||R.numSpotShadows!==U||R.numSpotMaps!==Y||R.numLightProbes!==B)&&(s.directional.length=g,s.spot.length=M,s.rectArea.length=x,s.point.length=A,s.hemi.length=v,s.directionalShadow.length=D,s.directionalShadowMap.length=D,s.pointShadow.length=I,s.pointShadowMap.length=I,s.spotShadow.length=U,s.spotShadowMap.length=U,s.directionalShadowMatrix.length=D,s.pointShadowMatrix.length=I,s.spotLightMatrix.length=U+Y-F,s.spotLightMap.length=Y,s.numSpotLightShadowsWithMaps=F,s.numLightProbes=B,R.directionalLength=g,R.pointLength=A,R.spotLength=M,R.rectAreaLength=x,R.hemiLength=v,R.numDirectionalShadows=D,R.numPointShadows=I,R.numSpotShadows=U,R.numSpotMaps=Y,R.numLightProbes=B,s.version=_M++)}function p(h,m){let E=0,S=0,g=0,A=0,M=0;const x=m.matrixWorldInverse;for(let v=0,D=h.length;v<D;v++){const I=h[v];if(I.isDirectionalLight){const U=s.directional[E];U.direction.setFromMatrixPosition(I.matrixWorld),l.setFromMatrixPosition(I.target.matrixWorld),U.direction.sub(l),U.direction.transformDirection(x),E++}else if(I.isSpotLight){const U=s.spot[g];U.position.setFromMatrixPosition(I.matrixWorld),U.position.applyMatrix4(x),U.direction.setFromMatrixPosition(I.matrixWorld),l.setFromMatrixPosition(I.target.matrixWorld),U.direction.sub(l),U.direction.transformDirection(x),g++}else if(I.isRectAreaLight){const U=s.rectArea[A];U.position.setFromMatrixPosition(I.matrixWorld),U.position.applyMatrix4(x),f.identity(),c.copy(I.matrixWorld),c.premultiply(x),f.extractRotation(c),U.halfWidth.set(I.width*.5,0,0),U.halfHeight.set(0,I.height*.5,0),U.halfWidth.applyMatrix4(f),U.halfHeight.applyMatrix4(f),A++}else if(I.isPointLight){const U=s.point[S];U.position.setFromMatrixPosition(I.matrixWorld),U.position.applyMatrix4(x),S++}else if(I.isHemisphereLight){const U=s.hemi[M];U.direction.setFromMatrixPosition(I.matrixWorld),U.direction.transformDirection(x),M++}}}return{setup:T,setupView:p,state:s}}function cE(r){const t=new AM(r),i=[],s=[],l=[];function c(S){E.camera=S,i.length=0,s.length=0,l.length=0}function f(S){i.push(S)}function T(S){s.push(S)}function p(S){l.push(S)}function h(){t.setup(i)}function m(S){t.setupView(i,S)}const E={lightsArray:i,shadowsArray:s,lightProbeGridArray:l,camera:null,lights:t,transmissionRenderTarget:{},textureUnits:0};return{init:c,state:E,setupLights:h,setupLightsView:m,pushLight:f,pushShadow:T,pushLightProbeGrid:p}}function xM(r){let t=new WeakMap;function i(l,c=0){const f=t.get(l);let T;return f===void 0?(T=new cE(r),t.set(l,[T])):c>=f.length?(T=new cE(r),f.push(T)):T=f[c],T}function s(){t=new WeakMap}return{get:i,dispose:s}}const NM=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,MM=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ).rg;
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ).r;
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( max( 0.0, squared_mean - mean * mean ) );
	gl_FragColor = vec4( mean, std_dev, 0.0, 1.0 );
}`,RM=[new nt(1,0,0),new nt(-1,0,0),new nt(0,1,0),new nt(0,-1,0),new nt(0,0,1),new nt(0,0,-1)],CM=[new nt(0,-1,0),new nt(0,-1,0),new nt(0,0,1),new nt(0,0,-1),new nt(0,-1,0),new nt(0,-1,0)],uE=new cn,el=new nt,Jh=new nt;function yM(r,t,i){let s=new p0;const l=new Oe,c=new Oe,f=new an,T=new X2,p=new P2,h={},m=i.maxTextureSize,E={[Es]:ti,[ti]:Es,[Zi]:Zi},S=new ea({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new Oe},radius:{value:4}},vertexShader:NM,fragmentShader:MM}),g=S.clone();g.defines.HORIZONTAL_PASS=1;const A=new na;A.setAttribute("position",new Ji(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));const M=new Bi(A,S),x=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=kc;let v=this.type;this.render=function(F,B,R){if(x.enabled===!1||x.autoUpdate===!1&&x.needsUpdate===!1||F.length===0)return;this.type===AE&&(ee("WebGLShadowMap: PCFSoftShadowMap has been deprecated. Using PCFShadowMap instead."),this.type=kc);const w=r.getRenderTarget(),Z=r.getActiveCubeFace(),H=r.getActiveMipmapLevel(),$=r.state;$.setBlending(Da),$.buffers.depth.getReversed()===!0?$.buffers.color.setClear(0,0,0,0):$.buffers.color.setClear(1,1,1,1),$.buffers.depth.setTest(!0),$.setScissorTest(!1);const ct=v!==this.type;ct&&B.traverse(function(lt){lt.material&&(Array.isArray(lt.material)?lt.material.forEach(W=>W.needsUpdate=!0):lt.material.needsUpdate=!0)});for(let lt=0,W=F.length;lt<W;lt++){const L=F[lt],P=L.shadow;if(P===void 0){ee("WebGLShadowMap:",L,"has no shadow.");continue}if(P.autoUpdate===!1&&P.needsUpdate===!1)continue;l.copy(P.mapSize);const it=P.getFrameExtents();l.multiply(it),c.copy(P.mapSize),(l.x>m||l.y>m)&&(l.x>m&&(c.x=Math.floor(m/it.x),l.x=c.x*it.x,P.mapSize.x=c.x),l.y>m&&(c.y=Math.floor(m/it.y),l.y=c.y*it.y,P.mapSize.y=c.y));const mt=r.state.buffers.depth.getReversed();if(P.camera._reversedDepth=mt,P.map===null||ct===!0){if(P.map!==null&&(P.map.depthTexture!==null&&(P.map.depthTexture.dispose(),P.map.depthTexture=null),P.map.dispose()),this.type===al){if(L.isPointLight){ee("WebGLShadowMap: VSM shadow maps are not supported for PointLights. Use PCF or BasicShadowMap instead.");continue}P.map=new ji(l.x,l.y,{format:qs,type:ba,minFilter:Nn,magFilter:Nn,generateMipmaps:!1}),P.map.texture.name=L.name+".shadowMap",P.map.depthTexture=new Zr(l.x,l.y,qi),P.map.depthTexture.name=L.name+".shadowMapDepth",P.map.depthTexture.format=Ia,P.map.depthTexture.compareFunction=null,P.map.depthTexture.minFilter=In,P.map.depthTexture.magFilter=In}else L.isPointLight?(P.map=new jE(l.x),P.map.depthTexture=new I2(l.x,ta)):(P.map=new ji(l.x,l.y),P.map.depthTexture=new Zr(l.x,l.y,ta)),P.map.depthTexture.name=L.name+".shadowMap",P.map.depthTexture.format=Ia,this.type===kc?(P.map.depthTexture.compareFunction=mt?f0:u0,P.map.depthTexture.minFilter=Nn,P.map.depthTexture.magFilter=Nn):(P.map.depthTexture.compareFunction=null,P.map.depthTexture.minFilter=In,P.map.depthTexture.magFilter=In);P.camera.updateProjectionMatrix()}const ft=P.map.isWebGLCubeRenderTarget?6:1;for(let O=0;O<ft;O++){if(P.map.isWebGLCubeRenderTarget)r.setRenderTarget(P.map,O),r.clear();else{O===0&&(r.setRenderTarget(P.map),r.clear());const V=P.getViewport(O);f.set(c.x*V.x,c.y*V.y,c.x*V.z,c.y*V.w),$.viewport(f)}if(L.isPointLight){const V=P.camera,dt=P.matrix,gt=L.distance||V.far;gt!==V.far&&(V.far=gt,V.updateProjectionMatrix()),el.setFromMatrixPosition(L.matrixWorld),V.position.copy(el),Jh.copy(V.position),Jh.add(RM[O]),V.up.copy(CM[O]),V.lookAt(Jh),V.updateMatrixWorld(),dt.makeTranslation(-el.x,-el.y,-el.z),uE.multiplyMatrices(V.projectionMatrix,V.matrixWorldInverse),P._frustum.setFromProjectionMatrix(uE,V.coordinateSystem,V.reversedDepth)}else P.updateMatrices(L);s=P.getFrustum(),U(B,R,P.camera,L,this.type)}P.isPointLightShadow!==!0&&this.type===al&&D(P,R),P.needsUpdate=!1}v=this.type,x.needsUpdate=!1,r.setRenderTarget(w,Z,H)};function D(F,B){const R=t.update(M);S.defines.VSM_SAMPLES!==F.blurSamples&&(S.defines.VSM_SAMPLES=F.blurSamples,g.defines.VSM_SAMPLES=F.blurSamples,S.needsUpdate=!0,g.needsUpdate=!0),F.mapPass===null&&(F.mapPass=new ji(l.x,l.y,{format:qs,type:ba})),S.uniforms.shadow_pass.value=F.map.depthTexture,S.uniforms.resolution.value=F.mapSize,S.uniforms.radius.value=F.radius,r.setRenderTarget(F.mapPass),r.clear(),r.renderBufferDirect(B,null,R,S,M,null),g.uniforms.shadow_pass.value=F.mapPass.texture,g.uniforms.resolution.value=F.mapSize,g.uniforms.radius.value=F.radius,r.setRenderTarget(F.map),r.clear(),r.renderBufferDirect(B,null,R,g,M,null)}function I(F,B,R,w){let Z=null;const H=R.isPointLight===!0?F.customDistanceMaterial:F.customDepthMaterial;if(H!==void 0)Z=H;else if(Z=R.isPointLight===!0?p:T,r.localClippingEnabled&&B.clipShadows===!0&&Array.isArray(B.clippingPlanes)&&B.clippingPlanes.length!==0||B.displacementMap&&B.displacementScale!==0||B.alphaMap&&B.alphaTest>0||B.map&&B.alphaTest>0||B.alphaToCoverage===!0){const $=Z.uuid,ct=B.uuid;let lt=h[$];lt===void 0&&(lt={},h[$]=lt);let W=lt[ct];W===void 0&&(W=Z.clone(),lt[ct]=W,B.addEventListener("dispose",Y)),Z=W}if(Z.visible=B.visible,Z.wireframe=B.wireframe,w===al?Z.side=B.shadowSide!==null?B.shadowSide:B.side:Z.side=B.shadowSide!==null?B.shadowSide:E[B.side],Z.alphaMap=B.alphaMap,Z.alphaTest=B.alphaToCoverage===!0?.5:B.alphaTest,Z.map=B.map,Z.clipShadows=B.clipShadows,Z.clippingPlanes=B.clippingPlanes,Z.clipIntersection=B.clipIntersection,Z.displacementMap=B.displacementMap,Z.displacementScale=B.displacementScale,Z.displacementBias=B.displacementBias,Z.wireframeLinewidth=B.wireframeLinewidth,Z.linewidth=B.linewidth,R.isPointLight===!0&&Z.isMeshDistanceMaterial===!0){const $=r.properties.get(Z);$.light=R}return Z}function U(F,B,R,w,Z){if(F.visible===!1)return;if(F.layers.test(B.layers)&&(F.isMesh||F.isLine||F.isPoints)&&(F.castShadow||F.receiveShadow&&Z===al)&&(!F.frustumCulled||s.intersectsObject(F))){F.modelViewMatrix.multiplyMatrices(R.matrixWorldInverse,F.matrixWorld);const ct=t.update(F),lt=F.material;if(Array.isArray(lt)){const W=ct.groups;for(let L=0,P=W.length;L<P;L++){const it=W[L],mt=lt[it.materialIndex];if(mt&&mt.visible){const ft=I(F,mt,w,Z);F.onBeforeShadow(r,F,B,R,ct,ft,it),r.renderBufferDirect(R,null,ct,ft,F,it),F.onAfterShadow(r,F,B,R,ct,ft,it)}}}else if(lt.visible){const W=I(F,lt,w,Z);F.onBeforeShadow(r,F,B,R,ct,W,null),r.renderBufferDirect(R,null,ct,W,F,null),F.onAfterShadow(r,F,B,R,ct,W,null)}}const $=F.children;for(let ct=0,lt=$.length;ct<lt;ct++)U($[ct],B,R,w,Z)}function Y(F){F.target.removeEventListener("dispose",Y);for(const R in h){const w=h[R],Z=F.target.uuid;Z in w&&(w[Z].dispose(),delete w[Z])}}}function DM(r,t){function i(){let G=!1;const Rt=new an;let Tt=null;const Bt=new an(0,0,0,0);return{setMask:function(bt){Tt!==bt&&!G&&(r.colorMask(bt,bt,bt,bt),Tt=bt)},setLocked:function(bt){G=bt},setClear:function(bt,At,Wt,te,tn){tn===!0&&(bt*=te,At*=te,Wt*=te),Rt.set(bt,At,Wt,te),Bt.equals(Rt)===!1&&(r.clearColor(bt,At,Wt,te),Bt.copy(Rt))},reset:function(){G=!1,Tt=null,Bt.set(-1,0,0,0)}}}function s(){let G=!1,Rt=!1,Tt=null,Bt=null,bt=null;return{setReversed:function(At){if(Rt!==At){const Wt=t.get("EXT_clip_control");At?Wt.clipControlEXT(Wt.LOWER_LEFT_EXT,Wt.ZERO_TO_ONE_EXT):Wt.clipControlEXT(Wt.LOWER_LEFT_EXT,Wt.NEGATIVE_ONE_TO_ONE_EXT),Rt=At;const te=bt;bt=null,this.setClear(te)}},getReversed:function(){return Rt},setTest:function(At){At?Nt(r.DEPTH_TEST):Pt(r.DEPTH_TEST)},setMask:function(At){Tt!==At&&!G&&(r.depthMask(At),Tt=At)},setFunc:function(At){if(Rt&&(At=s2[At]),Bt!==At){switch(At){case od:r.depthFunc(r.NEVER);break;case ld:r.depthFunc(r.ALWAYS);break;case cd:r.depthFunc(r.LESS);break;case kr:r.depthFunc(r.LEQUAL);break;case ud:r.depthFunc(r.EQUAL);break;case fd:r.depthFunc(r.GEQUAL);break;case hd:r.depthFunc(r.GREATER);break;case dd:r.depthFunc(r.NOTEQUAL);break;default:r.depthFunc(r.LEQUAL)}Bt=At}},setLocked:function(At){G=At},setClear:function(At){bt!==At&&(bt=At,Rt&&(At=1-At),r.clearDepth(At))},reset:function(){G=!1,Tt=null,Bt=null,bt=null,Rt=!1}}}function l(){let G=!1,Rt=null,Tt=null,Bt=null,bt=null,At=null,Wt=null,te=null,tn=null;return{setTest:function(ye){G||(ye?Nt(r.STENCIL_TEST):Pt(r.STENCIL_TEST))},setMask:function(ye){Rt!==ye&&!G&&(r.stencilMask(ye),Rt=ye)},setFunc:function(ye,pi,ei){(Tt!==ye||Bt!==pi||bt!==ei)&&(r.stencilFunc(ye,pi,ei),Tt=ye,Bt=pi,bt=ei)},setOp:function(ye,pi,ei){(At!==ye||Wt!==pi||te!==ei)&&(r.stencilOp(ye,pi,ei),At=ye,Wt=pi,te=ei)},setLocked:function(ye){G=ye},setClear:function(ye){tn!==ye&&(r.clearStencil(ye),tn=ye)},reset:function(){G=!1,Rt=null,Tt=null,Bt=null,bt=null,At=null,Wt=null,te=null,tn=null}}}const c=new i,f=new s,T=new l,p=new WeakMap,h=new WeakMap;let m={},E={},S={},g=new WeakMap,A=[],M=null,x=!1,v=null,D=null,I=null,U=null,Y=null,F=null,B=null,R=new _e(0,0,0),w=0,Z=!1,H=null,$=null,ct=null,lt=null,W=null;const L=r.getParameter(r.MAX_COMBINED_TEXTURE_IMAGE_UNITS);let P=!1,it=0;const mt=r.getParameter(r.VERSION);mt.indexOf("WebGL")!==-1?(it=parseFloat(/^WebGL (\d)/.exec(mt)[1]),P=it>=1):mt.indexOf("OpenGL ES")!==-1&&(it=parseFloat(/^OpenGL ES (\d)/.exec(mt)[1]),P=it>=2);let ft=null,O={};const V=r.getParameter(r.SCISSOR_BOX),dt=r.getParameter(r.VIEWPORT),gt=new an().fromArray(V),Mt=new an().fromArray(dt);function rt(G,Rt,Tt,Bt){const bt=new Uint8Array(4),At=r.createTexture();r.bindTexture(G,At),r.texParameteri(G,r.TEXTURE_MIN_FILTER,r.NEAREST),r.texParameteri(G,r.TEXTURE_MAG_FILTER,r.NEAREST);for(let Wt=0;Wt<Tt;Wt++)G===r.TEXTURE_3D||G===r.TEXTURE_2D_ARRAY?r.texImage3D(Rt,0,r.RGBA,1,1,Bt,0,r.RGBA,r.UNSIGNED_BYTE,bt):r.texImage2D(Rt+Wt,0,r.RGBA,1,1,0,r.RGBA,r.UNSIGNED_BYTE,bt);return At}const vt={};vt[r.TEXTURE_2D]=rt(r.TEXTURE_2D,r.TEXTURE_2D,1),vt[r.TEXTURE_CUBE_MAP]=rt(r.TEXTURE_CUBE_MAP,r.TEXTURE_CUBE_MAP_POSITIVE_X,6),vt[r.TEXTURE_2D_ARRAY]=rt(r.TEXTURE_2D_ARRAY,r.TEXTURE_2D_ARRAY,1,1),vt[r.TEXTURE_3D]=rt(r.TEXTURE_3D,r.TEXTURE_3D,1,1),c.setClear(0,0,0,1),f.setClear(1),T.setClear(0),Nt(r.DEPTH_TEST),f.setFunc(kr),sn(!1),ke(fm),Nt(r.CULL_FACE),Ie(Da);function Nt(G){m[G]!==!0&&(r.enable(G),m[G]=!0)}function Pt(G){m[G]!==!1&&(r.disable(G),m[G]=!1)}function Jt(G,Rt){return S[G]!==Rt?(r.bindFramebuffer(G,Rt),S[G]=Rt,G===r.DRAW_FRAMEBUFFER&&(S[r.FRAMEBUFFER]=Rt),G===r.FRAMEBUFFER&&(S[r.DRAW_FRAMEBUFFER]=Rt),!0):!1}function Qt(G,Rt){let Tt=A,Bt=!1;if(G){Tt=g.get(Rt),Tt===void 0&&(Tt=[],g.set(Rt,Tt));const bt=G.textures;if(Tt.length!==bt.length||Tt[0]!==r.COLOR_ATTACHMENT0){for(let At=0,Wt=bt.length;At<Wt;At++)Tt[At]=r.COLOR_ATTACHMENT0+At;Tt.length=bt.length,Bt=!0}}else Tt[0]!==r.BACK&&(Tt[0]=r.BACK,Bt=!0);Bt&&r.drawBuffers(Tt)}function ze(G){return M!==G?(r.useProgram(G),M=G,!0):!1}const fe={[Vs]:r.FUNC_ADD,[y_]:r.FUNC_SUBTRACT,[D_]:r.FUNC_REVERSE_SUBTRACT};fe[O_]=r.MIN,fe[b_]=r.MAX;const Ee={[I_]:r.ZERO,[L_]:r.ONE,[U_]:r.SRC_COLOR,[sd]:r.SRC_ALPHA,[H_]:r.SRC_ALPHA_SATURATE,[X_]:r.DST_COLOR,[w_]:r.DST_ALPHA,[F_]:r.ONE_MINUS_SRC_COLOR,[rd]:r.ONE_MINUS_SRC_ALPHA,[P_]:r.ONE_MINUS_DST_COLOR,[B_]:r.ONE_MINUS_DST_ALPHA,[Y_]:r.CONSTANT_COLOR,[G_]:r.ONE_MINUS_CONSTANT_COLOR,[z_]:r.CONSTANT_ALPHA,[V_]:r.ONE_MINUS_CONSTANT_ALPHA};function Ie(G,Rt,Tt,Bt,bt,At,Wt,te,tn,ye){if(G===Da){x===!0&&(Pt(r.BLEND),x=!1);return}if(x===!1&&(Nt(r.BLEND),x=!0),G!==C_){if(G!==v||ye!==Z){if((D!==Vs||Y!==Vs)&&(r.blendEquation(r.FUNC_ADD),D=Vs,Y=Vs),ye)switch(G){case Vr:r.blendFuncSeparate(r.ONE,r.ONE_MINUS_SRC_ALPHA,r.ONE,r.ONE_MINUS_SRC_ALPHA);break;case hm:r.blendFunc(r.ONE,r.ONE);break;case dm:r.blendFuncSeparate(r.ZERO,r.ONE_MINUS_SRC_COLOR,r.ZERO,r.ONE);break;case pm:r.blendFuncSeparate(r.DST_COLOR,r.ONE_MINUS_SRC_ALPHA,r.ZERO,r.ONE);break;default:Ne("WebGLState: Invalid blending: ",G);break}else switch(G){case Vr:r.blendFuncSeparate(r.SRC_ALPHA,r.ONE_MINUS_SRC_ALPHA,r.ONE,r.ONE_MINUS_SRC_ALPHA);break;case hm:r.blendFuncSeparate(r.SRC_ALPHA,r.ONE,r.ONE,r.ONE);break;case dm:Ne("WebGLState: SubtractiveBlending requires material.premultipliedAlpha = true");break;case pm:Ne("WebGLState: MultiplyBlending requires material.premultipliedAlpha = true");break;default:Ne("WebGLState: Invalid blending: ",G);break}I=null,U=null,F=null,B=null,R.set(0,0,0),w=0,v=G,Z=ye}return}bt=bt||Rt,At=At||Tt,Wt=Wt||Bt,(Rt!==D||bt!==Y)&&(r.blendEquationSeparate(fe[Rt],fe[bt]),D=Rt,Y=bt),(Tt!==I||Bt!==U||At!==F||Wt!==B)&&(r.blendFuncSeparate(Ee[Tt],Ee[Bt],Ee[At],Ee[Wt]),I=Tt,U=Bt,F=At,B=Wt),(te.equals(R)===!1||tn!==w)&&(r.blendColor(te.r,te.g,te.b,tn),R.copy(te),w=tn),v=G,Z=!1}function le(G,Rt){G.side===Zi?Pt(r.CULL_FACE):Nt(r.CULL_FACE);let Tt=G.side===ti;Rt&&(Tt=!Tt),sn(Tt),G.blending===Vr&&G.transparent===!1?Ie(Da):Ie(G.blending,G.blendEquation,G.blendSrc,G.blendDst,G.blendEquationAlpha,G.blendSrcAlpha,G.blendDstAlpha,G.blendColor,G.blendAlpha,G.premultipliedAlpha),f.setFunc(G.depthFunc),f.setTest(G.depthTest),f.setMask(G.depthWrite),c.setMask(G.colorWrite);const Bt=G.stencilWrite;T.setTest(Bt),Bt&&(T.setMask(G.stencilWriteMask),T.setFunc(G.stencilFunc,G.stencilRef,G.stencilFuncMask),T.setOp(G.stencilFail,G.stencilZFail,G.stencilZPass)),k(G.polygonOffset,G.polygonOffsetFactor,G.polygonOffsetUnits),G.alphaToCoverage===!0?Nt(r.SAMPLE_ALPHA_TO_COVERAGE):Pt(r.SAMPLE_ALPHA_TO_COVERAGE)}function sn(G){H!==G&&(G?r.frontFace(r.CW):r.frontFace(r.CCW),H=G)}function ke(G){G!==M_?(Nt(r.CULL_FACE),G!==$&&(G===fm?r.cullFace(r.BACK):G===R_?r.cullFace(r.FRONT):r.cullFace(r.FRONT_AND_BACK))):Pt(r.CULL_FACE),$=G}function Mn(G){G!==ct&&(P&&r.lineWidth(G),ct=G)}function k(G,Rt,Tt){G?(Nt(r.POLYGON_OFFSET_FILL),(lt!==Rt||W!==Tt)&&(lt=Rt,W=Tt,f.getReversed()&&(Rt=-Rt),r.polygonOffset(Rt,Tt))):Pt(r.POLYGON_OFFSET_FILL)}function Je(G){G?Nt(r.SCISSOR_TEST):Pt(r.SCISSOR_TEST)}function he(G){G===void 0&&(G=r.TEXTURE0+L-1),ft!==G&&(r.activeTexture(G),ft=G)}function Pe(G,Rt,Tt){Tt===void 0&&(ft===null?Tt=r.TEXTURE0+L-1:Tt=ft);let Bt=O[Tt];Bt===void 0&&(Bt={type:void 0,texture:void 0},O[Tt]=Bt),(Bt.type!==G||Bt.texture!==Rt)&&(ft!==Tt&&(r.activeTexture(Tt),ft=Tt),r.bindTexture(G,Rt||vt[G]),Bt.type=G,Bt.texture=Rt)}function Ct(){const G=O[ft];G!==void 0&&G.type!==void 0&&(r.bindTexture(G.type,null),G.type=void 0,G.texture=void 0)}function qe(){try{r.compressedTexImage2D(...arguments)}catch(G){Ne("WebGLState:",G)}}function b(){try{r.compressedTexImage3D(...arguments)}catch(G){Ne("WebGLState:",G)}}function N(){try{r.texSubImage2D(...arguments)}catch(G){Ne("WebGLState:",G)}}function Q(){try{r.texSubImage3D(...arguments)}catch(G){Ne("WebGLState:",G)}}function St(){try{r.compressedTexSubImage2D(...arguments)}catch(G){Ne("WebGLState:",G)}}function xt(){try{r.compressedTexSubImage3D(...arguments)}catch(G){Ne("WebGLState:",G)}}function yt(){try{r.texStorage2D(...arguments)}catch(G){Ne("WebGLState:",G)}}function It(){try{r.texStorage3D(...arguments)}catch(G){Ne("WebGLState:",G)}}function ut(){try{r.texImage2D(...arguments)}catch(G){Ne("WebGLState:",G)}}function ht(){try{r.texImage3D(...arguments)}catch(G){Ne("WebGLState:",G)}}function Lt(G){return E[G]!==void 0?E[G]:r.getParameter(G)}function Ut(G,Rt){E[G]!==Rt&&(r.pixelStorei(G,Rt),E[G]=Rt)}function Ot(G){gt.equals(G)===!1&&(r.scissor(G.x,G.y,G.z,G.w),gt.copy(G))}function Dt(G){Mt.equals(G)===!1&&(r.viewport(G.x,G.y,G.z,G.w),Mt.copy(G))}function ne(G,Rt){let Tt=h.get(Rt);Tt===void 0&&(Tt=new WeakMap,h.set(Rt,Tt));let Bt=Tt.get(G);Bt===void 0&&(Bt=r.getUniformBlockIndex(Rt,G.name),Tt.set(G,Bt))}function ie(G,Rt){const Bt=h.get(Rt).get(G);p.get(Rt)!==Bt&&(r.uniformBlockBinding(Rt,Bt,G.__bindingPointIndex),p.set(Rt,Bt))}function de(){r.disable(r.BLEND),r.disable(r.CULL_FACE),r.disable(r.DEPTH_TEST),r.disable(r.POLYGON_OFFSET_FILL),r.disable(r.SCISSOR_TEST),r.disable(r.STENCIL_TEST),r.disable(r.SAMPLE_ALPHA_TO_COVERAGE),r.blendEquation(r.FUNC_ADD),r.blendFunc(r.ONE,r.ZERO),r.blendFuncSeparate(r.ONE,r.ZERO,r.ONE,r.ZERO),r.blendColor(0,0,0,0),r.colorMask(!0,!0,!0,!0),r.clearColor(0,0,0,0),r.depthMask(!0),r.depthFunc(r.LESS),f.setReversed(!1),r.clearDepth(1),r.stencilMask(4294967295),r.stencilFunc(r.ALWAYS,0,4294967295),r.stencilOp(r.KEEP,r.KEEP,r.KEEP),r.clearStencil(0),r.cullFace(r.BACK),r.frontFace(r.CCW),r.polygonOffset(0,0),r.activeTexture(r.TEXTURE0),r.bindFramebuffer(r.FRAMEBUFFER,null),r.bindFramebuffer(r.DRAW_FRAMEBUFFER,null),r.bindFramebuffer(r.READ_FRAMEBUFFER,null),r.useProgram(null),r.lineWidth(1),r.scissor(0,0,r.canvas.width,r.canvas.height),r.viewport(0,0,r.canvas.width,r.canvas.height),r.pixelStorei(r.PACK_ALIGNMENT,4),r.pixelStorei(r.UNPACK_ALIGNMENT,4),r.pixelStorei(r.UNPACK_FLIP_Y_WEBGL,!1),r.pixelStorei(r.UNPACK_PREMULTIPLY_ALPHA_WEBGL,!1),r.pixelStorei(r.UNPACK_COLORSPACE_CONVERSION_WEBGL,r.BROWSER_DEFAULT_WEBGL),r.pixelStorei(r.PACK_ROW_LENGTH,0),r.pixelStorei(r.PACK_SKIP_PIXELS,0),r.pixelStorei(r.PACK_SKIP_ROWS,0),r.pixelStorei(r.UNPACK_ROW_LENGTH,0),r.pixelStorei(r.UNPACK_IMAGE_HEIGHT,0),r.pixelStorei(r.UNPACK_SKIP_PIXELS,0),r.pixelStorei(r.UNPACK_SKIP_ROWS,0),r.pixelStorei(r.UNPACK_SKIP_IMAGES,0),m={},E={},ft=null,O={},S={},g=new WeakMap,A=[],M=null,x=!1,v=null,D=null,I=null,U=null,Y=null,F=null,B=null,R=new _e(0,0,0),w=0,Z=!1,H=null,$=null,ct=null,lt=null,W=null,gt.set(0,0,r.canvas.width,r.canvas.height),Mt.set(0,0,r.canvas.width,r.canvas.height),c.reset(),f.reset(),T.reset()}return{buffers:{color:c,depth:f,stencil:T},enable:Nt,disable:Pt,bindFramebuffer:Jt,drawBuffers:Qt,useProgram:ze,setBlending:Ie,setMaterial:le,setFlipSided:sn,setCullFace:ke,setLineWidth:Mn,setPolygonOffset:k,setScissorTest:Je,activeTexture:he,bindTexture:Pe,unbindTexture:Ct,compressedTexImage2D:qe,compressedTexImage3D:b,texImage2D:ut,texImage3D:ht,pixelStorei:Ut,getParameter:Lt,updateUBOMapping:ne,uniformBlockBinding:ie,texStorage2D:yt,texStorage3D:It,texSubImage2D:N,texSubImage3D:Q,compressedTexSubImage2D:St,compressedTexSubImage3D:xt,scissor:Ot,viewport:Dt,reset:de}}function OM(r,t,i,s,l,c,f){const T=t.has("WEBGL_multisampled_render_to_texture")?t.get("WEBGL_multisampled_render_to_texture"):null,p=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),h=new Oe,m=new WeakMap,E=new Set;let S;const g=new WeakMap;let A=!1;try{A=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function M(b,N){return A?new OffscreenCanvas(b,N):iu("canvas")}function x(b,N,Q){let St=1;const xt=qe(b);if((xt.width>Q||xt.height>Q)&&(St=Q/Math.max(xt.width,xt.height)),St<1)if(typeof HTMLImageElement<"u"&&b instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&b instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&b instanceof ImageBitmap||typeof VideoFrame<"u"&&b instanceof VideoFrame){const yt=Math.floor(St*xt.width),It=Math.floor(St*xt.height);S===void 0&&(S=M(yt,It));const ut=N?M(yt,It):S;return ut.width=yt,ut.height=It,ut.getContext("2d").drawImage(b,0,0,yt,It),ee("WebGLRenderer: Texture has been resized from ("+xt.width+"x"+xt.height+") to ("+yt+"x"+It+")."),ut}else return"data"in b&&ee("WebGLRenderer: Image in DataTexture is too big ("+xt.width+"x"+xt.height+")."),b;return b}function v(b){return b.generateMipmaps}function D(b){r.generateMipmap(b)}function I(b){return b.isWebGLCubeRenderTarget?r.TEXTURE_CUBE_MAP:b.isWebGL3DRenderTarget?r.TEXTURE_3D:b.isWebGLArrayRenderTarget||b.isCompressedArrayTexture?r.TEXTURE_2D_ARRAY:r.TEXTURE_2D}function U(b,N,Q,St,xt,yt=!1){if(b!==null){if(r[b]!==void 0)return r[b];ee("WebGLRenderer: Attempt to use non-existing WebGL internal format '"+b+"'")}let It;St&&(It=t.get("EXT_texture_norm16"),It||ee("WebGLRenderer: Unable to use normalized textures without EXT_texture_norm16 extension"));let ut=N;if(N===r.RED&&(Q===r.FLOAT&&(ut=r.R32F),Q===r.HALF_FLOAT&&(ut=r.R16F),Q===r.UNSIGNED_BYTE&&(ut=r.R8),Q===r.UNSIGNED_SHORT&&It&&(ut=It.R16_EXT),Q===r.SHORT&&It&&(ut=It.R16_SNORM_EXT)),N===r.RED_INTEGER&&(Q===r.UNSIGNED_BYTE&&(ut=r.R8UI),Q===r.UNSIGNED_SHORT&&(ut=r.R16UI),Q===r.UNSIGNED_INT&&(ut=r.R32UI),Q===r.BYTE&&(ut=r.R8I),Q===r.SHORT&&(ut=r.R16I),Q===r.INT&&(ut=r.R32I)),N===r.RG&&(Q===r.FLOAT&&(ut=r.RG32F),Q===r.HALF_FLOAT&&(ut=r.RG16F),Q===r.UNSIGNED_BYTE&&(ut=r.RG8),Q===r.UNSIGNED_SHORT&&It&&(ut=It.RG16_EXT),Q===r.SHORT&&It&&(ut=It.RG16_SNORM_EXT)),N===r.RG_INTEGER&&(Q===r.UNSIGNED_BYTE&&(ut=r.RG8UI),Q===r.UNSIGNED_SHORT&&(ut=r.RG16UI),Q===r.UNSIGNED_INT&&(ut=r.RG32UI),Q===r.BYTE&&(ut=r.RG8I),Q===r.SHORT&&(ut=r.RG16I),Q===r.INT&&(ut=r.RG32I)),N===r.RGB_INTEGER&&(Q===r.UNSIGNED_BYTE&&(ut=r.RGB8UI),Q===r.UNSIGNED_SHORT&&(ut=r.RGB16UI),Q===r.UNSIGNED_INT&&(ut=r.RGB32UI),Q===r.BYTE&&(ut=r.RGB8I),Q===r.SHORT&&(ut=r.RGB16I),Q===r.INT&&(ut=r.RGB32I)),N===r.RGBA_INTEGER&&(Q===r.UNSIGNED_BYTE&&(ut=r.RGBA8UI),Q===r.UNSIGNED_SHORT&&(ut=r.RGBA16UI),Q===r.UNSIGNED_INT&&(ut=r.RGBA32UI),Q===r.BYTE&&(ut=r.RGBA8I),Q===r.SHORT&&(ut=r.RGBA16I),Q===r.INT&&(ut=r.RGBA32I)),N===r.RGB&&(Q===r.UNSIGNED_SHORT&&It&&(ut=It.RGB16_EXT),Q===r.SHORT&&It&&(ut=It.RGB16_SNORM_EXT),Q===r.UNSIGNED_INT_5_9_9_9_REV&&(ut=r.RGB9_E5),Q===r.UNSIGNED_INT_10F_11F_11F_REV&&(ut=r.R11F_G11F_B10F)),N===r.RGBA){const ht=yt?nu:Ae.getTransfer(xt);Q===r.FLOAT&&(ut=r.RGBA32F),Q===r.HALF_FLOAT&&(ut=r.RGBA16F),Q===r.UNSIGNED_BYTE&&(ut=ht===Xe?r.SRGB8_ALPHA8:r.RGBA8),Q===r.UNSIGNED_SHORT&&It&&(ut=It.RGBA16_EXT),Q===r.SHORT&&It&&(ut=It.RGBA16_SNORM_EXT),Q===r.UNSIGNED_SHORT_4_4_4_4&&(ut=r.RGBA4),Q===r.UNSIGNED_SHORT_5_5_5_1&&(ut=r.RGB5_A1)}return(ut===r.R16F||ut===r.R32F||ut===r.RG16F||ut===r.RG32F||ut===r.RGBA16F||ut===r.RGBA32F)&&t.get("EXT_color_buffer_float"),ut}function Y(b,N){let Q;return b?N===null||N===ta||N===ol?Q=r.DEPTH24_STENCIL8:N===qi?Q=r.DEPTH32F_STENCIL8:N===rl&&(Q=r.DEPTH24_STENCIL8,ee("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):N===null||N===ta||N===ol?Q=r.DEPTH_COMPONENT24:N===qi?Q=r.DEPTH_COMPONENT32F:N===rl&&(Q=r.DEPTH_COMPONENT16),Q}function F(b,N){return v(b)===!0||b.isFramebufferTexture&&b.minFilter!==In&&b.minFilter!==Nn?Math.log2(Math.max(N.width,N.height))+1:b.mipmaps!==void 0&&b.mipmaps.length>0?b.mipmaps.length:b.isCompressedTexture&&Array.isArray(b.image)?N.mipmaps.length:1}function B(b){const N=b.target;N.removeEventListener("dispose",B),w(N),N.isVideoTexture&&m.delete(N),N.isHTMLTexture&&E.delete(N)}function R(b){const N=b.target;N.removeEventListener("dispose",R),H(N)}function w(b){const N=s.get(b);if(N.__webglInit===void 0)return;const Q=b.source,St=g.get(Q);if(St){const xt=St[N.__cacheKey];xt.usedTimes--,xt.usedTimes===0&&Z(b),Object.keys(St).length===0&&g.delete(Q)}s.remove(b)}function Z(b){const N=s.get(b);r.deleteTexture(N.__webglTexture);const Q=b.source,St=g.get(Q);delete St[N.__cacheKey],f.memory.textures--}function H(b){const N=s.get(b);if(b.depthTexture&&(b.depthTexture.dispose(),s.remove(b.depthTexture)),b.isWebGLCubeRenderTarget)for(let St=0;St<6;St++){if(Array.isArray(N.__webglFramebuffer[St]))for(let xt=0;xt<N.__webglFramebuffer[St].length;xt++)r.deleteFramebuffer(N.__webglFramebuffer[St][xt]);else r.deleteFramebuffer(N.__webglFramebuffer[St]);N.__webglDepthbuffer&&r.deleteRenderbuffer(N.__webglDepthbuffer[St])}else{if(Array.isArray(N.__webglFramebuffer))for(let St=0;St<N.__webglFramebuffer.length;St++)r.deleteFramebuffer(N.__webglFramebuffer[St]);else r.deleteFramebuffer(N.__webglFramebuffer);if(N.__webglDepthbuffer&&r.deleteRenderbuffer(N.__webglDepthbuffer),N.__webglMultisampledFramebuffer&&r.deleteFramebuffer(N.__webglMultisampledFramebuffer),N.__webglColorRenderbuffer)for(let St=0;St<N.__webglColorRenderbuffer.length;St++)N.__webglColorRenderbuffer[St]&&r.deleteRenderbuffer(N.__webglColorRenderbuffer[St]);N.__webglDepthRenderbuffer&&r.deleteRenderbuffer(N.__webglDepthRenderbuffer)}const Q=b.textures;for(let St=0,xt=Q.length;St<xt;St++){const yt=s.get(Q[St]);yt.__webglTexture&&(r.deleteTexture(yt.__webglTexture),f.memory.textures--),s.remove(Q[St])}s.remove(b)}let $=0;function ct(){$=0}function lt(){return $}function W(b){$=b}function L(){const b=$;return b>=l.maxTextures&&ee("WebGLTextures: Trying to use "+b+" texture units while this GPU supports only "+l.maxTextures),$+=1,b}function P(b){const N=[];return N.push(b.wrapS),N.push(b.wrapT),N.push(b.wrapR||0),N.push(b.magFilter),N.push(b.minFilter),N.push(b.anisotropy),N.push(b.internalFormat),N.push(b.format),N.push(b.type),N.push(b.generateMipmaps),N.push(b.premultiplyAlpha),N.push(b.flipY),N.push(b.unpackAlignment),N.push(b.colorSpace),N.join()}function it(b,N){const Q=s.get(b);if(b.isVideoTexture&&Pe(b),b.isRenderTargetTexture===!1&&b.isExternalTexture!==!0&&b.version>0&&Q.__version!==b.version){const St=b.image;if(St===null)ee("WebGLRenderer: Texture marked for update but no image data found.");else if(St.complete===!1)ee("WebGLRenderer: Texture marked for update but image is incomplete");else{Pt(Q,b,N);return}}else b.isExternalTexture&&(Q.__webglTexture=b.sourceTexture?b.sourceTexture:null);i.bindTexture(r.TEXTURE_2D,Q.__webglTexture,r.TEXTURE0+N)}function mt(b,N){const Q=s.get(b);if(b.isRenderTargetTexture===!1&&b.version>0&&Q.__version!==b.version){Pt(Q,b,N);return}else b.isExternalTexture&&(Q.__webglTexture=b.sourceTexture?b.sourceTexture:null);i.bindTexture(r.TEXTURE_2D_ARRAY,Q.__webglTexture,r.TEXTURE0+N)}function ft(b,N){const Q=s.get(b);if(b.isRenderTargetTexture===!1&&b.version>0&&Q.__version!==b.version){Pt(Q,b,N);return}i.bindTexture(r.TEXTURE_3D,Q.__webglTexture,r.TEXTURE0+N)}function O(b,N){const Q=s.get(b);if(b.isCubeDepthTexture!==!0&&b.version>0&&Q.__version!==b.version){Jt(Q,b,N);return}i.bindTexture(r.TEXTURE_CUBE_MAP,Q.__webglTexture,r.TEXTURE0+N)}const V={[pd]:r.REPEAT,[ya]:r.CLAMP_TO_EDGE,[Td]:r.MIRRORED_REPEAT},dt={[In]:r.NEAREST,[K_]:r.NEAREST_MIPMAP_NEAREST,[Ac]:r.NEAREST_MIPMAP_LINEAR,[Nn]:r.LINEAR,[Ah]:r.LINEAR_MIPMAP_NEAREST,[ks]:r.LINEAR_MIPMAP_LINEAR},gt={[$_]:r.NEVER,[e2]:r.ALWAYS,[Q_]:r.LESS,[u0]:r.LEQUAL,[j_]:r.EQUAL,[f0]:r.GEQUAL,[J_]:r.GREATER,[t2]:r.NOTEQUAL};function Mt(b,N){if(N.type===qi&&t.has("OES_texture_float_linear")===!1&&(N.magFilter===Nn||N.magFilter===Ah||N.magFilter===Ac||N.magFilter===ks||N.minFilter===Nn||N.minFilter===Ah||N.minFilter===Ac||N.minFilter===ks)&&ee("WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),r.texParameteri(b,r.TEXTURE_WRAP_S,V[N.wrapS]),r.texParameteri(b,r.TEXTURE_WRAP_T,V[N.wrapT]),(b===r.TEXTURE_3D||b===r.TEXTURE_2D_ARRAY)&&r.texParameteri(b,r.TEXTURE_WRAP_R,V[N.wrapR]),r.texParameteri(b,r.TEXTURE_MAG_FILTER,dt[N.magFilter]),r.texParameteri(b,r.TEXTURE_MIN_FILTER,dt[N.minFilter]),N.compareFunction&&(r.texParameteri(b,r.TEXTURE_COMPARE_MODE,r.COMPARE_REF_TO_TEXTURE),r.texParameteri(b,r.TEXTURE_COMPARE_FUNC,gt[N.compareFunction])),t.has("EXT_texture_filter_anisotropic")===!0){if(N.magFilter===In||N.minFilter!==Ac&&N.minFilter!==ks||N.type===qi&&t.has("OES_texture_float_linear")===!1)return;if(N.anisotropy>1||s.get(N).__currentAnisotropy){const Q=t.get("EXT_texture_filter_anisotropic");r.texParameterf(b,Q.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(N.anisotropy,l.getMaxAnisotropy())),s.get(N).__currentAnisotropy=N.anisotropy}}}function rt(b,N){let Q=!1;b.__webglInit===void 0&&(b.__webglInit=!0,N.addEventListener("dispose",B));const St=N.source;let xt=g.get(St);xt===void 0&&(xt={},g.set(St,xt));const yt=P(N);if(yt!==b.__cacheKey){xt[yt]===void 0&&(xt[yt]={texture:r.createTexture(),usedTimes:0},f.memory.textures++,Q=!0),xt[yt].usedTimes++;const It=xt[b.__cacheKey];It!==void 0&&(xt[b.__cacheKey].usedTimes--,It.usedTimes===0&&Z(N)),b.__cacheKey=yt,b.__webglTexture=xt[yt].texture}return Q}function vt(b,N,Q){return Math.floor(Math.floor(b/Q)/N)}function Nt(b,N,Q,St){const yt=b.updateRanges;if(yt.length===0)i.texSubImage2D(r.TEXTURE_2D,0,0,0,N.width,N.height,Q,St,N.data);else{yt.sort((Ut,Ot)=>Ut.start-Ot.start);let It=0;for(let Ut=1;Ut<yt.length;Ut++){const Ot=yt[It],Dt=yt[Ut],ne=Ot.start+Ot.count,ie=vt(Dt.start,N.width,4),de=vt(Ot.start,N.width,4);Dt.start<=ne+1&&ie===de&&vt(Dt.start+Dt.count-1,N.width,4)===ie?Ot.count=Math.max(Ot.count,Dt.start+Dt.count-Ot.start):(++It,yt[It]=Dt)}yt.length=It+1;const ut=i.getParameter(r.UNPACK_ROW_LENGTH),ht=i.getParameter(r.UNPACK_SKIP_PIXELS),Lt=i.getParameter(r.UNPACK_SKIP_ROWS);i.pixelStorei(r.UNPACK_ROW_LENGTH,N.width);for(let Ut=0,Ot=yt.length;Ut<Ot;Ut++){const Dt=yt[Ut],ne=Math.floor(Dt.start/4),ie=Math.ceil(Dt.count/4),de=ne%N.width,G=Math.floor(ne/N.width),Rt=ie,Tt=1;i.pixelStorei(r.UNPACK_SKIP_PIXELS,de),i.pixelStorei(r.UNPACK_SKIP_ROWS,G),i.texSubImage2D(r.TEXTURE_2D,0,de,G,Rt,Tt,Q,St,N.data)}b.clearUpdateRanges(),i.pixelStorei(r.UNPACK_ROW_LENGTH,ut),i.pixelStorei(r.UNPACK_SKIP_PIXELS,ht),i.pixelStorei(r.UNPACK_SKIP_ROWS,Lt)}}function Pt(b,N,Q){let St=r.TEXTURE_2D;(N.isDataArrayTexture||N.isCompressedArrayTexture)&&(St=r.TEXTURE_2D_ARRAY),N.isData3DTexture&&(St=r.TEXTURE_3D);const xt=rt(b,N),yt=N.source;i.bindTexture(St,b.__webglTexture,r.TEXTURE0+Q);const It=s.get(yt);if(yt.version!==It.__version||xt===!0){if(i.activeTexture(r.TEXTURE0+Q),(typeof ImageBitmap<"u"&&N.image instanceof ImageBitmap)===!1){const Tt=Ae.getPrimaries(Ae.workingColorSpace),Bt=N.colorSpace===Ts?null:Ae.getPrimaries(N.colorSpace),bt=N.colorSpace===Ts||Tt===Bt?r.NONE:r.BROWSER_DEFAULT_WEBGL;i.pixelStorei(r.UNPACK_FLIP_Y_WEBGL,N.flipY),i.pixelStorei(r.UNPACK_PREMULTIPLY_ALPHA_WEBGL,N.premultiplyAlpha),i.pixelStorei(r.UNPACK_COLORSPACE_CONVERSION_WEBGL,bt)}i.pixelStorei(r.UNPACK_ALIGNMENT,N.unpackAlignment);let ht=x(N.image,!1,l.maxTextureSize);ht=Ct(N,ht);const Lt=c.convert(N.format,N.colorSpace),Ut=c.convert(N.type);let Ot=U(N.internalFormat,Lt,Ut,N.normalized,N.colorSpace,N.isVideoTexture);Mt(St,N);let Dt;const ne=N.mipmaps,ie=N.isVideoTexture!==!0,de=It.__version===void 0||xt===!0,G=yt.dataReady,Rt=F(N,ht);if(N.isDepthTexture)Ot=Y(N.format===Ks,N.type),de&&(ie?i.texStorage2D(r.TEXTURE_2D,1,Ot,ht.width,ht.height):i.texImage2D(r.TEXTURE_2D,0,Ot,ht.width,ht.height,0,Lt,Ut,null));else if(N.isDataTexture)if(ne.length>0){ie&&de&&i.texStorage2D(r.TEXTURE_2D,Rt,Ot,ne[0].width,ne[0].height);for(let Tt=0,Bt=ne.length;Tt<Bt;Tt++)Dt=ne[Tt],ie?G&&i.texSubImage2D(r.TEXTURE_2D,Tt,0,0,Dt.width,Dt.height,Lt,Ut,Dt.data):i.texImage2D(r.TEXTURE_2D,Tt,Ot,Dt.width,Dt.height,0,Lt,Ut,Dt.data);N.generateMipmaps=!1}else ie?(de&&i.texStorage2D(r.TEXTURE_2D,Rt,Ot,ht.width,ht.height),G&&Nt(N,ht,Lt,Ut)):i.texImage2D(r.TEXTURE_2D,0,Ot,ht.width,ht.height,0,Lt,Ut,ht.data);else if(N.isCompressedTexture)if(N.isCompressedArrayTexture){ie&&de&&i.texStorage3D(r.TEXTURE_2D_ARRAY,Rt,Ot,ne[0].width,ne[0].height,ht.depth);for(let Tt=0,Bt=ne.length;Tt<Bt;Tt++)if(Dt=ne[Tt],N.format!==Fi)if(Lt!==null)if(ie){if(G)if(N.layerUpdates.size>0){const bt=Ym(Dt.width,Dt.height,N.format,N.type);for(const At of N.layerUpdates){const Wt=Dt.data.subarray(At*bt/Dt.data.BYTES_PER_ELEMENT,(At+1)*bt/Dt.data.BYTES_PER_ELEMENT);i.compressedTexSubImage3D(r.TEXTURE_2D_ARRAY,Tt,0,0,At,Dt.width,Dt.height,1,Lt,Wt)}N.clearLayerUpdates()}else i.compressedTexSubImage3D(r.TEXTURE_2D_ARRAY,Tt,0,0,0,Dt.width,Dt.height,ht.depth,Lt,Dt.data)}else i.compressedTexImage3D(r.TEXTURE_2D_ARRAY,Tt,Ot,Dt.width,Dt.height,ht.depth,0,Dt.data,0,0);else ee("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else ie?G&&i.texSubImage3D(r.TEXTURE_2D_ARRAY,Tt,0,0,0,Dt.width,Dt.height,ht.depth,Lt,Ut,Dt.data):i.texImage3D(r.TEXTURE_2D_ARRAY,Tt,Ot,Dt.width,Dt.height,ht.depth,0,Lt,Ut,Dt.data)}else{ie&&de&&i.texStorage2D(r.TEXTURE_2D,Rt,Ot,ne[0].width,ne[0].height);for(let Tt=0,Bt=ne.length;Tt<Bt;Tt++)Dt=ne[Tt],N.format!==Fi?Lt!==null?ie?G&&i.compressedTexSubImage2D(r.TEXTURE_2D,Tt,0,0,Dt.width,Dt.height,Lt,Dt.data):i.compressedTexImage2D(r.TEXTURE_2D,Tt,Ot,Dt.width,Dt.height,0,Dt.data):ee("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):ie?G&&i.texSubImage2D(r.TEXTURE_2D,Tt,0,0,Dt.width,Dt.height,Lt,Ut,Dt.data):i.texImage2D(r.TEXTURE_2D,Tt,Ot,Dt.width,Dt.height,0,Lt,Ut,Dt.data)}else if(N.isDataArrayTexture)if(ie){if(de&&i.texStorage3D(r.TEXTURE_2D_ARRAY,Rt,Ot,ht.width,ht.height,ht.depth),G)if(N.layerUpdates.size>0){const Tt=Ym(ht.width,ht.height,N.format,N.type);for(const Bt of N.layerUpdates){const bt=ht.data.subarray(Bt*Tt/ht.data.BYTES_PER_ELEMENT,(Bt+1)*Tt/ht.data.BYTES_PER_ELEMENT);i.texSubImage3D(r.TEXTURE_2D_ARRAY,0,0,0,Bt,ht.width,ht.height,1,Lt,Ut,bt)}N.clearLayerUpdates()}else i.texSubImage3D(r.TEXTURE_2D_ARRAY,0,0,0,0,ht.width,ht.height,ht.depth,Lt,Ut,ht.data)}else i.texImage3D(r.TEXTURE_2D_ARRAY,0,Ot,ht.width,ht.height,ht.depth,0,Lt,Ut,ht.data);else if(N.isData3DTexture)ie?(de&&i.texStorage3D(r.TEXTURE_3D,Rt,Ot,ht.width,ht.height,ht.depth),G&&i.texSubImage3D(r.TEXTURE_3D,0,0,0,0,ht.width,ht.height,ht.depth,Lt,Ut,ht.data)):i.texImage3D(r.TEXTURE_3D,0,Ot,ht.width,ht.height,ht.depth,0,Lt,Ut,ht.data);else if(N.isFramebufferTexture){if(de)if(ie)i.texStorage2D(r.TEXTURE_2D,Rt,Ot,ht.width,ht.height);else{let Tt=ht.width,Bt=ht.height;for(let bt=0;bt<Rt;bt++)i.texImage2D(r.TEXTURE_2D,bt,Ot,Tt,Bt,0,Lt,Ut,null),Tt>>=1,Bt>>=1}}else if(N.isHTMLTexture){if("texElementImage2D"in r){const Tt=r.canvas;if(Tt.hasAttribute("layoutsubtree")||Tt.setAttribute("layoutsubtree","true"),ht.parentNode!==Tt){Tt.appendChild(ht),E.add(N),Tt.onpaint=te=>{const tn=te.changedElements;for(const ye of E)tn.includes(ye.image)&&(ye.needsUpdate=!0)},Tt.requestPaint();return}const Bt=0,bt=r.RGBA,At=r.RGBA,Wt=r.UNSIGNED_BYTE;r.texElementImage2D(r.TEXTURE_2D,Bt,bt,At,Wt,ht),r.texParameteri(r.TEXTURE_2D,r.TEXTURE_MIN_FILTER,r.LINEAR),r.texParameteri(r.TEXTURE_2D,r.TEXTURE_WRAP_S,r.CLAMP_TO_EDGE),r.texParameteri(r.TEXTURE_2D,r.TEXTURE_WRAP_T,r.CLAMP_TO_EDGE)}}else if(ne.length>0){if(ie&&de){const Tt=qe(ne[0]);i.texStorage2D(r.TEXTURE_2D,Rt,Ot,Tt.width,Tt.height)}for(let Tt=0,Bt=ne.length;Tt<Bt;Tt++)Dt=ne[Tt],ie?G&&i.texSubImage2D(r.TEXTURE_2D,Tt,0,0,Lt,Ut,Dt):i.texImage2D(r.TEXTURE_2D,Tt,Ot,Lt,Ut,Dt);N.generateMipmaps=!1}else if(ie){if(de){const Tt=qe(ht);i.texStorage2D(r.TEXTURE_2D,Rt,Ot,Tt.width,Tt.height)}G&&i.texSubImage2D(r.TEXTURE_2D,0,0,0,Lt,Ut,ht)}else i.texImage2D(r.TEXTURE_2D,0,Ot,Lt,Ut,ht);v(N)&&D(St),It.__version=yt.version,N.onUpdate&&N.onUpdate(N)}b.__version=N.version}function Jt(b,N,Q){if(N.image.length!==6)return;const St=rt(b,N),xt=N.source;i.bindTexture(r.TEXTURE_CUBE_MAP,b.__webglTexture,r.TEXTURE0+Q);const yt=s.get(xt);if(xt.version!==yt.__version||St===!0){i.activeTexture(r.TEXTURE0+Q);const It=Ae.getPrimaries(Ae.workingColorSpace),ut=N.colorSpace===Ts?null:Ae.getPrimaries(N.colorSpace),ht=N.colorSpace===Ts||It===ut?r.NONE:r.BROWSER_DEFAULT_WEBGL;i.pixelStorei(r.UNPACK_FLIP_Y_WEBGL,N.flipY),i.pixelStorei(r.UNPACK_PREMULTIPLY_ALPHA_WEBGL,N.premultiplyAlpha),i.pixelStorei(r.UNPACK_ALIGNMENT,N.unpackAlignment),i.pixelStorei(r.UNPACK_COLORSPACE_CONVERSION_WEBGL,ht);const Lt=N.isCompressedTexture||N.image[0].isCompressedTexture,Ut=N.image[0]&&N.image[0].isDataTexture,Ot=[];for(let At=0;At<6;At++)!Lt&&!Ut?Ot[At]=x(N.image[At],!0,l.maxCubemapSize):Ot[At]=Ut?N.image[At].image:N.image[At],Ot[At]=Ct(N,Ot[At]);const Dt=Ot[0],ne=c.convert(N.format,N.colorSpace),ie=c.convert(N.type),de=U(N.internalFormat,ne,ie,N.normalized,N.colorSpace),G=N.isVideoTexture!==!0,Rt=yt.__version===void 0||St===!0,Tt=xt.dataReady;let Bt=F(N,Dt);Mt(r.TEXTURE_CUBE_MAP,N);let bt;if(Lt){G&&Rt&&i.texStorage2D(r.TEXTURE_CUBE_MAP,Bt,de,Dt.width,Dt.height);for(let At=0;At<6;At++){bt=Ot[At].mipmaps;for(let Wt=0;Wt<bt.length;Wt++){const te=bt[Wt];N.format!==Fi?ne!==null?G?Tt&&i.compressedTexSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+At,Wt,0,0,te.width,te.height,ne,te.data):i.compressedTexImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+At,Wt,de,te.width,te.height,0,te.data):ee("WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):G?Tt&&i.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+At,Wt,0,0,te.width,te.height,ne,ie,te.data):i.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+At,Wt,de,te.width,te.height,0,ne,ie,te.data)}}}else{if(bt=N.mipmaps,G&&Rt){bt.length>0&&Bt++;const At=qe(Ot[0]);i.texStorage2D(r.TEXTURE_CUBE_MAP,Bt,de,At.width,At.height)}for(let At=0;At<6;At++)if(Ut){G?Tt&&i.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+At,0,0,0,Ot[At].width,Ot[At].height,ne,ie,Ot[At].data):i.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+At,0,de,Ot[At].width,Ot[At].height,0,ne,ie,Ot[At].data);for(let Wt=0;Wt<bt.length;Wt++){const tn=bt[Wt].image[At].image;G?Tt&&i.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+At,Wt+1,0,0,tn.width,tn.height,ne,ie,tn.data):i.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+At,Wt+1,de,tn.width,tn.height,0,ne,ie,tn.data)}}else{G?Tt&&i.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+At,0,0,0,ne,ie,Ot[At]):i.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+At,0,de,ne,ie,Ot[At]);for(let Wt=0;Wt<bt.length;Wt++){const te=bt[Wt];G?Tt&&i.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+At,Wt+1,0,0,ne,ie,te.image[At]):i.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+At,Wt+1,de,ne,ie,te.image[At])}}}v(N)&&D(r.TEXTURE_CUBE_MAP),yt.__version=xt.version,N.onUpdate&&N.onUpdate(N)}b.__version=N.version}function Qt(b,N,Q,St,xt,yt){const It=c.convert(Q.format,Q.colorSpace),ut=c.convert(Q.type),ht=U(Q.internalFormat,It,ut,Q.normalized,Q.colorSpace),Lt=s.get(N),Ut=s.get(Q);if(Ut.__renderTarget=N,!Lt.__hasExternalTextures){const Ot=Math.max(1,N.width>>yt),Dt=Math.max(1,N.height>>yt);xt===r.TEXTURE_3D||xt===r.TEXTURE_2D_ARRAY?i.texImage3D(xt,yt,ht,Ot,Dt,N.depth,0,It,ut,null):i.texImage2D(xt,yt,ht,Ot,Dt,0,It,ut,null)}i.bindFramebuffer(r.FRAMEBUFFER,b),he(N)?T.framebufferTexture2DMultisampleEXT(r.FRAMEBUFFER,St,xt,Ut.__webglTexture,0,Je(N)):(xt===r.TEXTURE_2D||xt>=r.TEXTURE_CUBE_MAP_POSITIVE_X&&xt<=r.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&r.framebufferTexture2D(r.FRAMEBUFFER,St,xt,Ut.__webglTexture,yt),i.bindFramebuffer(r.FRAMEBUFFER,null)}function ze(b,N,Q){if(r.bindRenderbuffer(r.RENDERBUFFER,b),N.depthBuffer){const St=N.depthTexture,xt=St&&St.isDepthTexture?St.type:null,yt=Y(N.stencilBuffer,xt),It=N.stencilBuffer?r.DEPTH_STENCIL_ATTACHMENT:r.DEPTH_ATTACHMENT;he(N)?T.renderbufferStorageMultisampleEXT(r.RENDERBUFFER,Je(N),yt,N.width,N.height):Q?r.renderbufferStorageMultisample(r.RENDERBUFFER,Je(N),yt,N.width,N.height):r.renderbufferStorage(r.RENDERBUFFER,yt,N.width,N.height),r.framebufferRenderbuffer(r.FRAMEBUFFER,It,r.RENDERBUFFER,b)}else{const St=N.textures;for(let xt=0;xt<St.length;xt++){const yt=St[xt],It=c.convert(yt.format,yt.colorSpace),ut=c.convert(yt.type),ht=U(yt.internalFormat,It,ut,yt.normalized,yt.colorSpace);he(N)?T.renderbufferStorageMultisampleEXT(r.RENDERBUFFER,Je(N),ht,N.width,N.height):Q?r.renderbufferStorageMultisample(r.RENDERBUFFER,Je(N),ht,N.width,N.height):r.renderbufferStorage(r.RENDERBUFFER,ht,N.width,N.height)}}r.bindRenderbuffer(r.RENDERBUFFER,null)}function fe(b,N,Q){const St=N.isWebGLCubeRenderTarget===!0;if(i.bindFramebuffer(r.FRAMEBUFFER,b),!(N.depthTexture&&N.depthTexture.isDepthTexture))throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");const xt=s.get(N.depthTexture);if(xt.__renderTarget=N,(!xt.__webglTexture||N.depthTexture.image.width!==N.width||N.depthTexture.image.height!==N.height)&&(N.depthTexture.image.width=N.width,N.depthTexture.image.height=N.height,N.depthTexture.needsUpdate=!0),St){if(xt.__webglInit===void 0&&(xt.__webglInit=!0,N.depthTexture.addEventListener("dispose",B)),xt.__webglTexture===void 0){xt.__webglTexture=r.createTexture(),i.bindTexture(r.TEXTURE_CUBE_MAP,xt.__webglTexture),Mt(r.TEXTURE_CUBE_MAP,N.depthTexture);const Lt=c.convert(N.depthTexture.format),Ut=c.convert(N.depthTexture.type);let Ot;N.depthTexture.format===Ia?Ot=r.DEPTH_COMPONENT24:N.depthTexture.format===Ks&&(Ot=r.DEPTH24_STENCIL8);for(let Dt=0;Dt<6;Dt++)r.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+Dt,0,Ot,N.width,N.height,0,Lt,Ut,null)}}else it(N.depthTexture,0);const yt=xt.__webglTexture,It=Je(N),ut=St?r.TEXTURE_CUBE_MAP_POSITIVE_X+Q:r.TEXTURE_2D,ht=N.depthTexture.format===Ks?r.DEPTH_STENCIL_ATTACHMENT:r.DEPTH_ATTACHMENT;if(N.depthTexture.format===Ia)he(N)?T.framebufferTexture2DMultisampleEXT(r.FRAMEBUFFER,ht,ut,yt,0,It):r.framebufferTexture2D(r.FRAMEBUFFER,ht,ut,yt,0);else if(N.depthTexture.format===Ks)he(N)?T.framebufferTexture2DMultisampleEXT(r.FRAMEBUFFER,ht,ut,yt,0,It):r.framebufferTexture2D(r.FRAMEBUFFER,ht,ut,yt,0);else throw new Error("Unknown depthTexture format")}function Ee(b){const N=s.get(b),Q=b.isWebGLCubeRenderTarget===!0;if(N.__boundDepthTexture!==b.depthTexture){const St=b.depthTexture;if(N.__depthDisposeCallback&&N.__depthDisposeCallback(),St){const xt=()=>{delete N.__boundDepthTexture,delete N.__depthDisposeCallback,St.removeEventListener("dispose",xt)};St.addEventListener("dispose",xt),N.__depthDisposeCallback=xt}N.__boundDepthTexture=St}if(b.depthTexture&&!N.__autoAllocateDepthBuffer)if(Q)for(let St=0;St<6;St++)fe(N.__webglFramebuffer[St],b,St);else{const St=b.texture.mipmaps;St&&St.length>0?fe(N.__webglFramebuffer[0],b,0):fe(N.__webglFramebuffer,b,0)}else if(Q){N.__webglDepthbuffer=[];for(let St=0;St<6;St++)if(i.bindFramebuffer(r.FRAMEBUFFER,N.__webglFramebuffer[St]),N.__webglDepthbuffer[St]===void 0)N.__webglDepthbuffer[St]=r.createRenderbuffer(),ze(N.__webglDepthbuffer[St],b,!1);else{const xt=b.stencilBuffer?r.DEPTH_STENCIL_ATTACHMENT:r.DEPTH_ATTACHMENT,yt=N.__webglDepthbuffer[St];r.bindRenderbuffer(r.RENDERBUFFER,yt),r.framebufferRenderbuffer(r.FRAMEBUFFER,xt,r.RENDERBUFFER,yt)}}else{const St=b.texture.mipmaps;if(St&&St.length>0?i.bindFramebuffer(r.FRAMEBUFFER,N.__webglFramebuffer[0]):i.bindFramebuffer(r.FRAMEBUFFER,N.__webglFramebuffer),N.__webglDepthbuffer===void 0)N.__webglDepthbuffer=r.createRenderbuffer(),ze(N.__webglDepthbuffer,b,!1);else{const xt=b.stencilBuffer?r.DEPTH_STENCIL_ATTACHMENT:r.DEPTH_ATTACHMENT,yt=N.__webglDepthbuffer;r.bindRenderbuffer(r.RENDERBUFFER,yt),r.framebufferRenderbuffer(r.FRAMEBUFFER,xt,r.RENDERBUFFER,yt)}}i.bindFramebuffer(r.FRAMEBUFFER,null)}function Ie(b,N,Q){const St=s.get(b);N!==void 0&&Qt(St.__webglFramebuffer,b,b.texture,r.COLOR_ATTACHMENT0,r.TEXTURE_2D,0),Q!==void 0&&Ee(b)}function le(b){const N=b.texture,Q=s.get(b),St=s.get(N);b.addEventListener("dispose",R);const xt=b.textures,yt=b.isWebGLCubeRenderTarget===!0,It=xt.length>1;if(It||(St.__webglTexture===void 0&&(St.__webglTexture=r.createTexture()),St.__version=N.version,f.memory.textures++),yt){Q.__webglFramebuffer=[];for(let ut=0;ut<6;ut++)if(N.mipmaps&&N.mipmaps.length>0){Q.__webglFramebuffer[ut]=[];for(let ht=0;ht<N.mipmaps.length;ht++)Q.__webglFramebuffer[ut][ht]=r.createFramebuffer()}else Q.__webglFramebuffer[ut]=r.createFramebuffer()}else{if(N.mipmaps&&N.mipmaps.length>0){Q.__webglFramebuffer=[];for(let ut=0;ut<N.mipmaps.length;ut++)Q.__webglFramebuffer[ut]=r.createFramebuffer()}else Q.__webglFramebuffer=r.createFramebuffer();if(It)for(let ut=0,ht=xt.length;ut<ht;ut++){const Lt=s.get(xt[ut]);Lt.__webglTexture===void 0&&(Lt.__webglTexture=r.createTexture(),f.memory.textures++)}if(b.samples>0&&he(b)===!1){Q.__webglMultisampledFramebuffer=r.createFramebuffer(),Q.__webglColorRenderbuffer=[],i.bindFramebuffer(r.FRAMEBUFFER,Q.__webglMultisampledFramebuffer);for(let ut=0;ut<xt.length;ut++){const ht=xt[ut];Q.__webglColorRenderbuffer[ut]=r.createRenderbuffer(),r.bindRenderbuffer(r.RENDERBUFFER,Q.__webglColorRenderbuffer[ut]);const Lt=c.convert(ht.format,ht.colorSpace),Ut=c.convert(ht.type),Ot=U(ht.internalFormat,Lt,Ut,ht.normalized,ht.colorSpace,b.isXRRenderTarget===!0),Dt=Je(b);r.renderbufferStorageMultisample(r.RENDERBUFFER,Dt,Ot,b.width,b.height),r.framebufferRenderbuffer(r.FRAMEBUFFER,r.COLOR_ATTACHMENT0+ut,r.RENDERBUFFER,Q.__webglColorRenderbuffer[ut])}r.bindRenderbuffer(r.RENDERBUFFER,null),b.depthBuffer&&(Q.__webglDepthRenderbuffer=r.createRenderbuffer(),ze(Q.__webglDepthRenderbuffer,b,!0)),i.bindFramebuffer(r.FRAMEBUFFER,null)}}if(yt){i.bindTexture(r.TEXTURE_CUBE_MAP,St.__webglTexture),Mt(r.TEXTURE_CUBE_MAP,N);for(let ut=0;ut<6;ut++)if(N.mipmaps&&N.mipmaps.length>0)for(let ht=0;ht<N.mipmaps.length;ht++)Qt(Q.__webglFramebuffer[ut][ht],b,N,r.COLOR_ATTACHMENT0,r.TEXTURE_CUBE_MAP_POSITIVE_X+ut,ht);else Qt(Q.__webglFramebuffer[ut],b,N,r.COLOR_ATTACHMENT0,r.TEXTURE_CUBE_MAP_POSITIVE_X+ut,0);v(N)&&D(r.TEXTURE_CUBE_MAP),i.unbindTexture()}else if(It){for(let ut=0,ht=xt.length;ut<ht;ut++){const Lt=xt[ut],Ut=s.get(Lt);let Ot=r.TEXTURE_2D;(b.isWebGL3DRenderTarget||b.isWebGLArrayRenderTarget)&&(Ot=b.isWebGL3DRenderTarget?r.TEXTURE_3D:r.TEXTURE_2D_ARRAY),i.bindTexture(Ot,Ut.__webglTexture),Mt(Ot,Lt),Qt(Q.__webglFramebuffer,b,Lt,r.COLOR_ATTACHMENT0+ut,Ot,0),v(Lt)&&D(Ot)}i.unbindTexture()}else{let ut=r.TEXTURE_2D;if((b.isWebGL3DRenderTarget||b.isWebGLArrayRenderTarget)&&(ut=b.isWebGL3DRenderTarget?r.TEXTURE_3D:r.TEXTURE_2D_ARRAY),i.bindTexture(ut,St.__webglTexture),Mt(ut,N),N.mipmaps&&N.mipmaps.length>0)for(let ht=0;ht<N.mipmaps.length;ht++)Qt(Q.__webglFramebuffer[ht],b,N,r.COLOR_ATTACHMENT0,ut,ht);else Qt(Q.__webglFramebuffer,b,N,r.COLOR_ATTACHMENT0,ut,0);v(N)&&D(ut),i.unbindTexture()}b.depthBuffer&&Ee(b)}function sn(b){const N=b.textures;for(let Q=0,St=N.length;Q<St;Q++){const xt=N[Q];if(v(xt)){const yt=I(b),It=s.get(xt).__webglTexture;i.bindTexture(yt,It),D(yt),i.unbindTexture()}}}const ke=[],Mn=[];function k(b){if(b.samples>0){if(he(b)===!1){const N=b.textures,Q=b.width,St=b.height;let xt=r.COLOR_BUFFER_BIT;const yt=b.stencilBuffer?r.DEPTH_STENCIL_ATTACHMENT:r.DEPTH_ATTACHMENT,It=s.get(b),ut=N.length>1;if(ut)for(let Lt=0;Lt<N.length;Lt++)i.bindFramebuffer(r.FRAMEBUFFER,It.__webglMultisampledFramebuffer),r.framebufferRenderbuffer(r.FRAMEBUFFER,r.COLOR_ATTACHMENT0+Lt,r.RENDERBUFFER,null),i.bindFramebuffer(r.FRAMEBUFFER,It.__webglFramebuffer),r.framebufferTexture2D(r.DRAW_FRAMEBUFFER,r.COLOR_ATTACHMENT0+Lt,r.TEXTURE_2D,null,0);i.bindFramebuffer(r.READ_FRAMEBUFFER,It.__webglMultisampledFramebuffer);const ht=b.texture.mipmaps;ht&&ht.length>0?i.bindFramebuffer(r.DRAW_FRAMEBUFFER,It.__webglFramebuffer[0]):i.bindFramebuffer(r.DRAW_FRAMEBUFFER,It.__webglFramebuffer);for(let Lt=0;Lt<N.length;Lt++){if(b.resolveDepthBuffer&&(b.depthBuffer&&(xt|=r.DEPTH_BUFFER_BIT),b.stencilBuffer&&b.resolveStencilBuffer&&(xt|=r.STENCIL_BUFFER_BIT)),ut){r.framebufferRenderbuffer(r.READ_FRAMEBUFFER,r.COLOR_ATTACHMENT0,r.RENDERBUFFER,It.__webglColorRenderbuffer[Lt]);const Ut=s.get(N[Lt]).__webglTexture;r.framebufferTexture2D(r.DRAW_FRAMEBUFFER,r.COLOR_ATTACHMENT0,r.TEXTURE_2D,Ut,0)}r.blitFramebuffer(0,0,Q,St,0,0,Q,St,xt,r.NEAREST),p===!0&&(ke.length=0,Mn.length=0,ke.push(r.COLOR_ATTACHMENT0+Lt),b.depthBuffer&&b.resolveDepthBuffer===!1&&(ke.push(yt),Mn.push(yt),r.invalidateFramebuffer(r.DRAW_FRAMEBUFFER,Mn)),r.invalidateFramebuffer(r.READ_FRAMEBUFFER,ke))}if(i.bindFramebuffer(r.READ_FRAMEBUFFER,null),i.bindFramebuffer(r.DRAW_FRAMEBUFFER,null),ut)for(let Lt=0;Lt<N.length;Lt++){i.bindFramebuffer(r.FRAMEBUFFER,It.__webglMultisampledFramebuffer),r.framebufferRenderbuffer(r.FRAMEBUFFER,r.COLOR_ATTACHMENT0+Lt,r.RENDERBUFFER,It.__webglColorRenderbuffer[Lt]);const Ut=s.get(N[Lt]).__webglTexture;i.bindFramebuffer(r.FRAMEBUFFER,It.__webglFramebuffer),r.framebufferTexture2D(r.DRAW_FRAMEBUFFER,r.COLOR_ATTACHMENT0+Lt,r.TEXTURE_2D,Ut,0)}i.bindFramebuffer(r.DRAW_FRAMEBUFFER,It.__webglMultisampledFramebuffer)}else if(b.depthBuffer&&b.resolveDepthBuffer===!1&&p){const N=b.stencilBuffer?r.DEPTH_STENCIL_ATTACHMENT:r.DEPTH_ATTACHMENT;r.invalidateFramebuffer(r.DRAW_FRAMEBUFFER,[N])}}}function Je(b){return Math.min(l.maxSamples,b.samples)}function he(b){const N=s.get(b);return b.samples>0&&t.has("WEBGL_multisampled_render_to_texture")===!0&&N.__useRenderToTexture!==!1}function Pe(b){const N=f.render.frame;m.get(b)!==N&&(m.set(b,N),b.update())}function Ct(b,N){const Q=b.colorSpace,St=b.format,xt=b.type;return b.isCompressedTexture===!0||b.isVideoTexture===!0||Q!==eu&&Q!==Ts&&(Ae.getTransfer(Q)===Xe?(St!==Fi||xt!==di)&&ee("WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):Ne("WebGLTextures: Unsupported texture color space:",Q)),N}function qe(b){return typeof HTMLImageElement<"u"&&b instanceof HTMLImageElement?(h.width=b.naturalWidth||b.width,h.height=b.naturalHeight||b.height):typeof VideoFrame<"u"&&b instanceof VideoFrame?(h.width=b.displayWidth,h.height=b.displayHeight):(h.width=b.width,h.height=b.height),h}this.allocateTextureUnit=L,this.resetTextureUnits=ct,this.getTextureUnits=lt,this.setTextureUnits=W,this.setTexture2D=it,this.setTexture2DArray=mt,this.setTexture3D=ft,this.setTextureCube=O,this.rebindTextures=Ie,this.setupRenderTarget=le,this.updateRenderTargetMipmap=sn,this.updateMultisampleRenderTarget=k,this.setupDepthRenderbuffer=Ee,this.setupFrameBufferTexture=Qt,this.useMultisampledRTT=he,this.isReversedDepthBuffer=function(){return i.buffers.depth.getReversed()}}function bM(r,t){function i(s,l=Ts){let c;const f=Ae.getTransfer(l);if(s===di)return r.UNSIGNED_BYTE;if(s===s0)return r.UNSIGNED_SHORT_4_4_4_4;if(s===r0)return r.UNSIGNED_SHORT_5_5_5_1;if(s===LE)return r.UNSIGNED_INT_5_9_9_9_REV;if(s===UE)return r.UNSIGNED_INT_10F_11F_11F_REV;if(s===bE)return r.BYTE;if(s===IE)return r.SHORT;if(s===rl)return r.UNSIGNED_SHORT;if(s===a0)return r.INT;if(s===ta)return r.UNSIGNED_INT;if(s===qi)return r.FLOAT;if(s===ba)return r.HALF_FLOAT;if(s===FE)return r.ALPHA;if(s===wE)return r.RGB;if(s===Fi)return r.RGBA;if(s===Ia)return r.DEPTH_COMPONENT;if(s===Ks)return r.DEPTH_STENCIL;if(s===BE)return r.RED;if(s===o0)return r.RED_INTEGER;if(s===qs)return r.RG;if(s===l0)return r.RG_INTEGER;if(s===c0)return r.RGBA_INTEGER;if(s===Kc||s===Zc||s===qc||s===$c)if(f===Xe)if(c=t.get("WEBGL_compressed_texture_s3tc_srgb"),c!==null){if(s===Kc)return c.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(s===Zc)return c.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(s===qc)return c.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(s===$c)return c.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(c=t.get("WEBGL_compressed_texture_s3tc"),c!==null){if(s===Kc)return c.COMPRESSED_RGB_S3TC_DXT1_EXT;if(s===Zc)return c.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(s===qc)return c.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(s===$c)return c.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(s===md||s===Ed||s===Sd||s===gd)if(c=t.get("WEBGL_compressed_texture_pvrtc"),c!==null){if(s===md)return c.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(s===Ed)return c.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(s===Sd)return c.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(s===gd)return c.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(s===_d||s===vd||s===Ad||s===xd||s===Nd||s===Jc||s===Md)if(c=t.get("WEBGL_compressed_texture_etc"),c!==null){if(s===_d||s===vd)return f===Xe?c.COMPRESSED_SRGB8_ETC2:c.COMPRESSED_RGB8_ETC2;if(s===Ad)return f===Xe?c.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:c.COMPRESSED_RGBA8_ETC2_EAC;if(s===xd)return c.COMPRESSED_R11_EAC;if(s===Nd)return c.COMPRESSED_SIGNED_R11_EAC;if(s===Jc)return c.COMPRESSED_RG11_EAC;if(s===Md)return c.COMPRESSED_SIGNED_RG11_EAC}else return null;if(s===Rd||s===Cd||s===yd||s===Dd||s===Od||s===bd||s===Id||s===Ld||s===Ud||s===Fd||s===wd||s===Bd||s===Xd||s===Pd)if(c=t.get("WEBGL_compressed_texture_astc"),c!==null){if(s===Rd)return f===Xe?c.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:c.COMPRESSED_RGBA_ASTC_4x4_KHR;if(s===Cd)return f===Xe?c.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:c.COMPRESSED_RGBA_ASTC_5x4_KHR;if(s===yd)return f===Xe?c.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:c.COMPRESSED_RGBA_ASTC_5x5_KHR;if(s===Dd)return f===Xe?c.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:c.COMPRESSED_RGBA_ASTC_6x5_KHR;if(s===Od)return f===Xe?c.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:c.COMPRESSED_RGBA_ASTC_6x6_KHR;if(s===bd)return f===Xe?c.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:c.COMPRESSED_RGBA_ASTC_8x5_KHR;if(s===Id)return f===Xe?c.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:c.COMPRESSED_RGBA_ASTC_8x6_KHR;if(s===Ld)return f===Xe?c.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:c.COMPRESSED_RGBA_ASTC_8x8_KHR;if(s===Ud)return f===Xe?c.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:c.COMPRESSED_RGBA_ASTC_10x5_KHR;if(s===Fd)return f===Xe?c.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:c.COMPRESSED_RGBA_ASTC_10x6_KHR;if(s===wd)return f===Xe?c.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:c.COMPRESSED_RGBA_ASTC_10x8_KHR;if(s===Bd)return f===Xe?c.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:c.COMPRESSED_RGBA_ASTC_10x10_KHR;if(s===Xd)return f===Xe?c.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:c.COMPRESSED_RGBA_ASTC_12x10_KHR;if(s===Pd)return f===Xe?c.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:c.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(s===Hd||s===Yd||s===Gd)if(c=t.get("EXT_texture_compression_bptc"),c!==null){if(s===Hd)return f===Xe?c.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:c.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(s===Yd)return c.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(s===Gd)return c.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(s===zd||s===Vd||s===tu||s===Wd)if(c=t.get("EXT_texture_compression_rgtc"),c!==null){if(s===zd)return c.COMPRESSED_RED_RGTC1_EXT;if(s===Vd)return c.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(s===tu)return c.COMPRESSED_RED_GREEN_RGTC2_EXT;if(s===Wd)return c.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return s===ol?r.UNSIGNED_INT_24_8:r[s]!==void 0?r[s]:null}return{convert:i}}const IM=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,LM=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`;class UM{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(t,i){if(this.texture===null){const s=new kE(t.texture);(t.depthNear!==i.depthNear||t.depthFar!==i.depthFar)&&(this.depthNear=t.depthNear,this.depthFar=t.depthFar),this.texture=s}}getMesh(t){if(this.texture!==null&&this.mesh===null){const i=t.cameras[0].viewport,s=new ea({vertexShader:IM,fragmentShader:LM,uniforms:{depthColor:{value:this.texture},depthWidth:{value:i.z},depthHeight:{value:i.w}}});this.mesh=new Bi(new ou(20,20),s)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}}class FM extends $s{constructor(t,i){super();const s=this;let l=null,c=1,f=null,T="local-floor",p=1,h=null,m=null,E=null,S=null,g=null,A=null;const M=typeof XRWebGLBinding<"u",x=new UM,v={},D=i.getContextAttributes();let I=null,U=null;const Y=[],F=[],B=new Oe;let R=null;const w=new Ni;w.viewport=new an;const Z=new Ni;Z.viewport=new an;const H=[w,Z],$=new W2;let ct=null,lt=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(rt){let vt=Y[rt];return vt===void 0&&(vt=new Oh,Y[rt]=vt),vt.getTargetRaySpace()},this.getControllerGrip=function(rt){let vt=Y[rt];return vt===void 0&&(vt=new Oh,Y[rt]=vt),vt.getGripSpace()},this.getHand=function(rt){let vt=Y[rt];return vt===void 0&&(vt=new Oh,Y[rt]=vt),vt.getHandSpace()};function W(rt){const vt=F.indexOf(rt.inputSource);if(vt===-1)return;const Nt=Y[vt];Nt!==void 0&&(Nt.update(rt.inputSource,rt.frame,h||f),Nt.dispatchEvent({type:rt.type,data:rt.inputSource}))}function L(){l.removeEventListener("select",W),l.removeEventListener("selectstart",W),l.removeEventListener("selectend",W),l.removeEventListener("squeeze",W),l.removeEventListener("squeezestart",W),l.removeEventListener("squeezeend",W),l.removeEventListener("end",L),l.removeEventListener("inputsourceschange",P);for(let rt=0;rt<Y.length;rt++){const vt=F[rt];vt!==null&&(F[rt]=null,Y[rt].disconnect(vt))}ct=null,lt=null,x.reset();for(const rt in v)delete v[rt];t.setRenderTarget(I),g=null,S=null,E=null,l=null,U=null,Mt.stop(),s.isPresenting=!1,t.setPixelRatio(R),t.setSize(B.width,B.height,!1),s.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(rt){c=rt,s.isPresenting===!0&&ee("WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(rt){T=rt,s.isPresenting===!0&&ee("WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return h||f},this.setReferenceSpace=function(rt){h=rt},this.getBaseLayer=function(){return S!==null?S:g},this.getBinding=function(){return E===null&&M&&(E=new XRWebGLBinding(l,i)),E},this.getFrame=function(){return A},this.getSession=function(){return l},this.setSession=async function(rt){if(l=rt,l!==null){if(I=t.getRenderTarget(),l.addEventListener("select",W),l.addEventListener("selectstart",W),l.addEventListener("selectend",W),l.addEventListener("squeeze",W),l.addEventListener("squeezestart",W),l.addEventListener("squeezeend",W),l.addEventListener("end",L),l.addEventListener("inputsourceschange",P),D.xrCompatible!==!0&&await i.makeXRCompatible(),R=t.getPixelRatio(),t.getSize(B),M&&"createProjectionLayer"in XRWebGLBinding.prototype){let Nt=null,Pt=null,Jt=null;D.depth&&(Jt=D.stencil?i.DEPTH24_STENCIL8:i.DEPTH_COMPONENT24,Nt=D.stencil?Ks:Ia,Pt=D.stencil?ol:ta);const Qt={colorFormat:i.RGBA8,depthFormat:Jt,scaleFactor:c};E=this.getBinding(),S=E.createProjectionLayer(Qt),l.updateRenderState({layers:[S]}),t.setPixelRatio(1),t.setSize(S.textureWidth,S.textureHeight,!1),U=new ji(S.textureWidth,S.textureHeight,{format:Fi,type:di,depthTexture:new Zr(S.textureWidth,S.textureHeight,Pt,void 0,void 0,void 0,void 0,void 0,void 0,Nt),stencilBuffer:D.stencil,colorSpace:t.outputColorSpace,samples:D.antialias?4:0,resolveDepthBuffer:S.ignoreDepthValues===!1,resolveStencilBuffer:S.ignoreDepthValues===!1})}else{const Nt={antialias:D.antialias,alpha:!0,depth:D.depth,stencil:D.stencil,framebufferScaleFactor:c};g=new XRWebGLLayer(l,i,Nt),l.updateRenderState({baseLayer:g}),t.setPixelRatio(1),t.setSize(g.framebufferWidth,g.framebufferHeight,!1),U=new ji(g.framebufferWidth,g.framebufferHeight,{format:Fi,type:di,colorSpace:t.outputColorSpace,stencilBuffer:D.stencil,resolveDepthBuffer:g.ignoreDepthValues===!1,resolveStencilBuffer:g.ignoreDepthValues===!1})}U.isXRRenderTarget=!0,this.setFoveation(p),h=null,f=await l.requestReferenceSpace(T),Mt.setContext(l),Mt.start(),s.isPresenting=!0,s.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(l!==null)return l.environmentBlendMode},this.getDepthTexture=function(){return x.getDepthTexture()};function P(rt){for(let vt=0;vt<rt.removed.length;vt++){const Nt=rt.removed[vt],Pt=F.indexOf(Nt);Pt>=0&&(F[Pt]=null,Y[Pt].disconnect(Nt))}for(let vt=0;vt<rt.added.length;vt++){const Nt=rt.added[vt];let Pt=F.indexOf(Nt);if(Pt===-1){for(let Qt=0;Qt<Y.length;Qt++)if(Qt>=F.length){F.push(Nt),Pt=Qt;break}else if(F[Qt]===null){F[Qt]=Nt,Pt=Qt;break}if(Pt===-1)break}const Jt=Y[Pt];Jt&&Jt.connect(Nt)}}const it=new nt,mt=new nt;function ft(rt,vt,Nt){it.setFromMatrixPosition(vt.matrixWorld),mt.setFromMatrixPosition(Nt.matrixWorld);const Pt=it.distanceTo(mt),Jt=vt.projectionMatrix.elements,Qt=Nt.projectionMatrix.elements,ze=Jt[14]/(Jt[10]-1),fe=Jt[14]/(Jt[10]+1),Ee=(Jt[9]+1)/Jt[5],Ie=(Jt[9]-1)/Jt[5],le=(Jt[8]-1)/Jt[0],sn=(Qt[8]+1)/Qt[0],ke=ze*le,Mn=ze*sn,k=Pt/(-le+sn),Je=k*-le;if(vt.matrixWorld.decompose(rt.position,rt.quaternion,rt.scale),rt.translateX(Je),rt.translateZ(k),rt.matrixWorld.compose(rt.position,rt.quaternion,rt.scale),rt.matrixWorldInverse.copy(rt.matrixWorld).invert(),Jt[10]===-1)rt.projectionMatrix.copy(vt.projectionMatrix),rt.projectionMatrixInverse.copy(vt.projectionMatrixInverse);else{const he=ze+k,Pe=fe+k,Ct=ke-Je,qe=Mn+(Pt-Je),b=Ee*fe/Pe*he,N=Ie*fe/Pe*he;rt.projectionMatrix.makePerspective(Ct,qe,b,N,he,Pe),rt.projectionMatrixInverse.copy(rt.projectionMatrix).invert()}}function O(rt,vt){vt===null?rt.matrixWorld.copy(rt.matrix):rt.matrixWorld.multiplyMatrices(vt.matrixWorld,rt.matrix),rt.matrixWorldInverse.copy(rt.matrixWorld).invert()}this.updateCamera=function(rt){if(l===null)return;let vt=rt.near,Nt=rt.far;x.texture!==null&&(x.depthNear>0&&(vt=x.depthNear),x.depthFar>0&&(Nt=x.depthFar)),$.near=Z.near=w.near=vt,$.far=Z.far=w.far=Nt,(ct!==$.near||lt!==$.far)&&(l.updateRenderState({depthNear:$.near,depthFar:$.far}),ct=$.near,lt=$.far),$.layers.mask=rt.layers.mask|6,w.layers.mask=$.layers.mask&-5,Z.layers.mask=$.layers.mask&-3;const Pt=rt.parent,Jt=$.cameras;O($,Pt);for(let Qt=0;Qt<Jt.length;Qt++)O(Jt[Qt],Pt);Jt.length===2?ft($,w,Z):$.projectionMatrix.copy(w.projectionMatrix),V(rt,$,Pt)};function V(rt,vt,Nt){Nt===null?rt.matrix.copy(vt.matrixWorld):(rt.matrix.copy(Nt.matrixWorld),rt.matrix.invert(),rt.matrix.multiply(vt.matrixWorld)),rt.matrix.decompose(rt.position,rt.quaternion,rt.scale),rt.updateMatrixWorld(!0),rt.projectionMatrix.copy(vt.projectionMatrix),rt.projectionMatrixInverse.copy(vt.projectionMatrixInverse),rt.isPerspectiveCamera&&(rt.fov=Zd*2*Math.atan(1/rt.projectionMatrix.elements[5]),rt.zoom=1)}this.getCamera=function(){return $},this.getFoveation=function(){if(!(S===null&&g===null))return p},this.setFoveation=function(rt){p=rt,S!==null&&(S.fixedFoveation=rt),g!==null&&g.fixedFoveation!==void 0&&(g.fixedFoveation=rt)},this.hasDepthSensing=function(){return x.texture!==null},this.getDepthSensingMesh=function(){return x.getMesh($)},this.getCameraTexture=function(rt){return v[rt]};let dt=null;function gt(rt,vt){if(m=vt.getViewerPose(h||f),A=vt,m!==null){const Nt=m.views;g!==null&&(t.setRenderTargetFramebuffer(U,g.framebuffer),t.setRenderTarget(U));let Pt=!1;Nt.length!==$.cameras.length&&($.cameras.length=0,Pt=!0);for(let fe=0;fe<Nt.length;fe++){const Ee=Nt[fe];let Ie=null;if(g!==null)Ie=g.getViewport(Ee);else{const sn=E.getViewSubImage(S,Ee);Ie=sn.viewport,fe===0&&(t.setRenderTargetTextures(U,sn.colorTexture,sn.depthStencilTexture),t.setRenderTarget(U))}let le=H[fe];le===void 0&&(le=new Ni,le.layers.enable(fe),le.viewport=new an,H[fe]=le),le.matrix.fromArray(Ee.transform.matrix),le.matrix.decompose(le.position,le.quaternion,le.scale),le.projectionMatrix.fromArray(Ee.projectionMatrix),le.projectionMatrixInverse.copy(le.projectionMatrix).invert(),le.viewport.set(Ie.x,Ie.y,Ie.width,Ie.height),fe===0&&($.matrix.copy(le.matrix),$.matrix.decompose($.position,$.quaternion,$.scale)),Pt===!0&&$.cameras.push(le)}const Jt=l.enabledFeatures;if(Jt&&Jt.includes("depth-sensing")&&l.depthUsage=="gpu-optimized"&&M){E=s.getBinding();const fe=E.getDepthInformation(Nt[0]);fe&&fe.isValid&&fe.texture&&x.init(fe,l.renderState)}if(Jt&&Jt.includes("camera-access")&&M){t.state.unbindTexture(),E=s.getBinding();for(let fe=0;fe<Nt.length;fe++){const Ee=Nt[fe].camera;if(Ee){let Ie=v[Ee];Ie||(Ie=new kE,v[Ee]=Ie);const le=E.getCameraImage(Ee);Ie.sourceTexture=le}}}}for(let Nt=0;Nt<Y.length;Nt++){const Pt=F[Nt],Jt=Y[Nt];Pt!==null&&Jt!==void 0&&Jt.update(Pt,vt,h||f)}dt&&dt(rt,vt),vt.detectedPlanes&&s.dispatchEvent({type:"planesdetected",data:vt}),A=null}const Mt=new $E;Mt.setAnimationLoop(gt),this.setAnimationLoop=function(rt){dt=rt},this.dispose=function(){}}}const wM=new cn,iS=new se;iS.set(-1,0,0,0,1,0,0,0,1);function BM(r,t){function i(x,v){x.matrixAutoUpdate===!0&&x.updateMatrix(),v.value.copy(x.matrix)}function s(x,v){v.color.getRGB(x.fogColor.value,KE(r)),v.isFog?(x.fogNear.value=v.near,x.fogFar.value=v.far):v.isFogExp2&&(x.fogDensity.value=v.density)}function l(x,v,D,I,U){v.isNodeMaterial?v.uniformsNeedUpdate=!1:v.isMeshBasicMaterial?c(x,v):v.isMeshLambertMaterial?(c(x,v),v.envMap&&(x.envMapIntensity.value=v.envMapIntensity)):v.isMeshToonMaterial?(c(x,v),E(x,v)):v.isMeshPhongMaterial?(c(x,v),m(x,v),v.envMap&&(x.envMapIntensity.value=v.envMapIntensity)):v.isMeshStandardMaterial?(c(x,v),S(x,v),v.isMeshPhysicalMaterial&&g(x,v,U)):v.isMeshMatcapMaterial?(c(x,v),A(x,v)):v.isMeshDepthMaterial?c(x,v):v.isMeshDistanceMaterial?(c(x,v),M(x,v)):v.isMeshNormalMaterial?c(x,v):v.isLineBasicMaterial?(f(x,v),v.isLineDashedMaterial&&T(x,v)):v.isPointsMaterial?p(x,v,D,I):v.isSpriteMaterial?h(x,v):v.isShadowMaterial?(x.color.value.copy(v.color),x.opacity.value=v.opacity):v.isShaderMaterial&&(v.uniformsNeedUpdate=!1)}function c(x,v){x.opacity.value=v.opacity,v.color&&x.diffuse.value.copy(v.color),v.emissive&&x.emissive.value.copy(v.emissive).multiplyScalar(v.emissiveIntensity),v.map&&(x.map.value=v.map,i(v.map,x.mapTransform)),v.alphaMap&&(x.alphaMap.value=v.alphaMap,i(v.alphaMap,x.alphaMapTransform)),v.bumpMap&&(x.bumpMap.value=v.bumpMap,i(v.bumpMap,x.bumpMapTransform),x.bumpScale.value=v.bumpScale,v.side===ti&&(x.bumpScale.value*=-1)),v.normalMap&&(x.normalMap.value=v.normalMap,i(v.normalMap,x.normalMapTransform),x.normalScale.value.copy(v.normalScale),v.side===ti&&x.normalScale.value.negate()),v.displacementMap&&(x.displacementMap.value=v.displacementMap,i(v.displacementMap,x.displacementMapTransform),x.displacementScale.value=v.displacementScale,x.displacementBias.value=v.displacementBias),v.emissiveMap&&(x.emissiveMap.value=v.emissiveMap,i(v.emissiveMap,x.emissiveMapTransform)),v.specularMap&&(x.specularMap.value=v.specularMap,i(v.specularMap,x.specularMapTransform)),v.alphaTest>0&&(x.alphaTest.value=v.alphaTest);const D=t.get(v),I=D.envMap,U=D.envMapRotation;I&&(x.envMap.value=I,x.envMapRotation.value.setFromMatrix4(wM.makeRotationFromEuler(U)).transpose(),I.isCubeTexture&&I.isRenderTargetTexture===!1&&x.envMapRotation.value.premultiply(iS),x.reflectivity.value=v.reflectivity,x.ior.value=v.ior,x.refractionRatio.value=v.refractionRatio),v.lightMap&&(x.lightMap.value=v.lightMap,x.lightMapIntensity.value=v.lightMapIntensity,i(v.lightMap,x.lightMapTransform)),v.aoMap&&(x.aoMap.value=v.aoMap,x.aoMapIntensity.value=v.aoMapIntensity,i(v.aoMap,x.aoMapTransform))}function f(x,v){x.diffuse.value.copy(v.color),x.opacity.value=v.opacity,v.map&&(x.map.value=v.map,i(v.map,x.mapTransform))}function T(x,v){x.dashSize.value=v.dashSize,x.totalSize.value=v.dashSize+v.gapSize,x.scale.value=v.scale}function p(x,v,D,I){x.diffuse.value.copy(v.color),x.opacity.value=v.opacity,x.size.value=v.size*D,x.scale.value=I*.5,v.map&&(x.map.value=v.map,i(v.map,x.uvTransform)),v.alphaMap&&(x.alphaMap.value=v.alphaMap,i(v.alphaMap,x.alphaMapTransform)),v.alphaTest>0&&(x.alphaTest.value=v.alphaTest)}function h(x,v){x.diffuse.value.copy(v.color),x.opacity.value=v.opacity,x.rotation.value=v.rotation,v.map&&(x.map.value=v.map,i(v.map,x.mapTransform)),v.alphaMap&&(x.alphaMap.value=v.alphaMap,i(v.alphaMap,x.alphaMapTransform)),v.alphaTest>0&&(x.alphaTest.value=v.alphaTest)}function m(x,v){x.specular.value.copy(v.specular),x.shininess.value=Math.max(v.shininess,1e-4)}function E(x,v){v.gradientMap&&(x.gradientMap.value=v.gradientMap)}function S(x,v){x.metalness.value=v.metalness,v.metalnessMap&&(x.metalnessMap.value=v.metalnessMap,i(v.metalnessMap,x.metalnessMapTransform)),x.roughness.value=v.roughness,v.roughnessMap&&(x.roughnessMap.value=v.roughnessMap,i(v.roughnessMap,x.roughnessMapTransform)),v.envMap&&(x.envMapIntensity.value=v.envMapIntensity)}function g(x,v,D){x.ior.value=v.ior,v.sheen>0&&(x.sheenColor.value.copy(v.sheenColor).multiplyScalar(v.sheen),x.sheenRoughness.value=v.sheenRoughness,v.sheenColorMap&&(x.sheenColorMap.value=v.sheenColorMap,i(v.sheenColorMap,x.sheenColorMapTransform)),v.sheenRoughnessMap&&(x.sheenRoughnessMap.value=v.sheenRoughnessMap,i(v.sheenRoughnessMap,x.sheenRoughnessMapTransform))),v.clearcoat>0&&(x.clearcoat.value=v.clearcoat,x.clearcoatRoughness.value=v.clearcoatRoughness,v.clearcoatMap&&(x.clearcoatMap.value=v.clearcoatMap,i(v.clearcoatMap,x.clearcoatMapTransform)),v.clearcoatRoughnessMap&&(x.clearcoatRoughnessMap.value=v.clearcoatRoughnessMap,i(v.clearcoatRoughnessMap,x.clearcoatRoughnessMapTransform)),v.clearcoatNormalMap&&(x.clearcoatNormalMap.value=v.clearcoatNormalMap,i(v.clearcoatNormalMap,x.clearcoatNormalMapTransform),x.clearcoatNormalScale.value.copy(v.clearcoatNormalScale),v.side===ti&&x.clearcoatNormalScale.value.negate())),v.dispersion>0&&(x.dispersion.value=v.dispersion),v.iridescence>0&&(x.iridescence.value=v.iridescence,x.iridescenceIOR.value=v.iridescenceIOR,x.iridescenceThicknessMinimum.value=v.iridescenceThicknessRange[0],x.iridescenceThicknessMaximum.value=v.iridescenceThicknessRange[1],v.iridescenceMap&&(x.iridescenceMap.value=v.iridescenceMap,i(v.iridescenceMap,x.iridescenceMapTransform)),v.iridescenceThicknessMap&&(x.iridescenceThicknessMap.value=v.iridescenceThicknessMap,i(v.iridescenceThicknessMap,x.iridescenceThicknessMapTransform))),v.transmission>0&&(x.transmission.value=v.transmission,x.transmissionSamplerMap.value=D.texture,x.transmissionSamplerSize.value.set(D.width,D.height),v.transmissionMap&&(x.transmissionMap.value=v.transmissionMap,i(v.transmissionMap,x.transmissionMapTransform)),x.thickness.value=v.thickness,v.thicknessMap&&(x.thicknessMap.value=v.thicknessMap,i(v.thicknessMap,x.thicknessMapTransform)),x.attenuationDistance.value=v.attenuationDistance,x.attenuationColor.value.copy(v.attenuationColor)),v.anisotropy>0&&(x.anisotropyVector.value.set(v.anisotropy*Math.cos(v.anisotropyRotation),v.anisotropy*Math.sin(v.anisotropyRotation)),v.anisotropyMap&&(x.anisotropyMap.value=v.anisotropyMap,i(v.anisotropyMap,x.anisotropyMapTransform))),x.specularIntensity.value=v.specularIntensity,x.specularColor.value.copy(v.specularColor),v.specularColorMap&&(x.specularColorMap.value=v.specularColorMap,i(v.specularColorMap,x.specularColorMapTransform)),v.specularIntensityMap&&(x.specularIntensityMap.value=v.specularIntensityMap,i(v.specularIntensityMap,x.specularIntensityMapTransform))}function A(x,v){v.matcap&&(x.matcap.value=v.matcap)}function M(x,v){const D=t.get(v).light;x.referencePosition.value.setFromMatrixPosition(D.matrixWorld),x.nearDistance.value=D.shadow.camera.near,x.farDistance.value=D.shadow.camera.far}return{refreshFogUniforms:s,refreshMaterialUniforms:l}}function XM(r,t,i,s){let l={},c={},f=[];const T=r.getParameter(r.MAX_UNIFORM_BUFFER_BINDINGS);function p(D,I){const U=I.program;s.uniformBlockBinding(D,U)}function h(D,I){let U=l[D.id];U===void 0&&(A(D),U=m(D),l[D.id]=U,D.addEventListener("dispose",x));const Y=I.program;s.updateUBOMapping(D,Y);const F=t.render.frame;c[D.id]!==F&&(S(D),c[D.id]=F)}function m(D){const I=E();D.__bindingPointIndex=I;const U=r.createBuffer(),Y=D.__size,F=D.usage;return r.bindBuffer(r.UNIFORM_BUFFER,U),r.bufferData(r.UNIFORM_BUFFER,Y,F),r.bindBuffer(r.UNIFORM_BUFFER,null),r.bindBufferBase(r.UNIFORM_BUFFER,I,U),U}function E(){for(let D=0;D<T;D++)if(f.indexOf(D)===-1)return f.push(D),D;return Ne("WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function S(D){const I=l[D.id],U=D.uniforms,Y=D.__cache;r.bindBuffer(r.UNIFORM_BUFFER,I);for(let F=0,B=U.length;F<B;F++){const R=Array.isArray(U[F])?U[F]:[U[F]];for(let w=0,Z=R.length;w<Z;w++){const H=R[w];if(g(H,F,w,Y)===!0){const $=H.__offset,ct=Array.isArray(H.value)?H.value:[H.value];let lt=0;for(let W=0;W<ct.length;W++){const L=ct[W],P=M(L);typeof L=="number"||typeof L=="boolean"?(H.__data[0]=L,r.bufferSubData(r.UNIFORM_BUFFER,$+lt,H.__data)):L.isMatrix3?(H.__data[0]=L.elements[0],H.__data[1]=L.elements[1],H.__data[2]=L.elements[2],H.__data[3]=0,H.__data[4]=L.elements[3],H.__data[5]=L.elements[4],H.__data[6]=L.elements[5],H.__data[7]=0,H.__data[8]=L.elements[6],H.__data[9]=L.elements[7],H.__data[10]=L.elements[8],H.__data[11]=0):ArrayBuffer.isView(L)?H.__data.set(new L.constructor(L.buffer,L.byteOffset,H.__data.length)):(L.toArray(H.__data,lt),lt+=P.storage/Float32Array.BYTES_PER_ELEMENT)}r.bufferSubData(r.UNIFORM_BUFFER,$,H.__data)}}}r.bindBuffer(r.UNIFORM_BUFFER,null)}function g(D,I,U,Y){const F=D.value,B=I+"_"+U;if(Y[B]===void 0)return typeof F=="number"||typeof F=="boolean"?Y[B]=F:ArrayBuffer.isView(F)?Y[B]=F.slice():Y[B]=F.clone(),!0;{const R=Y[B];if(typeof F=="number"||typeof F=="boolean"){if(R!==F)return Y[B]=F,!0}else{if(ArrayBuffer.isView(F))return!0;if(R.equals(F)===!1)return R.copy(F),!0}}return!1}function A(D){const I=D.uniforms;let U=0;const Y=16;for(let B=0,R=I.length;B<R;B++){const w=Array.isArray(I[B])?I[B]:[I[B]];for(let Z=0,H=w.length;Z<H;Z++){const $=w[Z],ct=Array.isArray($.value)?$.value:[$.value];for(let lt=0,W=ct.length;lt<W;lt++){const L=ct[lt],P=M(L),it=U%Y,mt=it%P.boundary,ft=it+mt;U+=mt,ft!==0&&Y-ft<P.storage&&(U+=Y-ft),$.__data=new Float32Array(P.storage/Float32Array.BYTES_PER_ELEMENT),$.__offset=U,U+=P.storage}}}const F=U%Y;return F>0&&(U+=Y-F),D.__size=U,D.__cache={},this}function M(D){const I={boundary:0,storage:0};return typeof D=="number"||typeof D=="boolean"?(I.boundary=4,I.storage=4):D.isVector2?(I.boundary=8,I.storage=8):D.isVector3||D.isColor?(I.boundary=16,I.storage=12):D.isVector4?(I.boundary=16,I.storage=16):D.isMatrix3?(I.boundary=48,I.storage=48):D.isMatrix4?(I.boundary=64,I.storage=64):D.isTexture?ee("WebGLRenderer: Texture samplers can not be part of an uniforms group."):ArrayBuffer.isView(D)?(I.boundary=16,I.storage=D.byteLength):ee("WebGLRenderer: Unsupported uniform value type.",D),I}function x(D){const I=D.target;I.removeEventListener("dispose",x);const U=f.indexOf(I.__bindingPointIndex);f.splice(U,1),r.deleteBuffer(l[I.id]),delete l[I.id],delete c[I.id]}function v(){for(const D in l)r.deleteBuffer(l[D]);f=[],l={},c={}}return{bind:p,update:h,dispose:v}}const PM=new Uint16Array([12469,15057,12620,14925,13266,14620,13807,14376,14323,13990,14545,13625,14713,13328,14840,12882,14931,12528,14996,12233,15039,11829,15066,11525,15080,11295,15085,10976,15082,10705,15073,10495,13880,14564,13898,14542,13977,14430,14158,14124,14393,13732,14556,13410,14702,12996,14814,12596,14891,12291,14937,11834,14957,11489,14958,11194,14943,10803,14921,10506,14893,10278,14858,9960,14484,14039,14487,14025,14499,13941,14524,13740,14574,13468,14654,13106,14743,12678,14818,12344,14867,11893,14889,11509,14893,11180,14881,10751,14852,10428,14812,10128,14765,9754,14712,9466,14764,13480,14764,13475,14766,13440,14766,13347,14769,13070,14786,12713,14816,12387,14844,11957,14860,11549,14868,11215,14855,10751,14825,10403,14782,10044,14729,9651,14666,9352,14599,9029,14967,12835,14966,12831,14963,12804,14954,12723,14936,12564,14917,12347,14900,11958,14886,11569,14878,11247,14859,10765,14828,10401,14784,10011,14727,9600,14660,9289,14586,8893,14508,8533,15111,12234,15110,12234,15104,12216,15092,12156,15067,12010,15028,11776,14981,11500,14942,11205,14902,10752,14861,10393,14812,9991,14752,9570,14682,9252,14603,8808,14519,8445,14431,8145,15209,11449,15208,11451,15202,11451,15190,11438,15163,11384,15117,11274,15055,10979,14994,10648,14932,10343,14871,9936,14803,9532,14729,9218,14645,8742,14556,8381,14461,8020,14365,7603,15273,10603,15272,10607,15267,10619,15256,10631,15231,10614,15182,10535,15118,10389,15042,10167,14963,9787,14883,9447,14800,9115,14710,8665,14615,8318,14514,7911,14411,7507,14279,7198,15314,9675,15313,9683,15309,9712,15298,9759,15277,9797,15229,9773,15166,9668,15084,9487,14995,9274,14898,8910,14800,8539,14697,8234,14590,7790,14479,7409,14367,7067,14178,6621,15337,8619,15337,8631,15333,8677,15325,8769,15305,8871,15264,8940,15202,8909,15119,8775,15022,8565,14916,8328,14804,8009,14688,7614,14569,7287,14448,6888,14321,6483,14088,6171,15350,7402,15350,7419,15347,7480,15340,7613,15322,7804,15287,7973,15229,8057,15148,8012,15046,7846,14933,7611,14810,7357,14682,7069,14552,6656,14421,6316,14251,5948,14007,5528,15356,5942,15356,5977,15353,6119,15348,6294,15332,6551,15302,6824,15249,7044,15171,7122,15070,7050,14949,6861,14818,6611,14679,6349,14538,6067,14398,5651,14189,5311,13935,4958,15359,4123,15359,4153,15356,4296,15353,4646,15338,5160,15311,5508,15263,5829,15188,6042,15088,6094,14966,6001,14826,5796,14678,5543,14527,5287,14377,4985,14133,4586,13869,4257,15360,1563,15360,1642,15358,2076,15354,2636,15341,3350,15317,4019,15273,4429,15203,4732,15105,4911,14981,4932,14836,4818,14679,4621,14517,4386,14359,4156,14083,3795,13808,3437,15360,122,15360,137,15358,285,15355,636,15344,1274,15322,2177,15281,2765,15215,3223,15120,3451,14995,3569,14846,3567,14681,3466,14511,3305,14344,3121,14037,2800,13753,2467,15360,0,15360,1,15359,21,15355,89,15346,253,15325,479,15287,796,15225,1148,15133,1492,15008,1749,14856,1882,14685,1886,14506,1783,14324,1608,13996,1398,13702,1183]);let Vi=null;function HM(){return Vi===null&&(Vi=new C2(PM,16,16,qs,ba),Vi.name="DFG_LUT",Vi.minFilter=Nn,Vi.magFilter=Nn,Vi.wrapS=ya,Vi.wrapT=ya,Vi.generateMipmaps=!1,Vi.needsUpdate=!0),Vi}class YM{constructor(t={}){const{canvas:i=i2(),context:s=null,depth:l=!0,stencil:c=!1,alpha:f=!1,antialias:T=!1,premultipliedAlpha:p=!0,preserveDrawingBuffer:h=!1,powerPreference:m="default",failIfMajorPerformanceCaveat:E=!1,reversedDepthBuffer:S=!1,outputBufferType:g=di}=t;this.isWebGLRenderer=!0;let A;if(s!==null){if(typeof WebGLRenderingContext<"u"&&s instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");A=s.getContextAttributes().alpha}else A=f;const M=g,x=new Set([c0,l0,o0]),v=new Set([di,ta,rl,ol,s0,r0]),D=new Uint32Array(4),I=new Int32Array(4),U=new nt;let Y=null,F=null;const B=[],R=[];let w=null;this.domElement=i,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this.toneMapping=Qi,this.toneMappingExposure=1,this.transmissionResolutionScale=1;const Z=this;let H=!1,$=null;this._outputColorSpace=Jn;let ct=0,lt=0,W=null,L=-1,P=null;const it=new an,mt=new an;let ft=null;const O=new _e(0);let V=0,dt=i.width,gt=i.height,Mt=1,rt=null,vt=null;const Nt=new an(0,0,dt,gt),Pt=new an(0,0,dt,gt);let Jt=!1;const Qt=new p0;let ze=!1,fe=!1;const Ee=new cn,Ie=new nt,le=new an,sn={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};let ke=!1;function Mn(){return W===null?Mt:1}let k=s;function Je(C,K){return i.getContext(C,K)}try{const C={alpha:!0,depth:l,stencil:c,antialias:T,premultipliedAlpha:p,preserveDrawingBuffer:h,powerPreference:m,failIfMajorPerformanceCaveat:E};if("setAttribute"in i&&i.setAttribute("data-engine",`three.js r${n0}`),i.addEventListener("webglcontextlost",At,!1),i.addEventListener("webglcontextrestored",Wt,!1),i.addEventListener("webglcontextcreationerror",te,!1),k===null){const K="webgl2";if(k=Je(K,C),k===null)throw Je(K)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}}catch(C){throw Ne("WebGLRenderer: "+C.message),C}let he,Pe,Ct,qe,b,N,Q,St,xt,yt,It,ut,ht,Lt,Ut,Ot,Dt,ne,ie,de,G,Rt,Tt;function Bt(){he=new Hx(k),he.init(),G=new bM(k,he),Pe=new Ix(k,he,t,G),Ct=new DM(k,he),Pe.reversedDepthBuffer&&S&&Ct.buffers.depth.setReversed(!0),qe=new zx(k),b=new TM,N=new OM(k,he,Ct,b,Pe,G,qe),Q=new Px(Z),St=new K2(k),Rt=new Ox(k,St),xt=new Yx(k,St,qe,Rt),yt=new Wx(k,xt,St,Rt,qe),ne=new Vx(k,Pe,N),Ut=new Lx(b),It=new pM(Z,Q,he,Pe,Rt,Ut),ut=new BM(Z,b),ht=new EM,Lt=new xM(he),Dt=new Dx(Z,Q,Ct,yt,A,p),Ot=new yM(Z,yt,Pe),Tt=new XM(k,qe,Pe,Ct),ie=new bx(k,he,qe),de=new Gx(k,he,qe),qe.programs=It.programs,Z.capabilities=Pe,Z.extensions=he,Z.properties=b,Z.renderLists=ht,Z.shadowMap=Ot,Z.state=Ct,Z.info=qe}Bt(),M!==di&&(w=new Kx(M,i.width,i.height,l,c));const bt=new FM(Z,k);this.xr=bt,this.getContext=function(){return k},this.getContextAttributes=function(){return k.getContextAttributes()},this.forceContextLoss=function(){const C=he.get("WEBGL_lose_context");C&&C.loseContext()},this.forceContextRestore=function(){const C=he.get("WEBGL_lose_context");C&&C.restoreContext()},this.getPixelRatio=function(){return Mt},this.setPixelRatio=function(C){C!==void 0&&(Mt=C,this.setSize(dt,gt,!1))},this.getSize=function(C){return C.set(dt,gt)},this.setSize=function(C,K,at=!0){if(bt.isPresenting){ee("WebGLRenderer: Can't change size while VR device is presenting.");return}dt=C,gt=K,i.width=Math.floor(C*Mt),i.height=Math.floor(K*Mt),at===!0&&(i.style.width=C+"px",i.style.height=K+"px"),w!==null&&w.setSize(i.width,i.height),this.setViewport(0,0,C,K)},this.getDrawingBufferSize=function(C){return C.set(dt*Mt,gt*Mt).floor()},this.setDrawingBufferSize=function(C,K,at){dt=C,gt=K,Mt=at,i.width=Math.floor(C*at),i.height=Math.floor(K*at),this.setViewport(0,0,C,K)},this.setEffects=function(C){if(M===di){Ne("THREE.WebGLRenderer: setEffects() requires outputBufferType set to HalfFloatType or FloatType.");return}if(C){for(let K=0;K<C.length;K++)if(C[K].isOutputPass===!0){ee("THREE.WebGLRenderer: OutputPass is not needed in setEffects(). Tone mapping and color space conversion are applied automatically.");break}}w.setEffects(C||[])},this.getCurrentViewport=function(C){return C.copy(it)},this.getViewport=function(C){return C.copy(Nt)},this.setViewport=function(C,K,at,tt){C.isVector4?Nt.set(C.x,C.y,C.z,C.w):Nt.set(C,K,at,tt),Ct.viewport(it.copy(Nt).multiplyScalar(Mt).round())},this.getScissor=function(C){return C.copy(Pt)},this.setScissor=function(C,K,at,tt){C.isVector4?Pt.set(C.x,C.y,C.z,C.w):Pt.set(C,K,at,tt),Ct.scissor(mt.copy(Pt).multiplyScalar(Mt).round())},this.getScissorTest=function(){return Jt},this.setScissorTest=function(C){Ct.setScissorTest(Jt=C)},this.setOpaqueSort=function(C){rt=C},this.setTransparentSort=function(C){vt=C},this.getClearColor=function(C){return C.copy(Dt.getClearColor())},this.setClearColor=function(){Dt.setClearColor(...arguments)},this.getClearAlpha=function(){return Dt.getClearAlpha()},this.setClearAlpha=function(){Dt.setClearAlpha(...arguments)},this.clear=function(C=!0,K=!0,at=!0){let tt=0;if(C){let et=!1;if(W!==null){const wt=W.texture.format;et=x.has(wt)}if(et){const wt=W.texture.type,Yt=v.has(wt),Ft=Dt.getClearColor(),zt=Dt.getClearAlpha(),Gt=Ft.r,qt=Ft.g,re=Ft.b;Yt?(D[0]=Gt,D[1]=qt,D[2]=re,D[3]=zt,k.clearBufferuiv(k.COLOR,0,D)):(I[0]=Gt,I[1]=qt,I[2]=re,I[3]=zt,k.clearBufferiv(k.COLOR,0,I))}else tt|=k.COLOR_BUFFER_BIT}K&&(tt|=k.DEPTH_BUFFER_BIT,this.state.buffers.depth.setMask(!0)),at&&(tt|=k.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),tt!==0&&k.clear(tt)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.setNodesHandler=function(C){C.setRenderer(this),$=C},this.dispose=function(){i.removeEventListener("webglcontextlost",At,!1),i.removeEventListener("webglcontextrestored",Wt,!1),i.removeEventListener("webglcontextcreationerror",te,!1),Dt.dispose(),ht.dispose(),Lt.dispose(),b.dispose(),Q.dispose(),yt.dispose(),Rt.dispose(),Tt.dispose(),It.dispose(),bt.dispose(),bt.removeEventListener("sessionstart",to),bt.removeEventListener("sessionend",eo),Ln.stop()};function At(C){C.preventDefault(),gm("WebGLRenderer: Context Lost."),H=!0}function Wt(){gm("WebGLRenderer: Context Restored."),H=!1;const C=qe.autoReset,K=Ot.enabled,at=Ot.autoUpdate,tt=Ot.needsUpdate,et=Ot.type;Bt(),qe.autoReset=C,Ot.enabled=K,Ot.autoUpdate=at,Ot.needsUpdate=tt,Ot.type=et}function te(C){Ne("WebGLRenderer: A WebGL context could not be created. Reason: ",C.statusMessage)}function tn(C){const K=C.target;K.removeEventListener("dispose",tn),ye(K)}function ye(C){pi(C),b.remove(C)}function pi(C){const K=b.get(C).programs;K!==void 0&&(K.forEach(function(at){It.releaseProgram(at)}),C.isShaderMaterial&&It.releaseShaderCache(C))}this.renderBufferDirect=function(C,K,at,tt,et,wt){K===null&&(K=sn);const Yt=et.isMesh&&et.matrixWorld.determinant()<0,Ft=Fa(C,K,at,tt,et);Ct.setMaterial(tt,Yt);let zt=at.index,Gt=1;if(tt.wireframe===!0){if(zt=xt.getWireframeAttribute(at),zt===void 0)return;Gt=2}const qt=at.drawRange,re=at.attributes.position;let Zt=qt.start*Gt,Me=(qt.start+qt.count)*Gt;wt!==null&&(Zt=Math.max(Zt,wt.start*Gt),Me=Math.min(Me,(wt.start+wt.count)*Gt)),zt!==null?(Zt=Math.max(Zt,0),Me=Math.min(Me,zt.count)):re!=null&&(Zt=Math.max(Zt,0),Me=Math.min(Me,re.count));const $e=Me-Zt;if($e<0||$e===1/0)return;Rt.setup(et,tt,Ft,at,zt);let Ve,Le=ie;if(zt!==null&&(Ve=St.get(zt),Le=de,Le.setIndex(Ve)),et.isMesh)tt.wireframe===!0?(Ct.setLineWidth(tt.wireframeLinewidth*Mn()),Le.setMode(k.LINES)):Le.setMode(k.TRIANGLES);else if(et.isLine){let Ue=tt.linewidth;Ue===void 0&&(Ue=1),Ct.setLineWidth(Ue*Mn()),et.isLineSegments?Le.setMode(k.LINES):et.isLineLoop?Le.setMode(k.LINE_LOOP):Le.setMode(k.LINE_STRIP)}else et.isPoints?Le.setMode(k.POINTS):et.isSprite&&Le.setMode(k.TRIANGLES);if(et.isBatchedMesh)if(he.get("WEBGL_multi_draw"))Le.renderMultiDraw(et._multiDrawStarts,et._multiDrawCounts,et._multiDrawCount);else{const Ue=et._multiDrawStarts,Ht=et._multiDrawCounts,Un=et._multiDrawCount,pe=zt?St.get(zt).bytesPerElement:1,mn=b.get(tt).currentProgram.getUniforms();for(let ni=0;ni<Un;ni++)mn.setValue(k,"_gl_DrawID",ni),Le.render(Ue[ni]/pe,Ht[ni])}else if(et.isInstancedMesh)Le.renderInstances(Zt,$e,et.count);else if(at.isInstancedBufferGeometry){const Ue=at._maxInstanceCount!==void 0?at._maxInstanceCount:1/0,Ht=Math.min(at.instanceCount,Ue);Le.renderInstances(Zt,$e,Ht)}else Le.render(Zt,$e)};function ei(C,K,at){C.transparent===!0&&C.side===Zi&&C.forceSinglePass===!1?(C.side=ti,C.needsUpdate=!0,Qs(C,K,at),C.side=Es,C.needsUpdate=!0,Qs(C,K,at),C.side=Zi):Qs(C,K,at)}this.compile=function(C,K,at=null){at===null&&(at=C),F=Lt.get(at),F.init(K),R.push(F),at.traverseVisible(function(et){et.isLight&&et.layers.test(K.layers)&&(F.pushLight(et),et.castShadow&&F.pushShadow(et))}),C!==at&&C.traverseVisible(function(et){et.isLight&&et.layers.test(K.layers)&&(F.pushLight(et),et.castShadow&&F.pushShadow(et))}),F.setupLights();const tt=new Set;return C.traverse(function(et){if(!(et.isMesh||et.isPoints||et.isLine||et.isSprite))return;const wt=et.material;if(wt)if(Array.isArray(wt))for(let Yt=0;Yt<wt.length;Yt++){const Ft=wt[Yt];ei(Ft,at,et),tt.add(Ft)}else ei(wt,at,et),tt.add(wt)}),F=R.pop(),tt},this.compileAsync=function(C,K,at=null){const tt=this.compile(C,K,at);return new Promise(et=>{function wt(){if(tt.forEach(function(Yt){b.get(Yt).currentProgram.isReady()&&tt.delete(Yt)}),tt.size===0){et(C);return}setTimeout(wt,10)}he.get("KHR_parallel_shader_compile")!==null?wt():setTimeout(wt,10)})};let gs=null;function Jr(C){gs&&gs(C)}function to(){Ln.stop()}function eo(){Ln.start()}const Ln=new $E;Ln.setAnimationLoop(Jr),typeof self<"u"&&Ln.setContext(self),this.setAnimationLoop=function(C){gs=C,bt.setAnimationLoop(C),C===null?Ln.stop():Ln.start()},bt.addEventListener("sessionstart",to),bt.addEventListener("sessionend",eo),this.render=function(C,K){if(K!==void 0&&K.isCamera!==!0){Ne("WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(H===!0)return;$!==null&&$.renderStart(C,K);const at=bt.enabled===!0&&bt.isPresenting===!0,tt=w!==null&&(W===null||at)&&w.begin(Z,W);if(C.matrixWorldAutoUpdate===!0&&C.updateMatrixWorld(),K.parent===null&&K.matrixWorldAutoUpdate===!0&&K.updateMatrixWorld(),bt.enabled===!0&&bt.isPresenting===!0&&(w===null||w.isCompositing()===!1)&&(bt.cameraAutoUpdate===!0&&bt.updateCamera(K),K=bt.getCamera()),C.isScene===!0&&C.onBeforeRender(Z,C,K,W),F=Lt.get(C,R.length),F.init(K),F.state.textureUnits=N.getTextureUnits(),R.push(F),Ee.multiplyMatrices(K.projectionMatrix,K.matrixWorldInverse),Qt.setFromProjectionMatrix(Ee,$i,K.reversedDepth),fe=this.localClippingEnabled,ze=Ut.init(this.clippingPlanes,fe),Y=ht.get(C,B.length),Y.init(),B.push(Y),bt.enabled===!0&&bt.isPresenting===!0){const Yt=Z.xr.getDepthSensingMesh();Yt!==null&&rn(Yt,K,-1/0,Z.sortObjects)}rn(C,K,0,Z.sortObjects),Y.finish(),Z.sortObjects===!0&&Y.sort(rt,vt),ke=bt.enabled===!1||bt.isPresenting===!1||bt.hasDepthSensing()===!1,ke&&Dt.addToRenderList(Y,C),this.info.render.frame++,ze===!0&&Ut.beginShadows();const et=F.state.shadowsArray;if(Ot.render(et,C,K),ze===!0&&Ut.endShadows(),this.info.autoReset===!0&&this.info.reset(),(tt&&w.hasRenderPass())===!1){const Yt=Y.opaque,Ft=Y.transmissive;if(F.setupLights(),K.isArrayCamera){const zt=K.cameras;if(Ft.length>0)for(let Gt=0,qt=zt.length;Gt<qt;Gt++){const re=zt[Gt];ia(Yt,Ft,C,re)}ke&&Dt.render(C);for(let Gt=0,qt=zt.length;Gt<qt;Gt++){const re=zt[Gt];Rn(Y,C,re,re.viewport)}}else Ft.length>0&&ia(Yt,Ft,C,K),ke&&Dt.render(C),Rn(Y,C,K)}W!==null&&lt===0&&(N.updateMultisampleRenderTarget(W),N.updateRenderTargetMipmap(W)),tt&&w.end(Z),C.isScene===!0&&C.onAfterRender(Z,C,K),Rt.resetDefaultState(),L=-1,P=null,R.pop(),R.length>0?(F=R[R.length-1],N.setTextureUnits(F.state.textureUnits),ze===!0&&Ut.setGlobalState(Z.clippingPlanes,F.state.camera)):F=null,B.pop(),B.length>0?Y=B[B.length-1]:Y=null,$!==null&&$.renderEnd()};function rn(C,K,at,tt){if(C.visible===!1)return;if(C.layers.test(K.layers)){if(C.isGroup)at=C.renderOrder;else if(C.isLOD)C.autoUpdate===!0&&C.update(K);else if(C.isLightProbeGrid)F.pushLightProbeGrid(C);else if(C.isLight)F.pushLight(C),C.castShadow&&F.pushShadow(C);else if(C.isSprite){if(!C.frustumCulled||Qt.intersectsSprite(C)){tt&&le.setFromMatrixPosition(C.matrixWorld).applyMatrix4(Ee);const Yt=yt.update(C),Ft=C.material;Ft.visible&&Y.push(C,Yt,Ft,at,le.z,null)}}else if((C.isMesh||C.isLine||C.isPoints)&&(!C.frustumCulled||Qt.intersectsObject(C))){const Yt=yt.update(C),Ft=C.material;if(tt&&(C.boundingSphere!==void 0?(C.boundingSphere===null&&C.computeBoundingSphere(),le.copy(C.boundingSphere.center)):(Yt.boundingSphere===null&&Yt.computeBoundingSphere(),le.copy(Yt.boundingSphere.center)),le.applyMatrix4(C.matrixWorld).applyMatrix4(Ee)),Array.isArray(Ft)){const zt=Yt.groups;for(let Gt=0,qt=zt.length;Gt<qt;Gt++){const re=zt[Gt],Zt=Ft[re.materialIndex];Zt&&Zt.visible&&Y.push(C,Yt,Zt,at,le.z,re)}}else Ft.visible&&Y.push(C,Yt,Ft,at,le.z,null)}}const wt=C.children;for(let Yt=0,Ft=wt.length;Yt<Ft;Yt++)rn(wt[Yt],K,at,tt)}function Rn(C,K,at,tt){const{opaque:et,transmissive:wt,transparent:Yt}=C;F.setupLightsView(at),ze===!0&&Ut.setGlobalState(Z.clippingPlanes,at),tt&&Ct.viewport(it.copy(tt)),et.length>0&&La(et,K,at),wt.length>0&&La(wt,K,at),Yt.length>0&&La(Yt,K,at),Ct.buffers.depth.setTest(!0),Ct.buffers.depth.setMask(!0),Ct.buffers.color.setMask(!0),Ct.setPolygonOffset(!1)}function ia(C,K,at,tt){if((at.isScene===!0?at.overrideMaterial:null)!==null)return;if(F.state.transmissionRenderTarget[tt.id]===void 0){const Zt=he.has("EXT_color_buffer_half_float")||he.has("EXT_color_buffer_float");F.state.transmissionRenderTarget[tt.id]=new ji(1,1,{generateMipmaps:!0,type:Zt?ba:di,minFilter:ks,samples:Math.max(4,Pe.samples),stencilBuffer:c,resolveDepthBuffer:!1,resolveStencilBuffer:!1,colorSpace:Ae.workingColorSpace})}const wt=F.state.transmissionRenderTarget[tt.id],Yt=tt.viewport||it;wt.setSize(Yt.z*Z.transmissionResolutionScale,Yt.w*Z.transmissionResolutionScale);const Ft=Z.getRenderTarget(),zt=Z.getActiveCubeFace(),Gt=Z.getActiveMipmapLevel();Z.setRenderTarget(wt),Z.getClearColor(O),V=Z.getClearAlpha(),V<1&&Z.setClearColor(16777215,.5),Z.clear(),ke&&Dt.render(at);const qt=Z.toneMapping;Z.toneMapping=Qi;const re=tt.viewport;if(tt.viewport!==void 0&&(tt.viewport=void 0),F.setupLightsView(tt),ze===!0&&Ut.setGlobalState(Z.clippingPlanes,tt),La(C,at,tt),N.updateMultisampleRenderTarget(wt),N.updateRenderTargetMipmap(wt),he.has("WEBGL_multisampled_render_to_texture")===!1){let Zt=!1;for(let Me=0,$e=K.length;Me<$e;Me++){const Ve=K[Me],{object:Le,geometry:Ue,material:Ht,group:Un}=Ve;if(Ht.side===Zi&&Le.layers.test(tt.layers)){const pe=Ht.side;Ht.side=ti,Ht.needsUpdate=!0,hl(Le,at,tt,Ue,Ht,Un),Ht.side=pe,Ht.needsUpdate=!0,Zt=!0}}Zt===!0&&(N.updateMultisampleRenderTarget(wt),N.updateRenderTargetMipmap(wt))}Z.setRenderTarget(Ft,zt,Gt),Z.setClearColor(O,V),re!==void 0&&(tt.viewport=re),Z.toneMapping=qt}function La(C,K,at){const tt=K.isScene===!0?K.overrideMaterial:null;for(let et=0,wt=C.length;et<wt;et++){const Yt=C[et],{object:Ft,geometry:zt,group:Gt}=Yt;let qt=Yt.material;qt.allowOverride===!0&&tt!==null&&(qt=tt),Ft.layers.test(at.layers)&&hl(Ft,K,at,zt,qt,Gt)}}function hl(C,K,at,tt,et,wt){C.onBeforeRender(Z,K,at,tt,et,wt),C.modelViewMatrix.multiplyMatrices(at.matrixWorldInverse,C.matrixWorld),C.normalMatrix.getNormalMatrix(C.modelViewMatrix),et.onBeforeRender(Z,K,at,tt,C,wt),et.transparent===!0&&et.side===Zi&&et.forceSinglePass===!1?(et.side=ti,et.needsUpdate=!0,Z.renderBufferDirect(at,K,tt,et,C,wt),et.side=Es,et.needsUpdate=!0,Z.renderBufferDirect(at,K,tt,et,C,wt),et.side=Zi):Z.renderBufferDirect(at,K,tt,et,C,wt),C.onAfterRender(Z,K,at,tt,et,wt)}function Qs(C,K,at){K.isScene!==!0&&(K=sn);const tt=b.get(C),et=F.state.lights,wt=F.state.shadowsArray,Yt=et.state.version,Ft=It.getParameters(C,et.state,wt,K,at,F.state.lightProbeGridArray),zt=It.getProgramCacheKey(Ft);let Gt=tt.programs;tt.environment=C.isMeshStandardMaterial||C.isMeshLambertMaterial||C.isMeshPhongMaterial?K.environment:null,tt.fog=K.fog;const qt=C.isMeshStandardMaterial||C.isMeshLambertMaterial&&!C.envMap||C.isMeshPhongMaterial&&!C.envMap;tt.envMap=Q.get(C.envMap||tt.environment,qt),tt.envMapRotation=tt.environment!==null&&C.envMap===null?K.environmentRotation:C.envMapRotation,Gt===void 0&&(C.addEventListener("dispose",tn),Gt=new Map,tt.programs=Gt);let re=Gt.get(zt);if(re!==void 0){if(tt.currentProgram===re&&tt.lightsStateVersion===Yt)return Ua(C,Ft),re}else Ft.uniforms=It.getUniforms(C),$!==null&&C.isNodeMaterial&&$.build(C,at,Ft),C.onBeforeCompile(Ft,Z),re=It.acquireProgram(Ft,zt),Gt.set(zt,re),tt.uniforms=Ft.uniforms;const Zt=tt.uniforms;return(!C.isShaderMaterial&&!C.isRawShaderMaterial||C.clipping===!0)&&(Zt.clippingPlanes=Ut.uniform),Ua(C,Ft),tt.needsLights=_s(C),tt.lightsStateVersion=Yt,tt.needsLights&&(Zt.ambientLightColor.value=et.state.ambient,Zt.lightProbe.value=et.state.probe,Zt.directionalLights.value=et.state.directional,Zt.directionalLightShadows.value=et.state.directionalShadow,Zt.spotLights.value=et.state.spot,Zt.spotLightShadows.value=et.state.spotShadow,Zt.rectAreaLights.value=et.state.rectArea,Zt.ltc_1.value=et.state.rectAreaLTC1,Zt.ltc_2.value=et.state.rectAreaLTC2,Zt.pointLights.value=et.state.point,Zt.pointLightShadows.value=et.state.pointShadow,Zt.hemisphereLights.value=et.state.hemi,Zt.directionalShadowMatrix.value=et.state.directionalShadowMatrix,Zt.spotLightMatrix.value=et.state.spotLightMatrix,Zt.spotLightMap.value=et.state.spotLightMap,Zt.pointShadowMatrix.value=et.state.pointShadowMatrix),tt.lightProbeGrid=F.state.lightProbeGridArray.length>0,tt.currentProgram=re,tt.uniformsList=null,re}function no(C){if(C.uniformsList===null){const K=C.currentProgram.getUniforms();C.uniformsList=Qc.seqWithValue(K.seq,C.uniforms)}return C.uniformsList}function Ua(C,K){const at=b.get(C);at.outputColorSpace=K.outputColorSpace,at.batching=K.batching,at.batchingColor=K.batchingColor,at.instancing=K.instancing,at.instancingColor=K.instancingColor,at.instancingMorph=K.instancingMorph,at.skinning=K.skinning,at.morphTargets=K.morphTargets,at.morphNormals=K.morphNormals,at.morphColors=K.morphColors,at.morphTargetsCount=K.morphTargetsCount,at.numClippingPlanes=K.numClippingPlanes,at.numIntersection=K.numClipIntersection,at.vertexAlphas=K.vertexAlphas,at.vertexTangents=K.vertexTangents,at.toneMapping=K.toneMapping}function io(C,K){if(C.length===0)return null;if(C.length===1)return C[0].texture!==null?C[0]:null;U.setFromMatrixPosition(K.matrixWorld);for(let at=0,tt=C.length;at<tt;at++){const et=C[at];if(et.texture!==null&&et.boundingBox.containsPoint(U))return et}return null}function Fa(C,K,at,tt,et){K.isScene!==!0&&(K=sn),N.resetTextureUnits();const wt=K.fog,Yt=tt.isMeshStandardMaterial||tt.isMeshLambertMaterial||tt.isMeshPhongMaterial?K.environment:null,Ft=W===null?Z.outputColorSpace:W.isXRRenderTarget===!0?W.texture.colorSpace:Ae.workingColorSpace,zt=tt.isMeshStandardMaterial||tt.isMeshLambertMaterial&&!tt.envMap||tt.isMeshPhongMaterial&&!tt.envMap,Gt=Q.get(tt.envMap||Yt,zt),qt=tt.vertexColors===!0&&!!at.attributes.color&&at.attributes.color.itemSize===4,re=!!at.attributes.tangent&&(!!tt.normalMap||tt.anisotropy>0),Zt=!!at.morphAttributes.position,Me=!!at.morphAttributes.normal,$e=!!at.morphAttributes.color;let Ve=Qi;tt.toneMapped&&(W===null||W.isXRRenderTarget===!0)&&(Ve=Z.toneMapping);const Le=at.morphAttributes.position||at.morphAttributes.normal||at.morphAttributes.color,Ue=Le!==void 0?Le.length:0,Ht=b.get(tt),Un=F.state.lights;if(ze===!0&&(fe===!0||C!==P)){const be=C===P&&tt.id===L;Ut.setState(tt,C,be)}let pe=!1;tt.version===Ht.__version?(Ht.needsLights&&Ht.lightsStateVersion!==Un.state.version||Ht.outputColorSpace!==Ft||et.isBatchedMesh&&Ht.batching===!1||!et.isBatchedMesh&&Ht.batching===!0||et.isBatchedMesh&&Ht.batchingColor===!0&&et.colorTexture===null||et.isBatchedMesh&&Ht.batchingColor===!1&&et.colorTexture!==null||et.isInstancedMesh&&Ht.instancing===!1||!et.isInstancedMesh&&Ht.instancing===!0||et.isSkinnedMesh&&Ht.skinning===!1||!et.isSkinnedMesh&&Ht.skinning===!0||et.isInstancedMesh&&Ht.instancingColor===!0&&et.instanceColor===null||et.isInstancedMesh&&Ht.instancingColor===!1&&et.instanceColor!==null||et.isInstancedMesh&&Ht.instancingMorph===!0&&et.morphTexture===null||et.isInstancedMesh&&Ht.instancingMorph===!1&&et.morphTexture!==null||Ht.envMap!==Gt||tt.fog===!0&&Ht.fog!==wt||Ht.numClippingPlanes!==void 0&&(Ht.numClippingPlanes!==Ut.numPlanes||Ht.numIntersection!==Ut.numIntersection)||Ht.vertexAlphas!==qt||Ht.vertexTangents!==re||Ht.morphTargets!==Zt||Ht.morphNormals!==Me||Ht.morphColors!==$e||Ht.toneMapping!==Ve||Ht.morphTargetsCount!==Ue||!!Ht.lightProbeGrid!=F.state.lightProbeGridArray.length>0)&&(pe=!0):(pe=!0,Ht.__version=tt.version);let mn=Ht.currentProgram;pe===!0&&(mn=Qs(tt,K,et),$&&tt.isNodeMaterial&&$.onUpdateProgram(tt,mn,Ht));let ni=!1,Mi=!1,ii=!1;const Fe=mn.getUniforms(),Qe=Ht.uniforms;if(Ct.useProgram(mn.program)&&(ni=!0,Mi=!0,ii=!0),tt.id!==L&&(L=tt.id,Mi=!0),Ht.needsLights){const be=io(F.state.lightProbeGridArray,et);Ht.lightProbeGrid!==be&&(Ht.lightProbeGrid=be,Mi=!0)}if(ni||P!==C){Ct.buffers.depth.getReversed()&&C.reversedDepth!==!0&&(C._reversedDepth=!0,C.updateProjectionMatrix()),Fe.setValue(k,"projectionMatrix",C.projectionMatrix),Fe.setValue(k,"viewMatrix",C.matrixWorldInverse);const Xi=Fe.map.cameraPosition;Xi!==void 0&&Xi.setValue(k,Ie.setFromMatrixPosition(C.matrixWorld)),Pe.logarithmicDepthBuffer&&Fe.setValue(k,"logDepthBufFC",2/(Math.log(C.far+1)/Math.LN2)),(tt.isMeshPhongMaterial||tt.isMeshToonMaterial||tt.isMeshLambertMaterial||tt.isMeshBasicMaterial||tt.isMeshStandardMaterial||tt.isShaderMaterial)&&Fe.setValue(k,"isOrthographic",C.isOrthographicCamera===!0),P!==C&&(P=C,Mi=!0,ii=!0)}if(Ht.needsLights&&(Un.state.directionalShadowMap.length>0&&Fe.setValue(k,"directionalShadowMap",Un.state.directionalShadowMap,N),Un.state.spotShadowMap.length>0&&Fe.setValue(k,"spotShadowMap",Un.state.spotShadowMap,N),Un.state.pointShadowMap.length>0&&Fe.setValue(k,"pointShadowMap",Un.state.pointShadowMap,N)),et.isSkinnedMesh){Fe.setOptional(k,et,"bindMatrix"),Fe.setOptional(k,et,"bindMatrixInverse");const be=et.skeleton;be&&(be.boneTexture===null&&be.computeBoneTexture(),Fe.setValue(k,"boneTexture",be.boneTexture,N))}et.isBatchedMesh&&(Fe.setOptional(k,et,"batchingTexture"),Fe.setValue(k,"batchingTexture",et._matricesTexture,N),Fe.setOptional(k,et,"batchingIdTexture"),Fe.setValue(k,"batchingIdTexture",et._indirectTexture,N),Fe.setOptional(k,et,"batchingColorTexture"),et._colorsTexture!==null&&Fe.setValue(k,"batchingColorTexture",et._colorsTexture,N));const Ri=at.morphAttributes;if((Ri.position!==void 0||Ri.normal!==void 0||Ri.color!==void 0)&&ne.update(et,at,mn),(Mi||Ht.receiveShadow!==et.receiveShadow)&&(Ht.receiveShadow=et.receiveShadow,Fe.setValue(k,"receiveShadow",et.receiveShadow)),(tt.isMeshStandardMaterial||tt.isMeshLambertMaterial||tt.isMeshPhongMaterial)&&tt.envMap===null&&K.environment!==null&&(Qe.envMapIntensity.value=K.environmentIntensity),Qe.dfgLUT!==void 0&&(Qe.dfgLUT.value=HM()),Mi){if(Fe.setValue(k,"toneMappingExposure",Z.toneMappingExposure),Ht.needsLights&&wa(Qe,ii),wt&&tt.fog===!0&&ut.refreshFogUniforms(Qe,wt),ut.refreshMaterialUniforms(Qe,tt,Mt,gt,F.state.transmissionRenderTarget[C.id]),Ht.needsLights&&Ht.lightProbeGrid){const be=Ht.lightProbeGrid;Qe.probesSH.value=be.texture,Qe.probesMin.value.copy(be.boundingBox.min),Qe.probesMax.value.copy(be.boundingBox.max),Qe.probesResolution.value.copy(be.resolution)}Qc.upload(k,no(Ht),Qe,N)}if(tt.isShaderMaterial&&tt.uniformsNeedUpdate===!0&&(Qc.upload(k,no(Ht),Qe,N),tt.uniformsNeedUpdate=!1),tt.isSpriteMaterial&&Fe.setValue(k,"center",et.center),Fe.setValue(k,"modelViewMatrix",et.modelViewMatrix),Fe.setValue(k,"normalMatrix",et.normalMatrix),Fe.setValue(k,"modelMatrix",et.matrixWorld),tt.uniformsGroups!==void 0){const be=tt.uniformsGroups;for(let Xi=0,Xa=be.length;Xi<Xa;Xi++){const vs=be[Xi];Tt.update(vs,mn),Tt.bind(vs,mn)}}return mn}function wa(C,K){C.ambientLightColor.needsUpdate=K,C.lightProbe.needsUpdate=K,C.directionalLights.needsUpdate=K,C.directionalLightShadows.needsUpdate=K,C.pointLights.needsUpdate=K,C.pointLightShadows.needsUpdate=K,C.spotLights.needsUpdate=K,C.spotLightShadows.needsUpdate=K,C.rectAreaLights.needsUpdate=K,C.hemisphereLights.needsUpdate=K}function _s(C){return C.isMeshLambertMaterial||C.isMeshToonMaterial||C.isMeshPhongMaterial||C.isMeshStandardMaterial||C.isShadowMaterial||C.isShaderMaterial&&C.lights===!0}this.getActiveCubeFace=function(){return ct},this.getActiveMipmapLevel=function(){return lt},this.getRenderTarget=function(){return W},this.setRenderTargetTextures=function(C,K,at){const tt=b.get(C);tt.__autoAllocateDepthBuffer=C.resolveDepthBuffer===!1,tt.__autoAllocateDepthBuffer===!1&&(tt.__useRenderToTexture=!1),b.get(C.texture).__webglTexture=K,b.get(C.depthTexture).__webglTexture=tt.__autoAllocateDepthBuffer?void 0:at,tt.__hasExternalTextures=!0},this.setRenderTargetFramebuffer=function(C,K){const at=b.get(C);at.__webglFramebuffer=K,at.__useDefaultFramebuffer=K===void 0};const Ba=k.createFramebuffer();this.setRenderTarget=function(C,K=0,at=0){W=C,ct=K,lt=at;let tt=null,et=!1,wt=!1;if(C){const Ft=b.get(C);if(Ft.__useDefaultFramebuffer!==void 0){Ct.bindFramebuffer(k.FRAMEBUFFER,Ft.__webglFramebuffer),it.copy(C.viewport),mt.copy(C.scissor),ft=C.scissorTest,Ct.viewport(it),Ct.scissor(mt),Ct.setScissorTest(ft),L=-1;return}else if(Ft.__webglFramebuffer===void 0)N.setupRenderTarget(C);else if(Ft.__hasExternalTextures)N.rebindTextures(C,b.get(C.texture).__webglTexture,b.get(C.depthTexture).__webglTexture);else if(C.depthBuffer){const qt=C.depthTexture;if(Ft.__boundDepthTexture!==qt){if(qt!==null&&b.has(qt)&&(C.width!==qt.image.width||C.height!==qt.image.height))throw new Error("WebGLRenderTarget: Attached DepthTexture is initialized to the incorrect size.");N.setupDepthRenderbuffer(C)}}const zt=C.texture;(zt.isData3DTexture||zt.isDataArrayTexture||zt.isCompressedArrayTexture)&&(wt=!0);const Gt=b.get(C).__webglFramebuffer;C.isWebGLCubeRenderTarget?(Array.isArray(Gt[K])?tt=Gt[K][at]:tt=Gt[K],et=!0):C.samples>0&&N.useMultisampledRTT(C)===!1?tt=b.get(C).__webglMultisampledFramebuffer:Array.isArray(Gt)?tt=Gt[at]:tt=Gt,it.copy(C.viewport),mt.copy(C.scissor),ft=C.scissorTest}else it.copy(Nt).multiplyScalar(Mt).floor(),mt.copy(Pt).multiplyScalar(Mt).floor(),ft=Jt;if(at!==0&&(tt=Ba),Ct.bindFramebuffer(k.FRAMEBUFFER,tt)&&Ct.drawBuffers(C,tt),Ct.viewport(it),Ct.scissor(mt),Ct.setScissorTest(ft),et){const Ft=b.get(C.texture);k.framebufferTexture2D(k.FRAMEBUFFER,k.COLOR_ATTACHMENT0,k.TEXTURE_CUBE_MAP_POSITIVE_X+K,Ft.__webglTexture,at)}else if(wt){const Ft=K;for(let zt=0;zt<C.textures.length;zt++){const Gt=b.get(C.textures[zt]);k.framebufferTextureLayer(k.FRAMEBUFFER,k.COLOR_ATTACHMENT0+zt,Gt.__webglTexture,at,Ft)}}else if(C!==null&&at!==0){const Ft=b.get(C.texture);k.framebufferTexture2D(k.FRAMEBUFFER,k.COLOR_ATTACHMENT0,k.TEXTURE_2D,Ft.__webglTexture,at)}L=-1},this.readRenderTargetPixels=function(C,K,at,tt,et,wt,Yt,Ft=0){if(!(C&&C.isWebGLRenderTarget)){Ne("WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let zt=b.get(C).__webglFramebuffer;if(C.isWebGLCubeRenderTarget&&Yt!==void 0&&(zt=zt[Yt]),zt){Ct.bindFramebuffer(k.FRAMEBUFFER,zt);try{const Gt=C.textures[Ft],qt=Gt.format,re=Gt.type;if(C.textures.length>1&&k.readBuffer(k.COLOR_ATTACHMENT0+Ft),!Pe.textureFormatReadable(qt)){Ne("WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(!Pe.textureTypeReadable(re)){Ne("WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}K>=0&&K<=C.width-tt&&at>=0&&at<=C.height-et&&k.readPixels(K,at,tt,et,G.convert(qt),G.convert(re),wt)}finally{const Gt=W!==null?b.get(W).__webglFramebuffer:null;Ct.bindFramebuffer(k.FRAMEBUFFER,Gt)}}},this.readRenderTargetPixelsAsync=async function(C,K,at,tt,et,wt,Yt,Ft=0){if(!(C&&C.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let zt=b.get(C).__webglFramebuffer;if(C.isWebGLCubeRenderTarget&&Yt!==void 0&&(zt=zt[Yt]),zt)if(K>=0&&K<=C.width-tt&&at>=0&&at<=C.height-et){Ct.bindFramebuffer(k.FRAMEBUFFER,zt);const Gt=C.textures[Ft],qt=Gt.format,re=Gt.type;if(C.textures.length>1&&k.readBuffer(k.COLOR_ATTACHMENT0+Ft),!Pe.textureFormatReadable(qt))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(!Pe.textureTypeReadable(re))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");const Zt=k.createBuffer();k.bindBuffer(k.PIXEL_PACK_BUFFER,Zt),k.bufferData(k.PIXEL_PACK_BUFFER,wt.byteLength,k.STREAM_READ),k.readPixels(K,at,tt,et,G.convert(qt),G.convert(re),0);const Me=W!==null?b.get(W).__webglFramebuffer:null;Ct.bindFramebuffer(k.FRAMEBUFFER,Me);const $e=k.fenceSync(k.SYNC_GPU_COMMANDS_COMPLETE,0);return k.flush(),await a2(k,$e,4),k.bindBuffer(k.PIXEL_PACK_BUFFER,Zt),k.getBufferSubData(k.PIXEL_PACK_BUFFER,0,wt),k.deleteBuffer(Zt),k.deleteSync($e),wt}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")},this.copyFramebufferToTexture=function(C,K=null,at=0){const tt=Math.pow(2,-at),et=Math.floor(C.image.width*tt),wt=Math.floor(C.image.height*tt),Yt=K!==null?K.x:0,Ft=K!==null?K.y:0;N.setTexture2D(C,0),k.copyTexSubImage2D(k.TEXTURE_2D,at,0,0,Yt,Ft,et,wt),Ct.unbindTexture()};const un=k.createFramebuffer(),dl=k.createFramebuffer();this.copyTextureToTexture=function(C,K,at=null,tt=null,et=0,wt=0){let Yt,Ft,zt,Gt,qt,re,Zt,Me,$e;const Ve=C.isCompressedTexture?C.mipmaps[wt]:C.image;if(at!==null)Yt=at.max.x-at.min.x,Ft=at.max.y-at.min.y,zt=at.isBox3?at.max.z-at.min.z:1,Gt=at.min.x,qt=at.min.y,re=at.isBox3?at.min.z:0;else{const Qe=Math.pow(2,-et);Yt=Math.floor(Ve.width*Qe),Ft=Math.floor(Ve.height*Qe),C.isDataArrayTexture?zt=Ve.depth:C.isData3DTexture?zt=Math.floor(Ve.depth*Qe):zt=1,Gt=0,qt=0,re=0}tt!==null?(Zt=tt.x,Me=tt.y,$e=tt.z):(Zt=0,Me=0,$e=0);const Le=G.convert(K.format),Ue=G.convert(K.type);let Ht;K.isData3DTexture?(N.setTexture3D(K,0),Ht=k.TEXTURE_3D):K.isDataArrayTexture||K.isCompressedArrayTexture?(N.setTexture2DArray(K,0),Ht=k.TEXTURE_2D_ARRAY):(N.setTexture2D(K,0),Ht=k.TEXTURE_2D),Ct.activeTexture(k.TEXTURE0),Ct.pixelStorei(k.UNPACK_FLIP_Y_WEBGL,K.flipY),Ct.pixelStorei(k.UNPACK_PREMULTIPLY_ALPHA_WEBGL,K.premultiplyAlpha),Ct.pixelStorei(k.UNPACK_ALIGNMENT,K.unpackAlignment);const Un=Ct.getParameter(k.UNPACK_ROW_LENGTH),pe=Ct.getParameter(k.UNPACK_IMAGE_HEIGHT),mn=Ct.getParameter(k.UNPACK_SKIP_PIXELS),ni=Ct.getParameter(k.UNPACK_SKIP_ROWS),Mi=Ct.getParameter(k.UNPACK_SKIP_IMAGES);Ct.pixelStorei(k.UNPACK_ROW_LENGTH,Ve.width),Ct.pixelStorei(k.UNPACK_IMAGE_HEIGHT,Ve.height),Ct.pixelStorei(k.UNPACK_SKIP_PIXELS,Gt),Ct.pixelStorei(k.UNPACK_SKIP_ROWS,qt),Ct.pixelStorei(k.UNPACK_SKIP_IMAGES,re);const ii=C.isDataArrayTexture||C.isData3DTexture,Fe=K.isDataArrayTexture||K.isData3DTexture;if(C.isDepthTexture){const Qe=b.get(C),Ri=b.get(K),be=b.get(Qe.__renderTarget),Xi=b.get(Ri.__renderTarget);Ct.bindFramebuffer(k.READ_FRAMEBUFFER,be.__webglFramebuffer),Ct.bindFramebuffer(k.DRAW_FRAMEBUFFER,Xi.__webglFramebuffer);for(let Xa=0;Xa<zt;Xa++)ii&&(k.framebufferTextureLayer(k.READ_FRAMEBUFFER,k.COLOR_ATTACHMENT0,b.get(C).__webglTexture,et,re+Xa),k.framebufferTextureLayer(k.DRAW_FRAMEBUFFER,k.COLOR_ATTACHMENT0,b.get(K).__webglTexture,wt,$e+Xa)),k.blitFramebuffer(Gt,qt,Yt,Ft,Zt,Me,Yt,Ft,k.DEPTH_BUFFER_BIT,k.NEAREST);Ct.bindFramebuffer(k.READ_FRAMEBUFFER,null),Ct.bindFramebuffer(k.DRAW_FRAMEBUFFER,null)}else if(et!==0||C.isRenderTargetTexture||b.has(C)){const Qe=b.get(C),Ri=b.get(K);Ct.bindFramebuffer(k.READ_FRAMEBUFFER,un),Ct.bindFramebuffer(k.DRAW_FRAMEBUFFER,dl);for(let be=0;be<zt;be++)ii?k.framebufferTextureLayer(k.READ_FRAMEBUFFER,k.COLOR_ATTACHMENT0,Qe.__webglTexture,et,re+be):k.framebufferTexture2D(k.READ_FRAMEBUFFER,k.COLOR_ATTACHMENT0,k.TEXTURE_2D,Qe.__webglTexture,et),Fe?k.framebufferTextureLayer(k.DRAW_FRAMEBUFFER,k.COLOR_ATTACHMENT0,Ri.__webglTexture,wt,$e+be):k.framebufferTexture2D(k.DRAW_FRAMEBUFFER,k.COLOR_ATTACHMENT0,k.TEXTURE_2D,Ri.__webglTexture,wt),et!==0?k.blitFramebuffer(Gt,qt,Yt,Ft,Zt,Me,Yt,Ft,k.COLOR_BUFFER_BIT,k.NEAREST):Fe?k.copyTexSubImage3D(Ht,wt,Zt,Me,$e+be,Gt,qt,Yt,Ft):k.copyTexSubImage2D(Ht,wt,Zt,Me,Gt,qt,Yt,Ft);Ct.bindFramebuffer(k.READ_FRAMEBUFFER,null),Ct.bindFramebuffer(k.DRAW_FRAMEBUFFER,null)}else Fe?C.isDataTexture||C.isData3DTexture?k.texSubImage3D(Ht,wt,Zt,Me,$e,Yt,Ft,zt,Le,Ue,Ve.data):K.isCompressedArrayTexture?k.compressedTexSubImage3D(Ht,wt,Zt,Me,$e,Yt,Ft,zt,Le,Ve.data):k.texSubImage3D(Ht,wt,Zt,Me,$e,Yt,Ft,zt,Le,Ue,Ve):C.isDataTexture?k.texSubImage2D(k.TEXTURE_2D,wt,Zt,Me,Yt,Ft,Le,Ue,Ve.data):C.isCompressedTexture?k.compressedTexSubImage2D(k.TEXTURE_2D,wt,Zt,Me,Ve.width,Ve.height,Le,Ve.data):k.texSubImage2D(k.TEXTURE_2D,wt,Zt,Me,Yt,Ft,Le,Ue,Ve);Ct.pixelStorei(k.UNPACK_ROW_LENGTH,Un),Ct.pixelStorei(k.UNPACK_IMAGE_HEIGHT,pe),Ct.pixelStorei(k.UNPACK_SKIP_PIXELS,mn),Ct.pixelStorei(k.UNPACK_SKIP_ROWS,ni),Ct.pixelStorei(k.UNPACK_SKIP_IMAGES,Mi),wt===0&&K.generateMipmaps&&k.generateMipmap(Ht),Ct.unbindTexture()},this.initRenderTarget=function(C){b.get(C).__webglFramebuffer===void 0&&N.setupRenderTarget(C)},this.initTexture=function(C){C.isCubeTexture?N.setTextureCube(C,0):C.isData3DTexture?N.setTexture3D(C,0):C.isDataArrayTexture||C.isCompressedArrayTexture?N.setTexture2DArray(C,0):N.setTexture2D(C,0),Ct.unbindTexture()},this.resetState=function(){ct=0,lt=0,W=null,Ct.reset(),Rt.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return $i}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(t){this._outputColorSpace=t;const i=this.getContext();i.drawingBufferColorSpace=Ae._getDrawingBufferColorSpace(t),i.unpackColorSpace=Ae._getUnpackColorSpace()}}const m0=[{kind:"range",id:"speed",label:"Speed",description:"Animation timing multiplier. Classic defaults to the original pacing target.",min:.25,max:3,step:.05,defaultValue:1},{kind:"range",id:"density",label:"Density",description:"How many particles, beams, or repeated elements the scene draws where the routine allows it.",min:.35,max:2,step:.05,defaultValue:1},{kind:"range",id:"trail",label:"Trail",description:"Persistence amount for demos with afterimages. Set to 0 for no trail where supported.",min:0,max:1,step:.05,defaultValue:.35}],E0=[{kind:"toggle",id:"antialias",label:"Classic anti-aliasing",description:"Smoothing for Classic mode. On by default for a softer browser presentation.",defaultValue:!0},{kind:"range",id:"modernLineWidth",label:"Modern line width",description:"Stroke multiplier for high-resolution rendering, where one-pixel DOS lines become too thin.",min:1,max:8,step:.1,defaultValue:4}],aS=[...m0,...E0];function fE(r={}){return[...m0.map(t=>t.kind==="range"&&t.id==="trail"&&r.trail!==void 0?{...t,defaultValue:r.trail}:t),...E0.map(t=>t.kind==="range"&&t.id==="modernLineWidth"&&r.modernLineWidth!==void 0?{...t,defaultValue:r.modernLineWidth}:t)]}function Li(r,t="original",i={}){return[...m0.map(s=>s.kind==="range"&&s.id==="trail"&&i.trail!==void 0?{...s,defaultValue:i.trail}:s),{kind:"select",id:"variant",label:"Variant",description:"Original branches from this specific routine.",options:r,defaultValue:t},...E0.map(s=>s.kind==="range"&&s.id==="modernLineWidth"&&i.modernLineWidth!==void 0?{...s,defaultValue:i.modernLineWidth}:s)]}function TR(r=aS){return Object.fromEntries(r.map(t=>[t.id,t.defaultValue]))}function Ca(r,t,i){const s=r[t];return typeof s=="number"?s:i}function sS(r,t,i){const s=r[t];return typeof s=="string"?s:i}const Qn={dusk:{skyTop:"#16092e",skyMid:"#633078",skyBottom:"#e18a51",fog:"#b8614a",sun:"#ffd46a",sand:["#3c1f24","#623022","#8b4d26","#b86d2d","#d99a45","#ffd77a"],ruin:"#18070c",trace:"#65e8ff"},noon:{skyTop:"#24518f",skyMid:"#4d91bf",skyBottom:"#f1b86b",fog:"#d69958",sun:"#fff2a8",sand:["#5b351e","#805024","#a96c2b","#d08a39","#e6b35b","#ffe08a"],ruin:"#201008",trace:"#b7f6ff"},night:{skyTop:"#05061f",skyMid:"#10194a",skyBottom:"#5b3565",fog:"#4d335f",sun:"#ff8a54",sand:["#171424","#25203a","#3f2b46","#64425b","#95625f","#d79670"],ruin:"#05050a",trace:"#78fff0"}},td=16e3,ed=13e3,hE=6200,GM=210,nd=[{lane:-620,offset:1400,height:1.04,width:1.05},{lane:760,offset:4550,height:.82,width:.82}];class zM{renderer=null;scene=new _2;camera=new Ni(58,16/10,.5,16e3);terrain=null;terrainSignature="";skyTexture=null;skyCanvas=null;skyContext=null;ambientLight=null;sunLight=null;sunWorld=new nt(-118,150,1180);sunScreenX=.36;sunScreenY=.43;sunAmount=.35;sunElevation=0;sunVisibility=1;moonVisibility=0;moonWorld=new nt(380,260,1700);moonScreenX=.64;moonScreenY=.33;nightAmount=0;starAmount=0;shadowNeedsRefresh=!0;lastShadowUpdateTime=Number.NEGATIVE_INFINITY;lastShadowLightX=Number.NaN;lastShadowLightY=Number.NaN;lastShadowLightZ=Number.NaN;lastShadowTargetX=Number.NaN;lastShadowTargetY=Number.NaN;lastShadowTargetZ=Number.NaN;lastRuinShadowSignature="";skyPitchOffset=0;skyTime=0;ruins=new zr;terrainCols=0;terrainRows=0;terrainCenterX=Number.NaN;terrainCenterZ=Number.NaN;terrainDuneScale=Number.NaN;lastRenderWidth=0;lastRenderHeight=0;lastPaletteId="";cameraPosition=new nt;cameraTarget=new nt;cameraRoll=0;cameraReady=!1;worldOffset=0;init(t,i){this.renderer?.dispose(),this.renderer=null,this.resetScene();const s={canvas:t,antialias:!0,alpha:!1,powerPreference:"high-performance",preserveDrawingBuffer:!!i.nativeFrameBridge},l=this.createRendererContext(t,s);l&&(s.context=l),this.renderer=new YM(s),this.renderer.outputColorSpace=Jn,this.renderer.setPixelRatio(1),this.renderer.setClearColor(0,1),this.renderer.shadowMap.enabled=!0,this.renderer.shadowMap.autoUpdate=!1,this.renderer.shadowMap.type=AE,this.camera.position.set(0,78,GM),this.ambientLight=new z2(10511960,.82),this.scene.add(this.ambientLight);const c=new G2(16765850,2.65);c.position.set(-82,118,-760),c.castShadow=!0,c.shadow.mapSize.set(2048,2048),c.shadow.bias=-8e-5,c.shadow.normalBias=.75,c.shadow.camera.left=-2300,c.shadow.camera.right=2300,c.shadow.camera.top=2300,c.shadow.camera.bottom=-2300,c.shadow.camera.near=1,c.shadow.camera.far=4200,this.sunLight=c,this.scene.add(c),this.scene.add(c.target),this.scene.add(this.ruins),this.buildRuins(),this.resize(i)}resize(t){if(!this.renderer)return;const i=Ca(t.settings,"pixelation",2),s=t.mode==="classic"?jn((.56-i*.095)*1.55,.3,.58):jn(1-Math.max(0,i-1)*.07,.66,1),l=t.mode==="modern"?t.pixelRatio:1,c=Math.max(160,Math.floor(t.width*l*s)),f=Math.max(100,Math.floor(t.height*l*s));c===this.lastRenderWidth&&f===this.lastRenderHeight||(this.lastRenderWidth=c,this.lastRenderHeight=f,this.renderer.setSize(c,f,!1),this.camera.aspect=c/f,this.camera.updateProjectionMatrix())}update(t){const i=Ca(t.settings,"speed",1);this.worldOffset+=t.delta*i*56,this.skyTime=t.time;const s=sS(t.settings,"palette","dusk"),l=Qn[s]??Qn.dusk;s!==this.lastPaletteId&&(this.lastPaletteId=s,this.applyPalette(l)),this.updateCamera(t),this.ensureTerrain(t,l),this.updateTerrain(t.settings,l),this.updateSky(l),this.updateRuins(t.settings)}render(){this.renderer?.render(this.scene,this.camera)}dispose(){this.resetScene(),this.renderer?.dispose(),this.renderer=null}resetScene(){this.disposeTerrain(),this.disposeRuins(),this.skyTexture?.dispose(),this.skyTexture=null,this.skyCanvas=null,this.skyContext=null,this.ambientLight=null,this.sunLight=null,this.lastPaletteId="",this.shadowNeedsRefresh=!0,this.lastShadowUpdateTime=Number.NEGATIVE_INFINITY,this.lastShadowLightX=Number.NaN,this.lastShadowLightY=Number.NaN,this.lastShadowLightZ=Number.NaN,this.lastShadowTargetX=Number.NaN,this.lastShadowTargetY=Number.NaN,this.lastShadowTargetZ=Number.NaN,this.lastRuinShadowSignature="",this.lastRenderWidth=0,this.lastRenderHeight=0,this.cameraRoll=0,this.cameraReady=!1,this.scene.clear()}disposeTerrain(){this.terrain&&(this.scene.remove(this.terrain),this.terrain.geometry.dispose(),this.terrain.material.dispose(),this.terrain=null,this.terrainSignature="",this.terrainCols=0,this.terrainRows=0,this.terrainCenterX=Number.NaN,this.terrainCenterZ=Number.NaN,this.terrainDuneScale=Number.NaN)}disposeRuins(){this.ruins.traverse(t=>{const i=t;i.geometry?.dispose?.(),i.material?.dispose?.()}),this.ruins.clear()}createRendererContext(t,i){const s={alpha:!!i.alpha,antialias:!!i.antialias,powerPreference:i.powerPreference,preserveDrawingBuffer:!!i.preserveDrawingBuffer},l=t.getContext("webgl2",s);if(!l)return null;const c={rangeMin:127,rangeMax:127,precision:23},f=l.getShaderPrecisionFormat.bind(l);try{l.getShaderPrecisionFormat=(T,p)=>f(T,p)??c}catch{return l}return l}ensureTerrain(t,i){const s=Ca(t.settings,"terrainDetail",1),l=Math.round((t.mode==="classic"?78:118)+s*(t.mode==="classic"?18:34)),c=Math.round((t.mode==="classic"?118:172)+s*(t.mode==="classic"?28:46)),f=`${t.mode}:${l}:${c}`;if(f===this.terrainSignature)return;this.disposeTerrain(),this.terrainSignature=f,this.terrainCols=l,this.terrainRows=c;const T=new na,p=[],h=[],m=[];for(let S=0;S<=c;S+=1){const g=-1200+S/c*ed;for(let A=0;A<=l;A+=1){const M=(A/l-.5)*td;p.push(M,0,g),h.push(1,1,1)}}for(let S=0;S<c;S+=1)for(let g=0;g<l;g+=1){const A=S*(l+1)+g,M=A+1,x=A+l+1,v=x+1;m.push(A,x,M,M,x,v)}T.setIndex(m),T.setAttribute("position",new wi(p,3)),T.setAttribute("color",new wi(h,3));const E=new Fm({vertexColors:!0,fog:!0,side:Zi});this.terrain=new Bi(T,E),this.terrain.receiveShadow=!0,this.terrain.frustumCulled=!1,this.scene.add(this.terrain),this.updateTerrain(t.settings,i)}updateTerrain(t,i){if(!this.terrain)return;const s=this.terrain.geometry.getAttribute("position"),l=this.terrain.geometry.getAttribute("color"),c=new _e,f=new _e,T=this.flightPath(),p=this.sandRamp(i),h=td/Math.max(1,this.terrainCols),m=ed/Math.max(1,this.terrainRows),E=Math.round(T.x/h)*h,S=Math.round(T.z/m)*m,g=jn(Ca(t,"duneScale",1),.45,2.2);if(E!==this.terrainCenterX||S!==this.terrainCenterZ||g!==this.terrainDuneScale){for(let M=0;M<s.count;M+=1){const x=M%(this.terrainCols+1),v=Math.floor(M/(this.terrainCols+1)),D=(x/this.terrainCols-.5)*td,I=-1200+v/this.terrainRows*ed,U=E+D,Y=S+I;s.setX(M,U),s.setY(M,this.sampleHeight(U,Y,t)),s.setZ(M,Y)}s.needsUpdate=!0,this.terrain.geometry.computeVertexNormals(),this.terrainCenterX=E,this.terrainCenterZ=S,this.terrainDuneScale=g}for(let M=0;M<s.count;M+=1){const x=s.getZ(M),v=s.getY(M),D=x-T.z,I=Wi(2500,11600,D),U=Wi(1e3,120,D)*.03,Y=this.nightAmount*this.moonVisibility*.24,F=.26+this.sunAmount*.28+Y,R=jn(F+(v+30)/160-I*.12+U,.1,.98)*(p.length-1),w=Math.floor(R);c.set(p[w]),c.lerp(f.set(p[w+1]),R-w),l.setXYZ(M,c.r,c.g,c.b)}l.needsUpdate=!0}updateCamera(t){const i=Ca(t.settings,"cameraHeight",1),s=this.flightPath(),l=Math.sin(this.worldOffset*18e-5+1.7)*42+Math.sin(this.worldOffset*7e-5-.8)*24,c=s.x+s.rightX*l,f=s.z-96,T=this.sampleHeight(c,f+120,t.settings)*.5+this.sampleHeight(s.lookX,s.z+920,t.settings)*.25+this.sampleHeight(c+s.rightX*520,f+520,t.settings)*.125+this.sampleHeight(c-s.rightX*520,f+520,t.settings)*.125,p=this.sampleHeight(s.lookX,s.lookZ,t.settings),h=Math.sin(this.worldOffset*12e-5+1.3)*11+Math.sin(this.worldOffset*28e-5-.2)*5,m=T+126+i*42+h,E=(s.lookX-s.x)*.2-l*.12+Math.sin(this.worldOffset*15e-5+.6)*22,S=s.lookX+s.rightX*E,g=s.lookZ+s.rightZ*E,A=p+14-Math.abs(s.bank)*8,M=new nt(c,m,f),x=new nt(S,A,g),v=id(t.delta,2.25),D=id(t.delta,1.85),I=id(t.delta,2.8),U=jn(s.bank*.055+l*25e-6,-.055,.055);this.cameraReady?(this.cameraPosition.lerp(M,v),this.cameraTarget.lerp(x,D),this.cameraRoll+=(U-this.cameraRoll)*I):(this.cameraPosition.copy(M),this.cameraTarget.copy(x),this.cameraRoll=U,this.cameraReady=!0),this.camera.position.copy(this.cameraPosition),this.camera.lookAt(this.cameraTarget),this.camera.rotation.z+=this.cameraRoll;const Y=Math.hypot(this.cameraTarget.x-this.cameraPosition.x,this.cameraTarget.z-this.cameraPosition.z)||1,F=this.cameraTarget.y-this.cameraPosition.y;this.skyPitchOffset=jn(Math.atan2(F,Y)*.9,-.16,.16),this.updateSun(t)}updateRuins(t){Qn[this.lastPaletteId]??Qn.dusk;const c=Sn(Sn("#07070c","#211817",1-this.nightAmount),"#34312d",this.sunAmount*.72),f=this.flightPath(),T=[];this.ruins.children.forEach((h,m)=>{const E=nd[m%nd.length],S=Math.floor((f.z+5200-E.offset)/hE),g=S*23.41+m*19.17+4.2,A=S*hE+E.offset,M=E.lane+(Ra(g)-.5)*360,x=E.height+Ra(g+8)*.18;h.position.set(M,this.sampleHeight(M,A,t)+14*x-.4,A),h.scale.set(E.width+Ra(g+3)*.16,x,.85+Ra(g+6)*.2),T.push(`${m}:${M.toFixed(1)}:${A.toFixed(1)}:${x.toFixed(3)}`),h.traverse(v=>{v.material?.color?.set(c)})}),this.ruins.updateMatrixWorld(!0),this.terrain?.updateMatrixWorld(!0);const p=T.join("|");p!==this.lastRuinShadowSignature&&(this.lastRuinShadowSignature=p,this.shadowNeedsRefresh=!0)}sandRamp(t){return t.sand.map((i,s)=>{const l=Qn.night.sand[s]??Qn.night.sand[Qn.night.sand.length-1],c=Qn.noon.sand[s]??Qn.noon.sand[Qn.noon.sand.length-1],f=Qn.dusk.sand[s]??Qn.dusk.sand[Qn.dusk.sand.length-1],T=Sn(i,l,this.nightAmount*.72),p=Sn(T,f,(1-this.sunAmount)*(1-this.nightAmount)*.42);return Sn(p,c,this.sunAmount*.58)})}sampleHeight(t,i,s){const l=Ca(s,"duneScale",1),c=jn(l,.45,2.2),f=t+Math.sin(i*36e-5)*230*c+Math.sin(i*11e-5+2.4)*320*c,T=i+Math.sin(t*24e-5+i*13e-5)*140*c,p=this.transverseDunes(f,T,c),h=this.crescentDunes(f,T,c),m=Wi(12,38,p+h+8),E=Math.sin(T*.033/c+f*.009+Math.sin(f*.0024)*1.1)*.7,S=Math.sin((f*.0011+T*.0014)/c)*11+Math.sin((f*-8e-4+T*.0011)/c+1.7)*7;return p+h+E*m+S-42}transverseDunes(t,i,s){const l=780*s,c=Math.sin(t*72e-5+i*18e-5)*220*s+Math.sin(t*.00155)*105*s,f=dE((i+c)/l),T=Wi(.1,.72,f),p=1-Wi(.72,.9,f),h=Math.pow(Math.max(0,1-Math.abs(f-.72)/.16),2.1),m=.78+Math.sin(t*54e-5+i*25e-5)*.16;return(T*p*32+h*9)*m}crescentDunes(t,i,s){const l=1420*s,c=Math.sin(t*72e-5+Math.sin(i*19e-5)*1.15),f=dE((i+c*190*s)/l),T=f-.52,p=Math.exp(-(T*T*16)),h=Math.abs(Math.sin(t*.00138+i*22e-5)),m=Math.exp(-Math.pow(h-.72,2)*14)*Math.exp(-Math.pow(f-.66,2)*16),E=Math.exp(-Math.pow(h,2)*7)*Math.exp(-Math.pow(f-.69,2)*16);return p*14+m*7-E*5}applyPalette(t){const i=this.createSkyTexture(t);this.scene.fog=new au(t.fog,2400,10400),this.scene.background=i,this.sunLight&&this.sunLight.color.set(t.sun)}createSkyTexture(t){this.skyTexture?.dispose();const i=document.createElement("canvas");i.width=1024,i.height=640;const s=i.getContext("2d");if(!s)throw new Error("Could not create dune sky texture");return this.skyCanvas=i,this.skyContext=s,this.drawSkyTexture(t,i.width*.36,i.height*.43),this.skyTexture=new b2(i),this.skyTexture.magFilter=Nn,this.skyTexture.minFilter=Nn,this.skyTexture.colorSpace=Jn,this.skyTexture}updateSky(t){if(!this.skyTexture||!this.skyCanvas||!this.skyContext)return;const i=this.sunScreenX*this.skyCanvas.width,s=this.skyPitchOffset*this.skyCanvas.height,l=this.sunScreenY*this.skyCanvas.height+s,c=this.moonScreenX*this.skyCanvas.width,f=this.moonScreenY*this.skyCanvas.height+s;this.drawSkyTexture(t,i,l,c,f),this.skyTexture.needsUpdate=!0}drawSkyTexture(t,i,s,l=0,c=0){const f=this.skyCanvas,T=this.skyContext;if(!f||!T)return;const p=f.height,h=f.width,m=this.skyPitchOffset*p,E=this.sunAmount,S=this.nightAmount,g=jn(1-E-S*.6,0,1),A=g*.35+this.sunVisibility*.16,M=T.createLinearGradient(0,-m*.6,0,f.height-m*.35);if(M.addColorStop(0,Sn(Sn("#05071f","#21113e",g),"#55aee4",E*.74)),M.addColorStop(.46,Sn(Sn("#101640","#60306c",g),"#9bd7f1",E*.5)),M.addColorStop(.82,Sn(Sn("#2d2148","#d66f50",A),"#dda77a",E*.18)),M.addColorStop(1,Sn(Sn("#34213e",t.fog,g),"#d09266",E*.16)),T.fillStyle=M,T.fillRect(0,0,f.width,f.height),this.starAmount>.01)for(let I=0;I<95;I+=1){const U=Ra(I*8.31+.7)*h,Y=Ra(I*13.73+2.4)*p*.58+m,F=Ra(I*17.19+4.1)>.83?2:1,B=Ra(I*21.11+6.8)*Math.PI*2,R=1.2+Ra(I*4.37+9.1)*2.2,w=.42+Math.sin(this.skyTime*R+B)*.28+Math.sin(this.skyTime*R*.37+B*1.7)*.16,Z=jn(this.starAmount*w,.08,.86);T.fillStyle=`rgba(245, 239, 205, ${Z})`,T.fillRect(Math.floor(U),Math.floor(Y),F,F)}if(this.moonVisibility>.01){const I=T.createRadialGradient(l,c,p*.012,l,c,p*.19);I.addColorStop(0,`rgba(204, 221, 255, ${.12*this.moonVisibility})`),I.addColorStop(1,"rgba(110, 138, 220, 0)"),T.fillStyle=I,T.fillRect(0,0,h,p),T.globalAlpha=this.moonVisibility,T.fillStyle="#d8e2ff",T.beginPath(),T.arc(l,c,p*.027,0,Math.PI*2),T.fill(),T.fillStyle="rgba(114, 130, 180, 0.22)",T.fillRect(Math.floor(l-p*.01),Math.floor(c+p*.005),2,2),T.fillRect(Math.floor(l+p*.008),Math.floor(c-p*.01),1,1),T.globalAlpha=1}const x=T.createLinearGradient(0,p*.4+m,0,p+m);x.addColorStop(0,"rgba(255, 209, 124, 0)"),x.addColorStop(.56,`rgba(255, 176, 96, ${.08+g*.18})`),x.addColorStop(1,`rgba(255, 127, 74, ${.06+g*.14})`),T.fillStyle=x,T.fillRect(0,p*.3+m,h,p*.7);const v=this.sunVisibility;if(v>.01){const I=p*.038*(1-E*.15),U=T.createRadialGradient(i,s,I*.85,i,s,p*(.34+g*.18));U.addColorStop(0,`rgba(255, 220, 128, ${.12*v})`),U.addColorStop(.38,`rgba(255, 190, 96, ${.07*v})`),U.addColorStop(1,"rgba(255, 190, 96, 0)"),T.fillStyle=U,T.fillRect(0,0,h,p);const Y=T.createRadialGradient(i,s,I*.18,i,s,I*1.55);Y.addColorStop(0,`rgba(255, 242, 178, ${.92*v})`),Y.addColorStop(.58,`rgba(255, 214, 105, ${.76*v})`),Y.addColorStop(.9,`rgba(255, 196, 92, ${.22*v})`),Y.addColorStop(1,"rgba(255, 196, 92, 0)"),T.fillStyle=Y,T.fillRect(i-I*1.9,s-I*1.9,I*3.8,I*3.8)}const D=T.createLinearGradient(0,p*.6+m,0,p*.84+m);D.addColorStop(0,"rgba(255, 219, 132, 0)"),D.addColorStop(.55,`rgba(255, 184, 103, ${.08+g*.26})`),D.addColorStop(1,"rgba(86, 40, 76, 0)"),T.fillStyle=D,T.fillRect(0,p*.55+m,h,p*.36)}buildRuins(){for(let t=0;t<nd.length;t+=1){const i=new zr,s=new Fm({color:Qn.dusk.ruin,flatShading:!0,fog:!0}),l=new Bi(new Qr(12,42,10,1,1,1),s);l.position.set(0,7,0),l.rotation.z=t===0?-.04:.05,l.castShadow=!0,l.receiveShadow=!1,i.add(l),i.rotation.y=0,this.ruins.add(i)}}updateSun(t){const i=this.flightPath(),s=pE(t.time*.052,Math.PI*2);this.sunElevation=Math.sin(s),this.sunAmount=Wi(-.08,.55,this.sunElevation),this.sunVisibility=Wi(-.08,.08,this.sunElevation),this.nightAmount=1-Wi(-.32,.12,this.sunElevation),this.starAmount=1-Wi(-.26,.04,this.sunElevation);const l=jn(s/Math.PI,0,1);this.sunScreenX=.12+l*.76,this.sunScreenY=.67-Math.max(0,this.sunElevation)*.5;const c=i.x+(l-.5)*1200,f=28+this.sunElevation*420,T=i.z+1800,p=-this.sunElevation,h=pE(s-Math.PI,Math.PI*2),m=jn(h/Math.PI,0,1);this.moonVisibility=Wi(.05,.28,p),this.moonScreenX=.12+m*.76,this.moonScreenY=.66-Math.max(0,p)*.46;const E=i.x+(m-.5)*980,S=92+p*310,g=i.z+1720;if(this.sunWorld.set(c,f,T),this.moonWorld.set(E,S,g),this.ambientLight&&(this.ambientLight.intensity=.48+this.sunAmount*.62+this.moonVisibility*this.nightAmount*.36,this.ambientLight.color.set(Sn(Sn("#46588e","#a76755",1-this.nightAmount),"#db9d72",this.sunAmount))),this.scene.fog instanceof au&&this.scene.fog.color.set(Sn(Sn("#241b3e","#a94b3d",1-this.nightAmount),"#c77754",this.sunAmount)),this.sunLight){this.sunVisibility>.02||this.sunAmount>this.moonVisibility*.72?this.sunLight.position.set(c,Math.max(90,f),T):this.sunLight.position.set(E,Math.max(120,S),g),this.sunLight.target.position.set(i.x,-12,i.z+420),this.sunLight.intensity=.16+this.sunAmount*3.15+this.moonVisibility*this.nightAmount*.92,this.sunLight.color.set(Sn("#b7c9ff",Sn("#ff9f69","#ffe0a5",this.sunAmount),1-this.nightAmount*.78)),this.sunLight.target.updateMatrix(),this.sunLight.updateMatrix(),this.sunLight.updateMatrixWorld(),this.sunLight.target.updateMatrixWorld(),this.sunLight.shadow.camera.updateMatrixWorld(),this.sunLight.shadow.camera.updateProjectionMatrix();const A=t.time-this.lastShadowUpdateTime>=1/30,M=Math.abs(this.sunLight.position.x-this.lastShadowLightX)>2||Math.abs(this.sunLight.position.y-this.lastShadowLightY)>2||Math.abs(this.sunLight.position.z-this.lastShadowLightZ)>2||Math.abs(this.sunLight.target.position.x-this.lastShadowTargetX)>2||Math.abs(this.sunLight.target.position.y-this.lastShadowTargetY)>2||Math.abs(this.sunLight.target.position.z-this.lastShadowTargetZ)>2;(this.shadowNeedsRefresh||A&&M)&&(this.sunLight.shadow.needsUpdate=!0,this.renderer.shadowMap.needsUpdate=!0,this.shadowNeedsRefresh=!1,this.lastShadowUpdateTime=t.time,this.lastShadowLightX=this.sunLight.position.x,this.lastShadowLightY=this.sunLight.position.y,this.lastShadowLightZ=this.sunLight.position.z,this.lastShadowTargetX=this.sunLight.target.position.x,this.lastShadowTargetY=this.sunLight.target.position.y,this.lastShadowTargetZ=this.sunLight.target.position.z)}}flightPath(){const t=this.worldOffset,i=t*25e-5,s=this.pathX(i),l=1720+Math.sin(i*.58+.5)*150,c=t+l,f=c*25e-5,T=this.pathX(f)+Math.sin(i*.5+1.1)*32,p=T-s,h=c-t,m=Math.hypot(p,h)||1,E=p/m,S=h/m;return{x:s,z:t,lookX:T,lookZ:c,forwardX:E,forwardZ:S,rightX:S,rightZ:-E,bank:jn((T-s)/1800+Math.cos(i*.45+.2)*.045,-1,1)}}pathX(t){return Math.sin(t)*380+Math.sin(t*.41+1.8)*160+Math.sin(t*1.07+.4)*42}}function jn(r,t,i){return Math.min(i,Math.max(t,r))}function dE(r){return r-Math.floor(r)}function pE(r,t){return(r%t+t)%t}function id(r,t){return 1-Math.exp(-Math.max(0,r)*t)}function Sn(r,t,i){return new _e(r).lerp(new _e(t),jn(i,0,1)).getStyle()}function Wi(r,t,i){const s=jn((i-r)/(t-r),0,1);return s*s*(3-2*s)}function Ra(r){const t=Math.sin(r*127.1)*43758.5453;return t-Math.floor(t)}const Qd=["#000000","#0000aa","#00aa00","#00aaaa","#aa0000","#aa00aa","#aa5500","#aaaaaa","#555555","#5555ff","#55ff55","#55ffff","#ff5555","#ff55ff","#ffff55","#ffffff"];function TE(r,t=1){const s=(Number.isFinite(r)?Math.max(0,Math.round(r)):0)%256;return s<Qd.length?VM(Qd[s],t):s<Vc.length?`rgba(${Vc[s][0]}, ${Vc[s][1]}, ${Vc[s][2]}, ${t})`:`rgba(255, 255, 255, ${t})`}function VM(r,t){const i=r.replace("#",""),s=parseInt(i.slice(0,2),16),l=parseInt(i.slice(2,4),16),c=parseInt(i.slice(4,6),16);return`rgba(${s}, ${l}, ${c}, ${t})`}const Vc=WM();function WM(){const r=Qd.map(s=>{const l=s.replace("#","");return[parseInt(l.slice(0,2),16),parseInt(l.slice(2,4),16),parseInt(l.slice(4,6),16)]});[0,5,8,11,14,17,20,24,28,32,36,40,45,50,56,63].forEach(s=>r.push(jd(s,s,s)));const i=rS(63,[0,16,31,47,63]).map(([s,l,c])=>jd(s,l,c));for(r.push(...i),r.push(...i.map(s=>mE(s,[255,255,255],.24))),r.push(...i.map(s=>mE(s,[255,255,255],.46))),Gs(r,31,[0,8,16,24,31]),Gs(r,47,[0,12,24,35,47]),Gs(r,39,[0,10,19,29,39]),Gs(r,55,[0,14,27,41,55]),Gs(r,23,[0,6,11,17,23]),Gs(r,63,[16,27,39,51,63]),Gs(r,45,[8,17,26,35,45]);r.length<256;)r.push([0,0,0]);return r.slice(0,256)}function Gs(r,t,i){rS(t,i).forEach(([s,l,c])=>r.push(jd(s,l,c)))}function rS(r,t){const[i,s,l,c]=t;return[[i,i,r],[s,i,r],[l,i,r],[c,i,r],[r,i,r],[r,i,c],[r,i,l],[r,i,s],[r,i,i],[r,s,i],[r,l,i],[r,c,i],[r,r,i],[c,r,i],[l,r,i],[s,r,i],[i,r,i],[i,r,s],[i,r,l],[i,r,c],[i,r,r],[i,c,r],[i,l,r],[i,s,r]]}function jd(r,t,i){return[Math.round(r/63*255),Math.round(t/63*255),Math.round(i/63*255)]}function mE(r,t,i){return[Math.round(r[0]+(t[0]-r[0])*i),Math.round(r[1]+(t[1]-r[1])*i),Math.round(r[2]+(t[2]-r[2])*i)]}function Jd(r,t,i,s,l=s==="modern",c=1){const f=s==="modern"||l,T=s==="modern"?c:1;r.imageSmoothingEnabled=f,r.lineCap=s==="modern"?"round":"butt",r.lineJoin=s==="modern"?"round":"miter";const p=(h=15,m=1)=>typeof h=="number"?TE(h,m):h;return{width:t,height:i,ctx:r,mode:s,antialias:f,lineScale:T,color:(h,m=1)=>TE(h,m),cls:(h=0,m=1)=>{r.save(),r.globalAlpha=m,r.fillStyle=p(h),r.fillRect(0,0,t,i),r.restore()},pset:(h,m,E=15,S=s==="classic"?1:2)=>{r.fillStyle=p(E);const g=s==="classic"?Math.round(h):Math.floor(h),A=s==="classic"?Math.round(m):Math.floor(m),M=s==="classic"?S:Math.max(1,Math.ceil(S));r.fillRect(g,A,M,M)},line:(h,m,E,S,g=15,A=1,M=1)=>{if(!f){nl(r,Math.round(h),Math.round(m),Math.round(E),Math.round(S),p(g),A,M);return}r.save(),r.globalAlpha=M,r.strokeStyle=p(g),r.lineWidth=A*T,r.beginPath(),r.moveTo(h,m),r.lineTo(E,S),r.stroke(),r.restore()},circle:(h,m,E,S=15,g=!1,A=1)=>{if(!f){kM(r,Math.round(h),Math.round(m),Math.round(E),p(S),g,A);return}r.save(),r.globalAlpha=A,r.beginPath(),r.arc(h,m,Math.max(0,E),0,Math.PI*2),g?(r.fillStyle=p(S),r.fill()):(r.strokeStyle=p(S),r.lineWidth=(s==="modern"?1.5:1)*T,r.stroke()),r.restore()},box:(h,m,E,S,g=15,A=!1,M=1)=>{if(!f){if(r.save(),r.globalAlpha=M,r.fillStyle=p(g),A)r.fillRect(Math.round(h),Math.round(m),Math.round(E),Math.round(S));else{const x=Math.round(h),v=Math.round(m),D=Math.round(h+E),I=Math.round(m+S);nl(r,x,v,D,v,p(g),1,M),nl(r,D,v,D,I,p(g),1,M),nl(r,D,I,x,I,p(g),1,M),nl(r,x,I,x,v,p(g),1,M)}r.restore();return}r.save(),r.globalAlpha=M,A?(r.fillStyle=p(g),r.fillRect(h,m,E,S)):(r.strokeStyle=p(g),r.lineWidth=T,r.strokeRect(h,m,E,S)),r.restore()},locateText:(h,m,E,S=15,g=1)=>{const A=8*g,M=8*g;r.fillStyle=p(S),ZM(r,E,(m-1)*A,(h-1)*M,g)}}}function nl(r,t,i,s,l,c,f,T){r.save(),r.globalAlpha=T,r.fillStyle=c;const p=Math.max(1,Math.round(f));let h=t,m=i;const E=Math.abs(s-h),S=h<s?1:-1,g=-Math.abs(l-m),A=m<l?1:-1;let M=E+g;for(;r.fillRect(h,m,p,p),!(h===s&&m===l);){const x=M*2;x>=g&&(M+=g,h+=S),x<=E&&(M+=E,m+=A)}r.restore()}function kM(r,t,i,s,l,c,f){if(r.save(),r.globalAlpha=f,r.fillStyle=l,c){for(let m=-s;m<=s;m+=1){const E=Math.floor(Math.sqrt(s*s-m*m));r.fillRect(t-E,i+m,E*2+1,1)}r.restore();return}let T=s,p=0,h=0;for(;T>=p;)KM(r,t,i,T,p),p+=1,h<=0&&(h+=2*p+1),h>0&&(T-=1,h-=2*T+1);r.restore()}function KM(r,t,i,s,l){r.fillRect(t+s,i+l,1,1),r.fillRect(t+l,i+s,1,1),r.fillRect(t-l,i+s,1,1),r.fillRect(t-s,i+l,1,1),r.fillRect(t-s,i-l,1,1),r.fillRect(t-l,i-s,1,1),r.fillRect(t+l,i-s,1,1),r.fillRect(t+s,i-l,1,1)}const EE={" ":["00000000","00000000","00000000","00000000","00000000","00000000","00000000","00000000"],B:["11111100","01100110","01100110","01111100","01100110","01100110","01100110","11111100"],C:["00111100","01100110","11000000","11000000","11000000","11000000","01100110","00111100"],D:["11111000","01101100","01100110","01100110","01100110","01100110","01101100","11111000"],E:["11111110","01100010","01101000","01111000","01101000","01100000","01100010","11111110"],O:["00111000","01101100","11000110","11000110","11000110","11000110","01101100","00111000"],R:["11111100","01100110","01100110","01111100","01101100","01100110","01100110","11100110"],Y:["11000110","11000110","01101100","00111000","00010000","00010000","00010000","00111000"]};function ZM(r,t,i,s,l){const c=Math.max(1,Math.round(l));[...t.toUpperCase()].forEach((f,T)=>{(EE[f]??EE[" "]).forEach((h,m)=>{[...h].forEach((E,S)=>{E==="1"&&r.fillRect(Math.round(i+T*8*l+S*l),Math.round(s+m*l),c,c)})})})}const zn=320,Xn=200;class qM{constructor(t){this.kind=t}kind;stars=QM(300);movers=jM(120);dots=JM(180);infoParticles=tR(150);craperWalker={x:160,y:100,color:20,tick:0};wormPoints=SE(100);doorway=gE();coolBuffer=null;coolBufferVariant="";menuNoise=iR();lastMode="";lastKind="";noiseTick=0;render(t,i){const s=Ca(i.settings,"speed",1),l=Ca(i.settings,"density",1),c=Ca(i.settings,"trail",.35),f=sS(i.settings,"variant","original"),T=i.mode==="modern",p=i.time*s,h=this.kind==="intro"||this.kind==="info"?Math.floor(p*30)/30:p,m=ad(t),E=this.lastMode!==i.mode||this.lastKind!==this.kind;if(this.lastMode=i.mode,this.lastKind=this.kind,this.kind==="intro"){t.cls(0),this.drawMainMenu(t,i,h,T,m);return}switch(E?(this.resetSceneState(),t.cls(0)):t.cls(0,$M(this.kind,c,T)),this.kind){case"info":this.drawInfo(t,h,T,m);break;case"saver":this.drawSaver(t,h,l,T,m);break;case"omega":this.drawOmega(t,h,l,T,m);break;case"laser":this.drawLaser(t,h,l,T,m);break;case"craper":this.drawCraper(t,h,l,T,m,f);break;case"cooler":this.drawCooler(t,h,l,T,m,f);break;case"cyber":this.drawCyber(t,h,l,T,m,f);break;case"delta":this.drawDelta(t,h,l,T,m,f);break;case"ball":this.drawBall(t,h,l,T,m,f);break;case"lines":this.drawLines(t,h,l,T,m,f);break;case"shella":this.drawShella(t,h,l,T,m,f);break;case"type1":this.drawType1(t,h,l,T,m);break;case"type2":this.drawType2(t,h,i.delta*s,l,T,m,f);break;case"tunnels":this.drawTunnels(t,h,l,T,m,f);break;case"coolx":this.drawCoolX(t,h,l,c,T,m,f);break;case"disco":this.drawDisco(t,h,l,T,m);break;case"spheres":this.drawSpheres(t,h,l,T,m);break;case"spots":this.drawSpots(t,h,l,T,m,f);break}}resetSceneState(){this.craperWalker={x:160,y:100,color:20,tick:0},this.wormPoints=SE(140),this.doorway=gE(),this.coolBuffer=null,this.coolBufferVariant=""}update(t,i){if(this.kind!=="intro"||!i.input.pointer.justPressed)return;const s=ad(t),l=i.input.pointer.x/s.sx,c=i.input.pointer.y/s.sy;il({x:l,y:c},24,134,92,30)&&i.action?.("open-info"),il({x:l,y:c},98,72,124,54)&&i.action?.("open-gallery"),il({x:l,y:c},204,136,88,32)&&i.action?.("open-gallery")}drawMainMenu(t,i,s,l,c){const f={x:i.input.pointer.x/c.sx,y:i.input.pointer.y/c.sy},T=il(f,24,134,92,30),p=il(f,204,136,88,32);this.drawStars(t,c,300,!1);const h=ls.DATA.slice(0,465),m=ls.DATA.slice(465,844).reverse();h.forEach((A,M)=>this.drawTitleShadowLine(t,c,A,M,!1,l)),m.forEach((A,M)=>this.drawTitleShadowLine(t,c,A,M,!0,l)),this.drawPointText(t,ls.DATA,c,0,-50,10,l?2:1,!1);let E=30;E=this.drawMenuWord(t,ls.DATA2,c,10,0,E,l),E=this.drawMenuWord(t,ls.DATA3,c,100,50,E,l),this.drawMenuWord(t,ls.DATA4,c,-100,50,E,l),this.drawByline(t,c,l),this.drawNoiseBox(t,s,c,l);const S=T?{x:60,y:150}:p?{x:250,y:150}:{x:160,y:95},g=20+s*18%10;this.ellipse(t,c.x(S.x),c.y(S.y),c.w(61),c.h(36.6),g,l?2:1,1)}drawStars(t,i,s,l){for(let c=0;c<s;c+=1){const f=this.stars[c%this.stars.length],T=i.pixel(1);t.pset(i.x(f.x*zn),i.y(f.y*Xn),l?18+c*.03:7,T)}}drawTitleShadowLine(t,i,s,l,c,f){const T=c?25.51-(l+1)*.01:19+(l+1)*.007,p=c?s.x-1:s.x,h=c?s.y+1:s.y;this.pixelLine(t,i.x(160),i.y(70),i.x(p),i.y(h-50),T,f?1.6:1,f)}drawMenuWord(t,i,s,l,c,f,T){let p=f;for(const h of i)p+=.1,this.pixelLine(t,s.x(h.x+l),s.y(h.y+c),s.x(h.x+l+3),s.y(h.y+c+3),p,T?2.2:1,T);return p}drawByline(t,i,s){let l=35;for(const c of ls.DATA5)l+=.1,t.pset(i.x(c.x+20),i.y(c.y+100),l,s?i.pixel(1.4):1)}drawPointText(t,i,s,l,c,f,T,p){i.forEach((h,m)=>{t.pset(s.x(h.x+l),s.y(h.y+c),p?f+m*.08:f,s.pixel(T))})}drawNoiseBox(t,i,s,l){t.box(s.x(130),s.y(120),s.w(52),s.h(52),0,!0),t.box(s.x(131),s.y(121),s.w(49),s.h(49),10,!1);const c=Math.floor(i*30);c!==this.noiseTick&&(this.noiseTick=c);const f=c%16;for(let T=1;T<=48;T+=1)for(let p=1;p<=48;p+=1){const h=16+(this.menuNoise[T*48+p]+f)%16;t.pset(s.x(131+p),s.y(121+T),h,l?s.pixel(1.15):1)}}drawInfo(t,i,s,l){this.drawInfoTitle(t,l,s),this.drawInfoParticles(t,i,l,s);const c=Math.floor(i*70)%500;for(let T=1;T<=35;T+=1)this.pixelBox(t,l.x(85+T),l.y(35+T),l.x(225-T),l.y(175-T),T+c,s);const f=24+Math.sin(i*3.6)*7;this.drawInfoCredits(t,l,f,s)}drawInfoCredits(t,i,s,l){l&&(t.ctx.save(),t.ctx.scale(i.sx,i.sy)),t.locateText(11,18,"CODED",s,1),t.locateText(13,20,"B",s,1),t.locateText(14,20,"Y",s,1),t.locateText(16,19,"ROY",s,1),l&&t.ctx.restore()}drawInfoTitle(t,i,s){let l=0,c=20;for(const f of ls.DATA){l+=.1,c+=.1;const T=f.x/2+Math.cos(l)*2+80,p=f.y/2+Math.sin(l)*2-30;t.pset(i.x(T),i.y(p),c,s?i.pixel(1.7):1)}}drawInfoParticles(t,i,s,l){this.infoParticles.forEach(c=>{if(c.x>85&&c.x<225&&c.y>35&&c.y<175)return;const f=25+Math.sin(i*c.speed+c.phase)*5;t.pset(s.x(c.x),s.y(c.y),f,s.pixel(1))})}drawSaver(t,i,s,l,c){const f=Math.floor(50*s);for(let T=0;T<f;T+=1){const p=this.movers[T],h=Ki(p.x+i*25*p.dx,zn),m=Ki(p.y+i*18*p.dy,Xn),E=Math.cos(i*4+T)*15,S=Math.sin(i*4+T)*15;T%3===0?t.line(c.x(h+E),c.y(m+S),c.x(zn/2),c.y(Xn/2),40+T,l?1.4:1,l?.7:1):t.pset(c.x(h),c.y(m),20+T,c.pixel(l?2:1))}}drawOmega(t,i,s,l,c){const T=Math.max(5,Math.floor(24/s)),p=Wc(i,.25,.55,.74);for(let h=0;h<200;h+=T){const m=Wc(i-h*.02,.25,.55,.74);t.line(c.x(m[0].x),c.y(m[0].y),c.x(m[1].x),c.y(m[1].y),18+h*.12,l?1.2:1,l?.35:.75),t.line(c.x(m[1].x),c.y(m[1].y),c.x(m[2].x),c.y(m[2].y),19+h*.12,l?1.2:1,l?.35:.75),t.line(c.x(m[2].x),c.y(m[2].y),c.x(m[0].x),c.y(m[0].y),20+h*.12,l?1.2:1,l?.35:.75)}t.line(c.x(p[0].x),c.y(p[0].y),c.x(p[1].x),c.y(p[1].y),30,l?2:1),t.line(c.x(p[1].x),c.y(p[1].y),c.x(p[2].x),c.y(p[2].y),33,l?2:1),t.line(c.x(p[2].x),c.y(p[2].y),c.x(p[0].x),c.y(p[0].y),36,l?2:1)}drawLaser(t,i,s,l,c){this.drawStars(t,c,200,!0);const f=Wc(i*1.5,1.2,.8,1.7),T=Wc(i*.9+80,.5,1.7,1.1);[0,-5,-9].forEach((h,m)=>{t.line(c.x(f[0].x+h),c.y(f[0].y+h),c.x(T[0].x+h),c.y(T[0].y+h),25+i*12+m,l?1.6:1),t.line(c.x(f[1].x+h),c.y(f[1].y+h),c.x(T[1].x+h),c.y(T[1].y+h),28+i*12+m,l?1.6:1),t.line(c.x(f[2].x+h),c.y(f[2].y+h),c.x(T[2].x+h),c.y(T[2].y+h),31+i*12+m,l?1.6:1),t.line(c.x(f[0].x+h),c.y(f[0].y+h),c.x(f[1].x+h),c.y(f[1].y+h),18+i*12+m,l?1.3:1),t.line(c.x(f[1].x+h),c.y(f[1].y+h),c.x(f[2].x+h),c.y(f[2].y+h),21+i*12+m,l?1.3:1),t.line(c.x(f[2].x+h),c.y(f[2].y+h),c.x(f[0].x+h),c.y(f[0].y+h),24+i*12+m,l?1.3:1)})}drawCraper(t,i,s,l,c,f){const T=Math.max(4,Math.floor(14*s));for(let p=0;p<T;p+=1){const h=this.craperWalker.tick*7+p,m=(Math.floor(Kt(h)*63)+1)/10,E=Math.floor(Kt(h+3)*15)+1,S=this.craperWalker.x+Math.cos(m)*E,g=this.craperWalker.y+Math.sin(m)*E,A=this.craperWalker.color;if(f==="dense")for(let M=1;M<=10;M+=1)t.circle(c.x(this.craperWalker.x),c.y(this.craperWalker.y),c.w(M),A+M,!1,l?.35:.75);else f==="wide"?t.box(c.x(this.craperWalker.x-5),c.y(this.craperWalker.y-5),c.w(10),c.h(10),A,!1,l?.55:1):t.line(c.x(this.craperWalker.x),c.y(this.craperWalker.y),c.x(S),c.y(g),A,l?1.2:1,l?.75:1);this.craperWalker.x=S<0||S>zn?160:S,this.craperWalker.y=g<0||g>Xn?100:g,this.craperWalker.color=this.craperWalker.color>300?20:this.craperWalker.color+.01,this.craperWalker.tick+=1}}drawCooler(t,i,s,l,c,f){if(f==="wide"){let h=150-i*45%350;for(let m=0;m<38*s;m+=1){const E=i*4+m*2;h-=1.2,t.line(c.x(150+Math.cos(E)*h),c.y(100+Math.sin(E)*h),c.x(150+Math.cos(E+1)*h),c.y(100+Math.sin(E+1)*h),18+m,l?1.4:1)}return}const p=52+Math.sin(i)*48;for(let h=2;h<=7.2;h+=1.26){const m=Math.cos(h+i)*(40+p)+160,E=Math.sin(h+i)*(40+p)+100;t.line(c.x(m),c.y(E),c.x(Math.cos(h+.62+i)*(10+p)+160),c.y(Math.sin(h+.62+i)*(10+p)+100),30+i*8,l?2:1),t.line(c.x(m),c.y(E),c.x(Math.cos(h-.62+i)*(10+p)+160),c.y(Math.sin(h-.62+i)*(10+p)+100),30+i*8,l?2:1)}}drawCyber(t,i,s,l,c,f){this.drawStars(t,c,150,!0);const T=Math.floor(180*s),p=f==="wide"?4:f==="dense"?6:1;for(let h=0;h<T;h+=1){const m=h*.08+i,E=Math.cos(m),S=Math.sin(m),g=12+h*.7+Math.sin(i)*8,A=10+h*.45+Math.cos(i*.7)*8,M=E*g+150,x=S*A+100,v=20+h*.25+i*8;p===4?(t.line(c.x(1),c.y(1),c.x(M),c.y(x),v,l?1.1:1,l?.28:.55),t.line(c.x(315),c.y(199),c.x(M),c.y(x),v,l?1.1:1,l?.28:.55)):p===6?(t.line(c.x(M-15),c.y(x),c.x(M+15),c.y(x),v),t.line(c.x(M-15),c.y(x),c.x(M),c.y(x-15),v),t.line(c.x(M+15),c.y(x),c.x(M),c.y(x-15),v)):t.line(c.x(M+Math.sin(i)*20),c.y(x),c.x(E*(g+18)+150),c.y(S*A+100),v,l?1.5:1,l?.55:1)}}drawDelta(t,i,s,l,c,f){if(f==="dense"){for(let p=1;p<Xn;p+=4)for(let h=1;h<zn;h+=12)t.line(c.x(160),c.y(100),c.x(h),c.y(p),16+h/10+i*20,l?.8:1,l?.22:.45);return}const T=f==="wide"?50+Math.sin(i)*50:50;for(let p=2;p<=7.2;p+=1.26){const h=f==="orbit"?i:0,m=Math.cos(p+h)*80+160,E=Math.sin(p+h)*80+100;t.line(c.x(m),c.y(E),c.x(Math.cos(p+.62+i)*T+160),c.y(Math.sin(p+.62+i)*T+100),30+i*10,l?2:1),t.line(c.x(m),c.y(E),c.x(Math.cos(p-.62+i)*T+160),c.y(Math.sin(p-.62+i)*T+100),30+i*10,l?2:1)}}drawBall(t,i,s,l,c,f){if(l&&f!=="orbit"){this.drawModernSpaceDepth(t,i,s,c,f);return}const T=Math.floor((f==="dense"?150:100)*s);for(let p=0;p<T;p+=1){const h=Kt(p)*7.3,m=5+Kt(p*2)*5,E=(Kt(p*3)*95+i*m*18)%180,S=Math.cos(h)*E+160,g=Math.sin(h)*E+100,A=Math.cos(h)*(E-m)+160,M=Math.sin(h)*(E-m)+100;f==="orbit"?t.pset(c.x(Math.cos(i+p)*(20+Kt(p)*130)+160),c.y(Math.sin(i+p)*(20+Kt(p+4)*80)+100),19+p,c.pixel(l?2:1)):t.line(c.x(A),c.y(M),c.x(S),c.y(g),18+p*.1,l?1.2:1,l?.7:1)}t.box(c.x(0),c.y(0),c.w(319),c.h(199),0,!1)}drawModernSpaceDepth(t,i,s,l,c){const f=Math.floor((c==="dense"?260:190)*s),T=160+Math.sin(i*.18)*8,p=100+Math.cos(i*.14)*5;for(let h=0;h<f;h+=1){const m=c==="dense"?3.5:3.1,E=(Kt(h*17+3)-.5)*m,S=(Kt(h*19+7)-.5)*m*.72,g=.22+Kt(h*23+11)*.6,A=(Kt(h*29+13)+i*g)%1,M=Math.max(0,A-(.018+Kt(h*31+17)*.026)),x=1-A*.96,v=1-M*.96,D=22/Math.max(.08,x),I=22/Math.max(.08,v),U=T+E*D,Y=p+S*D,F=T+E*I,B=p+S*I;if(U<-20||U>zn+20||Y<-20||Y>Xn+20)continue;const R=c==="original"?7+A*3:18+A*16+h*.02,w=.25+A*.65,Z=.35+A*1.5;t.line(l.x(F),l.y(B),l.x(U),l.y(Y),R,Z,w),t.pset(l.x(U),l.y(Y),R+2,l.pixel(.6+A*.7))}t.box(l.x(0),l.y(0),l.w(319),l.h(199),0,!1)}drawLines(t,i,s,l,c,f){if(f==="wide"){const p=_E(i*.35,1,1),h=_E(i*.35+90,1,-1);t.line(c.x(p.x),c.y(p.y),c.x(h.x),c.y(h.y),20+i*4,l?2:1);return}if(f==="orbit"){for(let p=0;p<6;p+=1){const h=i*.45+p,m=i*.6+p*.7;t.line(c.x(160+Math.cos(h)*70),c.y(100+Math.sin(h)*50),c.x(160+Math.cos(m)*70),c.y(100+Math.sin(m)*50),20+p*4+i*6)}return}const T=Math.floor(32*s);for(let p=0;p<T;p+=1){const h=Math.floor(i*12),m=Kt(p+h)*315,E=Kt(p*3+h)*315,S=Kt(p*4)>.5?199:0,g=Kt(p*5)>.5?199:0;t.line(c.x(m),c.y(S),c.x(E),c.y(g),Kt(p)*300,l?1.1:1,l?.28:.55)}}drawShella(t,i,s,l,c,f){const T=f==="dense"?9:3;for(let p=0;p<T;p+=1){const h=30+p*11,m=p*1.7;for(let E=1;E<=7.25*s;E+=.14){const S=Math.cos(E+i+m)*h+160,g=Math.sin(E+i*.7+m)*(h*.8)+100,A=Math.cos(E+2.1+m)*(h+15)+160,M=Math.sin(E+1.6+m)*(h+10)+100;t.line(c.x(S),c.y(g),c.x(A),c.y(M),10+p*5+E*2,l?1.3:1,l?.35:.75)}}}drawType1(t,i,s,l,c){const f=Math.floor(70*s);for(let T=5;T<f;T+=8)for(let p=1;p<=100;p+=20){const h=(T+p+i*12)%130+4;t.circle(c.x(150),c.y(100),c.w(h),20+h*.2,!1,l?.5:.8)}}drawType2(t,i,s,l,c,f,T){if(T==="trail"){t.cls(0,c?.065:.1);const h=Math.floor(420*l);for(let m=0;m<h;m+=1){const E=Kt(m*11+5)*70+i*.18,S=35+Kt(m*13+7)*70,g=35+Kt(m*17+11)*70,A=35+Kt(m*19+13)*70,M=35+Kt(m*23+17)*70,x=i*(.8+Kt(m*29)*.35)+m*.0025;t.line(f.x(Math.cos(E)*S+150),f.y(Math.sin(E)*g+100),f.x(Math.cos(E+x)*A+150),f.y(Math.sin(E+x)*M+100),18+m*.05+i*2,c?1.1:1,c?.35:.7)}return}this.doorway.lineDebt+=Math.max(0,s)*520*l;const p=Math.min(32,Math.floor(this.doorway.lineDebt));this.doorway.lineDebt-=p;for(let h=0;h<p;h+=1){const m=(Math.floor(Kt(this.doorway.tick*17+3)*700)+1)/10;this.doorway.color+=.01,this.doorway.color>300&&(this.doorway.color=18),this.doorway.g+=.01;const E=Math.cos(m)*this.doorway.r,S=Math.sin(m)*this.doorway.r2,g=Math.cos(m+this.doorway.g)*this.doorway.r1,A=Math.sin(m+this.doorway.g)*this.doorway.r21;t.line(f.x(E+150),f.y(S+100),f.x(g+150),f.y(A+100),this.doorway.color,c?1.1:1,c?.55:1),this.doorway.tick+=1}}drawTunnels(t,i,s,l,c,f){const T=Math.max(6,Math.floor(16*s));for(let p=0;p<T;p+=1){const h=Math.floor(i*60)+p,m=h%this.wormPoints.length,E=this.wormPoints[m],S={x:E.x,y:E.y},g=f==="orbit",A=f==="original"?10:f==="wide"?2:1,M=g?[[-A,0],[A,0],[0,-A],[0,A],[-A,-A],[A,A],[A,-A],[-A,A]]:[[-A,0],[A,0],[0,-A],[0,A]],x=M[Math.floor(Kt(h*11)*M.length)];E.x+=x[0],E.y+=x[1],E.color=f==="original"?m+1:E.color+1,E.color>95&&(E.color=33),t.line(c.x(S.x),c.y(S.y),c.x(E.x),c.y(E.y),E.color,l?1.2:1,l?.65:1)}}drawCoolX(t,i,s,l,c,f,T){this.drawStars(t,f,150,!0);const p=this.getCoolBufferDraw(t,T),h=ad(p);eR(p.ctx,nR(l,c),t.width,t.height);const m=T==="wide"?2:T==="dense"?3:1;let E=null;for(let S=1;S<=8*s;S+=.01){const g=Math.cos((2+m)*S+i)*42+150,A=Math.sin((4+m)*S)*42+100,M=Math.cos(S)*42+g,x=Math.sin(S)*42+A,v=25+S*8+i*5;m===1&&(c&&E?p.line(h.x(E.x),h.y(E.y),h.x(M),h.y(x),v,1.1,.75):p.pset(h.x(M),h.y(x),v,1),E={x:M,y:x}),m===2&&p.line(h.x(M),h.y(x),h.x(M+5),h.y(x+5),v,c?1.3:1),m===3&&p.circle(h.x(M),h.y(x),h.w(5),v,!1,c?.45:.8)}this.coolBuffer&&t.ctx.drawImage(this.coolBuffer,0,0)}getCoolBufferDraw(t,i){(!this.coolBuffer||this.coolBuffer.width!==t.width||this.coolBuffer.height!==t.height||this.coolBufferVariant!==i)&&(this.coolBuffer=document.createElement("canvas"),this.coolBuffer.width=t.width,this.coolBuffer.height=t.height,this.coolBufferVariant=i);const l=this.coolBuffer;if(!l)throw new Error("Could not create Cool scene buffer");const c=l.getContext("2d");if(!c)throw new Error("Could not create Cool scene buffer");return Jd(c,t.width,t.height,t.mode,t.antialias,t.lineScale)}drawDisco(t,i,s,l,c){const f=Math.floor(100*s);for(let T=0;T<f;T+=1){const p=T*.0627,h=sR(T),m={x:Math.cos(p)*55+160,y:Math.sin(p)*45+100},E=(Math.sin(i*.4)+1)/2,S=h.x+(m.x-h.x)*E,g=h.y+(m.y-h.y)*E;t.circle(c.x(S),c.y(g),c.w(l?1.1:1),20+T*.1+i*3,!0,l?.7:1)}}drawSpheres(t,i,s,l,c){this.drawStars(t,c,150,!0);const f=Math.floor(90*s);for(let T=0;T<f;T+=1){const h=T%2?310:0,m=(T*17+i*35)%260,E=(T/f+i*.04)%1,S=150+(h-150)*E,g=100+(m-100)*E,A=1+(T+i*10)%50;t.circle(c.x(S),c.y(g),c.w(A),18+T+i*3,!1,l?.32:.65),t.pset(c.x(S),c.y(g),10,c.pixel(l?2:1))}}drawSpots(t,i,s,l,c,f){if(f==="wide"){for(let p=0;p<40*s;p+=1){const h=Kt(p+Math.floor(i*6))*zn,m=Kt(p*5+Math.floor(i*8))*Xn;for(let E=1;E<30;E+=2)t.circle(c.x(h),c.y(m),c.w(E),30+E+p,!1,l?.18:.35),t.line(c.x(h),c.y(m-E),c.x(h-E),c.y(m),30+E+p,l?1.1:1,l?.18:.35),t.line(c.x(h),c.y(m+E),c.x(h+E),c.y(m),30+E+p,l?1.1:1,l?.18:.35)}return}if(f==="dense"){for(let p=0;p<50;p+=1){const h=Kt(p)*7.3,m=(i*30+p*8)%180;t.circle(c.x(Math.cos(h)*m+160),c.y(Math.sin(h)*m+100),c.w(4+Kt(p)*24),20+p,!1,l?.5:1)}t.box(c.x(0),c.y(0),c.w(319),c.h(199),0,!1);return}const T=Math.floor(36*s);for(let p=0;p<T;p+=1){const h=Math.floor(i*12),m=Kt(p+h)*zn,E=Kt(p*2)*Xn,S=E+Kt(p*3)*(Xn-E);t.line(c.x(m),c.y(E),c.x(m),c.y(S),20+p*.1,l?1.2:1,l?.35:.75),t.circle(c.x(m),c.y(S),c.w(1+Kt(p)*25),25+p,!1,l?.32:.65)}}ellipse(t,i,s,l,c,f,T,p){if(!t.antialias){const h=Math.max(48,Math.round(Math.max(l,c)*3));let m={x:i+l,y:s};for(let E=1;E<=h;E+=1){const S=E/h*Math.PI*2,g={x:i+Math.cos(S)*l,y:s+Math.sin(S)*c};t.line(m.x,m.y,g.x,g.y,f,T,p),m=g}return}t.ctx.save(),t.ctx.globalAlpha=p,t.ctx.strokeStyle=t.color(f),t.ctx.lineWidth=T*t.lineScale,t.ctx.beginPath(),t.ctx.ellipse(i,s,l,c,0,0,Math.PI*2),t.ctx.stroke(),t.ctx.restore()}pixelLine(t,i,s,l,c,f,T,p){if(p){t.line(i,s,l,c,f,T);return}let h=Math.round(i),m=Math.round(s);const E=Math.round(l),S=Math.round(c),g=Math.abs(E-h),A=h<E?1:-1,M=-Math.abs(S-m),x=m<S?1:-1;let v=g+M;for(;t.pset(h,m,f,1),!(h===E&&m===S);){const D=v*2;D>=M&&(v+=M,h+=A),D<=g&&(v+=g,m+=x)}}pixelBox(t,i,s,l,c,f,T){this.pixelLine(t,i,s,l,s,f,T?1.4:1,T),this.pixelLine(t,l,s,l,c,f,T?1.4:1,T),this.pixelLine(t,l,c,i,c,f,T?1.4:1,T),this.pixelLine(t,i,c,i,s,f,T?1.4:1,T)}}function ad(r){const t=r.width/zn,i=r.height/Xn;return{sx:t,sy:i,x:s=>s*t,y:s=>s*i,w:s=>s*t,h:s=>s*i,pixel:s=>Math.max(1,Math.round(s*Math.min(t,i)))}}function $M(r,t,i){return t<=0?1:r==="craper"?i?.018:.012:r==="lines"?i?.065:.04:r==="type1"?i?.045:.03:r==="type2"?0:r==="tunnels"?i?.045:.03:r==="coolx"?1:r==="spots"?i?.08:.055:i?Math.max(.04,.18-t*.12):Math.max(.1,.35-t*.2)}function QM(r){return Array.from({length:r},(t,i)=>({x:Kt(i*2),y:Kt(i*3),speed:.2+Kt(i*5)*1.6,size:1+Math.floor(Kt(i*7)*2)}))}function jM(r){return Array.from({length:r},(t,i)=>({x:Kt(i)*zn,y:Kt(i*2)*Xn,dx:(Kt(i*3)>.5?1:-1)*(.5+Kt(i*4)*2),dy:(Kt(i*5)>.5?1:-1)*(.5+Kt(i*6)*2),color:20+Kt(i*7)*60}))}function JM(r){return Array.from({length:r},(t,i)=>({x:Kt(i*11)*zn,y:Kt(i*13)*Xn}))}function tR(r){return Array.from({length:r},(t,i)=>({x:Math.floor(Kt(i*19)*360)+1,y:Math.floor(Kt(i*23)*200)+1,phase:Kt(i*29)*Math.PI*2,speed:(Math.floor(Kt(i*31)*10)+1)/5}))}function SE(r){return Array.from({length:r},(t,i)=>({x:Math.floor(Kt(i*41)*360)+1,y:Math.floor(Kt(i*43)*200)+1,color:33+Math.floor(Kt(i*47)*30)}))}function gE(){return{r:Math.floor(Kt(103)*100)+1,r2:Math.floor(Kt(107)*100)+1,r1:Math.floor(Kt(109)*100)+1,r21:Math.floor(Kt(113)*100)+1,g:0,color:18,tick:0,lineDebt:0}}function eR(r,t,i,s){r.save(),r.globalCompositeOperation="destination-out",r.globalAlpha=t,r.fillStyle="#000",r.fillRect(0,0,i,s),r.restore()}function nR(r,t){return r<=0?1:t?Math.max(.04,.18-r*.12):Math.max(.1,.35-r*.2)}function iR(){return Array.from({length:2353},(r,t)=>Math.floor(Kt(t*17)*10))}function Kt(r){return aR(Math.sin(r*12.9898+78.233)*43758.5453)}function aR(r){return r-Math.floor(r)}function Ki(r,t){const i=t*2,s=(r%i+i)%i;return s>t?i-s:s}function _E(r,t,i){return{x:Ki(40+r*45*t,zn),y:Ki(30+r*31*i,Xn)}}function Wc(r,t,i,s){return[{x:Ki(20+r*45*t,zn),y:Ki(40+r*35*t,Xn)},{x:Ki(160+r*45*i,zn),y:Ki(20+r*35*i,Xn)},{x:Ki(300+r*45*s,zn),y:Ki(160+r*35*s,Xn)}]}function sR(r){const t=Math.floor(r/33),i=r%33,s=1+Kt(r)*2;return t===0?{x:80+i*s,y:60+i*s}:t===1?{x:80+33*s-i*s*2,y:60+33*s}:{x:80-33*s+i*s,y:60+33*s-i*s}}function il(r,t,i,s,l){return r.x>=t&&r.x<=t+s&&r.y>=i&&r.y<=i+l}function gn(r,t,i,s,l,c,f,T,p=aS){return{id:r,title:t,key:i,originalName:s,note:l,renderer:"canvas2d",settings:p,annotation:{file:"VIRT.BAS",subroutine:s,startLine:c,endLine:f},create:()=>new qM(T)}}function rR(r,t,i,s,l){return{id:r,title:t,key:i,originalName:"NEW 3D",note:s,renderer:"three",badge:"NEW 3D",settings:l,createThree:()=>new zM}}const oR=[{kind:"range",id:"speed",label:"Speed",description:"Forward flyover speed.",min:.25,max:2.5,step:.05,defaultValue:1},{kind:"range",id:"duneScale",label:"Dune scale",description:"Width and spacing of the rolling dune ridges.",min:.5,max:2,step:.05,defaultValue:.5},{kind:"range",id:"terrainDetail",label:"Terrain detail",description:"Mesh density for dune silhouettes and facets.",min:0,max:2,step:.05,defaultValue:1},{kind:"range",id:"cameraHeight",label:"Camera height",description:"How high the flyover rides above the dune field.",min:0,max:2,step:.05,defaultValue:1},{kind:"range",id:"pixelation",label:"Pixelation",description:"Internal render scale for the retro-CG crunch.",min:0,max:4,step:.05,defaultValue:2},{kind:"select",id:"palette",label:"Palette",description:"DOS-era color treatment for sky, sand, and traces.",options:[{label:"Sietch Dusk",value:"dusk",description:"Purple sky, amber dunes, cyan horizon traces."},{label:"VGA Noon",value:"noon",description:"Bright blue sky and hot gold sand."},{label:"Night Flight",value:"night",description:"Deep indigo desert with red sun glow."}],defaultValue:"dusk"}],lR=[gn("intro","Intro and Title","I","program start","The opening star field, title data art, and menu identity remade for canvas.",27,258,"intro"),gn("info","Info","N","INFO","The old credits chamber, now with readable archive notes beside it.",1588,1661,"info"),gn("saver","Screen Savers","S","SAVER/SAVER2/SAVER3","Idle animations from the menus, preserved as standalone scenes.",2172,2316,"saver")],cR=[rR("dune-flyover","Dune Flyover","3D","A new live Three.js desert flyover with retro-CG dunes, ruins, sun, and horizon traces.",oR),gn("omega","Omega Beams","1","OMEGA","Radial beam geometry with density and length controls.",2069,2170,"omega",fE({trail:.05})),gn("laser","Laser Beams","2","LASER","Triangular laser traces driven by speed and color motion.",1663,1827,"laser",fE({trail:.05})),gn("craper","Random Walker","3","CRAPER","Slow random-walk line drawing from the original mode selector.",1070,1105,"craper",Li([{label:"Original",value:"original",description:"Colorful random-walk line drawing."},{label:"Variant 1",value:"dense",description:"Circle traces around the walker."},{label:"Variant 2",value:"wide",description:"Box traces around the walker."}])),gn("cooler","Cooler","4","COOLER","Orbiting line structures with two classic motion modes.",893,951,"cooler",Li([{label:"Original",value:"original",description:"Orbiting line structure."},{label:"Variant 1",value:"wide",description:"Contracting spiral line mode."}])),gn("cyber","Cyber Storm","5","CYBER","Tunnel and storm forms pulled from the old custom/random selector.",1107,1196,"cyber",Li([{label:"Original",value:"original",description:"Central storm tunnel."},{label:"Variant 1",value:"wide",description:"Corner-to-center beam traces."},{label:"Variant 2",value:"dense",description:"Triangular storm traces."}])),gn("delta","Delta","6","DELTA","Rotating triangular forms and mirrored line fields.",1198,1390,"delta",Li([{label:"Original",value:"original",description:"Rotating triangular arms."},{label:"Variant 1",value:"wide",description:"Wider radius arm motion."},{label:"Variant 2",value:"dense",description:"Dense radial line field."},{label:"Variant 3",value:"orbit",description:"Orbiting anchor points."}])),gn("ball","Space","7","BALL","The bouncing/orbiting space particle routines grouped under SPACE.",267,725,"ball",Li([{label:"Original",value:"original",description:"Radiating space particle trails."},{label:"Variant 1",value:"dense",description:"More particle trails."},{label:"Variant 2",value:"orbit",description:"Orbital point field."}])),gn("lines","Lines","8","LINES","The line experiments, boxes, bounces, and perspective traces.",1829,2067,"lines",Li([{label:"Original",value:"wide",description:"Single bouncing line mode."},{label:"Variant 1",value:"original",description:"Random edge-to-edge line traces."},{label:"Variant 2",value:"orbit",description:"Orbital line mode."}],"wide")),gn("shella","Gravity","A","SHELLA","Gravity-style orbiting strokes and multi-arm motion.",2318,2510,"shella",Li([{label:"Original",value:"original",description:"Three-arm gravity trace."},{label:"Variant 1",value:"dense",description:"Nine-arm gravity trace."}])),gn("type1","Warp","B","TYPE1","Concentric warp rings from the original WARP routine.",3027,3042,"type1"),gn("type2","Doorway","C","TYPE2","Doorway rectangles that pull the eye into the center.",3044,3067,"type2",Li([{label:"Original",value:"original",description:"Faithful accumulating TYPE2 line loop."},{label:"Variant 1",value:"trail",description:"Smooth fading doorway cloud."}])),gn("tunnels","Bugs and Worms","D","TUNNELS","Tunnel crawlers and worm-like line motion.",2918,3025,"tunnels",Li([{label:"Original",value:"original",description:"Large-step worm motion."},{label:"Variant 1",value:"wide",description:"Small-step worm motion."},{label:"Variant 2",value:"dense",description:"Small-step color-cycling motion."},{label:"Variant 3",value:"orbit",description:"Diagonal worm motion."}])),gn("coolx","Cool","E","COOLX","Random custom cool-stuff generator remade from the original lissajous and bounce modes.",953,1068,"coolx",Li([{label:"Original",value:"original",description:"Lissajous point field."},{label:"Variant 1",value:"wide",description:"Offset line field."},{label:"Variant 2",value:"dense",description:"Circle field."}],"original",{trail:0,modernLineWidth:8})),gn("disco","Morph","F","DISCO","Morphing disco blobs and shifting colorful trails.",1392,1563,"disco"),gn("spheres","Spheres","G","SPHERES","Sphere arcs, center points, and orbital shell motion.",2539,2605,"spheres"),gn("spots","Spots","H","SPOTS","Spot, box, circle, and floating particle variants.",2607,2916,"spots",Li([{label:"Original",value:"dense",description:"Expanding spot circles from the original routine."},{label:"Variant 1",value:"wide",description:"Circle-and-cross spot field."},{label:"Variant 2",value:"original",description:"Vertical spot streaks."}],"dense"))],t0=[...lR,...cR],vE=t0.filter(r=>r.id!=="intro"&&r.id!=="info");function mR(r){return t0.find(t=>t.id===r)??t0[0]}function ER(r){return vE.find(t=>t.id===r)??vE[0]}function uR({scene:r,mode:t,settings:i,onExit:s,onSceneAction:l,nativeHost:c=!1,nativeFrameBridge:f=!1}){const T=bn.useRef(null),p=bn.useMemo(()=>{const A=r.create?.();if(!A)throw new Error(`${r.title} does not provide a canvas renderer`);return A},[r]),h=bn.useRef(i),m=bn.useRef(t),E=bn.useRef(s),S=bn.useRef(l),g=bn.useRef({pointer:{x:160,y:100,down:!1,justPressed:!1,active:!1},keys:new Set,lastKey:""});return h.current=i,m.current=t,E.current=s,S.current=l,bn.useLayoutEffect(()=>{const A=T.current;if(!A)return;let M=0,x=0,v=0,D=performance.now(),I=m.current,U=0,Y=!1;const F=A.getContext("2d");if(!F)return;const B=()=>{const ft=A.getBoundingClientRect(),O=m.current==="classic",V=c||f?1:window.devicePixelRatio||1;let dt=O?320:Math.max(640,Math.floor(ft.width*V)),gt=O?200:Math.max(400,Math.floor(ft.height*V));(A.width!==dt||A.height!==gt)&&(A.width=dt,A.height=gt),A.style.imageRendering=O?"pixelated":"auto"},R=ft=>{const O=A.getBoundingClientRect(),V=m.current==="classic",dt=V?320:A.width,gt=V?200:A.height;return{x:(ft.clientX-O.left)/O.width*dt,y:(ft.clientY-O.top)/O.height*gt}},w=ft=>{const O=R(ft);g.current.pointer={...g.current.pointer,...O,active:!0}},Z=ft=>{const O=R(ft);g.current.pointer={...O,down:!0,justPressed:!0,active:!0},A.setPointerCapture(ft.pointerId)},H=()=>{g.current.pointer={...g.current.pointer,down:!1}},$=ft=>{if(ft.key==="Escape"){ft.preventDefault(),E.current();return}g.current.keys.add(ft.key),g.current.lastKey=ft.key},ct=ft=>{g.current.keys.delete(ft.key)};B(),window.addEventListener("resize",B),window.addEventListener("keydown",$),window.addEventListener("keyup",ct),A.addEventListener("pointermove",w),A.addEventListener("pointerdown",Z),A.addEventListener("pointerup",H),A.addEventListener("pointerleave",H);const lt=ft=>{if(Y)return;I!==m.current&&(B(),I=m.current);const O=(ft-D)/1e3,V=Number.isFinite(O)&&O>0?Math.min(.05,O):1/30;D=ft;const dt=Jd(F,A.width,A.height,m.current,m.current==="modern"||!!h.current.antialias,Number(h.current.modernLineWidth)||1),gt={mode:m.current,time:ft/1e3,delta:V,frame:M,settings:h.current,input:g.current,action:S.current};try{p.update?.(dt,gt),p.render(dt,gt),window.__VIRTUALITY_STATUS__={frame:M,height:A.height,mode:m.current,sceneId:r.id,width:A.width}}catch(Mt){throw window.__VIRTUALITY_STATUS__={error:Mt instanceof Error?Mt.message:String(Mt),frame:M,height:A.height,mode:m.current,sceneId:r.id,width:A.width},Mt}g.current.pointer.justPressed=!1,M+=1,U=performance.now()},W=ft=>{Y||(lt(ft),x=requestAnimationFrame(W))};let L=0,P=0;const it=()=>{B(),lt(performance.now());const ft=A.getBoundingClientRect();if(M<=3||M%60===0){const V=F.getImageData(0,0,A.width,A.height),dt=Math.max(4,Math.floor(A.width*A.height/1200)*4);L=0,P=0;for(let gt=0;gt<V.data.length;gt+=dt)P+=1,(V.data[gt]||V.data[gt+1]||V.data[gt+2])&&(L+=1)}return{ok:!0,width:A.width,height:A.height,cssWidth:Math.round(ft.width),cssHeight:Math.round(ft.height),pixelRatio:c||f?1:window.devicePixelRatio||1,frame:M,sampleNonBlack:L,sampleTotal:P,dataURL:A.toDataURL("image/png")}},mt=()=>{Y=!0,cancelAnimationFrame(x),window.clearInterval(v)};return p.init?.(Jd(F,A.width,A.height,m.current,m.current==="modern"||!!h.current.antialias,Number(h.current.modernLineWidth)||1),{mode:m.current,time:0,delta:0,frame:0,settings:h.current,input:g.current,action:S.current}),window.__VIRTUALITY_STOP__=mt,f&&(window.__VIRTUALITY_RENDER_FRAME__=it),lt(performance.now()),f||(x=requestAnimationFrame(W),v=window.setInterval(()=>{performance.now()-U>120&&lt(performance.now())},100)),()=>{Y=!0,cancelAnimationFrame(x),window.clearInterval(v),f&&window.__VIRTUALITY_RENDER_FRAME__===it&&delete window.__VIRTUALITY_RENDER_FRAME__,window.__VIRTUALITY_STOP__===mt&&delete window.__VIRTUALITY_STOP__,p.dispose?.(),window.removeEventListener("resize",B),window.removeEventListener("keydown",$),window.removeEventListener("keyup",ct),A.removeEventListener("pointermove",w),A.removeEventListener("pointerdown",Z),A.removeEventListener("pointerup",H),A.removeEventListener("pointerleave",H)}},[p,c,f]),jc.jsx("canvas",{ref:T,className:`stage-canvas ${t}`,"aria-label":`${r.title} canvas`})}function fR({scene:r,mode:t,settings:i,onExit:s,onSceneAction:l,nativeHost:c=!1,nativeFrameBridge:f=!1}){const T=bn.useRef(null),p=bn.useMemo(()=>{const A=r.createThree?.();if(!A)throw new Error(`${r.title} does not provide a Three.js renderer`);return A},[r]),h=bn.useRef(i),m=bn.useRef(t),E=bn.useRef(s),S=bn.useRef(l),g=bn.useRef({pointer:{x:0,y:0,down:!1,justPressed:!1,active:!1},keys:new Set,lastKey:""});return h.current=i,m.current=t,E.current=s,S.current=l,bn.useLayoutEffect(()=>{const A=T.current;if(!A)return;let M=0,x=0,v=0,D=performance.now(),I=0,U=!1;const Y=(O,V)=>{const dt=A.getBoundingClientRect(),gt=c||f?1:window.devicePixelRatio||1;return{mode:m.current,time:O/1e3,delta:V,frame:M,settings:h.current,input:g.current,action:S.current,width:Math.max(1,Math.floor(dt.width)),height:Math.max(1,Math.floor(dt.height)),pixelRatio:gt,nativeFrameBridge:f,nativeHost:c}},F=O=>{const V=A.getBoundingClientRect();return{x:O.clientX-V.left,y:O.clientY-V.top}},B=O=>{const V=F(O);g.current.pointer={...g.current.pointer,...V,active:!0}},R=O=>{const V=F(O);g.current.pointer={...V,down:!0,justPressed:!0,active:!0},A.setPointerCapture(O.pointerId)},w=()=>{g.current.pointer={...g.current.pointer,down:!1}},Z=O=>{if(O.key==="Escape"){O.preventDefault(),E.current();return}g.current.keys.add(O.key),g.current.lastKey=O.key},H=O=>{g.current.keys.delete(O.key)};window.addEventListener("keydown",Z),window.addEventListener("keyup",H),A.addEventListener("pointermove",B),A.addEventListener("pointerdown",R),A.addEventListener("pointerup",w),A.addEventListener("pointerleave",w);const $=Y(performance.now(),0);p.init(A,$),p.resize?.($);const ct=O=>{if(U)return;const V=(O-D)/1e3,dt=Number.isFinite(V)&&V>0?Math.min(.05,V):1/30;D=O;const gt=Y(O,dt);try{p.resize?.(gt),p.update?.(gt),p.render(gt),window.__VIRTUALITY_STATUS__={frame:M,height:A.height,mode:m.current,sceneId:r.id,width:A.width}}catch(Mt){throw window.__VIRTUALITY_STATUS__={error:Mt instanceof Error?Mt.message:String(Mt),frame:M,height:A.height,mode:m.current,sceneId:r.id,width:A.width},Mt}g.current.pointer.justPressed=!1,M+=1,I=performance.now()},lt=O=>{U||(ct(O),x=requestAnimationFrame(lt))},W=document.createElement("canvas");W.width=48,W.height=30;const L=W.getContext("2d",{willReadFrequently:!0});let P=0,it=0;const mt=()=>{ct(performance.now());const O=A.getBoundingClientRect(),V=M<=3||M%60===0;if(L&&V){L.clearRect(0,0,W.width,W.height),L.drawImage(A,0,0,W.width,W.height);const dt=L.getImageData(0,0,W.width,W.height);P=0,it=0;for(let gt=0;gt<dt.data.length;gt+=4)it+=1,(dt.data[gt]||dt.data[gt+1]||dt.data[gt+2])&&(P+=1)}return{ok:!0,width:A.width,height:A.height,cssWidth:Math.round(O.width),cssHeight:Math.round(O.height),pixelRatio:c||f?1:window.devicePixelRatio||1,frame:M,sampleNonBlack:P,sampleTotal:it,dataURL:A.toDataURL("image/png")}},ft=()=>{U=!0,cancelAnimationFrame(x),window.clearInterval(v)};return ct(performance.now()),window.__VIRTUALITY_STOP__=ft,f&&(window.__VIRTUALITY_RENDER_FRAME__=mt),f||(x=requestAnimationFrame(lt),v=window.setInterval(()=>{performance.now()-I>120&&ct(performance.now())},100)),()=>{U=!0,cancelAnimationFrame(x),window.clearInterval(v),f&&window.__VIRTUALITY_RENDER_FRAME__===mt&&delete window.__VIRTUALITY_RENDER_FRAME__,window.__VIRTUALITY_STOP__===ft&&delete window.__VIRTUALITY_STOP__,p.dispose?.(),window.removeEventListener("keydown",Z),window.removeEventListener("keyup",H),A.removeEventListener("pointermove",B),A.removeEventListener("pointerdown",R),A.removeEventListener("pointerup",w),A.removeEventListener("pointerleave",w)}},[r,p,t,c,f]),jc.jsx("canvas",{ref:T,className:`stage-canvas three-stage ${t}`,"aria-label":`${r.title} canvas`})}function SR(r){return r.scene.renderer==="three"?jc.jsx(fR,{...r}):jc.jsx(uR,{...r})}export{hR as R,SR as S,ER as a,vE as b,dR as c,TR as d,mR as f,jc as j,pR as o,bn as r,t0 as s};
