(function(){const O=document.createElement("link").relList;if(O&&O.supports&&O.supports("modulepreload"))return;for(const S of document.querySelectorAll('link[rel="modulepreload"]'))i(S);new MutationObserver(S=>{for(const c of S)if(c.type==="childList")for(const I of c.addedNodes)I.tagName==="LINK"&&I.rel==="modulepreload"&&i(I)}).observe(document,{childList:!0,subtree:!0});function E(S){const c={};return S.integrity&&(c.integrity=S.integrity),S.referrerPolicy&&(c.referrerPolicy=S.referrerPolicy),S.crossOrigin==="use-credentials"?c.credentials="include":S.crossOrigin==="anonymous"?c.credentials="omit":c.credentials="same-origin",c}function i(S){if(S.ep)return;S.ep=!0;const c=E(S);fetch(S.href,c)}})();function IO(A){return A&&A.__esModule&&Object.prototype.hasOwnProperty.call(A,"default")?A.default:A}var Cu={exports:{}},da={};var Mf;function rO(){if(Mf)return da;Mf=1;var A=Symbol.for("react.transitional.element"),O=Symbol.for("react.fragment");function E(i,S,c){var I=null;if(c!==void 0&&(I=""+c),S.key!==void 0&&(I=""+S.key),"key"in S){c={};for(var r in S)r!=="key"&&(c[r]=S[r])}else c=S;return S=c.ref,{$$typeof:A,type:i,key:I,ref:S!==void 0?S:null,props:c}}return da.Fragment=O,da.jsx=E,da.jsxs=E,da}var Uf;function HO(){return Uf||(Uf=1,Cu.exports=rO()),Cu.exports}var yO=HO(),Yu={exports:{}},W={};var Gf;function hO(){if(Gf)return W;Gf=1;var A=Symbol.for("react.transitional.element"),O=Symbol.for("react.portal"),E=Symbol.for("react.fragment"),i=Symbol.for("react.strict_mode"),S=Symbol.for("react.profiler"),c=Symbol.for("react.consumer"),I=Symbol.for("react.context"),r=Symbol.for("react.forward_ref"),D=Symbol.for("react.suspense"),N=Symbol.for("react.memo"),C=Symbol.for("react.lazy"),o=Symbol.for("react.activity"),U=Symbol.iterator;function M(Y){return Y===null||typeof Y!="object"?null:(Y=U&&Y[U]||Y["@@iterator"],typeof Y=="function"?Y:null)}var b={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},p=Object.assign,q={};function w(Y,v,g){this.props=Y,this.context=v,this.refs=q,this.updater=g||b}w.prototype.isReactComponent={},w.prototype.setState=function(Y,v){if(typeof Y!="object"&&typeof Y!="function"&&Y!=null)throw Error("takes an object of state variables to update or a function which returns an object of state variables.");this.updater.enqueueSetState(this,Y,v,"setState")},w.prototype.forceUpdate=function(Y){this.updater.enqueueForceUpdate(this,Y,"forceUpdate")};function In(){}In.prototype=w.prototype;function Cn(Y,v,g){this.props=Y,this.context=v,this.refs=q,this.updater=g||b}var rn=Cn.prototype=new In;rn.constructor=Cn,p(rn,w.prototype),rn.isPureReactComponent=!0;var vn=Array.isArray;function Hn(){}var P={H:null,A:null,T:null,S:null},mn=Object.prototype.hasOwnProperty;function $n(Y,v,g){var K=g.ref;return{$$typeof:A,type:Y,key:v,ref:K!==void 0?K:null,props:g}}function u1(Y,v){return $n(Y.type,v,Y.props)}function i1(Y){return typeof Y=="object"&&Y!==null&&Y.$$typeof===A}function _n(Y){var v={"=":"=0",":":"=2"};return"$"+Y.replace(/[=:]/g,function(g){return v[g]})}var Y1=/\/+/g;function s1(Y,v){return typeof Y=="object"&&Y!==null&&Y.key!=null?_n(""+Y.key):v.toString(36)}function wn(Y){switch(Y.status){case"fulfilled":return Y.value;case"rejected":throw Y.reason;default:switch(typeof Y.status=="string"?Y.then(Hn,Hn):(Y.status="pending",Y.then(function(v){Y.status==="pending"&&(Y.status="fulfilled",Y.value=v)},function(v){Y.status==="pending"&&(Y.status="rejected",Y.reason=v)})),Y.status){case"fulfilled":return Y.value;case"rejected":throw Y.reason}}throw Y}function L(Y,v,g,K,$){var ln=typeof Y;(ln==="undefined"||ln==="boolean")&&(Y=null);var En=!1;if(Y===null)En=!0;else switch(ln){case"bigint":case"string":case"number":En=!0;break;case"object":switch(Y.$$typeof){case A:case O:En=!0;break;case C:return En=Y._init,L(En(Y._payload),v,g,K,$)}}if(En)return $=$(Y),En=K===""?"."+s1(Y,0):K,vn($)?(g="",En!=null&&(g=En.replace(Y1,"$&/")+"/"),L($,v,g,"",function(Ut){return Ut})):$!=null&&(i1($)&&($=u1($,g+($.key==null||Y&&Y.key===$.key?"":(""+$.key).replace(Y1,"$&/")+"/")+En)),v.push($)),1;En=0;var jn=K===""?".":K+":";if(vn(Y))for(var dn=0;dn<Y.length;dn++)K=Y[dn],ln=jn+s1(K,dn),En+=L(K,v,g,ln,$);else if(dn=M(Y),typeof dn=="function")for(Y=dn.call(Y),dn=0;!(K=Y.next()).done;)K=K.value,ln=jn+s1(K,dn++),En+=L(K,v,g,ln,$);else if(ln==="object"){if(typeof Y.then=="function")return L(wn(Y),v,g,K,$);throw v=String(Y),Error("Objects are not valid as a React child (found: "+(v==="[object Object]"?"object with keys {"+Object.keys(Y).join(", ")+"}":v)+"). If you meant to render a collection of children, use an array instead.")}return En}function G(Y,v,g){if(Y==null)return Y;var K=[],$=0;return L(Y,K,"","",function(ln){return v.call(g,ln,$++)}),K}function z(Y){if(Y._status===-1){var v=Y._result;v=v(),v.then(function(g){(Y._status===0||Y._status===-1)&&(Y._status=1,Y._result=g)},function(g){(Y._status===0||Y._status===-1)&&(Y._status=2,Y._result=g)}),Y._status===-1&&(Y._status=0,Y._result=v)}if(Y._status===1)return Y._result.default;throw Y._result}var k=typeof reportError=="function"?reportError:function(Y){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var v=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof Y=="object"&&Y!==null&&typeof Y.message=="string"?String(Y.message):String(Y),error:Y});if(!window.dispatchEvent(v))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",Y);return}console.error(Y)},nn={map:G,forEach:function(Y,v,g){G(Y,function(){v.apply(this,arguments)},g)},count:function(Y){var v=0;return G(Y,function(){v++}),v},toArray:function(Y){return G(Y,function(v){return v})||[]},only:function(Y){if(!i1(Y))throw Error("React.Children.only expected to receive a single React element child.");return Y}};return W.Activity=o,W.Children=nn,W.Component=w,W.Fragment=E,W.Profiler=S,W.PureComponent=Cn,W.StrictMode=i,W.Suspense=D,W.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=P,W.__COMPILER_RUNTIME={__proto__:null,c:function(Y){return P.H.useMemoCache(Y)}},W.cache=function(Y){return function(){return Y.apply(null,arguments)}},W.cacheSignal=function(){return null},W.cloneElement=function(Y,v,g){if(Y==null)throw Error("The argument must be a React element, but you passed "+Y+".");var K=p({},Y.props),$=Y.key;if(v!=null)for(ln in v.key!==void 0&&($=""+v.key),v)!mn.call(v,ln)||ln==="key"||ln==="__self"||ln==="__source"||ln==="ref"&&v.ref===void 0||(K[ln]=v[ln]);var ln=arguments.length-2;if(ln===1)K.children=g;else if(1<ln){for(var En=Array(ln),jn=0;jn<ln;jn++)En[jn]=arguments[jn+2];K.children=En}return $n(Y.type,$,K)},W.createContext=function(Y){return Y={$$typeof:I,_currentValue:Y,_currentValue2:Y,_threadCount:0,Provider:null,Consumer:null},Y.Provider=Y,Y.Consumer={$$typeof:c,_context:Y},Y},W.createElement=function(Y,v,g){var K,$={},ln=null;if(v!=null)for(K in v.key!==void 0&&(ln=""+v.key),v)mn.call(v,K)&&K!=="key"&&K!=="__self"&&K!=="__source"&&($[K]=v[K]);var En=arguments.length-2;if(En===1)$.children=g;else if(1<En){for(var jn=Array(En),dn=0;dn<En;dn++)jn[dn]=arguments[dn+2];$.children=jn}if(Y&&Y.defaultProps)for(K in En=Y.defaultProps,En)$[K]===void 0&&($[K]=En[K]);return $n(Y,ln,$)},W.createRef=function(){return{current:null}},W.forwardRef=function(Y){return{$$typeof:r,render:Y}},W.isValidElement=i1,W.lazy=function(Y){return{$$typeof:C,_payload:{_status:-1,_result:Y},_init:z}},W.memo=function(Y,v){return{$$typeof:N,type:Y,compare:v===void 0?null:v}},W.startTransition=function(Y){var v=P.T,g={};P.T=g;try{var K=Y(),$=P.S;$!==null&&$(g,K),typeof K=="object"&&K!==null&&typeof K.then=="function"&&K.then(Hn,k)}catch(ln){k(ln)}finally{v!==null&&g.types!==null&&(v.types=g.types),P.T=v}},W.unstable_useCacheRefresh=function(){return P.H.useCacheRefresh()},W.use=function(Y){return P.H.use(Y)},W.useActionState=function(Y,v,g){return P.H.useActionState(Y,v,g)},W.useCallback=function(Y,v){return P.H.useCallback(Y,v)},W.useContext=function(Y){return P.H.useContext(Y)},W.useDebugValue=function(){},W.useDeferredValue=function(Y,v){return P.H.useDeferredValue(Y,v)},W.useEffect=function(Y,v){return P.H.useEffect(Y,v)},W.useEffectEvent=function(Y){return P.H.useEffectEvent(Y)},W.useId=function(){return P.H.useId()},W.useImperativeHandle=function(Y,v,g){return P.H.useImperativeHandle(Y,v,g)},W.useInsertionEffect=function(Y,v){return P.H.useInsertionEffect(Y,v)},W.useLayoutEffect=function(Y,v){return P.H.useLayoutEffect(Y,v)},W.useMemo=function(Y,v){return P.H.useMemo(Y,v)},W.useOptimistic=function(Y,v){return P.H.useOptimistic(Y,v)},W.useReducer=function(Y,v,g){return P.H.useReducer(Y,v,g)},W.useRef=function(Y){return P.H.useRef(Y)},W.useState=function(Y){return P.H.useState(Y)},W.useSyncExternalStore=function(Y,v,g){return P.H.useSyncExternalStore(Y,v,g)},W.useTransition=function(){return P.H.useTransition()},W.version="19.2.6",W}var bf;function Bu(){return bf||(bf=1,Yu.exports=hO()),Yu.exports}var Ll=Bu();const eA=IO(Ll);var su={exports:{}},Ba={},Xu={exports:{}},ou={};var pf;function dO(){return pf||(pf=1,(function(A){function O(L,G){var z=L.length;L.push(G);n:for(;0<z;){var k=z-1>>>1,nn=L[k];if(0<S(nn,G))L[k]=G,L[z]=nn,z=k;else break n}}function E(L){return L.length===0?null:L[0]}function i(L){if(L.length===0)return null;var G=L[0],z=L.pop();if(z!==G){L[0]=z;n:for(var k=0,nn=L.length,Y=nn>>>1;k<Y;){var v=2*(k+1)-1,g=L[v],K=v+1,$=L[K];if(0>S(g,z))K<nn&&0>S($,g)?(L[k]=$,L[K]=z,k=K):(L[k]=g,L[v]=z,k=v);else if(K<nn&&0>S($,z))L[k]=$,L[K]=z,k=K;else break n}}return G}function S(L,G){var z=L.sortIndex-G.sortIndex;return z!==0?z:L.id-G.id}if(A.unstable_now=void 0,typeof performance=="object"&&typeof performance.now=="function"){var c=performance;A.unstable_now=function(){return c.now()}}else{var I=Date,r=I.now();A.unstable_now=function(){return I.now()-r}}var D=[],N=[],C=1,o=null,U=3,M=!1,b=!1,p=!1,q=!1,w=typeof setTimeout=="function"?setTimeout:null,In=typeof clearTimeout=="function"?clearTimeout:null,Cn=typeof setImmediate<"u"?setImmediate:null;function rn(L){for(var G=E(N);G!==null;){if(G.callback===null)i(N);else if(G.startTime<=L)i(N),G.sortIndex=G.expirationTime,O(D,G);else break;G=E(N)}}function vn(L){if(p=!1,rn(L),!b)if(E(D)!==null)b=!0,Hn||(Hn=!0,_n());else{var G=E(N);G!==null&&wn(vn,G.startTime-L)}}var Hn=!1,P=-1,mn=5,$n=-1;function u1(){return q?!0:!(A.unstable_now()-$n<mn)}function i1(){if(q=!1,Hn){var L=A.unstable_now();$n=L;var G=!0;try{n:{b=!1,p&&(p=!1,In(P),P=-1),M=!0;var z=U;try{l:{for(rn(L),o=E(D);o!==null&&!(o.expirationTime>L&&u1());){var k=o.callback;if(typeof k=="function"){o.callback=null,U=o.priorityLevel;var nn=k(o.expirationTime<=L);if(L=A.unstable_now(),typeof nn=="function"){o.callback=nn,rn(L),G=!0;break l}o===E(D)&&i(D),rn(L)}else i(D);o=E(D)}if(o!==null)G=!0;else{var Y=E(N);Y!==null&&wn(vn,Y.startTime-L),G=!1}}break n}finally{o=null,U=z,M=!1}G=void 0}}finally{G?_n():Hn=!1}}}var _n;if(typeof Cn=="function")_n=function(){Cn(i1)};else if(typeof MessageChannel<"u"){var Y1=new MessageChannel,s1=Y1.port2;Y1.port1.onmessage=i1,_n=function(){s1.postMessage(null)}}else _n=function(){w(i1,0)};function wn(L,G){P=w(function(){L(A.unstable_now())},G)}A.unstable_IdlePriority=5,A.unstable_ImmediatePriority=1,A.unstable_LowPriority=4,A.unstable_NormalPriority=3,A.unstable_Profiling=null,A.unstable_UserBlockingPriority=2,A.unstable_cancelCallback=function(L){L.callback=null},A.unstable_forceFrameRate=function(L){0>L||125<L?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):mn=0<L?Math.floor(1e3/L):5},A.unstable_getCurrentPriorityLevel=function(){return U},A.unstable_next=function(L){switch(U){case 1:case 2:case 3:var G=3;break;default:G=U}var z=U;U=G;try{return L()}finally{U=z}},A.unstable_requestPaint=function(){q=!0},A.unstable_runWithPriority=function(L,G){switch(L){case 1:case 2:case 3:case 4:case 5:break;default:L=3}var z=U;U=L;try{return G()}finally{U=z}},A.unstable_scheduleCallback=function(L,G,z){var k=A.unstable_now();switch(typeof z=="object"&&z!==null?(z=z.delay,z=typeof z=="number"&&0<z?k+z:k):z=k,L){case 1:var nn=-1;break;case 2:nn=250;break;case 5:nn=1073741823;break;case 4:nn=1e4;break;default:nn=5e3}return nn=z+nn,L={id:C++,callback:G,priorityLevel:L,startTime:z,expirationTime:nn,sortIndex:-1},z>k?(L.sortIndex=z,O(N,L),E(D)===null&&L===E(N)&&(p?(In(P),P=-1):p=!0,wn(vn,z-k))):(L.sortIndex=nn,O(D,L),b||M||(b=!0,Hn||(Hn=!0,_n()))),L},A.unstable_shouldYield=u1,A.unstable_wrapCallback=function(L){var G=U;return function(){var z=U;U=G;try{return L.apply(this,arguments)}finally{U=z}}}})(ou)),ou}var gf;function BO(){return gf||(gf=1,Xu.exports=dO()),Xu.exports}var Iu={exports:{}},qn={};var zf;function LO(){if(zf)return qn;zf=1;var A=Bu();function O(D){var N="https://react.dev/errors/"+D;if(1<arguments.length){N+="?args[]="+encodeURIComponent(arguments[1]);for(var C=2;C<arguments.length;C++)N+="&args[]="+encodeURIComponent(arguments[C])}return"Minified React error #"+D+"; visit "+N+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function E(){}var i={d:{f:E,r:function(){throw Error(O(522))},D:E,C:E,L:E,m:E,X:E,S:E,M:E},p:0,findDOMNode:null},S=Symbol.for("react.portal");function c(D,N,C){var o=3<arguments.length&&arguments[3]!==void 0?arguments[3]:null;return{$$typeof:S,key:o==null?null:""+o,children:D,containerInfo:N,implementation:C}}var I=A.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;function r(D,N){if(D==="font")return"";if(typeof N=="string")return N==="use-credentials"?N:""}return qn.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=i,qn.createPortal=function(D,N){var C=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null;if(!N||N.nodeType!==1&&N.nodeType!==9&&N.nodeType!==11)throw Error(O(299));return c(D,N,null,C)},qn.flushSync=function(D){var N=I.T,C=i.p;try{if(I.T=null,i.p=2,D)return D()}finally{I.T=N,i.p=C,i.d.f()}},qn.preconnect=function(D,N){typeof D=="string"&&(N?(N=N.crossOrigin,N=typeof N=="string"?N==="use-credentials"?N:"":void 0):N=null,i.d.C(D,N))},qn.prefetchDNS=function(D){typeof D=="string"&&i.d.D(D)},qn.preinit=function(D,N){if(typeof D=="string"&&N&&typeof N.as=="string"){var C=N.as,o=r(C,N.crossOrigin),U=typeof N.integrity=="string"?N.integrity:void 0,M=typeof N.fetchPriority=="string"?N.fetchPriority:void 0;C==="style"?i.d.S(D,typeof N.precedence=="string"?N.precedence:void 0,{crossOrigin:o,integrity:U,fetchPriority:M}):C==="script"&&i.d.X(D,{crossOrigin:o,integrity:U,fetchPriority:M,nonce:typeof N.nonce=="string"?N.nonce:void 0})}},qn.preinitModule=function(D,N){if(typeof D=="string")if(typeof N=="object"&&N!==null){if(N.as==null||N.as==="script"){var C=r(N.as,N.crossOrigin);i.d.M(D,{crossOrigin:C,integrity:typeof N.integrity=="string"?N.integrity:void 0,nonce:typeof N.nonce=="string"?N.nonce:void 0})}}else N==null&&i.d.M(D)},qn.preload=function(D,N){if(typeof D=="string"&&typeof N=="object"&&N!==null&&typeof N.as=="string"){var C=N.as,o=r(C,N.crossOrigin);i.d.L(D,C,{crossOrigin:o,integrity:typeof N.integrity=="string"?N.integrity:void 0,nonce:typeof N.nonce=="string"?N.nonce:void 0,type:typeof N.type=="string"?N.type:void 0,fetchPriority:typeof N.fetchPriority=="string"?N.fetchPriority:void 0,referrerPolicy:typeof N.referrerPolicy=="string"?N.referrerPolicy:void 0,imageSrcSet:typeof N.imageSrcSet=="string"?N.imageSrcSet:void 0,imageSizes:typeof N.imageSizes=="string"?N.imageSizes:void 0,media:typeof N.media=="string"?N.media:void 0})}},qn.preloadModule=function(D,N){if(typeof D=="string")if(N){var C=r(N.as,N.crossOrigin);i.d.m(D,{as:typeof N.as=="string"&&N.as!=="script"?N.as:void 0,crossOrigin:C,integrity:typeof N.integrity=="string"?N.integrity:void 0})}else i.d.m(D)},qn.requestFormReset=function(D){i.d.r(D)},qn.unstable_batchedUpdates=function(D,N){return D(N)},qn.useFormState=function(D,N,C){return I.H.useFormState(D,N,C)},qn.useFormStatus=function(){return I.H.useHostTransitionStatus()},qn.version="19.2.6",qn}var _f;function vO(){if(_f)return Iu.exports;_f=1;function A(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(A)}catch(O){console.error(O)}}return A(),Iu.exports=LO(),Iu.exports}var Kf;function mO(){if(Kf)return Ba;Kf=1;var A=BO(),O=Bu(),E=vO();function i(n){var l="https://react.dev/errors/"+n;if(1<arguments.length){l+="?args[]="+encodeURIComponent(arguments[1]);for(var t=2;t<arguments.length;t++)l+="&args[]="+encodeURIComponent(arguments[t])}return"Minified React error #"+n+"; visit "+l+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function S(n){return!(!n||n.nodeType!==1&&n.nodeType!==9&&n.nodeType!==11)}function c(n){var l=n,t=n;if(n.alternate)for(;l.return;)l=l.return;else{n=l;do l=n,(l.flags&4098)!==0&&(t=l.return),n=l.return;while(n)}return l.tag===3?t:null}function I(n){if(n.tag===13){var l=n.memoizedState;if(l===null&&(n=n.alternate,n!==null&&(l=n.memoizedState)),l!==null)return l.dehydrated}return null}function r(n){if(n.tag===31){var l=n.memoizedState;if(l===null&&(n=n.alternate,n!==null&&(l=n.memoizedState)),l!==null)return l.dehydrated}return null}function D(n){if(c(n)!==n)throw Error(i(188))}function N(n){var l=n.alternate;if(!l){if(l=c(n),l===null)throw Error(i(188));return l!==n?null:n}for(var t=n,a=l;;){var e=t.return;if(e===null)break;var T=e.alternate;if(T===null){if(a=e.return,a!==null){t=a;continue}break}if(e.child===T.child){for(T=e.child;T;){if(T===t)return D(e),n;if(T===a)return D(e),l;T=T.sibling}throw Error(i(188))}if(t.return!==a.return)t=e,a=T;else{for(var u=!1,f=e.child;f;){if(f===t){u=!0,t=e,a=T;break}if(f===a){u=!0,a=e,t=T;break}f=f.sibling}if(!u){for(f=T.child;f;){if(f===t){u=!0,t=T,a=e;break}if(f===a){u=!0,a=T,t=e;break}f=f.sibling}if(!u)throw Error(i(189))}}if(t.alternate!==a)throw Error(i(190))}if(t.tag!==3)throw Error(i(188));return t.stateNode.current===t?n:l}function C(n){var l=n.tag;if(l===5||l===26||l===27||l===6)return n;for(n=n.child;n!==null;){if(l=C(n),l!==null)return l;n=n.sibling}return null}var o=Object.assign,U=Symbol.for("react.element"),M=Symbol.for("react.transitional.element"),b=Symbol.for("react.portal"),p=Symbol.for("react.fragment"),q=Symbol.for("react.strict_mode"),w=Symbol.for("react.profiler"),In=Symbol.for("react.consumer"),Cn=Symbol.for("react.context"),rn=Symbol.for("react.forward_ref"),vn=Symbol.for("react.suspense"),Hn=Symbol.for("react.suspense_list"),P=Symbol.for("react.memo"),mn=Symbol.for("react.lazy"),$n=Symbol.for("react.activity"),u1=Symbol.for("react.memo_cache_sentinel"),i1=Symbol.iterator;function _n(n){return n===null||typeof n!="object"?null:(n=i1&&n[i1]||n["@@iterator"],typeof n=="function"?n:null)}var Y1=Symbol.for("react.client.reference");function s1(n){if(n==null)return null;if(typeof n=="function")return n.$$typeof===Y1?null:n.displayName||n.name||null;if(typeof n=="string")return n;switch(n){case p:return"Fragment";case w:return"Profiler";case q:return"StrictMode";case vn:return"Suspense";case Hn:return"SuspenseList";case $n:return"Activity"}if(typeof n=="object")switch(n.$$typeof){case b:return"Portal";case Cn:return n.displayName||"Context";case In:return(n._context.displayName||"Context")+".Consumer";case rn:var l=n.render;return n=n.displayName,n||(n=l.displayName||l.name||"",n=n!==""?"ForwardRef("+n+")":"ForwardRef"),n;case P:return l=n.displayName||null,l!==null?l:s1(n.type)||"Memo";case mn:l=n._payload,n=n._init;try{return s1(n(l))}catch{}}return null}var wn=Array.isArray,L=O.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,G=E.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,z={pending:!1,data:null,method:null,action:null},k=[],nn=-1;function Y(n){return{current:n}}function v(n){0>nn||(n.current=k[nn],k[nn]=null,nn--)}function g(n,l){nn++,k[nn]=n.current,n.current=l}var K=Y(null),$=Y(null),ln=Y(null),En=Y(null);function jn(n,l){switch(g(ln,l),g($,n),g(K,null),l.nodeType){case 9:case 11:n=(n=l.documentElement)&&(n=n.namespaceURI)?lf(n):0;break;default:if(n=l.tagName,l=l.namespaceURI)l=lf(l),n=tf(l,n);else switch(n){case"svg":n=1;break;case"math":n=2;break;default:n=0}}v(K),g(K,n)}function dn(){v(K),v($),v(ln)}function Ut(n){n.memoizedState!==null&&g(En,n);var l=K.current,t=tf(l,n.type);l!==t&&(g($,n),g(K,t))}function Fa(n){$.current===n&&(v(K),v($)),En.current===n&&(v(En),ra._currentValue=z)}var k0,mu;function vl(n){if(k0===void 0)try{throw Error()}catch(t){var l=t.stack.trim().match(/\n( *(at )?)/);k0=l&&l[1]||"",mu=-1<t.stack.indexOf(`
    at`)?" (<anonymous>)":-1<t.stack.indexOf("@")?"@unknown:0:0":""}return`
`+k0+n+mu}var ne=!1;function le(n,l){if(!n||ne)return"";ne=!0;var t=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{var a={DetermineComponentFrameRoot:function(){try{if(l){var F=function(){throw Error()};if(Object.defineProperty(F.prototype,"props",{set:function(){throw Error()}}),typeof Reflect=="object"&&Reflect.construct){try{Reflect.construct(F,[])}catch(d){var h=d}Reflect.construct(n,[],F)}else{try{F.call()}catch(d){h=d}n.call(F.prototype)}}else{try{throw Error()}catch(d){h=d}(F=n())&&typeof F.catch=="function"&&F.catch(function(){})}}catch(d){if(d&&h&&typeof d.stack=="string")return[d.stack,h.stack]}return[null,null]}};a.DetermineComponentFrameRoot.displayName="DetermineComponentFrameRoot";var e=Object.getOwnPropertyDescriptor(a.DetermineComponentFrameRoot,"name");e&&e.configurable&&Object.defineProperty(a.DetermineComponentFrameRoot,"name",{value:"DetermineComponentFrameRoot"});var T=a.DetermineComponentFrameRoot(),u=T[0],f=T[1];if(u&&f){var R=u.split(`
`),y=f.split(`
`);for(e=a=0;a<R.length&&!R[a].includes("DetermineComponentFrameRoot");)a++;for(;e<y.length&&!y[e].includes("DetermineComponentFrameRoot");)e++;if(a===R.length||e===y.length)for(a=R.length-1,e=y.length-1;1<=a&&0<=e&&R[a]!==y[e];)e--;for(;1<=a&&0<=e;a--,e--)if(R[a]!==y[e]){if(a!==1||e!==1)do if(a--,e--,0>e||R[a]!==y[e]){var B=`
`+R[a].replace(" at new "," at ");return n.displayName&&B.includes("<anonymous>")&&(B=B.replace("<anonymous>",n.displayName)),B}while(1<=a&&0<=e);break}}}finally{ne=!1,Error.prepareStackTrace=t}return(t=n?n.displayName||n.name:"")?vl(t):""}function kf(n,l){switch(n.tag){case 26:case 27:case 5:return vl(n.type);case 16:return vl("Lazy");case 13:return n.child!==l&&l!==null?vl("Suspense Fallback"):vl("Suspense");case 19:return vl("SuspenseList");case 0:case 15:return le(n.type,!1);case 11:return le(n.type.render,!1);case 1:return le(n.type,!0);case 31:return vl("Activity");default:return""}}function Fu(n){try{var l="",t=null;do l+=kf(n,t),t=n,n=n.return;while(n);return l}catch(a){return`
Error generating stack: `+a.message+`
`+a.stack}}var te=Object.prototype.hasOwnProperty,ae=A.unstable_scheduleCallback,ee=A.unstable_cancelCallback,nN=A.unstable_shouldYield,lN=A.unstable_requestPaint,c1=A.unstable_now,tN=A.unstable_getCurrentPriorityLevel,Mu=A.unstable_ImmediatePriority,Uu=A.unstable_UserBlockingPriority,Ma=A.unstable_NormalPriority,aN=A.unstable_LowPriority,Gu=A.unstable_IdlePriority,eN=A.log,TN=A.unstable_setDisableYieldValue,Gt=null,f1=null;function al(n){if(typeof eN=="function"&&TN(n),f1&&typeof f1.setStrictMode=="function")try{f1.setStrictMode(Gt,n)}catch{}}var N1=Math.clz32?Math.clz32:cN,uN=Math.log,iN=Math.LN2;function cN(n){return n>>>=0,n===0?32:31-(uN(n)/iN|0)|0}var Ua=256,Ga=262144,ba=4194304;function ml(n){var l=n&42;if(l!==0)return l;switch(n&-n){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:return 64;case 128:return 128;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:return n&261888;case 262144:case 524288:case 1048576:case 2097152:return n&3932160;case 4194304:case 8388608:case 16777216:case 33554432:return n&62914560;case 67108864:return 67108864;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 0;default:return n}}function pa(n,l,t){var a=n.pendingLanes;if(a===0)return 0;var e=0,T=n.suspendedLanes,u=n.pingedLanes;n=n.warmLanes;var f=a&134217727;return f!==0?(a=f&~T,a!==0?e=ml(a):(u&=f,u!==0?e=ml(u):t||(t=f&~n,t!==0&&(e=ml(t))))):(f=a&~T,f!==0?e=ml(f):u!==0?e=ml(u):t||(t=a&~n,t!==0&&(e=ml(t)))),e===0?0:l!==0&&l!==e&&(l&T)===0&&(T=e&-e,t=l&-l,T>=t||T===32&&(t&4194048)!==0)?l:e}function bt(n,l){return(n.pendingLanes&~(n.suspendedLanes&~n.pingedLanes)&l)===0}function fN(n,l){switch(n){case 1:case 2:case 4:case 8:case 64:return l+250;case 16:case 32:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return l+5e3;case 4194304:case 8388608:case 16777216:case 33554432:return-1;case 67108864:case 134217728:case 268435456:case 536870912:case 1073741824:return-1;default:return-1}}function bu(){var n=ba;return ba<<=1,(ba&62914560)===0&&(ba=4194304),n}function Te(n){for(var l=[],t=0;31>t;t++)l.push(n);return l}function pt(n,l){n.pendingLanes|=l,l!==268435456&&(n.suspendedLanes=0,n.pingedLanes=0,n.warmLanes=0)}function NN(n,l,t,a,e,T){var u=n.pendingLanes;n.pendingLanes=t,n.suspendedLanes=0,n.pingedLanes=0,n.warmLanes=0,n.expiredLanes&=t,n.entangledLanes&=t,n.errorRecoveryDisabledLanes&=t,n.shellSuspendCounter=0;var f=n.entanglements,R=n.expirationTimes,y=n.hiddenUpdates;for(t=u&~t;0<t;){var B=31-N1(t),F=1<<B;f[B]=0,R[B]=-1;var h=y[B];if(h!==null)for(y[B]=null,B=0;B<h.length;B++){var d=h[B];d!==null&&(d.lane&=-536870913)}t&=~F}a!==0&&pu(n,a,0),T!==0&&e===0&&n.tag!==0&&(n.suspendedLanes|=T&~(u&~l))}function pu(n,l,t){n.pendingLanes|=l,n.suspendedLanes&=~l;var a=31-N1(l);n.entangledLanes|=l,n.entanglements[a]=n.entanglements[a]|1073741824|t&261930}function gu(n,l){var t=n.entangledLanes|=l;for(n=n.entanglements;t;){var a=31-N1(t),e=1<<a;e&l|n[a]&l&&(n[a]|=l),t&=~e}}function zu(n,l){var t=l&-l;return t=(t&42)!==0?1:ue(t),(t&(n.suspendedLanes|l))!==0?0:t}function ue(n){switch(n){case 2:n=1;break;case 8:n=4;break;case 32:n=16;break;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:n=128;break;case 268435456:n=134217728;break;default:n=0}return n}function ie(n){return n&=-n,2<n?8<n?(n&134217727)!==0?32:268435456:8:2}function _u(){var n=G.p;return n!==0?n:(n=window.event,n===void 0?32:hf(n.type))}function Ku(n,l){var t=G.p;try{return G.p=n,l()}finally{G.p=t}}var el=Math.random().toString(36).slice(2),Kn="__reactFiber$"+el,kn="__reactProps$"+el,Jl="__reactContainer$"+el,ce="__reactEvents$"+el,EN="__reactListeners$"+el,ON="__reactHandles$"+el,Zu="__reactResources$"+el,gt="__reactMarker$"+el;function fe(n){delete n[Kn],delete n[kn],delete n[ce],delete n[EN],delete n[ON]}function Pl(n){var l=n[Kn];if(l)return l;for(var t=n.parentNode;t;){if(l=t[Jl]||t[Kn]){if(t=l.alternate,l.child!==null||t!==null&&t.child!==null)for(n=Nf(n);n!==null;){if(t=n[Kn])return t;n=Nf(n)}return l}n=t,t=n.parentNode}return null}function wl(n){if(n=n[Kn]||n[Jl]){var l=n.tag;if(l===5||l===6||l===13||l===31||l===26||l===27||l===3)return n}return null}function zt(n){var l=n.tag;if(l===5||l===26||l===27||l===6)return n.stateNode;throw Error(i(33))}function kl(n){var l=n[Zu];return l||(l=n[Zu]={hoistableStyles:new Map,hoistableScripts:new Map}),l}function gn(n){n[gt]=!0}var xu=new Set,Qu={};function Fl(n,l){nt(n,l),nt(n+"Capture",l)}function nt(n,l){for(Qu[n]=l,n=0;n<l.length;n++)xu.add(l[n])}var AN=RegExp("^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$"),Vu={},qu={};function SN(n){return te.call(qu,n)?!0:te.call(Vu,n)?!1:AN.test(n)?qu[n]=!0:(Vu[n]=!0,!1)}function ga(n,l,t){if(SN(l))if(t===null)n.removeAttribute(l);else{switch(typeof t){case"undefined":case"function":case"symbol":n.removeAttribute(l);return;case"boolean":var a=l.toLowerCase().slice(0,5);if(a!=="data-"&&a!=="aria-"){n.removeAttribute(l);return}}n.setAttribute(l,""+t)}}function za(n,l,t){if(t===null)n.removeAttribute(l);else{switch(typeof t){case"undefined":case"function":case"symbol":case"boolean":n.removeAttribute(l);return}n.setAttribute(l,""+t)}}function z1(n,l,t,a){if(a===null)n.removeAttribute(t);else{switch(typeof a){case"undefined":case"function":case"symbol":case"boolean":n.removeAttribute(t);return}n.setAttributeNS(l,t,""+a)}}function X1(n){switch(typeof n){case"bigint":case"boolean":case"number":case"string":case"undefined":return n;case"object":return n;default:return""}}function Wu(n){var l=n.type;return(n=n.nodeName)&&n.toLowerCase()==="input"&&(l==="checkbox"||l==="radio")}function DN(n,l,t){var a=Object.getOwnPropertyDescriptor(n.constructor.prototype,l);if(!n.hasOwnProperty(l)&&typeof a<"u"&&typeof a.get=="function"&&typeof a.set=="function"){var e=a.get,T=a.set;return Object.defineProperty(n,l,{configurable:!0,get:function(){return e.call(this)},set:function(u){t=""+u,T.call(this,u)}}),Object.defineProperty(n,l,{enumerable:a.enumerable}),{getValue:function(){return t},setValue:function(u){t=""+u},stopTracking:function(){n._valueTracker=null,delete n[l]}}}}function Ne(n){if(!n._valueTracker){var l=Wu(n)?"checked":"value";n._valueTracker=DN(n,l,""+n[l])}}function $u(n){if(!n)return!1;var l=n._valueTracker;if(!l)return!0;var t=l.getValue(),a="";return n&&(a=Wu(n)?n.checked?"true":"false":n.value),n=a,n!==t?(l.setValue(n),!0):!1}function _a(n){if(n=n||(typeof document<"u"?document:void 0),typeof n>"u")return null;try{return n.activeElement||n.body}catch{return n.body}}var RN=/[\n"\\]/g;function o1(n){return n.replace(RN,function(l){return"\\"+l.charCodeAt(0).toString(16)+" "})}function Ee(n,l,t,a,e,T,u,f){n.name="",u!=null&&typeof u!="function"&&typeof u!="symbol"&&typeof u!="boolean"?n.type=u:n.removeAttribute("type"),l!=null?u==="number"?(l===0&&n.value===""||n.value!=l)&&(n.value=""+X1(l)):n.value!==""+X1(l)&&(n.value=""+X1(l)):u!=="submit"&&u!=="reset"||n.removeAttribute("value"),l!=null?Oe(n,u,X1(l)):t!=null?Oe(n,u,X1(t)):a!=null&&n.removeAttribute("value"),e==null&&T!=null&&(n.defaultChecked=!!T),e!=null&&(n.checked=e&&typeof e!="function"&&typeof e!="symbol"),f!=null&&typeof f!="function"&&typeof f!="symbol"&&typeof f!="boolean"?n.name=""+X1(f):n.removeAttribute("name")}function ju(n,l,t,a,e,T,u,f){if(T!=null&&typeof T!="function"&&typeof T!="symbol"&&typeof T!="boolean"&&(n.type=T),l!=null||t!=null){if(!(T!=="submit"&&T!=="reset"||l!=null)){Ne(n);return}t=t!=null?""+X1(t):"",l=l!=null?""+X1(l):t,f||l===n.value||(n.value=l),n.defaultValue=l}a=a??e,a=typeof a!="function"&&typeof a!="symbol"&&!!a,n.checked=f?n.checked:!!a,n.defaultChecked=!!a,u!=null&&typeof u!="function"&&typeof u!="symbol"&&typeof u!="boolean"&&(n.name=u),Ne(n)}function Oe(n,l,t){l==="number"&&_a(n.ownerDocument)===n||n.defaultValue===""+t||(n.defaultValue=""+t)}function lt(n,l,t,a){if(n=n.options,l){l={};for(var e=0;e<t.length;e++)l["$"+t[e]]=!0;for(t=0;t<n.length;t++)e=l.hasOwnProperty("$"+n[t].value),n[t].selected!==e&&(n[t].selected=e),e&&a&&(n[t].defaultSelected=!0)}else{for(t=""+X1(t),l=null,e=0;e<n.length;e++){if(n[e].value===t){n[e].selected=!0,a&&(n[e].defaultSelected=!0);return}l!==null||n[e].disabled||(l=n[e])}l!==null&&(l.selected=!0)}}function Ju(n,l,t){if(l!=null&&(l=""+X1(l),l!==n.value&&(n.value=l),t==null)){n.defaultValue!==l&&(n.defaultValue=l);return}n.defaultValue=t!=null?""+X1(t):""}function Pu(n,l,t,a){if(l==null){if(a!=null){if(t!=null)throw Error(i(92));if(wn(a)){if(1<a.length)throw Error(i(93));a=a[0]}t=a}t==null&&(t=""),l=t}t=X1(l),n.defaultValue=t,a=n.textContent,a===t&&a!==""&&a!==null&&(n.value=a),Ne(n)}function tt(n,l){if(l){var t=n.firstChild;if(t&&t===n.lastChild&&t.nodeType===3){t.nodeValue=l;return}}n.textContent=l}var CN=new Set("animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp".split(" "));function wu(n,l,t){var a=l.indexOf("--")===0;t==null||typeof t=="boolean"||t===""?a?n.setProperty(l,""):l==="float"?n.cssFloat="":n[l]="":a?n.setProperty(l,t):typeof t!="number"||t===0||CN.has(l)?l==="float"?n.cssFloat=t:n[l]=(""+t).trim():n[l]=t+"px"}function ku(n,l,t){if(l!=null&&typeof l!="object")throw Error(i(62));if(n=n.style,t!=null){for(var a in t)!t.hasOwnProperty(a)||l!=null&&l.hasOwnProperty(a)||(a.indexOf("--")===0?n.setProperty(a,""):a==="float"?n.cssFloat="":n[a]="");for(var e in l)a=l[e],l.hasOwnProperty(e)&&t[e]!==a&&wu(n,e,a)}else for(var T in l)l.hasOwnProperty(T)&&wu(n,T,l[T])}function Ae(n){if(n.indexOf("-")===-1)return!1;switch(n){case"annotation-xml":case"color-profile":case"font-face":case"font-face-src":case"font-face-uri":case"font-face-format":case"font-face-name":case"missing-glyph":return!1;default:return!0}}var YN=new Map([["acceptCharset","accept-charset"],["htmlFor","for"],["httpEquiv","http-equiv"],["crossOrigin","crossorigin"],["accentHeight","accent-height"],["alignmentBaseline","alignment-baseline"],["arabicForm","arabic-form"],["baselineShift","baseline-shift"],["capHeight","cap-height"],["clipPath","clip-path"],["clipRule","clip-rule"],["colorInterpolation","color-interpolation"],["colorInterpolationFilters","color-interpolation-filters"],["colorProfile","color-profile"],["colorRendering","color-rendering"],["dominantBaseline","dominant-baseline"],["enableBackground","enable-background"],["fillOpacity","fill-opacity"],["fillRule","fill-rule"],["floodColor","flood-color"],["floodOpacity","flood-opacity"],["fontFamily","font-family"],["fontSize","font-size"],["fontSizeAdjust","font-size-adjust"],["fontStretch","font-stretch"],["fontStyle","font-style"],["fontVariant","font-variant"],["fontWeight","font-weight"],["glyphName","glyph-name"],["glyphOrientationHorizontal","glyph-orientation-horizontal"],["glyphOrientationVertical","glyph-orientation-vertical"],["horizAdvX","horiz-adv-x"],["horizOriginX","horiz-origin-x"],["imageRendering","image-rendering"],["letterSpacing","letter-spacing"],["lightingColor","lighting-color"],["markerEnd","marker-end"],["markerMid","marker-mid"],["markerStart","marker-start"],["overlinePosition","overline-position"],["overlineThickness","overline-thickness"],["paintOrder","paint-order"],["panose-1","panose-1"],["pointerEvents","pointer-events"],["renderingIntent","rendering-intent"],["shapeRendering","shape-rendering"],["stopColor","stop-color"],["stopOpacity","stop-opacity"],["strikethroughPosition","strikethrough-position"],["strikethroughThickness","strikethrough-thickness"],["strokeDasharray","stroke-dasharray"],["strokeDashoffset","stroke-dashoffset"],["strokeLinecap","stroke-linecap"],["strokeLinejoin","stroke-linejoin"],["strokeMiterlimit","stroke-miterlimit"],["strokeOpacity","stroke-opacity"],["strokeWidth","stroke-width"],["textAnchor","text-anchor"],["textDecoration","text-decoration"],["textRendering","text-rendering"],["transformOrigin","transform-origin"],["underlinePosition","underline-position"],["underlineThickness","underline-thickness"],["unicodeBidi","unicode-bidi"],["unicodeRange","unicode-range"],["unitsPerEm","units-per-em"],["vAlphabetic","v-alphabetic"],["vHanging","v-hanging"],["vIdeographic","v-ideographic"],["vMathematical","v-mathematical"],["vectorEffect","vector-effect"],["vertAdvY","vert-adv-y"],["vertOriginX","vert-origin-x"],["vertOriginY","vert-origin-y"],["wordSpacing","word-spacing"],["writingMode","writing-mode"],["xmlnsXlink","xmlns:xlink"],["xHeight","x-height"]]),sN=/^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;function Ka(n){return sN.test(""+n)?"javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')":n}function _1(){}var Se=null;function De(n){return n=n.target||n.srcElement||window,n.correspondingUseElement&&(n=n.correspondingUseElement),n.nodeType===3?n.parentNode:n}var at=null,et=null;function ni(n){var l=wl(n);if(l&&(n=l.stateNode)){var t=n[kn]||null;n:switch(n=l.stateNode,l.type){case"input":if(Ee(n,t.value,t.defaultValue,t.defaultValue,t.checked,t.defaultChecked,t.type,t.name),l=t.name,t.type==="radio"&&l!=null){for(t=n;t.parentNode;)t=t.parentNode;for(t=t.querySelectorAll('input[name="'+o1(""+l)+'"][type="radio"]'),l=0;l<t.length;l++){var a=t[l];if(a!==n&&a.form===n.form){var e=a[kn]||null;if(!e)throw Error(i(90));Ee(a,e.value,e.defaultValue,e.defaultValue,e.checked,e.defaultChecked,e.type,e.name)}}for(l=0;l<t.length;l++)a=t[l],a.form===n.form&&$u(a)}break n;case"textarea":Ju(n,t.value,t.defaultValue);break n;case"select":l=t.value,l!=null&&lt(n,!!t.multiple,l,!1)}}}var Re=!1;function li(n,l,t){if(Re)return n(l,t);Re=!0;try{var a=n(l);return a}finally{if(Re=!1,(at!==null||et!==null)&&(B0(),at&&(l=at,n=et,et=at=null,ni(l),n)))for(l=0;l<n.length;l++)ni(n[l])}}function _t(n,l){var t=n.stateNode;if(t===null)return null;var a=t[kn]||null;if(a===null)return null;t=a[l];n:switch(l){case"onClick":case"onClickCapture":case"onDoubleClick":case"onDoubleClickCapture":case"onMouseDown":case"onMouseDownCapture":case"onMouseMove":case"onMouseMoveCapture":case"onMouseUp":case"onMouseUpCapture":case"onMouseEnter":(a=!a.disabled)||(n=n.type,a=!(n==="button"||n==="input"||n==="select"||n==="textarea")),n=!a;break n;default:n=!1}if(n)return null;if(t&&typeof t!="function")throw Error(i(231,l,typeof t));return t}var K1=!(typeof window>"u"||typeof window.document>"u"||typeof window.document.createElement>"u"),Ce=!1;if(K1)try{var Kt={};Object.defineProperty(Kt,"passive",{get:function(){Ce=!0}}),window.addEventListener("test",Kt,Kt),window.removeEventListener("test",Kt,Kt)}catch{Ce=!1}var Tl=null,Ye=null,Za=null;function ti(){if(Za)return Za;var n,l=Ye,t=l.length,a,e="value"in Tl?Tl.value:Tl.textContent,T=e.length;for(n=0;n<t&&l[n]===e[n];n++);var u=t-n;for(a=1;a<=u&&l[t-a]===e[T-a];a++);return Za=e.slice(n,1<a?1-a:void 0)}function xa(n){var l=n.keyCode;return"charCode"in n?(n=n.charCode,n===0&&l===13&&(n=13)):n=l,n===10&&(n=13),32<=n||n===13?n:0}function Qa(){return!0}function ai(){return!1}function n1(n){function l(t,a,e,T,u){this._reactName=t,this._targetInst=e,this.type=a,this.nativeEvent=T,this.target=u,this.currentTarget=null;for(var f in n)n.hasOwnProperty(f)&&(t=n[f],this[f]=t?t(T):T[f]);return this.isDefaultPrevented=(T.defaultPrevented!=null?T.defaultPrevented:T.returnValue===!1)?Qa:ai,this.isPropagationStopped=ai,this}return o(l.prototype,{preventDefault:function(){this.defaultPrevented=!0;var t=this.nativeEvent;t&&(t.preventDefault?t.preventDefault():typeof t.returnValue!="unknown"&&(t.returnValue=!1),this.isDefaultPrevented=Qa)},stopPropagation:function(){var t=this.nativeEvent;t&&(t.stopPropagation?t.stopPropagation():typeof t.cancelBubble!="unknown"&&(t.cancelBubble=!0),this.isPropagationStopped=Qa)},persist:function(){},isPersistent:Qa}),l}var Ml={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(n){return n.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},Va=n1(Ml),Zt=o({},Ml,{view:0,detail:0}),XN=n1(Zt),se,Xe,xt,qa=o({},Zt,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:Ie,button:0,buttons:0,relatedTarget:function(n){return n.relatedTarget===void 0?n.fromElement===n.srcElement?n.toElement:n.fromElement:n.relatedTarget},movementX:function(n){return"movementX"in n?n.movementX:(n!==xt&&(xt&&n.type==="mousemove"?(se=n.screenX-xt.screenX,Xe=n.screenY-xt.screenY):Xe=se=0,xt=n),se)},movementY:function(n){return"movementY"in n?n.movementY:Xe}}),ei=n1(qa),oN=o({},qa,{dataTransfer:0}),IN=n1(oN),rN=o({},Zt,{relatedTarget:0}),oe=n1(rN),HN=o({},Ml,{animationName:0,elapsedTime:0,pseudoElement:0}),yN=n1(HN),hN=o({},Ml,{clipboardData:function(n){return"clipboardData"in n?n.clipboardData:window.clipboardData}}),dN=n1(hN),BN=o({},Ml,{data:0}),Ti=n1(BN),LN={Esc:"Escape",Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},vN={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},mN={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function FN(n){var l=this.nativeEvent;return l.getModifierState?l.getModifierState(n):(n=mN[n])?!!l[n]:!1}function Ie(){return FN}var MN=o({},Zt,{key:function(n){if(n.key){var l=LN[n.key]||n.key;if(l!=="Unidentified")return l}return n.type==="keypress"?(n=xa(n),n===13?"Enter":String.fromCharCode(n)):n.type==="keydown"||n.type==="keyup"?vN[n.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:Ie,charCode:function(n){return n.type==="keypress"?xa(n):0},keyCode:function(n){return n.type==="keydown"||n.type==="keyup"?n.keyCode:0},which:function(n){return n.type==="keypress"?xa(n):n.type==="keydown"||n.type==="keyup"?n.keyCode:0}}),UN=n1(MN),GN=o({},qa,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0}),ui=n1(GN),bN=o({},Zt,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:Ie}),pN=n1(bN),gN=o({},Ml,{propertyName:0,elapsedTime:0,pseudoElement:0}),zN=n1(gN),_N=o({},qa,{deltaX:function(n){return"deltaX"in n?n.deltaX:"wheelDeltaX"in n?-n.wheelDeltaX:0},deltaY:function(n){return"deltaY"in n?n.deltaY:"wheelDeltaY"in n?-n.wheelDeltaY:"wheelDelta"in n?-n.wheelDelta:0},deltaZ:0,deltaMode:0}),KN=n1(_N),ZN=o({},Ml,{newState:0,oldState:0}),xN=n1(ZN),QN=[9,13,27,32],re=K1&&"CompositionEvent"in window,Qt=null;K1&&"documentMode"in document&&(Qt=document.documentMode);var VN=K1&&"TextEvent"in window&&!Qt,ii=K1&&(!re||Qt&&8<Qt&&11>=Qt),ci=" ",fi=!1;function Ni(n,l){switch(n){case"keyup":return QN.indexOf(l.keyCode)!==-1;case"keydown":return l.keyCode!==229;case"keypress":case"mousedown":case"focusout":return!0;default:return!1}}function Ei(n){return n=n.detail,typeof n=="object"&&"data"in n?n.data:null}var Tt=!1;function qN(n,l){switch(n){case"compositionend":return Ei(l);case"keypress":return l.which!==32?null:(fi=!0,ci);case"textInput":return n=l.data,n===ci&&fi?null:n;default:return null}}function WN(n,l){if(Tt)return n==="compositionend"||!re&&Ni(n,l)?(n=ti(),Za=Ye=Tl=null,Tt=!1,n):null;switch(n){case"paste":return null;case"keypress":if(!(l.ctrlKey||l.altKey||l.metaKey)||l.ctrlKey&&l.altKey){if(l.char&&1<l.char.length)return l.char;if(l.which)return String.fromCharCode(l.which)}return null;case"compositionend":return ii&&l.locale!=="ko"?null:l.data;default:return null}}var $N={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function Oi(n){var l=n&&n.nodeName&&n.nodeName.toLowerCase();return l==="input"?!!$N[n.type]:l==="textarea"}function Ai(n,l,t,a){at?et?et.push(a):et=[a]:at=a,l=G0(l,"onChange"),0<l.length&&(t=new Va("onChange","change",null,t,a),n.push({event:t,listeners:l}))}var Vt=null,qt=null;function jN(n){jc(n,0)}function Wa(n){var l=zt(n);if($u(l))return n}function Si(n,l){if(n==="change")return l}var Di=!1;if(K1){var He;if(K1){var ye="oninput"in document;if(!ye){var Ri=document.createElement("div");Ri.setAttribute("oninput","return;"),ye=typeof Ri.oninput=="function"}He=ye}else He=!1;Di=He&&(!document.documentMode||9<document.documentMode)}function Ci(){Vt&&(Vt.detachEvent("onpropertychange",Yi),qt=Vt=null)}function Yi(n){if(n.propertyName==="value"&&Wa(qt)){var l=[];Ai(l,qt,n,De(n)),li(jN,l)}}function JN(n,l,t){n==="focusin"?(Ci(),Vt=l,qt=t,Vt.attachEvent("onpropertychange",Yi)):n==="focusout"&&Ci()}function PN(n){if(n==="selectionchange"||n==="keyup"||n==="keydown")return Wa(qt)}function wN(n,l){if(n==="click")return Wa(l)}function kN(n,l){if(n==="input"||n==="change")return Wa(l)}function nE(n,l){return n===l&&(n!==0||1/n===1/l)||n!==n&&l!==l}var E1=typeof Object.is=="function"?Object.is:nE;function Wt(n,l){if(E1(n,l))return!0;if(typeof n!="object"||n===null||typeof l!="object"||l===null)return!1;var t=Object.keys(n),a=Object.keys(l);if(t.length!==a.length)return!1;for(a=0;a<t.length;a++){var e=t[a];if(!te.call(l,e)||!E1(n[e],l[e]))return!1}return!0}function si(n){for(;n&&n.firstChild;)n=n.firstChild;return n}function Xi(n,l){var t=si(n);n=0;for(var a;t;){if(t.nodeType===3){if(a=n+t.textContent.length,n<=l&&a>=l)return{node:t,offset:l-n};n=a}n:{for(;t;){if(t.nextSibling){t=t.nextSibling;break n}t=t.parentNode}t=void 0}t=si(t)}}function oi(n,l){return n&&l?n===l?!0:n&&n.nodeType===3?!1:l&&l.nodeType===3?oi(n,l.parentNode):"contains"in n?n.contains(l):n.compareDocumentPosition?!!(n.compareDocumentPosition(l)&16):!1:!1}function Ii(n){n=n!=null&&n.ownerDocument!=null&&n.ownerDocument.defaultView!=null?n.ownerDocument.defaultView:window;for(var l=_a(n.document);l instanceof n.HTMLIFrameElement;){try{var t=typeof l.contentWindow.location.href=="string"}catch{t=!1}if(t)n=l.contentWindow;else break;l=_a(n.document)}return l}function he(n){var l=n&&n.nodeName&&n.nodeName.toLowerCase();return l&&(l==="input"&&(n.type==="text"||n.type==="search"||n.type==="tel"||n.type==="url"||n.type==="password")||l==="textarea"||n.contentEditable==="true")}var lE=K1&&"documentMode"in document&&11>=document.documentMode,ut=null,de=null,$t=null,Be=!1;function ri(n,l,t){var a=t.window===t?t.document:t.nodeType===9?t:t.ownerDocument;Be||ut==null||ut!==_a(a)||(a=ut,"selectionStart"in a&&he(a)?a={start:a.selectionStart,end:a.selectionEnd}:(a=(a.ownerDocument&&a.ownerDocument.defaultView||window).getSelection(),a={anchorNode:a.anchorNode,anchorOffset:a.anchorOffset,focusNode:a.focusNode,focusOffset:a.focusOffset}),$t&&Wt($t,a)||($t=a,a=G0(de,"onSelect"),0<a.length&&(l=new Va("onSelect","select",null,l,t),n.push({event:l,listeners:a}),l.target=ut)))}function Ul(n,l){var t={};return t[n.toLowerCase()]=l.toLowerCase(),t["Webkit"+n]="webkit"+l,t["Moz"+n]="moz"+l,t}var it={animationend:Ul("Animation","AnimationEnd"),animationiteration:Ul("Animation","AnimationIteration"),animationstart:Ul("Animation","AnimationStart"),transitionrun:Ul("Transition","TransitionRun"),transitionstart:Ul("Transition","TransitionStart"),transitioncancel:Ul("Transition","TransitionCancel"),transitionend:Ul("Transition","TransitionEnd")},Le={},Hi={};K1&&(Hi=document.createElement("div").style,"AnimationEvent"in window||(delete it.animationend.animation,delete it.animationiteration.animation,delete it.animationstart.animation),"TransitionEvent"in window||delete it.transitionend.transition);function Gl(n){if(Le[n])return Le[n];if(!it[n])return n;var l=it[n],t;for(t in l)if(l.hasOwnProperty(t)&&t in Hi)return Le[n]=l[t];return n}var yi=Gl("animationend"),hi=Gl("animationiteration"),di=Gl("animationstart"),tE=Gl("transitionrun"),aE=Gl("transitionstart"),eE=Gl("transitioncancel"),Bi=Gl("transitionend"),Li=new Map,ve="abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");ve.push("scrollEnd");function v1(n,l){Li.set(n,l),Fl(l,[n])}var $a=typeof reportError=="function"?reportError:function(n){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var l=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof n=="object"&&n!==null&&typeof n.message=="string"?String(n.message):String(n),error:n});if(!window.dispatchEvent(l))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",n);return}console.error(n)},I1=[],ct=0,me=0;function ja(){for(var n=ct,l=me=ct=0;l<n;){var t=I1[l];I1[l++]=null;var a=I1[l];I1[l++]=null;var e=I1[l];I1[l++]=null;var T=I1[l];if(I1[l++]=null,a!==null&&e!==null){var u=a.pending;u===null?e.next=e:(e.next=u.next,u.next=e),a.pending=e}T!==0&&vi(t,e,T)}}function Ja(n,l,t,a){I1[ct++]=n,I1[ct++]=l,I1[ct++]=t,I1[ct++]=a,me|=a,n.lanes|=a,n=n.alternate,n!==null&&(n.lanes|=a)}function Fe(n,l,t,a){return Ja(n,l,t,a),Pa(n)}function bl(n,l){return Ja(n,null,null,l),Pa(n)}function vi(n,l,t){n.lanes|=t;var a=n.alternate;a!==null&&(a.lanes|=t);for(var e=!1,T=n.return;T!==null;)T.childLanes|=t,a=T.alternate,a!==null&&(a.childLanes|=t),T.tag===22&&(n=T.stateNode,n===null||n._visibility&1||(e=!0)),n=T,T=T.return;return n.tag===3?(T=n.stateNode,e&&l!==null&&(e=31-N1(t),n=T.hiddenUpdates,a=n[e],a===null?n[e]=[l]:a.push(l),l.lane=t|536870912),T):null}function Pa(n){if(50<Ra)throw Ra=0,KT=null,Error(i(185));for(var l=n.return;l!==null;)n=l,l=n.return;return n.tag===3?n.stateNode:null}var ft={};function TE(n,l,t,a){this.tag=n,this.key=t,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.refCleanup=this.ref=null,this.pendingProps=l,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=a,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function O1(n,l,t,a){return new TE(n,l,t,a)}function Me(n){return n=n.prototype,!(!n||!n.isReactComponent)}function Z1(n,l){var t=n.alternate;return t===null?(t=O1(n.tag,l,n.key,n.mode),t.elementType=n.elementType,t.type=n.type,t.stateNode=n.stateNode,t.alternate=n,n.alternate=t):(t.pendingProps=l,t.type=n.type,t.flags=0,t.subtreeFlags=0,t.deletions=null),t.flags=n.flags&65011712,t.childLanes=n.childLanes,t.lanes=n.lanes,t.child=n.child,t.memoizedProps=n.memoizedProps,t.memoizedState=n.memoizedState,t.updateQueue=n.updateQueue,l=n.dependencies,t.dependencies=l===null?null:{lanes:l.lanes,firstContext:l.firstContext},t.sibling=n.sibling,t.index=n.index,t.ref=n.ref,t.refCleanup=n.refCleanup,t}function mi(n,l){n.flags&=65011714;var t=n.alternate;return t===null?(n.childLanes=0,n.lanes=l,n.child=null,n.subtreeFlags=0,n.memoizedProps=null,n.memoizedState=null,n.updateQueue=null,n.dependencies=null,n.stateNode=null):(n.childLanes=t.childLanes,n.lanes=t.lanes,n.child=t.child,n.subtreeFlags=0,n.deletions=null,n.memoizedProps=t.memoizedProps,n.memoizedState=t.memoizedState,n.updateQueue=t.updateQueue,n.type=t.type,l=t.dependencies,n.dependencies=l===null?null:{lanes:l.lanes,firstContext:l.firstContext}),n}function wa(n,l,t,a,e,T){var u=0;if(a=n,typeof n=="function")Me(n)&&(u=1);else if(typeof n=="string")u=NO(n,t,K.current)?26:n==="html"||n==="head"||n==="body"?27:5;else n:switch(n){case $n:return n=O1(31,t,l,e),n.elementType=$n,n.lanes=T,n;case p:return pl(t.children,e,T,l);case q:u=8,e|=24;break;case w:return n=O1(12,t,l,e|2),n.elementType=w,n.lanes=T,n;case vn:return n=O1(13,t,l,e),n.elementType=vn,n.lanes=T,n;case Hn:return n=O1(19,t,l,e),n.elementType=Hn,n.lanes=T,n;default:if(typeof n=="object"&&n!==null)switch(n.$$typeof){case Cn:u=10;break n;case In:u=9;break n;case rn:u=11;break n;case P:u=14;break n;case mn:u=16,a=null;break n}u=29,t=Error(i(130,n===null?"null":typeof n,"")),a=null}return l=O1(u,t,l,e),l.elementType=n,l.type=a,l.lanes=T,l}function pl(n,l,t,a){return n=O1(7,n,a,l),n.lanes=t,n}function Ue(n,l,t){return n=O1(6,n,null,l),n.lanes=t,n}function Fi(n){var l=O1(18,null,null,0);return l.stateNode=n,l}function Ge(n,l,t){return l=O1(4,n.children!==null?n.children:[],n.key,l),l.lanes=t,l.stateNode={containerInfo:n.containerInfo,pendingChildren:null,implementation:n.implementation},l}var Mi=new WeakMap;function r1(n,l){if(typeof n=="object"&&n!==null){var t=Mi.get(n);return t!==void 0?t:(l={value:n,source:l,stack:Fu(l)},Mi.set(n,l),l)}return{value:n,source:l,stack:Fu(l)}}var Nt=[],Et=0,ka=null,jt=0,H1=[],y1=0,ul=null,U1=1,G1="";function x1(n,l){Nt[Et++]=jt,Nt[Et++]=ka,ka=n,jt=l}function Ui(n,l,t){H1[y1++]=U1,H1[y1++]=G1,H1[y1++]=ul,ul=n;var a=U1;n=G1;var e=32-N1(a)-1;a&=~(1<<e),t+=1;var T=32-N1(l)+e;if(30<T){var u=e-e%5;T=(a&(1<<u)-1).toString(32),a>>=u,e-=u,U1=1<<32-N1(l)+e|t<<e|a,G1=T+n}else U1=1<<T|t<<e|a,G1=n}function be(n){n.return!==null&&(x1(n,1),Ui(n,1,0))}function pe(n){for(;n===ka;)ka=Nt[--Et],Nt[Et]=null,jt=Nt[--Et],Nt[Et]=null;for(;n===ul;)ul=H1[--y1],H1[y1]=null,G1=H1[--y1],H1[y1]=null,U1=H1[--y1],H1[y1]=null}function Gi(n,l){H1[y1++]=U1,H1[y1++]=G1,H1[y1++]=ul,U1=l.id,G1=l.overflow,ul=n}var Zn=null,sn=null,un=!1,il=null,h1=!1,ge=Error(i(519));function cl(n){var l=Error(i(418,1<arguments.length&&arguments[1]!==void 0&&arguments[1]?"text":"HTML",""));throw Jt(r1(l,n)),ge}function bi(n){var l=n.stateNode,t=n.type,a=n.memoizedProps;switch(l[Kn]=n,l[kn]=a,t){case"dialog":an("cancel",l),an("close",l);break;case"iframe":case"object":case"embed":an("load",l);break;case"video":case"audio":for(t=0;t<Ya.length;t++)an(Ya[t],l);break;case"source":an("error",l);break;case"img":case"image":case"link":an("error",l),an("load",l);break;case"details":an("toggle",l);break;case"input":an("invalid",l),ju(l,a.value,a.defaultValue,a.checked,a.defaultChecked,a.type,a.name,!0);break;case"select":an("invalid",l);break;case"textarea":an("invalid",l),Pu(l,a.value,a.defaultValue,a.children)}t=a.children,typeof t!="string"&&typeof t!="number"&&typeof t!="bigint"||l.textContent===""+t||a.suppressHydrationWarning===!0||kc(l.textContent,t)?(a.popover!=null&&(an("beforetoggle",l),an("toggle",l)),a.onScroll!=null&&an("scroll",l),a.onScrollEnd!=null&&an("scrollend",l),a.onClick!=null&&(l.onclick=_1),l=!0):l=!1,l||cl(n,!0)}function pi(n){for(Zn=n.return;Zn;)switch(Zn.tag){case 5:case 31:case 13:h1=!1;return;case 27:case 3:h1=!0;return;default:Zn=Zn.return}}function Ot(n){if(n!==Zn)return!1;if(!un)return pi(n),un=!0,!1;var l=n.tag,t;if((t=l!==3&&l!==27)&&((t=l===5)&&(t=n.type,t=!(t!=="form"&&t!=="button")||tu(n.type,n.memoizedProps)),t=!t),t&&sn&&cl(n),pi(n),l===13){if(n=n.memoizedState,n=n!==null?n.dehydrated:null,!n)throw Error(i(317));sn=ff(n)}else if(l===31){if(n=n.memoizedState,n=n!==null?n.dehydrated:null,!n)throw Error(i(317));sn=ff(n)}else l===27?(l=sn,Il(n.type)?(n=iu,iu=null,sn=n):sn=l):sn=Zn?B1(n.stateNode.nextSibling):null;return!0}function gl(){sn=Zn=null,un=!1}function ze(){var n=il;return n!==null&&(e1===null?e1=n:e1.push.apply(e1,n),il=null),n}function Jt(n){il===null?il=[n]:il.push(n)}var _e=Y(null),zl=null,Q1=null;function fl(n,l,t){g(_e,l._currentValue),l._currentValue=t}function V1(n){n._currentValue=_e.current,v(_e)}function Ke(n,l,t){for(;n!==null;){var a=n.alternate;if((n.childLanes&l)!==l?(n.childLanes|=l,a!==null&&(a.childLanes|=l)):a!==null&&(a.childLanes&l)!==l&&(a.childLanes|=l),n===t)break;n=n.return}}function Ze(n,l,t,a){var e=n.child;for(e!==null&&(e.return=n);e!==null;){var T=e.dependencies;if(T!==null){var u=e.child;T=T.firstContext;n:for(;T!==null;){var f=T;T=e;for(var R=0;R<l.length;R++)if(f.context===l[R]){T.lanes|=t,f=T.alternate,f!==null&&(f.lanes|=t),Ke(T.return,t,n),a||(u=null);break n}T=f.next}}else if(e.tag===18){if(u=e.return,u===null)throw Error(i(341));u.lanes|=t,T=u.alternate,T!==null&&(T.lanes|=t),Ke(u,t,n),u=null}else u=e.child;if(u!==null)u.return=e;else for(u=e;u!==null;){if(u===n){u=null;break}if(e=u.sibling,e!==null){e.return=u.return,u=e;break}u=u.return}e=u}}function At(n,l,t,a){n=null;for(var e=l,T=!1;e!==null;){if(!T){if((e.flags&524288)!==0)T=!0;else if((e.flags&262144)!==0)break}if(e.tag===10){var u=e.alternate;if(u===null)throw Error(i(387));if(u=u.memoizedProps,u!==null){var f=e.type;E1(e.pendingProps.value,u.value)||(n!==null?n.push(f):n=[f])}}else if(e===En.current){if(u=e.alternate,u===null)throw Error(i(387));u.memoizedState.memoizedState!==e.memoizedState.memoizedState&&(n!==null?n.push(ra):n=[ra])}e=e.return}n!==null&&Ze(l,n,t,a),l.flags|=262144}function n0(n){for(n=n.firstContext;n!==null;){if(!E1(n.context._currentValue,n.memoizedValue))return!0;n=n.next}return!1}function _l(n){zl=n,Q1=null,n=n.dependencies,n!==null&&(n.firstContext=null)}function xn(n){return gi(zl,n)}function l0(n,l){return zl===null&&_l(n),gi(n,l)}function gi(n,l){var t=l._currentValue;if(l={context:l,memoizedValue:t,next:null},Q1===null){if(n===null)throw Error(i(308));Q1=l,n.dependencies={lanes:0,firstContext:l},n.flags|=524288}else Q1=Q1.next=l;return t}var uE=typeof AbortController<"u"?AbortController:function(){var n=[],l=this.signal={aborted:!1,addEventListener:function(t,a){n.push(a)}};this.abort=function(){l.aborted=!0,n.forEach(function(t){return t()})}},iE=A.unstable_scheduleCallback,cE=A.unstable_NormalPriority,Fn={$$typeof:Cn,Consumer:null,Provider:null,_currentValue:null,_currentValue2:null,_threadCount:0};function xe(){return{controller:new uE,data:new Map,refCount:0}}function Pt(n){n.refCount--,n.refCount===0&&iE(cE,function(){n.controller.abort()})}var wt=null,Qe=0,St=0,Dt=null;function fE(n,l){if(wt===null){var t=wt=[];Qe=0,St=WT(),Dt={status:"pending",value:void 0,then:function(a){t.push(a)}}}return Qe++,l.then(zi,zi),l}function zi(){if(--Qe===0&&wt!==null){Dt!==null&&(Dt.status="fulfilled");var n=wt;wt=null,St=0,Dt=null;for(var l=0;l<n.length;l++)(0,n[l])()}}function NE(n,l){var t=[],a={status:"pending",value:null,reason:null,then:function(e){t.push(e)}};return n.then(function(){a.status="fulfilled",a.value=l;for(var e=0;e<t.length;e++)(0,t[e])(l)},function(e){for(a.status="rejected",a.reason=e,e=0;e<t.length;e++)(0,t[e])(void 0)}),a}var _i=L.S;L.S=function(n,l){rc=c1(),typeof l=="object"&&l!==null&&typeof l.then=="function"&&fE(n,l),_i!==null&&_i(n,l)};var Kl=Y(null);function Ve(){var n=Kl.current;return n!==null?n:Yn.pooledCache}function t0(n,l){l===null?g(Kl,Kl.current):g(Kl,l.pool)}function Ki(){var n=Ve();return n===null?null:{parent:Fn._currentValue,pool:n}}var Rt=Error(i(460)),qe=Error(i(474)),a0=Error(i(542)),e0={then:function(){}};function Zi(n){return n=n.status,n==="fulfilled"||n==="rejected"}function xi(n,l,t){switch(t=n[t],t===void 0?n.push(l):t!==l&&(l.then(_1,_1),l=t),l.status){case"fulfilled":return l.value;case"rejected":throw n=l.reason,Vi(n),n;default:if(typeof l.status=="string")l.then(_1,_1);else{if(n=Yn,n!==null&&100<n.shellSuspendCounter)throw Error(i(482));n=l,n.status="pending",n.then(function(a){if(l.status==="pending"){var e=l;e.status="fulfilled",e.value=a}},function(a){if(l.status==="pending"){var e=l;e.status="rejected",e.reason=a}})}switch(l.status){case"fulfilled":return l.value;case"rejected":throw n=l.reason,Vi(n),n}throw xl=l,Rt}}function Zl(n){try{var l=n._init;return l(n._payload)}catch(t){throw t!==null&&typeof t=="object"&&typeof t.then=="function"?(xl=t,Rt):t}}var xl=null;function Qi(){if(xl===null)throw Error(i(459));var n=xl;return xl=null,n}function Vi(n){if(n===Rt||n===a0)throw Error(i(483))}var Ct=null,kt=0;function T0(n){var l=kt;return kt+=1,Ct===null&&(Ct=[]),xi(Ct,n,l)}function na(n,l){l=l.props.ref,n.ref=l!==void 0?l:null}function u0(n,l){throw l.$$typeof===U?Error(i(525)):(n=Object.prototype.toString.call(l),Error(i(31,n==="[object Object]"?"object with keys {"+Object.keys(l).join(", ")+"}":n)))}function qi(n){function l(X,s){if(n){var H=X.deletions;H===null?(X.deletions=[s],X.flags|=16):H.push(s)}}function t(X,s){if(!n)return null;for(;s!==null;)l(X,s),s=s.sibling;return null}function a(X){for(var s=new Map;X!==null;)X.key!==null?s.set(X.key,X):s.set(X.index,X),X=X.sibling;return s}function e(X,s){return X=Z1(X,s),X.index=0,X.sibling=null,X}function T(X,s,H){return X.index=H,n?(H=X.alternate,H!==null?(H=H.index,H<s?(X.flags|=67108866,s):H):(X.flags|=67108866,s)):(X.flags|=1048576,s)}function u(X){return n&&X.alternate===null&&(X.flags|=67108866),X}function f(X,s,H,m){return s===null||s.tag!==6?(s=Ue(H,X.mode,m),s.return=X,s):(s=e(s,H),s.return=X,s)}function R(X,s,H,m){var Q=H.type;return Q===p?B(X,s,H.props.children,m,H.key):s!==null&&(s.elementType===Q||typeof Q=="object"&&Q!==null&&Q.$$typeof===mn&&Zl(Q)===s.type)?(s=e(s,H.props),na(s,H),s.return=X,s):(s=wa(H.type,H.key,H.props,null,X.mode,m),na(s,H),s.return=X,s)}function y(X,s,H,m){return s===null||s.tag!==4||s.stateNode.containerInfo!==H.containerInfo||s.stateNode.implementation!==H.implementation?(s=Ge(H,X.mode,m),s.return=X,s):(s=e(s,H.children||[]),s.return=X,s)}function B(X,s,H,m,Q){return s===null||s.tag!==7?(s=pl(H,X.mode,m,Q),s.return=X,s):(s=e(s,H),s.return=X,s)}function F(X,s,H){if(typeof s=="string"&&s!==""||typeof s=="number"||typeof s=="bigint")return s=Ue(""+s,X.mode,H),s.return=X,s;if(typeof s=="object"&&s!==null){switch(s.$$typeof){case M:return H=wa(s.type,s.key,s.props,null,X.mode,H),na(H,s),H.return=X,H;case b:return s=Ge(s,X.mode,H),s.return=X,s;case mn:return s=Zl(s),F(X,s,H)}if(wn(s)||_n(s))return s=pl(s,X.mode,H,null),s.return=X,s;if(typeof s.then=="function")return F(X,T0(s),H);if(s.$$typeof===Cn)return F(X,l0(X,s),H);u0(X,s)}return null}function h(X,s,H,m){var Q=s!==null?s.key:null;if(typeof H=="string"&&H!==""||typeof H=="number"||typeof H=="bigint")return Q!==null?null:f(X,s,""+H,m);if(typeof H=="object"&&H!==null){switch(H.$$typeof){case M:return H.key===Q?R(X,s,H,m):null;case b:return H.key===Q?y(X,s,H,m):null;case mn:return H=Zl(H),h(X,s,H,m)}if(wn(H)||_n(H))return Q!==null?null:B(X,s,H,m,null);if(typeof H.then=="function")return h(X,s,T0(H),m);if(H.$$typeof===Cn)return h(X,s,l0(X,H),m);u0(X,H)}return null}function d(X,s,H,m,Q){if(typeof m=="string"&&m!==""||typeof m=="number"||typeof m=="bigint")return X=X.get(H)||null,f(s,X,""+m,Q);if(typeof m=="object"&&m!==null){switch(m.$$typeof){case M:return X=X.get(m.key===null?H:m.key)||null,R(s,X,m,Q);case b:return X=X.get(m.key===null?H:m.key)||null,y(s,X,m,Q);case mn:return m=Zl(m),d(X,s,H,m,Q)}if(wn(m)||_n(m))return X=X.get(H)||null,B(s,X,m,Q,null);if(typeof m.then=="function")return d(X,s,H,T0(m),Q);if(m.$$typeof===Cn)return d(X,s,H,l0(s,m),Q);u0(s,m)}return null}function _(X,s,H,m){for(var Q=null,cn=null,Z=s,J=s=0,Tn=null;Z!==null&&J<H.length;J++){Z.index>J?(Tn=Z,Z=null):Tn=Z.sibling;var fn=h(X,Z,H[J],m);if(fn===null){Z===null&&(Z=Tn);break}n&&Z&&fn.alternate===null&&l(X,Z),s=T(fn,s,J),cn===null?Q=fn:cn.sibling=fn,cn=fn,Z=Tn}if(J===H.length)return t(X,Z),un&&x1(X,J),Q;if(Z===null){for(;J<H.length;J++)Z=F(X,H[J],m),Z!==null&&(s=T(Z,s,J),cn===null?Q=Z:cn.sibling=Z,cn=Z);return un&&x1(X,J),Q}for(Z=a(Z);J<H.length;J++)Tn=d(Z,X,J,H[J],m),Tn!==null&&(n&&Tn.alternate!==null&&Z.delete(Tn.key===null?J:Tn.key),s=T(Tn,s,J),cn===null?Q=Tn:cn.sibling=Tn,cn=Tn);return n&&Z.forEach(function(dl){return l(X,dl)}),un&&x1(X,J),Q}function V(X,s,H,m){if(H==null)throw Error(i(151));for(var Q=null,cn=null,Z=s,J=s=0,Tn=null,fn=H.next();Z!==null&&!fn.done;J++,fn=H.next()){Z.index>J?(Tn=Z,Z=null):Tn=Z.sibling;var dl=h(X,Z,fn.value,m);if(dl===null){Z===null&&(Z=Tn);break}n&&Z&&dl.alternate===null&&l(X,Z),s=T(dl,s,J),cn===null?Q=dl:cn.sibling=dl,cn=dl,Z=Tn}if(fn.done)return t(X,Z),un&&x1(X,J),Q;if(Z===null){for(;!fn.done;J++,fn=H.next())fn=F(X,fn.value,m),fn!==null&&(s=T(fn,s,J),cn===null?Q=fn:cn.sibling=fn,cn=fn);return un&&x1(X,J),Q}for(Z=a(Z);!fn.done;J++,fn=H.next())fn=d(Z,X,J,fn.value,m),fn!==null&&(n&&fn.alternate!==null&&Z.delete(fn.key===null?J:fn.key),s=T(fn,s,J),cn===null?Q=fn:cn.sibling=fn,cn=fn);return n&&Z.forEach(function(oO){return l(X,oO)}),un&&x1(X,J),Q}function Rn(X,s,H,m){if(typeof H=="object"&&H!==null&&H.type===p&&H.key===null&&(H=H.props.children),typeof H=="object"&&H!==null){switch(H.$$typeof){case M:n:{for(var Q=H.key;s!==null;){if(s.key===Q){if(Q=H.type,Q===p){if(s.tag===7){t(X,s.sibling),m=e(s,H.props.children),m.return=X,X=m;break n}}else if(s.elementType===Q||typeof Q=="object"&&Q!==null&&Q.$$typeof===mn&&Zl(Q)===s.type){t(X,s.sibling),m=e(s,H.props),na(m,H),m.return=X,X=m;break n}t(X,s);break}else l(X,s);s=s.sibling}H.type===p?(m=pl(H.props.children,X.mode,m,H.key),m.return=X,X=m):(m=wa(H.type,H.key,H.props,null,X.mode,m),na(m,H),m.return=X,X=m)}return u(X);case b:n:{for(Q=H.key;s!==null;){if(s.key===Q)if(s.tag===4&&s.stateNode.containerInfo===H.containerInfo&&s.stateNode.implementation===H.implementation){t(X,s.sibling),m=e(s,H.children||[]),m.return=X,X=m;break n}else{t(X,s);break}else l(X,s);s=s.sibling}m=Ge(H,X.mode,m),m.return=X,X=m}return u(X);case mn:return H=Zl(H),Rn(X,s,H,m)}if(wn(H))return _(X,s,H,m);if(_n(H)){if(Q=_n(H),typeof Q!="function")throw Error(i(150));return H=Q.call(H),V(X,s,H,m)}if(typeof H.then=="function")return Rn(X,s,T0(H),m);if(H.$$typeof===Cn)return Rn(X,s,l0(X,H),m);u0(X,H)}return typeof H=="string"&&H!==""||typeof H=="number"||typeof H=="bigint"?(H=""+H,s!==null&&s.tag===6?(t(X,s.sibling),m=e(s,H),m.return=X,X=m):(t(X,s),m=Ue(H,X.mode,m),m.return=X,X=m),u(X)):t(X,s)}return function(X,s,H,m){try{kt=0;var Q=Rn(X,s,H,m);return Ct=null,Q}catch(Z){if(Z===Rt||Z===a0)throw Z;var cn=O1(29,Z,null,X.mode);return cn.lanes=m,cn.return=X,cn}}}var Ql=qi(!0),Wi=qi(!1),Nl=!1;function We(n){n.updateQueue={baseState:n.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,lanes:0,hiddenCallbacks:null},callbacks:null}}function $e(n,l){n=n.updateQueue,l.updateQueue===n&&(l.updateQueue={baseState:n.baseState,firstBaseUpdate:n.firstBaseUpdate,lastBaseUpdate:n.lastBaseUpdate,shared:n.shared,callbacks:null})}function El(n){return{lane:n,tag:0,payload:null,callback:null,next:null}}function Ol(n,l,t){var a=n.updateQueue;if(a===null)return null;if(a=a.shared,(Nn&2)!==0){var e=a.pending;return e===null?l.next=l:(l.next=e.next,e.next=l),a.pending=l,l=Pa(n),vi(n,null,t),l}return Ja(n,a,l,t),Pa(n)}function la(n,l,t){if(l=l.updateQueue,l!==null&&(l=l.shared,(t&4194048)!==0)){var a=l.lanes;a&=n.pendingLanes,t|=a,l.lanes=t,gu(n,t)}}function je(n,l){var t=n.updateQueue,a=n.alternate;if(a!==null&&(a=a.updateQueue,t===a)){var e=null,T=null;if(t=t.firstBaseUpdate,t!==null){do{var u={lane:t.lane,tag:t.tag,payload:t.payload,callback:null,next:null};T===null?e=T=u:T=T.next=u,t=t.next}while(t!==null);T===null?e=T=l:T=T.next=l}else e=T=l;t={baseState:a.baseState,firstBaseUpdate:e,lastBaseUpdate:T,shared:a.shared,callbacks:a.callbacks},n.updateQueue=t;return}n=t.lastBaseUpdate,n===null?t.firstBaseUpdate=l:n.next=l,t.lastBaseUpdate=l}var Je=!1;function ta(){if(Je){var n=Dt;if(n!==null)throw n}}function aa(n,l,t,a){Je=!1;var e=n.updateQueue;Nl=!1;var T=e.firstBaseUpdate,u=e.lastBaseUpdate,f=e.shared.pending;if(f!==null){e.shared.pending=null;var R=f,y=R.next;R.next=null,u===null?T=y:u.next=y,u=R;var B=n.alternate;B!==null&&(B=B.updateQueue,f=B.lastBaseUpdate,f!==u&&(f===null?B.firstBaseUpdate=y:f.next=y,B.lastBaseUpdate=R))}if(T!==null){var F=e.baseState;u=0,B=y=R=null,f=T;do{var h=f.lane&-536870913,d=h!==f.lane;if(d?(en&h)===h:(a&h)===h){h!==0&&h===St&&(Je=!0),B!==null&&(B=B.next={lane:0,tag:f.tag,payload:f.payload,callback:null,next:null});n:{var _=n,V=f;h=l;var Rn=t;switch(V.tag){case 1:if(_=V.payload,typeof _=="function"){F=_.call(Rn,F,h);break n}F=_;break n;case 3:_.flags=_.flags&-65537|128;case 0:if(_=V.payload,h=typeof _=="function"?_.call(Rn,F,h):_,h==null)break n;F=o({},F,h);break n;case 2:Nl=!0}}h=f.callback,h!==null&&(n.flags|=64,d&&(n.flags|=8192),d=e.callbacks,d===null?e.callbacks=[h]:d.push(h))}else d={lane:h,tag:f.tag,payload:f.payload,callback:f.callback,next:null},B===null?(y=B=d,R=F):B=B.next=d,u|=h;if(f=f.next,f===null){if(f=e.shared.pending,f===null)break;d=f,f=d.next,d.next=null,e.lastBaseUpdate=d,e.shared.pending=null}}while(!0);B===null&&(R=F),e.baseState=R,e.firstBaseUpdate=y,e.lastBaseUpdate=B,T===null&&(e.shared.lanes=0),Cl|=u,n.lanes=u,n.memoizedState=F}}function $i(n,l){if(typeof n!="function")throw Error(i(191,n));n.call(l)}function ji(n,l){var t=n.callbacks;if(t!==null)for(n.callbacks=null,n=0;n<t.length;n++)$i(t[n],l)}var Yt=Y(null),i0=Y(0);function Ji(n,l){n=nl,g(i0,n),g(Yt,l),nl=n|l.baseLanes}function Pe(){g(i0,nl),g(Yt,Yt.current)}function we(){nl=i0.current,v(Yt),v(i0)}var A1=Y(null),d1=null;function Al(n){var l=n.alternate;g(Bn,Bn.current&1),g(A1,n),d1===null&&(l===null||Yt.current!==null||l.memoizedState!==null)&&(d1=n)}function ke(n){g(Bn,Bn.current),g(A1,n),d1===null&&(d1=n)}function Pi(n){n.tag===22?(g(Bn,Bn.current),g(A1,n),d1===null&&(d1=n)):Sl()}function Sl(){g(Bn,Bn.current),g(A1,A1.current)}function S1(n){v(A1),d1===n&&(d1=null),v(Bn)}var Bn=Y(0);function c0(n){for(var l=n;l!==null;){if(l.tag===13){var t=l.memoizedState;if(t!==null&&(t=t.dehydrated,t===null||Tu(t)||uu(t)))return l}else if(l.tag===19&&(l.memoizedProps.revealOrder==="forwards"||l.memoizedProps.revealOrder==="backwards"||l.memoizedProps.revealOrder==="unstable_legacy-backwards"||l.memoizedProps.revealOrder==="together")){if((l.flags&128)!==0)return l}else if(l.child!==null){l.child.return=l,l=l.child;continue}if(l===n)break;for(;l.sibling===null;){if(l.return===null||l.return===n)return null;l=l.return}l.sibling.return=l.return,l=l.sibling}return null}var q1=0,j=null,Sn=null,Mn=null,f0=!1,st=!1,Vl=!1,N0=0,ea=0,Xt=null,EE=0;function yn(){throw Error(i(321))}function nT(n,l){if(l===null)return!1;for(var t=0;t<l.length&&t<n.length;t++)if(!E1(n[t],l[t]))return!1;return!0}function lT(n,l,t,a,e,T){return q1=T,j=l,l.memoizedState=null,l.updateQueue=null,l.lanes=0,L.H=n===null||n.memoizedState===null?U2:RT,Vl=!1,T=t(a,e),Vl=!1,st&&(T=ki(l,t,a,e)),wi(n),T}function wi(n){L.H=ia;var l=Sn!==null&&Sn.next!==null;if(q1=0,Mn=Sn=j=null,f0=!1,ea=0,Xt=null,l)throw Error(i(300));n===null||Un||(n=n.dependencies,n!==null&&n0(n)&&(Un=!0))}function ki(n,l,t,a){j=n;var e=0;do{if(st&&(Xt=null),ea=0,st=!1,25<=e)throw Error(i(301));if(e+=1,Mn=Sn=null,n.updateQueue!=null){var T=n.updateQueue;T.lastEffect=null,T.events=null,T.stores=null,T.memoCache!=null&&(T.memoCache.index=0)}L.H=G2,T=l(t,a)}while(st);return T}function OE(){var n=L.H,l=n.useState()[0];return l=typeof l.then=="function"?Ta(l):l,n=n.useState()[0],(Sn!==null?Sn.memoizedState:null)!==n&&(j.flags|=1024),l}function tT(){var n=N0!==0;return N0=0,n}function aT(n,l,t){l.updateQueue=n.updateQueue,l.flags&=-2053,n.lanes&=~t}function eT(n){if(f0){for(n=n.memoizedState;n!==null;){var l=n.queue;l!==null&&(l.pending=null),n=n.next}f0=!1}q1=0,Mn=Sn=j=null,st=!1,ea=N0=0,Xt=null}function Jn(){var n={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return Mn===null?j.memoizedState=Mn=n:Mn=Mn.next=n,Mn}function Ln(){if(Sn===null){var n=j.alternate;n=n!==null?n.memoizedState:null}else n=Sn.next;var l=Mn===null?j.memoizedState:Mn.next;if(l!==null)Mn=l,Sn=n;else{if(n===null)throw j.alternate===null?Error(i(467)):Error(i(310));Sn=n,n={memoizedState:Sn.memoizedState,baseState:Sn.baseState,baseQueue:Sn.baseQueue,queue:Sn.queue,next:null},Mn===null?j.memoizedState=Mn=n:Mn=Mn.next=n}return Mn}function E0(){return{lastEffect:null,events:null,stores:null,memoCache:null}}function Ta(n){var l=ea;return ea+=1,Xt===null&&(Xt=[]),n=xi(Xt,n,l),l=j,(Mn===null?l.memoizedState:Mn.next)===null&&(l=l.alternate,L.H=l===null||l.memoizedState===null?U2:RT),n}function O0(n){if(n!==null&&typeof n=="object"){if(typeof n.then=="function")return Ta(n);if(n.$$typeof===Cn)return xn(n)}throw Error(i(438,String(n)))}function TT(n){var l=null,t=j.updateQueue;if(t!==null&&(l=t.memoCache),l==null){var a=j.alternate;a!==null&&(a=a.updateQueue,a!==null&&(a=a.memoCache,a!=null&&(l={data:a.data.map(function(e){return e.slice()}),index:0})))}if(l==null&&(l={data:[],index:0}),t===null&&(t=E0(),j.updateQueue=t),t.memoCache=l,t=l.data[l.index],t===void 0)for(t=l.data[l.index]=Array(n),a=0;a<n;a++)t[a]=u1;return l.index++,t}function W1(n,l){return typeof l=="function"?l(n):l}function A0(n){var l=Ln();return uT(l,Sn,n)}function uT(n,l,t){var a=n.queue;if(a===null)throw Error(i(311));a.lastRenderedReducer=t;var e=n.baseQueue,T=a.pending;if(T!==null){if(e!==null){var u=e.next;e.next=T.next,T.next=u}l.baseQueue=e=T,a.pending=null}if(T=n.baseState,e===null)n.memoizedState=T;else{l=e.next;var f=u=null,R=null,y=l,B=!1;do{var F=y.lane&-536870913;if(F!==y.lane?(en&F)===F:(q1&F)===F){var h=y.revertLane;if(h===0)R!==null&&(R=R.next={lane:0,revertLane:0,gesture:null,action:y.action,hasEagerState:y.hasEagerState,eagerState:y.eagerState,next:null}),F===St&&(B=!0);else if((q1&h)===h){y=y.next,h===St&&(B=!0);continue}else F={lane:0,revertLane:y.revertLane,gesture:null,action:y.action,hasEagerState:y.hasEagerState,eagerState:y.eagerState,next:null},R===null?(f=R=F,u=T):R=R.next=F,j.lanes|=h,Cl|=h;F=y.action,Vl&&t(T,F),T=y.hasEagerState?y.eagerState:t(T,F)}else h={lane:F,revertLane:y.revertLane,gesture:y.gesture,action:y.action,hasEagerState:y.hasEagerState,eagerState:y.eagerState,next:null},R===null?(f=R=h,u=T):R=R.next=h,j.lanes|=F,Cl|=F;y=y.next}while(y!==null&&y!==l);if(R===null?u=T:R.next=f,!E1(T,n.memoizedState)&&(Un=!0,B&&(t=Dt,t!==null)))throw t;n.memoizedState=T,n.baseState=u,n.baseQueue=R,a.lastRenderedState=T}return e===null&&(a.lanes=0),[n.memoizedState,a.dispatch]}function iT(n){var l=Ln(),t=l.queue;if(t===null)throw Error(i(311));t.lastRenderedReducer=n;var a=t.dispatch,e=t.pending,T=l.memoizedState;if(e!==null){t.pending=null;var u=e=e.next;do T=n(T,u.action),u=u.next;while(u!==e);E1(T,l.memoizedState)||(Un=!0),l.memoizedState=T,l.baseQueue===null&&(l.baseState=T),t.lastRenderedState=T}return[T,a]}function n2(n,l,t){var a=j,e=Ln(),T=un;if(T){if(t===void 0)throw Error(i(407));t=t()}else t=l();var u=!E1((Sn||e).memoizedState,t);if(u&&(e.memoizedState=t,Un=!0),e=e.queue,NT(a2.bind(null,a,e,n),[n]),e.getSnapshot!==l||u||Mn!==null&&Mn.memoizedState.tag&1){if(a.flags|=2048,ot(9,{destroy:void 0},t2.bind(null,a,e,t,l),null),Yn===null)throw Error(i(349));T||(q1&127)!==0||l2(a,l,t)}return t}function l2(n,l,t){n.flags|=16384,n={getSnapshot:l,value:t},l=j.updateQueue,l===null?(l=E0(),j.updateQueue=l,l.stores=[n]):(t=l.stores,t===null?l.stores=[n]:t.push(n))}function t2(n,l,t,a){l.value=t,l.getSnapshot=a,e2(l)&&T2(n)}function a2(n,l,t){return t(function(){e2(l)&&T2(n)})}function e2(n){var l=n.getSnapshot;n=n.value;try{var t=l();return!E1(n,t)}catch{return!0}}function T2(n){var l=bl(n,2);l!==null&&T1(l,n,2)}function cT(n){var l=Jn();if(typeof n=="function"){var t=n;if(n=t(),Vl){al(!0);try{t()}finally{al(!1)}}}return l.memoizedState=l.baseState=n,l.queue={pending:null,lanes:0,dispatch:null,lastRenderedReducer:W1,lastRenderedState:n},l}function u2(n,l,t,a){return n.baseState=t,uT(n,Sn,typeof a=="function"?a:W1)}function AE(n,l,t,a,e){if(R0(n))throw Error(i(485));if(n=l.action,n!==null){var T={payload:e,action:n,next:null,isTransition:!0,status:"pending",value:null,reason:null,listeners:[],then:function(u){T.listeners.push(u)}};L.T!==null?t(!0):T.isTransition=!1,a(T),t=l.pending,t===null?(T.next=l.pending=T,i2(l,T)):(T.next=t.next,l.pending=t.next=T)}}function i2(n,l){var t=l.action,a=l.payload,e=n.state;if(l.isTransition){var T=L.T,u={};L.T=u;try{var f=t(e,a),R=L.S;R!==null&&R(u,f),c2(n,l,f)}catch(y){fT(n,l,y)}finally{T!==null&&u.types!==null&&(T.types=u.types),L.T=T}}else try{T=t(e,a),c2(n,l,T)}catch(y){fT(n,l,y)}}function c2(n,l,t){t!==null&&typeof t=="object"&&typeof t.then=="function"?t.then(function(a){f2(n,l,a)},function(a){return fT(n,l,a)}):f2(n,l,t)}function f2(n,l,t){l.status="fulfilled",l.value=t,N2(l),n.state=t,l=n.pending,l!==null&&(t=l.next,t===l?n.pending=null:(t=t.next,l.next=t,i2(n,t)))}function fT(n,l,t){var a=n.pending;if(n.pending=null,a!==null){a=a.next;do l.status="rejected",l.reason=t,N2(l),l=l.next;while(l!==a)}n.action=null}function N2(n){n=n.listeners;for(var l=0;l<n.length;l++)(0,n[l])()}function E2(n,l){return l}function O2(n,l){if(un){var t=Yn.formState;if(t!==null){n:{var a=j;if(un){if(sn){l:{for(var e=sn,T=h1;e.nodeType!==8;){if(!T){e=null;break l}if(e=B1(e.nextSibling),e===null){e=null;break l}}T=e.data,e=T==="F!"||T==="F"?e:null}if(e){sn=B1(e.nextSibling),a=e.data==="F!";break n}}cl(a)}a=!1}a&&(l=t[0])}}return t=Jn(),t.memoizedState=t.baseState=l,a={pending:null,lanes:0,dispatch:null,lastRenderedReducer:E2,lastRenderedState:l},t.queue=a,t=m2.bind(null,j,a),a.dispatch=t,a=cT(!1),T=DT.bind(null,j,!1,a.queue),a=Jn(),e={state:l,dispatch:null,action:n,pending:null},a.queue=e,t=AE.bind(null,j,e,T,t),e.dispatch=t,a.memoizedState=n,[l,t,!1]}function A2(n){var l=Ln();return S2(l,Sn,n)}function S2(n,l,t){if(l=uT(n,l,E2)[0],n=A0(W1)[0],typeof l=="object"&&l!==null&&typeof l.then=="function")try{var a=Ta(l)}catch(u){throw u===Rt?a0:u}else a=l;l=Ln();var e=l.queue,T=e.dispatch;return t!==l.memoizedState&&(j.flags|=2048,ot(9,{destroy:void 0},SE.bind(null,e,t),null)),[a,T,n]}function SE(n,l){n.action=l}function D2(n){var l=Ln(),t=Sn;if(t!==null)return S2(l,t,n);Ln(),l=l.memoizedState,t=Ln();var a=t.queue.dispatch;return t.memoizedState=n,[l,a,!1]}function ot(n,l,t,a){return n={tag:n,create:t,deps:a,inst:l,next:null},l=j.updateQueue,l===null&&(l=E0(),j.updateQueue=l),t=l.lastEffect,t===null?l.lastEffect=n.next=n:(a=t.next,t.next=n,n.next=a,l.lastEffect=n),n}function R2(){return Ln().memoizedState}function S0(n,l,t,a){var e=Jn();j.flags|=n,e.memoizedState=ot(1|l,{destroy:void 0},t,a===void 0?null:a)}function D0(n,l,t,a){var e=Ln();a=a===void 0?null:a;var T=e.memoizedState.inst;Sn!==null&&a!==null&&nT(a,Sn.memoizedState.deps)?e.memoizedState=ot(l,T,t,a):(j.flags|=n,e.memoizedState=ot(1|l,T,t,a))}function C2(n,l){S0(8390656,8,n,l)}function NT(n,l){D0(2048,8,n,l)}function DE(n){j.flags|=4;var l=j.updateQueue;if(l===null)l=E0(),j.updateQueue=l,l.events=[n];else{var t=l.events;t===null?l.events=[n]:t.push(n)}}function Y2(n){var l=Ln().memoizedState;return DE({ref:l,nextImpl:n}),function(){if((Nn&2)!==0)throw Error(i(440));return l.impl.apply(void 0,arguments)}}function s2(n,l){return D0(4,2,n,l)}function X2(n,l){return D0(4,4,n,l)}function o2(n,l){if(typeof l=="function"){n=n();var t=l(n);return function(){typeof t=="function"?t():l(null)}}if(l!=null)return n=n(),l.current=n,function(){l.current=null}}function I2(n,l,t){t=t!=null?t.concat([n]):null,D0(4,4,o2.bind(null,l,n),t)}function ET(){}function r2(n,l){var t=Ln();l=l===void 0?null:l;var a=t.memoizedState;return l!==null&&nT(l,a[1])?a[0]:(t.memoizedState=[n,l],n)}function H2(n,l){var t=Ln();l=l===void 0?null:l;var a=t.memoizedState;if(l!==null&&nT(l,a[1]))return a[0];if(a=n(),Vl){al(!0);try{n()}finally{al(!1)}}return t.memoizedState=[a,l],a}function OT(n,l,t){return t===void 0||(q1&1073741824)!==0&&(en&261930)===0?n.memoizedState=l:(n.memoizedState=t,n=yc(),j.lanes|=n,Cl|=n,t)}function y2(n,l,t,a){return E1(t,l)?t:Yt.current!==null?(n=OT(n,t,a),E1(n,l)||(Un=!0),n):(q1&42)===0||(q1&1073741824)!==0&&(en&261930)===0?(Un=!0,n.memoizedState=t):(n=yc(),j.lanes|=n,Cl|=n,l)}function h2(n,l,t,a,e){var T=G.p;G.p=T!==0&&8>T?T:8;var u=L.T,f={};L.T=f,DT(n,!1,l,t);try{var R=e(),y=L.S;if(y!==null&&y(f,R),R!==null&&typeof R=="object"&&typeof R.then=="function"){var B=NE(R,a);ua(n,l,B,C1(n))}else ua(n,l,a,C1(n))}catch(F){ua(n,l,{then:function(){},status:"rejected",reason:F},C1())}finally{G.p=T,u!==null&&f.types!==null&&(u.types=f.types),L.T=u}}function RE(){}function AT(n,l,t,a){if(n.tag!==5)throw Error(i(476));var e=d2(n).queue;h2(n,e,l,z,t===null?RE:function(){return B2(n),t(a)})}function d2(n){var l=n.memoizedState;if(l!==null)return l;l={memoizedState:z,baseState:z,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:W1,lastRenderedState:z},next:null};var t={};return l.next={memoizedState:t,baseState:t,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:W1,lastRenderedState:t},next:null},n.memoizedState=l,n=n.alternate,n!==null&&(n.memoizedState=l),l}function B2(n){var l=d2(n);l.next===null&&(l=n.alternate.memoizedState),ua(n,l.next.queue,{},C1())}function ST(){return xn(ra)}function L2(){return Ln().memoizedState}function v2(){return Ln().memoizedState}function CE(n){for(var l=n.return;l!==null;){switch(l.tag){case 24:case 3:var t=C1();n=El(t);var a=Ol(l,n,t);a!==null&&(T1(a,l,t),la(a,l,t)),l={cache:xe()},n.payload=l;return}l=l.return}}function YE(n,l,t){var a=C1();t={lane:a,revertLane:0,gesture:null,action:t,hasEagerState:!1,eagerState:null,next:null},R0(n)?F2(l,t):(t=Fe(n,l,t,a),t!==null&&(T1(t,n,a),M2(t,l,a)))}function m2(n,l,t){var a=C1();ua(n,l,t,a)}function ua(n,l,t,a){var e={lane:a,revertLane:0,gesture:null,action:t,hasEagerState:!1,eagerState:null,next:null};if(R0(n))F2(l,e);else{var T=n.alternate;if(n.lanes===0&&(T===null||T.lanes===0)&&(T=l.lastRenderedReducer,T!==null))try{var u=l.lastRenderedState,f=T(u,t);if(e.hasEagerState=!0,e.eagerState=f,E1(f,u))return Ja(n,l,e,0),Yn===null&&ja(),!1}catch{}if(t=Fe(n,l,e,a),t!==null)return T1(t,n,a),M2(t,l,a),!0}return!1}function DT(n,l,t,a){if(a={lane:2,revertLane:WT(),gesture:null,action:a,hasEagerState:!1,eagerState:null,next:null},R0(n)){if(l)throw Error(i(479))}else l=Fe(n,t,a,2),l!==null&&T1(l,n,2)}function R0(n){var l=n.alternate;return n===j||l!==null&&l===j}function F2(n,l){st=f0=!0;var t=n.pending;t===null?l.next=l:(l.next=t.next,t.next=l),n.pending=l}function M2(n,l,t){if((t&4194048)!==0){var a=l.lanes;a&=n.pendingLanes,t|=a,l.lanes=t,gu(n,t)}}var ia={readContext:xn,use:O0,useCallback:yn,useContext:yn,useEffect:yn,useImperativeHandle:yn,useLayoutEffect:yn,useInsertionEffect:yn,useMemo:yn,useReducer:yn,useRef:yn,useState:yn,useDebugValue:yn,useDeferredValue:yn,useTransition:yn,useSyncExternalStore:yn,useId:yn,useHostTransitionStatus:yn,useFormState:yn,useActionState:yn,useOptimistic:yn,useMemoCache:yn,useCacheRefresh:yn};ia.useEffectEvent=yn;var U2={readContext:xn,use:O0,useCallback:function(n,l){return Jn().memoizedState=[n,l===void 0?null:l],n},useContext:xn,useEffect:C2,useImperativeHandle:function(n,l,t){t=t!=null?t.concat([n]):null,S0(4194308,4,o2.bind(null,l,n),t)},useLayoutEffect:function(n,l){return S0(4194308,4,n,l)},useInsertionEffect:function(n,l){S0(4,2,n,l)},useMemo:function(n,l){var t=Jn();l=l===void 0?null:l;var a=n();if(Vl){al(!0);try{n()}finally{al(!1)}}return t.memoizedState=[a,l],a},useReducer:function(n,l,t){var a=Jn();if(t!==void 0){var e=t(l);if(Vl){al(!0);try{t(l)}finally{al(!1)}}}else e=l;return a.memoizedState=a.baseState=e,n={pending:null,lanes:0,dispatch:null,lastRenderedReducer:n,lastRenderedState:e},a.queue=n,n=n.dispatch=YE.bind(null,j,n),[a.memoizedState,n]},useRef:function(n){var l=Jn();return n={current:n},l.memoizedState=n},useState:function(n){n=cT(n);var l=n.queue,t=m2.bind(null,j,l);return l.dispatch=t,[n.memoizedState,t]},useDebugValue:ET,useDeferredValue:function(n,l){var t=Jn();return OT(t,n,l)},useTransition:function(){var n=cT(!1);return n=h2.bind(null,j,n.queue,!0,!1),Jn().memoizedState=n,[!1,n]},useSyncExternalStore:function(n,l,t){var a=j,e=Jn();if(un){if(t===void 0)throw Error(i(407));t=t()}else{if(t=l(),Yn===null)throw Error(i(349));(en&127)!==0||l2(a,l,t)}e.memoizedState=t;var T={value:t,getSnapshot:l};return e.queue=T,C2(a2.bind(null,a,T,n),[n]),a.flags|=2048,ot(9,{destroy:void 0},t2.bind(null,a,T,t,l),null),t},useId:function(){var n=Jn(),l=Yn.identifierPrefix;if(un){var t=G1,a=U1;t=(a&~(1<<32-N1(a)-1)).toString(32)+t,l="_"+l+"R_"+t,t=N0++,0<t&&(l+="H"+t.toString(32)),l+="_"}else t=EE++,l="_"+l+"r_"+t.toString(32)+"_";return n.memoizedState=l},useHostTransitionStatus:ST,useFormState:O2,useActionState:O2,useOptimistic:function(n){var l=Jn();l.memoizedState=l.baseState=n;var t={pending:null,lanes:0,dispatch:null,lastRenderedReducer:null,lastRenderedState:null};return l.queue=t,l=DT.bind(null,j,!0,t),t.dispatch=l,[n,l]},useMemoCache:TT,useCacheRefresh:function(){return Jn().memoizedState=CE.bind(null,j)},useEffectEvent:function(n){var l=Jn(),t={impl:n};return l.memoizedState=t,function(){if((Nn&2)!==0)throw Error(i(440));return t.impl.apply(void 0,arguments)}}},RT={readContext:xn,use:O0,useCallback:r2,useContext:xn,useEffect:NT,useImperativeHandle:I2,useInsertionEffect:s2,useLayoutEffect:X2,useMemo:H2,useReducer:A0,useRef:R2,useState:function(){return A0(W1)},useDebugValue:ET,useDeferredValue:function(n,l){var t=Ln();return y2(t,Sn.memoizedState,n,l)},useTransition:function(){var n=A0(W1)[0],l=Ln().memoizedState;return[typeof n=="boolean"?n:Ta(n),l]},useSyncExternalStore:n2,useId:L2,useHostTransitionStatus:ST,useFormState:A2,useActionState:A2,useOptimistic:function(n,l){var t=Ln();return u2(t,Sn,n,l)},useMemoCache:TT,useCacheRefresh:v2};RT.useEffectEvent=Y2;var G2={readContext:xn,use:O0,useCallback:r2,useContext:xn,useEffect:NT,useImperativeHandle:I2,useInsertionEffect:s2,useLayoutEffect:X2,useMemo:H2,useReducer:iT,useRef:R2,useState:function(){return iT(W1)},useDebugValue:ET,useDeferredValue:function(n,l){var t=Ln();return Sn===null?OT(t,n,l):y2(t,Sn.memoizedState,n,l)},useTransition:function(){var n=iT(W1)[0],l=Ln().memoizedState;return[typeof n=="boolean"?n:Ta(n),l]},useSyncExternalStore:n2,useId:L2,useHostTransitionStatus:ST,useFormState:D2,useActionState:D2,useOptimistic:function(n,l){var t=Ln();return Sn!==null?u2(t,Sn,n,l):(t.baseState=n,[n,t.queue.dispatch])},useMemoCache:TT,useCacheRefresh:v2};G2.useEffectEvent=Y2;function CT(n,l,t,a){l=n.memoizedState,t=t(a,l),t=t==null?l:o({},l,t),n.memoizedState=t,n.lanes===0&&(n.updateQueue.baseState=t)}var YT={enqueueSetState:function(n,l,t){n=n._reactInternals;var a=C1(),e=El(a);e.payload=l,t!=null&&(e.callback=t),l=Ol(n,e,a),l!==null&&(T1(l,n,a),la(l,n,a))},enqueueReplaceState:function(n,l,t){n=n._reactInternals;var a=C1(),e=El(a);e.tag=1,e.payload=l,t!=null&&(e.callback=t),l=Ol(n,e,a),l!==null&&(T1(l,n,a),la(l,n,a))},enqueueForceUpdate:function(n,l){n=n._reactInternals;var t=C1(),a=El(t);a.tag=2,l!=null&&(a.callback=l),l=Ol(n,a,t),l!==null&&(T1(l,n,t),la(l,n,t))}};function b2(n,l,t,a,e,T,u){return n=n.stateNode,typeof n.shouldComponentUpdate=="function"?n.shouldComponentUpdate(a,T,u):l.prototype&&l.prototype.isPureReactComponent?!Wt(t,a)||!Wt(e,T):!0}function p2(n,l,t,a){n=l.state,typeof l.componentWillReceiveProps=="function"&&l.componentWillReceiveProps(t,a),typeof l.UNSAFE_componentWillReceiveProps=="function"&&l.UNSAFE_componentWillReceiveProps(t,a),l.state!==n&&YT.enqueueReplaceState(l,l.state,null)}function ql(n,l){var t=l;if("ref"in l){t={};for(var a in l)a!=="ref"&&(t[a]=l[a])}if(n=n.defaultProps){t===l&&(t=o({},t));for(var e in n)t[e]===void 0&&(t[e]=n[e])}return t}function g2(n){$a(n)}function z2(n){console.error(n)}function _2(n){$a(n)}function C0(n,l){try{var t=n.onUncaughtError;t(l.value,{componentStack:l.stack})}catch(a){setTimeout(function(){throw a})}}function K2(n,l,t){try{var a=n.onCaughtError;a(t.value,{componentStack:t.stack,errorBoundary:l.tag===1?l.stateNode:null})}catch(e){setTimeout(function(){throw e})}}function sT(n,l,t){return t=El(t),t.tag=3,t.payload={element:null},t.callback=function(){C0(n,l)},t}function Z2(n){return n=El(n),n.tag=3,n}function x2(n,l,t,a){var e=t.type.getDerivedStateFromError;if(typeof e=="function"){var T=a.value;n.payload=function(){return e(T)},n.callback=function(){K2(l,t,a)}}var u=t.stateNode;u!==null&&typeof u.componentDidCatch=="function"&&(n.callback=function(){K2(l,t,a),typeof e!="function"&&(Yl===null?Yl=new Set([this]):Yl.add(this));var f=a.stack;this.componentDidCatch(a.value,{componentStack:f!==null?f:""})})}function sE(n,l,t,a,e){if(t.flags|=32768,a!==null&&typeof a=="object"&&typeof a.then=="function"){if(l=t.alternate,l!==null&&At(l,t,e,!0),t=A1.current,t!==null){switch(t.tag){case 31:case 13:return d1===null?L0():t.alternate===null&&hn===0&&(hn=3),t.flags&=-257,t.flags|=65536,t.lanes=e,a===e0?t.flags|=16384:(l=t.updateQueue,l===null?t.updateQueue=new Set([a]):l.add(a),QT(n,a,e)),!1;case 22:return t.flags|=65536,a===e0?t.flags|=16384:(l=t.updateQueue,l===null?(l={transitions:null,markerInstances:null,retryQueue:new Set([a])},t.updateQueue=l):(t=l.retryQueue,t===null?l.retryQueue=new Set([a]):t.add(a)),QT(n,a,e)),!1}throw Error(i(435,t.tag))}return QT(n,a,e),L0(),!1}if(un)return l=A1.current,l!==null?((l.flags&65536)===0&&(l.flags|=256),l.flags|=65536,l.lanes=e,a!==ge&&(n=Error(i(422),{cause:a}),Jt(r1(n,t)))):(a!==ge&&(l=Error(i(423),{cause:a}),Jt(r1(l,t))),n=n.current.alternate,n.flags|=65536,e&=-e,n.lanes|=e,a=r1(a,t),e=sT(n.stateNode,a,e),je(n,e),hn!==4&&(hn=2)),!1;var T=Error(i(520),{cause:a});if(T=r1(T,t),Da===null?Da=[T]:Da.push(T),hn!==4&&(hn=2),l===null)return!0;a=r1(a,t),t=l;do{switch(t.tag){case 3:return t.flags|=65536,n=e&-e,t.lanes|=n,n=sT(t.stateNode,a,n),je(t,n),!1;case 1:if(l=t.type,T=t.stateNode,(t.flags&128)===0&&(typeof l.getDerivedStateFromError=="function"||T!==null&&typeof T.componentDidCatch=="function"&&(Yl===null||!Yl.has(T))))return t.flags|=65536,e&=-e,t.lanes|=e,e=Z2(e),x2(e,n,t,a),je(t,e),!1}t=t.return}while(t!==null);return!1}var XT=Error(i(461)),Un=!1;function Qn(n,l,t,a){l.child=n===null?Wi(l,null,t,a):Ql(l,n.child,t,a)}function Q2(n,l,t,a,e){t=t.render;var T=l.ref;if("ref"in a){var u={};for(var f in a)f!=="ref"&&(u[f]=a[f])}else u=a;return _l(l),a=lT(n,l,t,u,T,e),f=tT(),n!==null&&!Un?(aT(n,l,e),$1(n,l,e)):(un&&f&&be(l),l.flags|=1,Qn(n,l,a,e),l.child)}function V2(n,l,t,a,e){if(n===null){var T=t.type;return typeof T=="function"&&!Me(T)&&T.defaultProps===void 0&&t.compare===null?(l.tag=15,l.type=T,q2(n,l,T,a,e)):(n=wa(t.type,null,a,l,l.mode,e),n.ref=l.ref,n.return=l,l.child=n)}if(T=n.child,!BT(n,e)){var u=T.memoizedProps;if(t=t.compare,t=t!==null?t:Wt,t(u,a)&&n.ref===l.ref)return $1(n,l,e)}return l.flags|=1,n=Z1(T,a),n.ref=l.ref,n.return=l,l.child=n}function q2(n,l,t,a,e){if(n!==null){var T=n.memoizedProps;if(Wt(T,a)&&n.ref===l.ref)if(Un=!1,l.pendingProps=a=T,BT(n,e))(n.flags&131072)!==0&&(Un=!0);else return l.lanes=n.lanes,$1(n,l,e)}return oT(n,l,t,a,e)}function W2(n,l,t,a){var e=a.children,T=n!==null?n.memoizedState:null;if(n===null&&l.stateNode===null&&(l.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),a.mode==="hidden"){if((l.flags&128)!==0){if(T=T!==null?T.baseLanes|t:t,n!==null){for(a=l.child=n.child,e=0;a!==null;)e=e|a.lanes|a.childLanes,a=a.sibling;a=e&~T}else a=0,l.child=null;return $2(n,l,T,t,a)}if((t&536870912)!==0)l.memoizedState={baseLanes:0,cachePool:null},n!==null&&t0(l,T!==null?T.cachePool:null),T!==null?Ji(l,T):Pe(),Pi(l);else return a=l.lanes=536870912,$2(n,l,T!==null?T.baseLanes|t:t,t,a)}else T!==null?(t0(l,T.cachePool),Ji(l,T),Sl(),l.memoizedState=null):(n!==null&&t0(l,null),Pe(),Sl());return Qn(n,l,e,t),l.child}function ca(n,l){return n!==null&&n.tag===22||l.stateNode!==null||(l.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),l.sibling}function $2(n,l,t,a,e){var T=Ve();return T=T===null?null:{parent:Fn._currentValue,pool:T},l.memoizedState={baseLanes:t,cachePool:T},n!==null&&t0(l,null),Pe(),Pi(l),n!==null&&At(n,l,a,!0),l.childLanes=e,null}function Y0(n,l){return l=X0({mode:l.mode,children:l.children},n.mode),l.ref=n.ref,n.child=l,l.return=n,l}function j2(n,l,t){return Ql(l,n.child,null,t),n=Y0(l,l.pendingProps),n.flags|=2,S1(l),l.memoizedState=null,n}function XE(n,l,t){var a=l.pendingProps,e=(l.flags&128)!==0;if(l.flags&=-129,n===null){if(un){if(a.mode==="hidden")return n=Y0(l,a),l.lanes=536870912,ca(null,n);if(ke(l),(n=sn)?(n=cf(n,h1),n=n!==null&&n.data==="&"?n:null,n!==null&&(l.memoizedState={dehydrated:n,treeContext:ul!==null?{id:U1,overflow:G1}:null,retryLane:536870912,hydrationErrors:null},t=Fi(n),t.return=l,l.child=t,Zn=l,sn=null)):n=null,n===null)throw cl(l);return l.lanes=536870912,null}return Y0(l,a)}var T=n.memoizedState;if(T!==null){var u=T.dehydrated;if(ke(l),e)if(l.flags&256)l.flags&=-257,l=j2(n,l,t);else if(l.memoizedState!==null)l.child=n.child,l.flags|=128,l=null;else throw Error(i(558));else if(Un||At(n,l,t,!1),e=(t&n.childLanes)!==0,Un||e){if(a=Yn,a!==null&&(u=zu(a,t),u!==0&&u!==T.retryLane))throw T.retryLane=u,bl(n,u),T1(a,n,u),XT;L0(),l=j2(n,l,t)}else n=T.treeContext,sn=B1(u.nextSibling),Zn=l,un=!0,il=null,h1=!1,n!==null&&Gi(l,n),l=Y0(l,a),l.flags|=4096;return l}return n=Z1(n.child,{mode:a.mode,children:a.children}),n.ref=l.ref,l.child=n,n.return=l,n}function s0(n,l){var t=l.ref;if(t===null)n!==null&&n.ref!==null&&(l.flags|=4194816);else{if(typeof t!="function"&&typeof t!="object")throw Error(i(284));(n===null||n.ref!==t)&&(l.flags|=4194816)}}function oT(n,l,t,a,e){return _l(l),t=lT(n,l,t,a,void 0,e),a=tT(),n!==null&&!Un?(aT(n,l,e),$1(n,l,e)):(un&&a&&be(l),l.flags|=1,Qn(n,l,t,e),l.child)}function J2(n,l,t,a,e,T){return _l(l),l.updateQueue=null,t=ki(l,a,t,e),wi(n),a=tT(),n!==null&&!Un?(aT(n,l,T),$1(n,l,T)):(un&&a&&be(l),l.flags|=1,Qn(n,l,t,T),l.child)}function P2(n,l,t,a,e){if(_l(l),l.stateNode===null){var T=ft,u=t.contextType;typeof u=="object"&&u!==null&&(T=xn(u)),T=new t(a,T),l.memoizedState=T.state!==null&&T.state!==void 0?T.state:null,T.updater=YT,l.stateNode=T,T._reactInternals=l,T=l.stateNode,T.props=a,T.state=l.memoizedState,T.refs={},We(l),u=t.contextType,T.context=typeof u=="object"&&u!==null?xn(u):ft,T.state=l.memoizedState,u=t.getDerivedStateFromProps,typeof u=="function"&&(CT(l,t,u,a),T.state=l.memoizedState),typeof t.getDerivedStateFromProps=="function"||typeof T.getSnapshotBeforeUpdate=="function"||typeof T.UNSAFE_componentWillMount!="function"&&typeof T.componentWillMount!="function"||(u=T.state,typeof T.componentWillMount=="function"&&T.componentWillMount(),typeof T.UNSAFE_componentWillMount=="function"&&T.UNSAFE_componentWillMount(),u!==T.state&&YT.enqueueReplaceState(T,T.state,null),aa(l,a,T,e),ta(),T.state=l.memoizedState),typeof T.componentDidMount=="function"&&(l.flags|=4194308),a=!0}else if(n===null){T=l.stateNode;var f=l.memoizedProps,R=ql(t,f);T.props=R;var y=T.context,B=t.contextType;u=ft,typeof B=="object"&&B!==null&&(u=xn(B));var F=t.getDerivedStateFromProps;B=typeof F=="function"||typeof T.getSnapshotBeforeUpdate=="function",f=l.pendingProps!==f,B||typeof T.UNSAFE_componentWillReceiveProps!="function"&&typeof T.componentWillReceiveProps!="function"||(f||y!==u)&&p2(l,T,a,u),Nl=!1;var h=l.memoizedState;T.state=h,aa(l,a,T,e),ta(),y=l.memoizedState,f||h!==y||Nl?(typeof F=="function"&&(CT(l,t,F,a),y=l.memoizedState),(R=Nl||b2(l,t,R,a,h,y,u))?(B||typeof T.UNSAFE_componentWillMount!="function"&&typeof T.componentWillMount!="function"||(typeof T.componentWillMount=="function"&&T.componentWillMount(),typeof T.UNSAFE_componentWillMount=="function"&&T.UNSAFE_componentWillMount()),typeof T.componentDidMount=="function"&&(l.flags|=4194308)):(typeof T.componentDidMount=="function"&&(l.flags|=4194308),l.memoizedProps=a,l.memoizedState=y),T.props=a,T.state=y,T.context=u,a=R):(typeof T.componentDidMount=="function"&&(l.flags|=4194308),a=!1)}else{T=l.stateNode,$e(n,l),u=l.memoizedProps,B=ql(t,u),T.props=B,F=l.pendingProps,h=T.context,y=t.contextType,R=ft,typeof y=="object"&&y!==null&&(R=xn(y)),f=t.getDerivedStateFromProps,(y=typeof f=="function"||typeof T.getSnapshotBeforeUpdate=="function")||typeof T.UNSAFE_componentWillReceiveProps!="function"&&typeof T.componentWillReceiveProps!="function"||(u!==F||h!==R)&&p2(l,T,a,R),Nl=!1,h=l.memoizedState,T.state=h,aa(l,a,T,e),ta();var d=l.memoizedState;u!==F||h!==d||Nl||n!==null&&n.dependencies!==null&&n0(n.dependencies)?(typeof f=="function"&&(CT(l,t,f,a),d=l.memoizedState),(B=Nl||b2(l,t,B,a,h,d,R)||n!==null&&n.dependencies!==null&&n0(n.dependencies))?(y||typeof T.UNSAFE_componentWillUpdate!="function"&&typeof T.componentWillUpdate!="function"||(typeof T.componentWillUpdate=="function"&&T.componentWillUpdate(a,d,R),typeof T.UNSAFE_componentWillUpdate=="function"&&T.UNSAFE_componentWillUpdate(a,d,R)),typeof T.componentDidUpdate=="function"&&(l.flags|=4),typeof T.getSnapshotBeforeUpdate=="function"&&(l.flags|=1024)):(typeof T.componentDidUpdate!="function"||u===n.memoizedProps&&h===n.memoizedState||(l.flags|=4),typeof T.getSnapshotBeforeUpdate!="function"||u===n.memoizedProps&&h===n.memoizedState||(l.flags|=1024),l.memoizedProps=a,l.memoizedState=d),T.props=a,T.state=d,T.context=R,a=B):(typeof T.componentDidUpdate!="function"||u===n.memoizedProps&&h===n.memoizedState||(l.flags|=4),typeof T.getSnapshotBeforeUpdate!="function"||u===n.memoizedProps&&h===n.memoizedState||(l.flags|=1024),a=!1)}return T=a,s0(n,l),a=(l.flags&128)!==0,T||a?(T=l.stateNode,t=a&&typeof t.getDerivedStateFromError!="function"?null:T.render(),l.flags|=1,n!==null&&a?(l.child=Ql(l,n.child,null,e),l.child=Ql(l,null,t,e)):Qn(n,l,t,e),l.memoizedState=T.state,n=l.child):n=$1(n,l,e),n}function w2(n,l,t,a){return gl(),l.flags|=256,Qn(n,l,t,a),l.child}var IT={dehydrated:null,treeContext:null,retryLane:0,hydrationErrors:null};function rT(n){return{baseLanes:n,cachePool:Ki()}}function HT(n,l,t){return n=n!==null?n.childLanes&~t:0,l&&(n|=R1),n}function k2(n,l,t){var a=l.pendingProps,e=!1,T=(l.flags&128)!==0,u;if((u=T)||(u=n!==null&&n.memoizedState===null?!1:(Bn.current&2)!==0),u&&(e=!0,l.flags&=-129),u=(l.flags&32)!==0,l.flags&=-33,n===null){if(un){if(e?Al(l):Sl(),(n=sn)?(n=cf(n,h1),n=n!==null&&n.data!=="&"?n:null,n!==null&&(l.memoizedState={dehydrated:n,treeContext:ul!==null?{id:U1,overflow:G1}:null,retryLane:536870912,hydrationErrors:null},t=Fi(n),t.return=l,l.child=t,Zn=l,sn=null)):n=null,n===null)throw cl(l);return uu(n)?l.lanes=32:l.lanes=536870912,null}var f=a.children;return a=a.fallback,e?(Sl(),e=l.mode,f=X0({mode:"hidden",children:f},e),a=pl(a,e,t,null),f.return=l,a.return=l,f.sibling=a,l.child=f,a=l.child,a.memoizedState=rT(t),a.childLanes=HT(n,u,t),l.memoizedState=IT,ca(null,a)):(Al(l),yT(l,f))}var R=n.memoizedState;if(R!==null&&(f=R.dehydrated,f!==null)){if(T)l.flags&256?(Al(l),l.flags&=-257,l=hT(n,l,t)):l.memoizedState!==null?(Sl(),l.child=n.child,l.flags|=128,l=null):(Sl(),f=a.fallback,e=l.mode,a=X0({mode:"visible",children:a.children},e),f=pl(f,e,t,null),f.flags|=2,a.return=l,f.return=l,a.sibling=f,l.child=a,Ql(l,n.child,null,t),a=l.child,a.memoizedState=rT(t),a.childLanes=HT(n,u,t),l.memoizedState=IT,l=ca(null,a));else if(Al(l),uu(f)){if(u=f.nextSibling&&f.nextSibling.dataset,u)var y=u.dgst;u=y,a=Error(i(419)),a.stack="",a.digest=u,Jt({value:a,source:null,stack:null}),l=hT(n,l,t)}else if(Un||At(n,l,t,!1),u=(t&n.childLanes)!==0,Un||u){if(u=Yn,u!==null&&(a=zu(u,t),a!==0&&a!==R.retryLane))throw R.retryLane=a,bl(n,a),T1(u,n,a),XT;Tu(f)||L0(),l=hT(n,l,t)}else Tu(f)?(l.flags|=192,l.child=n.child,l=null):(n=R.treeContext,sn=B1(f.nextSibling),Zn=l,un=!0,il=null,h1=!1,n!==null&&Gi(l,n),l=yT(l,a.children),l.flags|=4096);return l}return e?(Sl(),f=a.fallback,e=l.mode,R=n.child,y=R.sibling,a=Z1(R,{mode:"hidden",children:a.children}),a.subtreeFlags=R.subtreeFlags&65011712,y!==null?f=Z1(y,f):(f=pl(f,e,t,null),f.flags|=2),f.return=l,a.return=l,a.sibling=f,l.child=a,ca(null,a),a=l.child,f=n.child.memoizedState,f===null?f=rT(t):(e=f.cachePool,e!==null?(R=Fn._currentValue,e=e.parent!==R?{parent:R,pool:R}:e):e=Ki(),f={baseLanes:f.baseLanes|t,cachePool:e}),a.memoizedState=f,a.childLanes=HT(n,u,t),l.memoizedState=IT,ca(n.child,a)):(Al(l),t=n.child,n=t.sibling,t=Z1(t,{mode:"visible",children:a.children}),t.return=l,t.sibling=null,n!==null&&(u=l.deletions,u===null?(l.deletions=[n],l.flags|=16):u.push(n)),l.child=t,l.memoizedState=null,t)}function yT(n,l){return l=X0({mode:"visible",children:l},n.mode),l.return=n,n.child=l}function X0(n,l){return n=O1(22,n,null,l),n.lanes=0,n}function hT(n,l,t){return Ql(l,n.child,null,t),n=yT(l,l.pendingProps.children),n.flags|=2,l.memoizedState=null,n}function nc(n,l,t){n.lanes|=l;var a=n.alternate;a!==null&&(a.lanes|=l),Ke(n.return,l,t)}function dT(n,l,t,a,e,T){var u=n.memoizedState;u===null?n.memoizedState={isBackwards:l,rendering:null,renderingStartTime:0,last:a,tail:t,tailMode:e,treeForkCount:T}:(u.isBackwards=l,u.rendering=null,u.renderingStartTime=0,u.last=a,u.tail=t,u.tailMode=e,u.treeForkCount=T)}function lc(n,l,t){var a=l.pendingProps,e=a.revealOrder,T=a.tail;a=a.children;var u=Bn.current,f=(u&2)!==0;if(f?(u=u&1|2,l.flags|=128):u&=1,g(Bn,u),Qn(n,l,a,t),a=un?jt:0,!f&&n!==null&&(n.flags&128)!==0)n:for(n=l.child;n!==null;){if(n.tag===13)n.memoizedState!==null&&nc(n,t,l);else if(n.tag===19)nc(n,t,l);else if(n.child!==null){n.child.return=n,n=n.child;continue}if(n===l)break n;for(;n.sibling===null;){if(n.return===null||n.return===l)break n;n=n.return}n.sibling.return=n.return,n=n.sibling}switch(e){case"forwards":for(t=l.child,e=null;t!==null;)n=t.alternate,n!==null&&c0(n)===null&&(e=t),t=t.sibling;t=e,t===null?(e=l.child,l.child=null):(e=t.sibling,t.sibling=null),dT(l,!1,e,t,T,a);break;case"backwards":case"unstable_legacy-backwards":for(t=null,e=l.child,l.child=null;e!==null;){if(n=e.alternate,n!==null&&c0(n)===null){l.child=e;break}n=e.sibling,e.sibling=t,t=e,e=n}dT(l,!0,t,null,T,a);break;case"together":dT(l,!1,null,null,void 0,a);break;default:l.memoizedState=null}return l.child}function $1(n,l,t){if(n!==null&&(l.dependencies=n.dependencies),Cl|=l.lanes,(t&l.childLanes)===0)if(n!==null){if(At(n,l,t,!1),(t&l.childLanes)===0)return null}else return null;if(n!==null&&l.child!==n.child)throw Error(i(153));if(l.child!==null){for(n=l.child,t=Z1(n,n.pendingProps),l.child=t,t.return=l;n.sibling!==null;)n=n.sibling,t=t.sibling=Z1(n,n.pendingProps),t.return=l;t.sibling=null}return l.child}function BT(n,l){return(n.lanes&l)!==0?!0:(n=n.dependencies,!!(n!==null&&n0(n)))}function oE(n,l,t){switch(l.tag){case 3:jn(l,l.stateNode.containerInfo),fl(l,Fn,n.memoizedState.cache),gl();break;case 27:case 5:Ut(l);break;case 4:jn(l,l.stateNode.containerInfo);break;case 10:fl(l,l.type,l.memoizedProps.value);break;case 31:if(l.memoizedState!==null)return l.flags|=128,ke(l),null;break;case 13:var a=l.memoizedState;if(a!==null)return a.dehydrated!==null?(Al(l),l.flags|=128,null):(t&l.child.childLanes)!==0?k2(n,l,t):(Al(l),n=$1(n,l,t),n!==null?n.sibling:null);Al(l);break;case 19:var e=(n.flags&128)!==0;if(a=(t&l.childLanes)!==0,a||(At(n,l,t,!1),a=(t&l.childLanes)!==0),e){if(a)return lc(n,l,t);l.flags|=128}if(e=l.memoizedState,e!==null&&(e.rendering=null,e.tail=null,e.lastEffect=null),g(Bn,Bn.current),a)break;return null;case 22:return l.lanes=0,W2(n,l,t,l.pendingProps);case 24:fl(l,Fn,n.memoizedState.cache)}return $1(n,l,t)}function tc(n,l,t){if(n!==null)if(n.memoizedProps!==l.pendingProps)Un=!0;else{if(!BT(n,t)&&(l.flags&128)===0)return Un=!1,oE(n,l,t);Un=(n.flags&131072)!==0}else Un=!1,un&&(l.flags&1048576)!==0&&Ui(l,jt,l.index);switch(l.lanes=0,l.tag){case 16:n:{var a=l.pendingProps;if(n=Zl(l.elementType),l.type=n,typeof n=="function")Me(n)?(a=ql(n,a),l.tag=1,l=P2(null,l,n,a,t)):(l.tag=0,l=oT(null,l,n,a,t));else{if(n!=null){var e=n.$$typeof;if(e===rn){l.tag=11,l=Q2(null,l,n,a,t);break n}else if(e===P){l.tag=14,l=V2(null,l,n,a,t);break n}}throw l=s1(n)||n,Error(i(306,l,""))}}return l;case 0:return oT(n,l,l.type,l.pendingProps,t);case 1:return a=l.type,e=ql(a,l.pendingProps),P2(n,l,a,e,t);case 3:n:{if(jn(l,l.stateNode.containerInfo),n===null)throw Error(i(387));a=l.pendingProps;var T=l.memoizedState;e=T.element,$e(n,l),aa(l,a,null,t);var u=l.memoizedState;if(a=u.cache,fl(l,Fn,a),a!==T.cache&&Ze(l,[Fn],t,!0),ta(),a=u.element,T.isDehydrated)if(T={element:a,isDehydrated:!1,cache:u.cache},l.updateQueue.baseState=T,l.memoizedState=T,l.flags&256){l=w2(n,l,a,t);break n}else if(a!==e){e=r1(Error(i(424)),l),Jt(e),l=w2(n,l,a,t);break n}else for(n=l.stateNode.containerInfo,n.nodeType===9?n=n.body:n=n.nodeName==="HTML"?n.ownerDocument.body:n,sn=B1(n.firstChild),Zn=l,un=!0,il=null,h1=!0,t=Wi(l,null,a,t),l.child=t;t;)t.flags=t.flags&-3|4096,t=t.sibling;else{if(gl(),a===e){l=$1(n,l,t);break n}Qn(n,l,a,t)}l=l.child}return l;case 26:return s0(n,l),n===null?(t=Sf(l.type,null,l.pendingProps,null))?l.memoizedState=t:un||(t=l.type,n=l.pendingProps,a=b0(ln.current).createElement(t),a[Kn]=l,a[kn]=n,Vn(a,t,n),gn(a),l.stateNode=a):l.memoizedState=Sf(l.type,n.memoizedProps,l.pendingProps,n.memoizedState),null;case 27:return Ut(l),n===null&&un&&(a=l.stateNode=Ef(l.type,l.pendingProps,ln.current),Zn=l,h1=!0,e=sn,Il(l.type)?(iu=e,sn=B1(a.firstChild)):sn=e),Qn(n,l,l.pendingProps.children,t),s0(n,l),n===null&&(l.flags|=4194304),l.child;case 5:return n===null&&un&&((e=a=sn)&&(a=PE(a,l.type,l.pendingProps,h1),a!==null?(l.stateNode=a,Zn=l,sn=B1(a.firstChild),h1=!1,e=!0):e=!1),e||cl(l)),Ut(l),e=l.type,T=l.pendingProps,u=n!==null?n.memoizedProps:null,a=T.children,tu(e,T)?a=null:u!==null&&tu(e,u)&&(l.flags|=32),l.memoizedState!==null&&(e=lT(n,l,OE,null,null,t),ra._currentValue=e),s0(n,l),Qn(n,l,a,t),l.child;case 6:return n===null&&un&&((n=t=sn)&&(t=wE(t,l.pendingProps,h1),t!==null?(l.stateNode=t,Zn=l,sn=null,n=!0):n=!1),n||cl(l)),null;case 13:return k2(n,l,t);case 4:return jn(l,l.stateNode.containerInfo),a=l.pendingProps,n===null?l.child=Ql(l,null,a,t):Qn(n,l,a,t),l.child;case 11:return Q2(n,l,l.type,l.pendingProps,t);case 7:return Qn(n,l,l.pendingProps,t),l.child;case 8:return Qn(n,l,l.pendingProps.children,t),l.child;case 12:return Qn(n,l,l.pendingProps.children,t),l.child;case 10:return a=l.pendingProps,fl(l,l.type,a.value),Qn(n,l,a.children,t),l.child;case 9:return e=l.type._context,a=l.pendingProps.children,_l(l),e=xn(e),a=a(e),l.flags|=1,Qn(n,l,a,t),l.child;case 14:return V2(n,l,l.type,l.pendingProps,t);case 15:return q2(n,l,l.type,l.pendingProps,t);case 19:return lc(n,l,t);case 31:return XE(n,l,t);case 22:return W2(n,l,t,l.pendingProps);case 24:return _l(l),a=xn(Fn),n===null?(e=Ve(),e===null&&(e=Yn,T=xe(),e.pooledCache=T,T.refCount++,T!==null&&(e.pooledCacheLanes|=t),e=T),l.memoizedState={parent:a,cache:e},We(l),fl(l,Fn,e)):((n.lanes&t)!==0&&($e(n,l),aa(l,null,null,t),ta()),e=n.memoizedState,T=l.memoizedState,e.parent!==a?(e={parent:a,cache:a},l.memoizedState=e,l.lanes===0&&(l.memoizedState=l.updateQueue.baseState=e),fl(l,Fn,a)):(a=T.cache,fl(l,Fn,a),a!==e.cache&&Ze(l,[Fn],t,!0))),Qn(n,l,l.pendingProps.children,t),l.child;case 29:throw l.pendingProps}throw Error(i(156,l.tag))}function j1(n){n.flags|=4}function LT(n,l,t,a,e){if((l=(n.mode&32)!==0)&&(l=!1),l){if(n.flags|=16777216,(e&335544128)===e)if(n.stateNode.complete)n.flags|=8192;else if(Lc())n.flags|=8192;else throw xl=e0,qe}else n.flags&=-16777217}function ac(n,l){if(l.type!=="stylesheet"||(l.state.loading&4)!==0)n.flags&=-16777217;else if(n.flags|=16777216,!sf(l))if(Lc())n.flags|=8192;else throw xl=e0,qe}function o0(n,l){l!==null&&(n.flags|=4),n.flags&16384&&(l=n.tag!==22?bu():536870912,n.lanes|=l,yt|=l)}function fa(n,l){if(!un)switch(n.tailMode){case"hidden":l=n.tail;for(var t=null;l!==null;)l.alternate!==null&&(t=l),l=l.sibling;t===null?n.tail=null:t.sibling=null;break;case"collapsed":t=n.tail;for(var a=null;t!==null;)t.alternate!==null&&(a=t),t=t.sibling;a===null?l||n.tail===null?n.tail=null:n.tail.sibling=null:a.sibling=null}}function Xn(n){var l=n.alternate!==null&&n.alternate.child===n.child,t=0,a=0;if(l)for(var e=n.child;e!==null;)t|=e.lanes|e.childLanes,a|=e.subtreeFlags&65011712,a|=e.flags&65011712,e.return=n,e=e.sibling;else for(e=n.child;e!==null;)t|=e.lanes|e.childLanes,a|=e.subtreeFlags,a|=e.flags,e.return=n,e=e.sibling;return n.subtreeFlags|=a,n.childLanes=t,l}function IE(n,l,t){var a=l.pendingProps;switch(pe(l),l.tag){case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return Xn(l),null;case 1:return Xn(l),null;case 3:return t=l.stateNode,a=null,n!==null&&(a=n.memoizedState.cache),l.memoizedState.cache!==a&&(l.flags|=2048),V1(Fn),dn(),t.pendingContext&&(t.context=t.pendingContext,t.pendingContext=null),(n===null||n.child===null)&&(Ot(l)?j1(l):n===null||n.memoizedState.isDehydrated&&(l.flags&256)===0||(l.flags|=1024,ze())),Xn(l),null;case 26:var e=l.type,T=l.memoizedState;return n===null?(j1(l),T!==null?(Xn(l),ac(l,T)):(Xn(l),LT(l,e,null,a,t))):T?T!==n.memoizedState?(j1(l),Xn(l),ac(l,T)):(Xn(l),l.flags&=-16777217):(n=n.memoizedProps,n!==a&&j1(l),Xn(l),LT(l,e,n,a,t)),null;case 27:if(Fa(l),t=ln.current,e=l.type,n!==null&&l.stateNode!=null)n.memoizedProps!==a&&j1(l);else{if(!a){if(l.stateNode===null)throw Error(i(166));return Xn(l),null}n=K.current,Ot(l)?bi(l):(n=Ef(e,a,t),l.stateNode=n,j1(l))}return Xn(l),null;case 5:if(Fa(l),e=l.type,n!==null&&l.stateNode!=null)n.memoizedProps!==a&&j1(l);else{if(!a){if(l.stateNode===null)throw Error(i(166));return Xn(l),null}if(T=K.current,Ot(l))bi(l);else{var u=b0(ln.current);switch(T){case 1:T=u.createElementNS("http://www.w3.org/2000/svg",e);break;case 2:T=u.createElementNS("http://www.w3.org/1998/Math/MathML",e);break;default:switch(e){case"svg":T=u.createElementNS("http://www.w3.org/2000/svg",e);break;case"math":T=u.createElementNS("http://www.w3.org/1998/Math/MathML",e);break;case"script":T=u.createElement("div"),T.innerHTML="<script><\/script>",T=T.removeChild(T.firstChild);break;case"select":T=typeof a.is=="string"?u.createElement("select",{is:a.is}):u.createElement("select"),a.multiple?T.multiple=!0:a.size&&(T.size=a.size);break;default:T=typeof a.is=="string"?u.createElement(e,{is:a.is}):u.createElement(e)}}T[Kn]=l,T[kn]=a;n:for(u=l.child;u!==null;){if(u.tag===5||u.tag===6)T.appendChild(u.stateNode);else if(u.tag!==4&&u.tag!==27&&u.child!==null){u.child.return=u,u=u.child;continue}if(u===l)break n;for(;u.sibling===null;){if(u.return===null||u.return===l)break n;u=u.return}u.sibling.return=u.return,u=u.sibling}l.stateNode=T;n:switch(Vn(T,e,a),e){case"button":case"input":case"select":case"textarea":a=!!a.autoFocus;break n;case"img":a=!0;break n;default:a=!1}a&&j1(l)}}return Xn(l),LT(l,l.type,n===null?null:n.memoizedProps,l.pendingProps,t),null;case 6:if(n&&l.stateNode!=null)n.memoizedProps!==a&&j1(l);else{if(typeof a!="string"&&l.stateNode===null)throw Error(i(166));if(n=ln.current,Ot(l)){if(n=l.stateNode,t=l.memoizedProps,a=null,e=Zn,e!==null)switch(e.tag){case 27:case 5:a=e.memoizedProps}n[Kn]=l,n=!!(n.nodeValue===t||a!==null&&a.suppressHydrationWarning===!0||kc(n.nodeValue,t)),n||cl(l,!0)}else n=b0(n).createTextNode(a),n[Kn]=l,l.stateNode=n}return Xn(l),null;case 31:if(t=l.memoizedState,n===null||n.memoizedState!==null){if(a=Ot(l),t!==null){if(n===null){if(!a)throw Error(i(318));if(n=l.memoizedState,n=n!==null?n.dehydrated:null,!n)throw Error(i(557));n[Kn]=l}else gl(),(l.flags&128)===0&&(l.memoizedState=null),l.flags|=4;Xn(l),n=!1}else t=ze(),n!==null&&n.memoizedState!==null&&(n.memoizedState.hydrationErrors=t),n=!0;if(!n)return l.flags&256?(S1(l),l):(S1(l),null);if((l.flags&128)!==0)throw Error(i(558))}return Xn(l),null;case 13:if(a=l.memoizedState,n===null||n.memoizedState!==null&&n.memoizedState.dehydrated!==null){if(e=Ot(l),a!==null&&a.dehydrated!==null){if(n===null){if(!e)throw Error(i(318));if(e=l.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(i(317));e[Kn]=l}else gl(),(l.flags&128)===0&&(l.memoizedState=null),l.flags|=4;Xn(l),e=!1}else e=ze(),n!==null&&n.memoizedState!==null&&(n.memoizedState.hydrationErrors=e),e=!0;if(!e)return l.flags&256?(S1(l),l):(S1(l),null)}return S1(l),(l.flags&128)!==0?(l.lanes=t,l):(t=a!==null,n=n!==null&&n.memoizedState!==null,t&&(a=l.child,e=null,a.alternate!==null&&a.alternate.memoizedState!==null&&a.alternate.memoizedState.cachePool!==null&&(e=a.alternate.memoizedState.cachePool.pool),T=null,a.memoizedState!==null&&a.memoizedState.cachePool!==null&&(T=a.memoizedState.cachePool.pool),T!==e&&(a.flags|=2048)),t!==n&&t&&(l.child.flags|=8192),o0(l,l.updateQueue),Xn(l),null);case 4:return dn(),n===null&&PT(l.stateNode.containerInfo),Xn(l),null;case 10:return V1(l.type),Xn(l),null;case 19:if(v(Bn),a=l.memoizedState,a===null)return Xn(l),null;if(e=(l.flags&128)!==0,T=a.rendering,T===null)if(e)fa(a,!1);else{if(hn!==0||n!==null&&(n.flags&128)!==0)for(n=l.child;n!==null;){if(T=c0(n),T!==null){for(l.flags|=128,fa(a,!1),n=T.updateQueue,l.updateQueue=n,o0(l,n),l.subtreeFlags=0,n=t,t=l.child;t!==null;)mi(t,n),t=t.sibling;return g(Bn,Bn.current&1|2),un&&x1(l,a.treeForkCount),l.child}n=n.sibling}a.tail!==null&&c1()>h0&&(l.flags|=128,e=!0,fa(a,!1),l.lanes=4194304)}else{if(!e)if(n=c0(T),n!==null){if(l.flags|=128,e=!0,n=n.updateQueue,l.updateQueue=n,o0(l,n),fa(a,!0),a.tail===null&&a.tailMode==="hidden"&&!T.alternate&&!un)return Xn(l),null}else 2*c1()-a.renderingStartTime>h0&&t!==536870912&&(l.flags|=128,e=!0,fa(a,!1),l.lanes=4194304);a.isBackwards?(T.sibling=l.child,l.child=T):(n=a.last,n!==null?n.sibling=T:l.child=T,a.last=T)}return a.tail!==null?(n=a.tail,a.rendering=n,a.tail=n.sibling,a.renderingStartTime=c1(),n.sibling=null,t=Bn.current,g(Bn,e?t&1|2:t&1),un&&x1(l,a.treeForkCount),n):(Xn(l),null);case 22:case 23:return S1(l),we(),a=l.memoizedState!==null,n!==null?n.memoizedState!==null!==a&&(l.flags|=8192):a&&(l.flags|=8192),a?(t&536870912)!==0&&(l.flags&128)===0&&(Xn(l),l.subtreeFlags&6&&(l.flags|=8192)):Xn(l),t=l.updateQueue,t!==null&&o0(l,t.retryQueue),t=null,n!==null&&n.memoizedState!==null&&n.memoizedState.cachePool!==null&&(t=n.memoizedState.cachePool.pool),a=null,l.memoizedState!==null&&l.memoizedState.cachePool!==null&&(a=l.memoizedState.cachePool.pool),a!==t&&(l.flags|=2048),n!==null&&v(Kl),null;case 24:return t=null,n!==null&&(t=n.memoizedState.cache),l.memoizedState.cache!==t&&(l.flags|=2048),V1(Fn),Xn(l),null;case 25:return null;case 30:return null}throw Error(i(156,l.tag))}function rE(n,l){switch(pe(l),l.tag){case 1:return n=l.flags,n&65536?(l.flags=n&-65537|128,l):null;case 3:return V1(Fn),dn(),n=l.flags,(n&65536)!==0&&(n&128)===0?(l.flags=n&-65537|128,l):null;case 26:case 27:case 5:return Fa(l),null;case 31:if(l.memoizedState!==null){if(S1(l),l.alternate===null)throw Error(i(340));gl()}return n=l.flags,n&65536?(l.flags=n&-65537|128,l):null;case 13:if(S1(l),n=l.memoizedState,n!==null&&n.dehydrated!==null){if(l.alternate===null)throw Error(i(340));gl()}return n=l.flags,n&65536?(l.flags=n&-65537|128,l):null;case 19:return v(Bn),null;case 4:return dn(),null;case 10:return V1(l.type),null;case 22:case 23:return S1(l),we(),n!==null&&v(Kl),n=l.flags,n&65536?(l.flags=n&-65537|128,l):null;case 24:return V1(Fn),null;case 25:return null;default:return null}}function ec(n,l){switch(pe(l),l.tag){case 3:V1(Fn),dn();break;case 26:case 27:case 5:Fa(l);break;case 4:dn();break;case 31:l.memoizedState!==null&&S1(l);break;case 13:S1(l);break;case 19:v(Bn);break;case 10:V1(l.type);break;case 22:case 23:S1(l),we(),n!==null&&v(Kl);break;case 24:V1(Fn)}}function Na(n,l){try{var t=l.updateQueue,a=t!==null?t.lastEffect:null;if(a!==null){var e=a.next;t=e;do{if((t.tag&n)===n){a=void 0;var T=t.create,u=t.inst;a=T(),u.destroy=a}t=t.next}while(t!==e)}}catch(f){An(l,l.return,f)}}function Dl(n,l,t){try{var a=l.updateQueue,e=a!==null?a.lastEffect:null;if(e!==null){var T=e.next;a=T;do{if((a.tag&n)===n){var u=a.inst,f=u.destroy;if(f!==void 0){u.destroy=void 0,e=l;var R=t,y=f;try{y()}catch(B){An(e,R,B)}}}a=a.next}while(a!==T)}}catch(B){An(l,l.return,B)}}function Tc(n){var l=n.updateQueue;if(l!==null){var t=n.stateNode;try{ji(l,t)}catch(a){An(n,n.return,a)}}}function uc(n,l,t){t.props=ql(n.type,n.memoizedProps),t.state=n.memoizedState;try{t.componentWillUnmount()}catch(a){An(n,l,a)}}function Ea(n,l){try{var t=n.ref;if(t!==null){switch(n.tag){case 26:case 27:case 5:var a=n.stateNode;break;case 30:a=n.stateNode;break;default:a=n.stateNode}typeof t=="function"?n.refCleanup=t(a):t.current=a}}catch(e){An(n,l,e)}}function b1(n,l){var t=n.ref,a=n.refCleanup;if(t!==null)if(typeof a=="function")try{a()}catch(e){An(n,l,e)}finally{n.refCleanup=null,n=n.alternate,n!=null&&(n.refCleanup=null)}else if(typeof t=="function")try{t(null)}catch(e){An(n,l,e)}else t.current=null}function ic(n){var l=n.type,t=n.memoizedProps,a=n.stateNode;try{n:switch(l){case"button":case"input":case"select":case"textarea":t.autoFocus&&a.focus();break n;case"img":t.src?a.src=t.src:t.srcSet&&(a.srcset=t.srcSet)}}catch(e){An(n,n.return,e)}}function vT(n,l,t){try{var a=n.stateNode;VE(a,n.type,t,l),a[kn]=l}catch(e){An(n,n.return,e)}}function cc(n){return n.tag===5||n.tag===3||n.tag===26||n.tag===27&&Il(n.type)||n.tag===4}function mT(n){n:for(;;){for(;n.sibling===null;){if(n.return===null||cc(n.return))return null;n=n.return}for(n.sibling.return=n.return,n=n.sibling;n.tag!==5&&n.tag!==6&&n.tag!==18;){if(n.tag===27&&Il(n.type)||n.flags&2||n.child===null||n.tag===4)continue n;n.child.return=n,n=n.child}if(!(n.flags&2))return n.stateNode}}function FT(n,l,t){var a=n.tag;if(a===5||a===6)n=n.stateNode,l?(t.nodeType===9?t.body:t.nodeName==="HTML"?t.ownerDocument.body:t).insertBefore(n,l):(l=t.nodeType===9?t.body:t.nodeName==="HTML"?t.ownerDocument.body:t,l.appendChild(n),t=t._reactRootContainer,t!=null||l.onclick!==null||(l.onclick=_1));else if(a!==4&&(a===27&&Il(n.type)&&(t=n.stateNode,l=null),n=n.child,n!==null))for(FT(n,l,t),n=n.sibling;n!==null;)FT(n,l,t),n=n.sibling}function I0(n,l,t){var a=n.tag;if(a===5||a===6)n=n.stateNode,l?t.insertBefore(n,l):t.appendChild(n);else if(a!==4&&(a===27&&Il(n.type)&&(t=n.stateNode),n=n.child,n!==null))for(I0(n,l,t),n=n.sibling;n!==null;)I0(n,l,t),n=n.sibling}function fc(n){var l=n.stateNode,t=n.memoizedProps;try{for(var a=n.type,e=l.attributes;e.length;)l.removeAttributeNode(e[0]);Vn(l,a,t),l[Kn]=n,l[kn]=t}catch(T){An(n,n.return,T)}}var J1=!1,Gn=!1,MT=!1,Nc=typeof WeakSet=="function"?WeakSet:Set,zn=null;function HE(n,l){if(n=n.containerInfo,nu=x0,n=Ii(n),he(n)){if("selectionStart"in n)var t={start:n.selectionStart,end:n.selectionEnd};else n:{t=(t=n.ownerDocument)&&t.defaultView||window;var a=t.getSelection&&t.getSelection();if(a&&a.rangeCount!==0){t=a.anchorNode;var e=a.anchorOffset,T=a.focusNode;a=a.focusOffset;try{t.nodeType,T.nodeType}catch{t=null;break n}var u=0,f=-1,R=-1,y=0,B=0,F=n,h=null;l:for(;;){for(var d;F!==t||e!==0&&F.nodeType!==3||(f=u+e),F!==T||a!==0&&F.nodeType!==3||(R=u+a),F.nodeType===3&&(u+=F.nodeValue.length),(d=F.firstChild)!==null;)h=F,F=d;for(;;){if(F===n)break l;if(h===t&&++y===e&&(f=u),h===T&&++B===a&&(R=u),(d=F.nextSibling)!==null)break;F=h,h=F.parentNode}F=d}t=f===-1||R===-1?null:{start:f,end:R}}else t=null}t=t||{start:0,end:0}}else t=null;for(lu={focusedElem:n,selectionRange:t},x0=!1,zn=l;zn!==null;)if(l=zn,n=l.child,(l.subtreeFlags&1028)!==0&&n!==null)n.return=l,zn=n;else for(;zn!==null;){switch(l=zn,T=l.alternate,n=l.flags,l.tag){case 0:if((n&4)!==0&&(n=l.updateQueue,n=n!==null?n.events:null,n!==null))for(t=0;t<n.length;t++)e=n[t],e.ref.impl=e.nextImpl;break;case 11:case 15:break;case 1:if((n&1024)!==0&&T!==null){n=void 0,t=l,e=T.memoizedProps,T=T.memoizedState,a=t.stateNode;try{var _=ql(t.type,e);n=a.getSnapshotBeforeUpdate(_,T),a.__reactInternalSnapshotBeforeUpdate=n}catch(V){An(t,t.return,V)}}break;case 3:if((n&1024)!==0){if(n=l.stateNode.containerInfo,t=n.nodeType,t===9)eu(n);else if(t===1)switch(n.nodeName){case"HEAD":case"HTML":case"BODY":eu(n);break;default:n.textContent=""}}break;case 5:case 26:case 27:case 6:case 4:case 17:break;default:if((n&1024)!==0)throw Error(i(163))}if(n=l.sibling,n!==null){n.return=l.return,zn=n;break}zn=l.return}}function Ec(n,l,t){var a=t.flags;switch(t.tag){case 0:case 11:case 15:w1(n,t),a&4&&Na(5,t);break;case 1:if(w1(n,t),a&4)if(n=t.stateNode,l===null)try{n.componentDidMount()}catch(u){An(t,t.return,u)}else{var e=ql(t.type,l.memoizedProps);l=l.memoizedState;try{n.componentDidUpdate(e,l,n.__reactInternalSnapshotBeforeUpdate)}catch(u){An(t,t.return,u)}}a&64&&Tc(t),a&512&&Ea(t,t.return);break;case 3:if(w1(n,t),a&64&&(n=t.updateQueue,n!==null)){if(l=null,t.child!==null)switch(t.child.tag){case 27:case 5:l=t.child.stateNode;break;case 1:l=t.child.stateNode}try{ji(n,l)}catch(u){An(t,t.return,u)}}break;case 27:l===null&&a&4&&fc(t);case 26:case 5:w1(n,t),l===null&&a&4&&ic(t),a&512&&Ea(t,t.return);break;case 12:w1(n,t);break;case 31:w1(n,t),a&4&&Sc(n,t);break;case 13:w1(n,t),a&4&&Dc(n,t),a&64&&(n=t.memoizedState,n!==null&&(n=n.dehydrated,n!==null&&(t=ME.bind(null,t),kE(n,t))));break;case 22:if(a=t.memoizedState!==null||J1,!a){l=l!==null&&l.memoizedState!==null||Gn,e=J1;var T=Gn;J1=a,(Gn=l)&&!T?k1(n,t,(t.subtreeFlags&8772)!==0):w1(n,t),J1=e,Gn=T}break;case 30:break;default:w1(n,t)}}function Oc(n){var l=n.alternate;l!==null&&(n.alternate=null,Oc(l)),n.child=null,n.deletions=null,n.sibling=null,n.tag===5&&(l=n.stateNode,l!==null&&fe(l)),n.stateNode=null,n.return=null,n.dependencies=null,n.memoizedProps=null,n.memoizedState=null,n.pendingProps=null,n.stateNode=null,n.updateQueue=null}var on=null,l1=!1;function P1(n,l,t){for(t=t.child;t!==null;)Ac(n,l,t),t=t.sibling}function Ac(n,l,t){if(f1&&typeof f1.onCommitFiberUnmount=="function")try{f1.onCommitFiberUnmount(Gt,t)}catch{}switch(t.tag){case 26:Gn||b1(t,l),P1(n,l,t),t.memoizedState?t.memoizedState.count--:t.stateNode&&(t=t.stateNode,t.parentNode.removeChild(t));break;case 27:Gn||b1(t,l);var a=on,e=l1;Il(t.type)&&(on=t.stateNode,l1=!1),P1(n,l,t),Xa(t.stateNode),on=a,l1=e;break;case 5:Gn||b1(t,l);case 6:if(a=on,e=l1,on=null,P1(n,l,t),on=a,l1=e,on!==null)if(l1)try{(on.nodeType===9?on.body:on.nodeName==="HTML"?on.ownerDocument.body:on).removeChild(t.stateNode)}catch(T){An(t,l,T)}else try{on.removeChild(t.stateNode)}catch(T){An(t,l,T)}break;case 18:on!==null&&(l1?(n=on,Tf(n.nodeType===9?n.body:n.nodeName==="HTML"?n.ownerDocument.body:n,t.stateNode),Mt(n)):Tf(on,t.stateNode));break;case 4:a=on,e=l1,on=t.stateNode.containerInfo,l1=!0,P1(n,l,t),on=a,l1=e;break;case 0:case 11:case 14:case 15:Dl(2,t,l),Gn||Dl(4,t,l),P1(n,l,t);break;case 1:Gn||(b1(t,l),a=t.stateNode,typeof a.componentWillUnmount=="function"&&uc(t,l,a)),P1(n,l,t);break;case 21:P1(n,l,t);break;case 22:Gn=(a=Gn)||t.memoizedState!==null,P1(n,l,t),Gn=a;break;default:P1(n,l,t)}}function Sc(n,l){if(l.memoizedState===null&&(n=l.alternate,n!==null&&(n=n.memoizedState,n!==null))){n=n.dehydrated;try{Mt(n)}catch(t){An(l,l.return,t)}}}function Dc(n,l){if(l.memoizedState===null&&(n=l.alternate,n!==null&&(n=n.memoizedState,n!==null&&(n=n.dehydrated,n!==null))))try{Mt(n)}catch(t){An(l,l.return,t)}}function yE(n){switch(n.tag){case 31:case 13:case 19:var l=n.stateNode;return l===null&&(l=n.stateNode=new Nc),l;case 22:return n=n.stateNode,l=n._retryCache,l===null&&(l=n._retryCache=new Nc),l;default:throw Error(i(435,n.tag))}}function r0(n,l){var t=yE(n);l.forEach(function(a){if(!t.has(a)){t.add(a);var e=UE.bind(null,n,a);a.then(e,e)}})}function t1(n,l){var t=l.deletions;if(t!==null)for(var a=0;a<t.length;a++){var e=t[a],T=n,u=l,f=u;n:for(;f!==null;){switch(f.tag){case 27:if(Il(f.type)){on=f.stateNode,l1=!1;break n}break;case 5:on=f.stateNode,l1=!1;break n;case 3:case 4:on=f.stateNode.containerInfo,l1=!0;break n}f=f.return}if(on===null)throw Error(i(160));Ac(T,u,e),on=null,l1=!1,T=e.alternate,T!==null&&(T.return=null),e.return=null}if(l.subtreeFlags&13886)for(l=l.child;l!==null;)Rc(l,n),l=l.sibling}var m1=null;function Rc(n,l){var t=n.alternate,a=n.flags;switch(n.tag){case 0:case 11:case 14:case 15:t1(l,n),a1(n),a&4&&(Dl(3,n,n.return),Na(3,n),Dl(5,n,n.return));break;case 1:t1(l,n),a1(n),a&512&&(Gn||t===null||b1(t,t.return)),a&64&&J1&&(n=n.updateQueue,n!==null&&(a=n.callbacks,a!==null&&(t=n.shared.hiddenCallbacks,n.shared.hiddenCallbacks=t===null?a:t.concat(a))));break;case 26:var e=m1;if(t1(l,n),a1(n),a&512&&(Gn||t===null||b1(t,t.return)),a&4){var T=t!==null?t.memoizedState:null;if(a=n.memoizedState,t===null)if(a===null)if(n.stateNode===null){n:{a=n.type,t=n.memoizedProps,e=e.ownerDocument||e;l:switch(a){case"title":T=e.getElementsByTagName("title")[0],(!T||T[gt]||T[Kn]||T.namespaceURI==="http://www.w3.org/2000/svg"||T.hasAttribute("itemprop"))&&(T=e.createElement(a),e.head.insertBefore(T,e.querySelector("head > title"))),Vn(T,a,t),T[Kn]=n,gn(T),a=T;break n;case"link":var u=Cf("link","href",e).get(a+(t.href||""));if(u){for(var f=0;f<u.length;f++)if(T=u[f],T.getAttribute("href")===(t.href==null||t.href===""?null:t.href)&&T.getAttribute("rel")===(t.rel==null?null:t.rel)&&T.getAttribute("title")===(t.title==null?null:t.title)&&T.getAttribute("crossorigin")===(t.crossOrigin==null?null:t.crossOrigin)){u.splice(f,1);break l}}T=e.createElement(a),Vn(T,a,t),e.head.appendChild(T);break;case"meta":if(u=Cf("meta","content",e).get(a+(t.content||""))){for(f=0;f<u.length;f++)if(T=u[f],T.getAttribute("content")===(t.content==null?null:""+t.content)&&T.getAttribute("name")===(t.name==null?null:t.name)&&T.getAttribute("property")===(t.property==null?null:t.property)&&T.getAttribute("http-equiv")===(t.httpEquiv==null?null:t.httpEquiv)&&T.getAttribute("charset")===(t.charSet==null?null:t.charSet)){u.splice(f,1);break l}}T=e.createElement(a),Vn(T,a,t),e.head.appendChild(T);break;default:throw Error(i(468,a))}T[Kn]=n,gn(T),a=T}n.stateNode=a}else Yf(e,n.type,n.stateNode);else n.stateNode=Rf(e,a,n.memoizedProps);else T!==a?(T===null?t.stateNode!==null&&(t=t.stateNode,t.parentNode.removeChild(t)):T.count--,a===null?Yf(e,n.type,n.stateNode):Rf(e,a,n.memoizedProps)):a===null&&n.stateNode!==null&&vT(n,n.memoizedProps,t.memoizedProps)}break;case 27:t1(l,n),a1(n),a&512&&(Gn||t===null||b1(t,t.return)),t!==null&&a&4&&vT(n,n.memoizedProps,t.memoizedProps);break;case 5:if(t1(l,n),a1(n),a&512&&(Gn||t===null||b1(t,t.return)),n.flags&32){e=n.stateNode;try{tt(e,"")}catch(_){An(n,n.return,_)}}a&4&&n.stateNode!=null&&(e=n.memoizedProps,vT(n,e,t!==null?t.memoizedProps:e)),a&1024&&(MT=!0);break;case 6:if(t1(l,n),a1(n),a&4){if(n.stateNode===null)throw Error(i(162));a=n.memoizedProps,t=n.stateNode;try{t.nodeValue=a}catch(_){An(n,n.return,_)}}break;case 3:if(z0=null,e=m1,m1=p0(l.containerInfo),t1(l,n),m1=e,a1(n),a&4&&t!==null&&t.memoizedState.isDehydrated)try{Mt(l.containerInfo)}catch(_){An(n,n.return,_)}MT&&(MT=!1,Cc(n));break;case 4:a=m1,m1=p0(n.stateNode.containerInfo),t1(l,n),a1(n),m1=a;break;case 12:t1(l,n),a1(n);break;case 31:t1(l,n),a1(n),a&4&&(a=n.updateQueue,a!==null&&(n.updateQueue=null,r0(n,a)));break;case 13:t1(l,n),a1(n),n.child.flags&8192&&n.memoizedState!==null!=(t!==null&&t.memoizedState!==null)&&(y0=c1()),a&4&&(a=n.updateQueue,a!==null&&(n.updateQueue=null,r0(n,a)));break;case 22:e=n.memoizedState!==null;var R=t!==null&&t.memoizedState!==null,y=J1,B=Gn;if(J1=y||e,Gn=B||R,t1(l,n),Gn=B,J1=y,a1(n),a&8192)n:for(l=n.stateNode,l._visibility=e?l._visibility&-2:l._visibility|1,e&&(t===null||R||J1||Gn||Wl(n)),t=null,l=n;;){if(l.tag===5||l.tag===26){if(t===null){R=t=l;try{if(T=R.stateNode,e)u=T.style,typeof u.setProperty=="function"?u.setProperty("display","none","important"):u.display="none";else{f=R.stateNode;var F=R.memoizedProps.style,h=F!=null&&F.hasOwnProperty("display")?F.display:null;f.style.display=h==null||typeof h=="boolean"?"":(""+h).trim()}}catch(_){An(R,R.return,_)}}}else if(l.tag===6){if(t===null){R=l;try{R.stateNode.nodeValue=e?"":R.memoizedProps}catch(_){An(R,R.return,_)}}}else if(l.tag===18){if(t===null){R=l;try{var d=R.stateNode;e?uf(d,!0):uf(R.stateNode,!1)}catch(_){An(R,R.return,_)}}}else if((l.tag!==22&&l.tag!==23||l.memoizedState===null||l===n)&&l.child!==null){l.child.return=l,l=l.child;continue}if(l===n)break n;for(;l.sibling===null;){if(l.return===null||l.return===n)break n;t===l&&(t=null),l=l.return}t===l&&(t=null),l.sibling.return=l.return,l=l.sibling}a&4&&(a=n.updateQueue,a!==null&&(t=a.retryQueue,t!==null&&(a.retryQueue=null,r0(n,t))));break;case 19:t1(l,n),a1(n),a&4&&(a=n.updateQueue,a!==null&&(n.updateQueue=null,r0(n,a)));break;case 30:break;case 21:break;default:t1(l,n),a1(n)}}function a1(n){var l=n.flags;if(l&2){try{for(var t,a=n.return;a!==null;){if(cc(a)){t=a;break}a=a.return}if(t==null)throw Error(i(160));switch(t.tag){case 27:var e=t.stateNode,T=mT(n);I0(n,T,e);break;case 5:var u=t.stateNode;t.flags&32&&(tt(u,""),t.flags&=-33);var f=mT(n);I0(n,f,u);break;case 3:case 4:var R=t.stateNode.containerInfo,y=mT(n);FT(n,y,R);break;default:throw Error(i(161))}}catch(B){An(n,n.return,B)}n.flags&=-3}l&4096&&(n.flags&=-4097)}function Cc(n){if(n.subtreeFlags&1024)for(n=n.child;n!==null;){var l=n;Cc(l),l.tag===5&&l.flags&1024&&l.stateNode.reset(),n=n.sibling}}function w1(n,l){if(l.subtreeFlags&8772)for(l=l.child;l!==null;)Ec(n,l.alternate,l),l=l.sibling}function Wl(n){for(n=n.child;n!==null;){var l=n;switch(l.tag){case 0:case 11:case 14:case 15:Dl(4,l,l.return),Wl(l);break;case 1:b1(l,l.return);var t=l.stateNode;typeof t.componentWillUnmount=="function"&&uc(l,l.return,t),Wl(l);break;case 27:Xa(l.stateNode);case 26:case 5:b1(l,l.return),Wl(l);break;case 22:l.memoizedState===null&&Wl(l);break;case 30:Wl(l);break;default:Wl(l)}n=n.sibling}}function k1(n,l,t){for(t=t&&(l.subtreeFlags&8772)!==0,l=l.child;l!==null;){var a=l.alternate,e=n,T=l,u=T.flags;switch(T.tag){case 0:case 11:case 15:k1(e,T,t),Na(4,T);break;case 1:if(k1(e,T,t),a=T,e=a.stateNode,typeof e.componentDidMount=="function")try{e.componentDidMount()}catch(y){An(a,a.return,y)}if(a=T,e=a.updateQueue,e!==null){var f=a.stateNode;try{var R=e.shared.hiddenCallbacks;if(R!==null)for(e.shared.hiddenCallbacks=null,e=0;e<R.length;e++)$i(R[e],f)}catch(y){An(a,a.return,y)}}t&&u&64&&Tc(T),Ea(T,T.return);break;case 27:fc(T);case 26:case 5:k1(e,T,t),t&&a===null&&u&4&&ic(T),Ea(T,T.return);break;case 12:k1(e,T,t);break;case 31:k1(e,T,t),t&&u&4&&Sc(e,T);break;case 13:k1(e,T,t),t&&u&4&&Dc(e,T);break;case 22:T.memoizedState===null&&k1(e,T,t),Ea(T,T.return);break;case 30:break;default:k1(e,T,t)}l=l.sibling}}function UT(n,l){var t=null;n!==null&&n.memoizedState!==null&&n.memoizedState.cachePool!==null&&(t=n.memoizedState.cachePool.pool),n=null,l.memoizedState!==null&&l.memoizedState.cachePool!==null&&(n=l.memoizedState.cachePool.pool),n!==t&&(n!=null&&n.refCount++,t!=null&&Pt(t))}function GT(n,l){n=null,l.alternate!==null&&(n=l.alternate.memoizedState.cache),l=l.memoizedState.cache,l!==n&&(l.refCount++,n!=null&&Pt(n))}function F1(n,l,t,a){if(l.subtreeFlags&10256)for(l=l.child;l!==null;)Yc(n,l,t,a),l=l.sibling}function Yc(n,l,t,a){var e=l.flags;switch(l.tag){case 0:case 11:case 15:F1(n,l,t,a),e&2048&&Na(9,l);break;case 1:F1(n,l,t,a);break;case 3:F1(n,l,t,a),e&2048&&(n=null,l.alternate!==null&&(n=l.alternate.memoizedState.cache),l=l.memoizedState.cache,l!==n&&(l.refCount++,n!=null&&Pt(n)));break;case 12:if(e&2048){F1(n,l,t,a),n=l.stateNode;try{var T=l.memoizedProps,u=T.id,f=T.onPostCommit;typeof f=="function"&&f(u,l.alternate===null?"mount":"update",n.passiveEffectDuration,-0)}catch(R){An(l,l.return,R)}}else F1(n,l,t,a);break;case 31:F1(n,l,t,a);break;case 13:F1(n,l,t,a);break;case 23:break;case 22:T=l.stateNode,u=l.alternate,l.memoizedState!==null?T._visibility&2?F1(n,l,t,a):Oa(n,l):T._visibility&2?F1(n,l,t,a):(T._visibility|=2,It(n,l,t,a,(l.subtreeFlags&10256)!==0||!1)),e&2048&&UT(u,l);break;case 24:F1(n,l,t,a),e&2048&&GT(l.alternate,l);break;default:F1(n,l,t,a)}}function It(n,l,t,a,e){for(e=e&&((l.subtreeFlags&10256)!==0||!1),l=l.child;l!==null;){var T=n,u=l,f=t,R=a,y=u.flags;switch(u.tag){case 0:case 11:case 15:It(T,u,f,R,e),Na(8,u);break;case 23:break;case 22:var B=u.stateNode;u.memoizedState!==null?B._visibility&2?It(T,u,f,R,e):Oa(T,u):(B._visibility|=2,It(T,u,f,R,e)),e&&y&2048&&UT(u.alternate,u);break;case 24:It(T,u,f,R,e),e&&y&2048&&GT(u.alternate,u);break;default:It(T,u,f,R,e)}l=l.sibling}}function Oa(n,l){if(l.subtreeFlags&10256)for(l=l.child;l!==null;){var t=n,a=l,e=a.flags;switch(a.tag){case 22:Oa(t,a),e&2048&&UT(a.alternate,a);break;case 24:Oa(t,a),e&2048&&GT(a.alternate,a);break;default:Oa(t,a)}l=l.sibling}}var Aa=8192;function rt(n,l,t){if(n.subtreeFlags&Aa)for(n=n.child;n!==null;)sc(n,l,t),n=n.sibling}function sc(n,l,t){switch(n.tag){case 26:rt(n,l,t),n.flags&Aa&&n.memoizedState!==null&&EO(t,m1,n.memoizedState,n.memoizedProps);break;case 5:rt(n,l,t);break;case 3:case 4:var a=m1;m1=p0(n.stateNode.containerInfo),rt(n,l,t),m1=a;break;case 22:n.memoizedState===null&&(a=n.alternate,a!==null&&a.memoizedState!==null?(a=Aa,Aa=16777216,rt(n,l,t),Aa=a):rt(n,l,t));break;default:rt(n,l,t)}}function Xc(n){var l=n.alternate;if(l!==null&&(n=l.child,n!==null)){l.child=null;do l=n.sibling,n.sibling=null,n=l;while(n!==null)}}function Sa(n){var l=n.deletions;if((n.flags&16)!==0){if(l!==null)for(var t=0;t<l.length;t++){var a=l[t];zn=a,Ic(a,n)}Xc(n)}if(n.subtreeFlags&10256)for(n=n.child;n!==null;)oc(n),n=n.sibling}function oc(n){switch(n.tag){case 0:case 11:case 15:Sa(n),n.flags&2048&&Dl(9,n,n.return);break;case 3:Sa(n);break;case 12:Sa(n);break;case 22:var l=n.stateNode;n.memoizedState!==null&&l._visibility&2&&(n.return===null||n.return.tag!==13)?(l._visibility&=-3,H0(n)):Sa(n);break;default:Sa(n)}}function H0(n){var l=n.deletions;if((n.flags&16)!==0){if(l!==null)for(var t=0;t<l.length;t++){var a=l[t];zn=a,Ic(a,n)}Xc(n)}for(n=n.child;n!==null;){switch(l=n,l.tag){case 0:case 11:case 15:Dl(8,l,l.return),H0(l);break;case 22:t=l.stateNode,t._visibility&2&&(t._visibility&=-3,H0(l));break;default:H0(l)}n=n.sibling}}function Ic(n,l){for(;zn!==null;){var t=zn;switch(t.tag){case 0:case 11:case 15:Dl(8,t,l);break;case 23:case 22:if(t.memoizedState!==null&&t.memoizedState.cachePool!==null){var a=t.memoizedState.cachePool.pool;a!=null&&a.refCount++}break;case 24:Pt(t.memoizedState.cache)}if(a=t.child,a!==null)a.return=t,zn=a;else n:for(t=n;zn!==null;){a=zn;var e=a.sibling,T=a.return;if(Oc(a),a===t){zn=null;break n}if(e!==null){e.return=T,zn=e;break n}zn=T}}}var hE={getCacheForType:function(n){var l=xn(Fn),t=l.data.get(n);return t===void 0&&(t=n(),l.data.set(n,t)),t},cacheSignal:function(){return xn(Fn).controller.signal}},dE=typeof WeakMap=="function"?WeakMap:Map,Nn=0,Yn=null,tn=null,en=0,On=0,D1=null,Rl=!1,Ht=!1,bT=!1,nl=0,hn=0,Cl=0,$l=0,pT=0,R1=0,yt=0,Da=null,e1=null,gT=!1,y0=0,rc=0,h0=1/0,d0=null,Yl=null,bn=0,sl=null,ht=null,ll=0,zT=0,_T=null,Hc=null,Ra=0,KT=null;function C1(){return(Nn&2)!==0&&en!==0?en&-en:L.T!==null?WT():_u()}function yc(){if(R1===0)if((en&536870912)===0||un){var n=Ga;Ga<<=1,(Ga&3932160)===0&&(Ga=262144),R1=n}else R1=536870912;return n=A1.current,n!==null&&(n.flags|=32),R1}function T1(n,l,t){(n===Yn&&(On===2||On===9)||n.cancelPendingCommit!==null)&&(dt(n,0),Xl(n,en,R1,!1)),pt(n,t),((Nn&2)===0||n!==Yn)&&(n===Yn&&((Nn&2)===0&&($l|=t),hn===4&&Xl(n,en,R1,!1)),p1(n))}function hc(n,l,t){if((Nn&6)!==0)throw Error(i(327));var a=!t&&(l&127)===0&&(l&n.expiredLanes)===0||bt(n,l),e=a?vE(n,l):xT(n,l,!0),T=a;do{if(e===0){Ht&&!a&&Xl(n,l,0,!1);break}else{if(t=n.current.alternate,T&&!BE(t)){e=xT(n,l,!1),T=!1;continue}if(e===2){if(T=l,n.errorRecoveryDisabledLanes&T)var u=0;else u=n.pendingLanes&-536870913,u=u!==0?u:u&536870912?536870912:0;if(u!==0){l=u;n:{var f=n;e=Da;var R=f.current.memoizedState.isDehydrated;if(R&&(dt(f,u).flags|=256),u=xT(f,u,!1),u!==2){if(bT&&!R){f.errorRecoveryDisabledLanes|=T,$l|=T,e=4;break n}T=e1,e1=e,T!==null&&(e1===null?e1=T:e1.push.apply(e1,T))}e=u}if(T=!1,e!==2)continue}}if(e===1){dt(n,0),Xl(n,l,0,!0);break}n:{switch(a=n,T=e,T){case 0:case 1:throw Error(i(345));case 4:if((l&4194048)!==l)break;case 6:Xl(a,l,R1,!Rl);break n;case 2:e1=null;break;case 3:case 5:break;default:throw Error(i(329))}if((l&62914560)===l&&(e=y0+300-c1(),10<e)){if(Xl(a,l,R1,!Rl),pa(a,0,!0)!==0)break n;ll=l,a.timeoutHandle=af(dc.bind(null,a,t,e1,d0,gT,l,R1,$l,yt,Rl,T,"Throttled",-0,0),e);break n}dc(a,t,e1,d0,gT,l,R1,$l,yt,Rl,T,null,-0,0)}}break}while(!0);p1(n)}function dc(n,l,t,a,e,T,u,f,R,y,B,F,h,d){if(n.timeoutHandle=-1,F=l.subtreeFlags,F&8192||(F&16785408)===16785408){F={stylesheets:null,count:0,imgCount:0,imgBytes:0,suspenseyImages:[],waitingForImages:!0,waitingForViewTransition:!1,unsuspend:_1},sc(l,T,F);var _=(T&62914560)===T?y0-c1():(T&4194048)===T?rc-c1():0;if(_=OO(F,_),_!==null){ll=T,n.cancelPendingCommit=_(Gc.bind(null,n,l,T,t,a,e,u,f,R,B,F,null,h,d)),Xl(n,T,u,!y);return}}Gc(n,l,T,t,a,e,u,f,R)}function BE(n){for(var l=n;;){var t=l.tag;if((t===0||t===11||t===15)&&l.flags&16384&&(t=l.updateQueue,t!==null&&(t=t.stores,t!==null)))for(var a=0;a<t.length;a++){var e=t[a],T=e.getSnapshot;e=e.value;try{if(!E1(T(),e))return!1}catch{return!1}}if(t=l.child,l.subtreeFlags&16384&&t!==null)t.return=l,l=t;else{if(l===n)break;for(;l.sibling===null;){if(l.return===null||l.return===n)return!0;l=l.return}l.sibling.return=l.return,l=l.sibling}}return!0}function Xl(n,l,t,a){l&=~pT,l&=~$l,n.suspendedLanes|=l,n.pingedLanes&=~l,a&&(n.warmLanes|=l),a=n.expirationTimes;for(var e=l;0<e;){var T=31-N1(e),u=1<<T;a[T]=-1,e&=~u}t!==0&&pu(n,t,l)}function B0(){return(Nn&6)===0?(Ca(0),!1):!0}function ZT(){if(tn!==null){if(On===0)var n=tn.return;else n=tn,Q1=zl=null,eT(n),Ct=null,kt=0,n=tn;for(;n!==null;)ec(n.alternate,n),n=n.return;tn=null}}function dt(n,l){var t=n.timeoutHandle;t!==-1&&(n.timeoutHandle=-1,$E(t)),t=n.cancelPendingCommit,t!==null&&(n.cancelPendingCommit=null,t()),ll=0,ZT(),Yn=n,tn=t=Z1(n.current,null),en=l,On=0,D1=null,Rl=!1,Ht=bt(n,l),bT=!1,yt=R1=pT=$l=Cl=hn=0,e1=Da=null,gT=!1,(l&8)!==0&&(l|=l&32);var a=n.entangledLanes;if(a!==0)for(n=n.entanglements,a&=l;0<a;){var e=31-N1(a),T=1<<e;l|=n[e],a&=~T}return nl=l,ja(),t}function Bc(n,l){j=null,L.H=ia,l===Rt||l===a0?(l=Qi(),On=3):l===qe?(l=Qi(),On=4):On=l===XT?8:l!==null&&typeof l=="object"&&typeof l.then=="function"?6:1,D1=l,tn===null&&(hn=1,C0(n,r1(l,n.current)))}function Lc(){var n=A1.current;return n===null?!0:(en&4194048)===en?d1===null:(en&62914560)===en||(en&536870912)!==0?n===d1:!1}function vc(){var n=L.H;return L.H=ia,n===null?ia:n}function mc(){var n=L.A;return L.A=hE,n}function L0(){hn=4,Rl||(en&4194048)!==en&&A1.current!==null||(Ht=!0),(Cl&134217727)===0&&($l&134217727)===0||Yn===null||Xl(Yn,en,R1,!1)}function xT(n,l,t){var a=Nn;Nn|=2;var e=vc(),T=mc();(Yn!==n||en!==l)&&(d0=null,dt(n,l)),l=!1;var u=hn;n:do try{if(On!==0&&tn!==null){var f=tn,R=D1;switch(On){case 8:ZT(),u=6;break n;case 3:case 2:case 9:case 6:A1.current===null&&(l=!0);var y=On;if(On=0,D1=null,Bt(n,f,R,y),t&&Ht){u=0;break n}break;default:y=On,On=0,D1=null,Bt(n,f,R,y)}}LE(),u=hn;break}catch(B){Bc(n,B)}while(!0);return l&&n.shellSuspendCounter++,Q1=zl=null,Nn=a,L.H=e,L.A=T,tn===null&&(Yn=null,en=0,ja()),u}function LE(){for(;tn!==null;)Fc(tn)}function vE(n,l){var t=Nn;Nn|=2;var a=vc(),e=mc();Yn!==n||en!==l?(d0=null,h0=c1()+500,dt(n,l)):Ht=bt(n,l);n:do try{if(On!==0&&tn!==null){l=tn;var T=D1;l:switch(On){case 1:On=0,D1=null,Bt(n,l,T,1);break;case 2:case 9:if(Zi(T)){On=0,D1=null,Mc(l);break}l=function(){On!==2&&On!==9||Yn!==n||(On=7),p1(n)},T.then(l,l);break n;case 3:On=7;break n;case 4:On=5;break n;case 7:Zi(T)?(On=0,D1=null,Mc(l)):(On=0,D1=null,Bt(n,l,T,7));break;case 5:var u=null;switch(tn.tag){case 26:u=tn.memoizedState;case 5:case 27:var f=tn;if(u?sf(u):f.stateNode.complete){On=0,D1=null;var R=f.sibling;if(R!==null)tn=R;else{var y=f.return;y!==null?(tn=y,v0(y)):tn=null}break l}}On=0,D1=null,Bt(n,l,T,5);break;case 6:On=0,D1=null,Bt(n,l,T,6);break;case 8:ZT(),hn=6;break n;default:throw Error(i(462))}}mE();break}catch(B){Bc(n,B)}while(!0);return Q1=zl=null,L.H=a,L.A=e,Nn=t,tn!==null?0:(Yn=null,en=0,ja(),hn)}function mE(){for(;tn!==null&&!nN();)Fc(tn)}function Fc(n){var l=tc(n.alternate,n,nl);n.memoizedProps=n.pendingProps,l===null?v0(n):tn=l}function Mc(n){var l=n,t=l.alternate;switch(l.tag){case 15:case 0:l=J2(t,l,l.pendingProps,l.type,void 0,en);break;case 11:l=J2(t,l,l.pendingProps,l.type.render,l.ref,en);break;case 5:eT(l);default:ec(t,l),l=tn=mi(l,nl),l=tc(t,l,nl)}n.memoizedProps=n.pendingProps,l===null?v0(n):tn=l}function Bt(n,l,t,a){Q1=zl=null,eT(l),Ct=null,kt=0;var e=l.return;try{if(sE(n,e,l,t,en)){hn=1,C0(n,r1(t,n.current)),tn=null;return}}catch(T){if(e!==null)throw tn=e,T;hn=1,C0(n,r1(t,n.current)),tn=null;return}l.flags&32768?(un||a===1?n=!0:Ht||(en&536870912)!==0?n=!1:(Rl=n=!0,(a===2||a===9||a===3||a===6)&&(a=A1.current,a!==null&&a.tag===13&&(a.flags|=16384))),Uc(l,n)):v0(l)}function v0(n){var l=n;do{if((l.flags&32768)!==0){Uc(l,Rl);return}n=l.return;var t=IE(l.alternate,l,nl);if(t!==null){tn=t;return}if(l=l.sibling,l!==null){tn=l;return}tn=l=n}while(l!==null);hn===0&&(hn=5)}function Uc(n,l){do{var t=rE(n.alternate,n);if(t!==null){t.flags&=32767,tn=t;return}if(t=n.return,t!==null&&(t.flags|=32768,t.subtreeFlags=0,t.deletions=null),!l&&(n=n.sibling,n!==null)){tn=n;return}tn=n=t}while(n!==null);hn=6,tn=null}function Gc(n,l,t,a,e,T,u,f,R){n.cancelPendingCommit=null;do m0();while(bn!==0);if((Nn&6)!==0)throw Error(i(327));if(l!==null){if(l===n.current)throw Error(i(177));if(T=l.lanes|l.childLanes,T|=me,NN(n,t,T,u,f,R),n===Yn&&(tn=Yn=null,en=0),ht=l,sl=n,ll=t,zT=T,_T=e,Hc=a,(l.subtreeFlags&10256)!==0||(l.flags&10256)!==0?(n.callbackNode=null,n.callbackPriority=0,GE(Ma,function(){return _c(),null})):(n.callbackNode=null,n.callbackPriority=0),a=(l.flags&13878)!==0,(l.subtreeFlags&13878)!==0||a){a=L.T,L.T=null,e=G.p,G.p=2,u=Nn,Nn|=4;try{HE(n,l,t)}finally{Nn=u,G.p=e,L.T=a}}bn=1,bc(),pc(),gc()}}function bc(){if(bn===1){bn=0;var n=sl,l=ht,t=(l.flags&13878)!==0;if((l.subtreeFlags&13878)!==0||t){t=L.T,L.T=null;var a=G.p;G.p=2;var e=Nn;Nn|=4;try{Rc(l,n);var T=lu,u=Ii(n.containerInfo),f=T.focusedElem,R=T.selectionRange;if(u!==f&&f&&f.ownerDocument&&oi(f.ownerDocument.documentElement,f)){if(R!==null&&he(f)){var y=R.start,B=R.end;if(B===void 0&&(B=y),"selectionStart"in f)f.selectionStart=y,f.selectionEnd=Math.min(B,f.value.length);else{var F=f.ownerDocument||document,h=F&&F.defaultView||window;if(h.getSelection){var d=h.getSelection(),_=f.textContent.length,V=Math.min(R.start,_),Rn=R.end===void 0?V:Math.min(R.end,_);!d.extend&&V>Rn&&(u=Rn,Rn=V,V=u);var X=Xi(f,V),s=Xi(f,Rn);if(X&&s&&(d.rangeCount!==1||d.anchorNode!==X.node||d.anchorOffset!==X.offset||d.focusNode!==s.node||d.focusOffset!==s.offset)){var H=F.createRange();H.setStart(X.node,X.offset),d.removeAllRanges(),V>Rn?(d.addRange(H),d.extend(s.node,s.offset)):(H.setEnd(s.node,s.offset),d.addRange(H))}}}}for(F=[],d=f;d=d.parentNode;)d.nodeType===1&&F.push({element:d,left:d.scrollLeft,top:d.scrollTop});for(typeof f.focus=="function"&&f.focus(),f=0;f<F.length;f++){var m=F[f];m.element.scrollLeft=m.left,m.element.scrollTop=m.top}}x0=!!nu,lu=nu=null}finally{Nn=e,G.p=a,L.T=t}}n.current=l,bn=2}}function pc(){if(bn===2){bn=0;var n=sl,l=ht,t=(l.flags&8772)!==0;if((l.subtreeFlags&8772)!==0||t){t=L.T,L.T=null;var a=G.p;G.p=2;var e=Nn;Nn|=4;try{Ec(n,l.alternate,l)}finally{Nn=e,G.p=a,L.T=t}}bn=3}}function gc(){if(bn===4||bn===3){bn=0,lN();var n=sl,l=ht,t=ll,a=Hc;(l.subtreeFlags&10256)!==0||(l.flags&10256)!==0?bn=5:(bn=0,ht=sl=null,zc(n,n.pendingLanes));var e=n.pendingLanes;if(e===0&&(Yl=null),ie(t),l=l.stateNode,f1&&typeof f1.onCommitFiberRoot=="function")try{f1.onCommitFiberRoot(Gt,l,void 0,(l.current.flags&128)===128)}catch{}if(a!==null){l=L.T,e=G.p,G.p=2,L.T=null;try{for(var T=n.onRecoverableError,u=0;u<a.length;u++){var f=a[u];T(f.value,{componentStack:f.stack})}}finally{L.T=l,G.p=e}}(ll&3)!==0&&m0(),p1(n),e=n.pendingLanes,(t&261930)!==0&&(e&42)!==0?n===KT?Ra++:(Ra=0,KT=n):Ra=0,Ca(0)}}function zc(n,l){(n.pooledCacheLanes&=l)===0&&(l=n.pooledCache,l!=null&&(n.pooledCache=null,Pt(l)))}function m0(){return bc(),pc(),gc(),_c()}function _c(){if(bn!==5)return!1;var n=sl,l=zT;zT=0;var t=ie(ll),a=L.T,e=G.p;try{G.p=32>t?32:t,L.T=null,t=_T,_T=null;var T=sl,u=ll;if(bn=0,ht=sl=null,ll=0,(Nn&6)!==0)throw Error(i(331));var f=Nn;if(Nn|=4,oc(T.current),Yc(T,T.current,u,t),Nn=f,Ca(0,!1),f1&&typeof f1.onPostCommitFiberRoot=="function")try{f1.onPostCommitFiberRoot(Gt,T)}catch{}return!0}finally{G.p=e,L.T=a,zc(n,l)}}function Kc(n,l,t){l=r1(t,l),l=sT(n.stateNode,l,2),n=Ol(n,l,2),n!==null&&(pt(n,2),p1(n))}function An(n,l,t){if(n.tag===3)Kc(n,n,t);else for(;l!==null;){if(l.tag===3){Kc(l,n,t);break}else if(l.tag===1){var a=l.stateNode;if(typeof l.type.getDerivedStateFromError=="function"||typeof a.componentDidCatch=="function"&&(Yl===null||!Yl.has(a))){n=r1(t,n),t=Z2(2),a=Ol(l,t,2),a!==null&&(x2(t,a,l,n),pt(a,2),p1(a));break}}l=l.return}}function QT(n,l,t){var a=n.pingCache;if(a===null){a=n.pingCache=new dE;var e=new Set;a.set(l,e)}else e=a.get(l),e===void 0&&(e=new Set,a.set(l,e));e.has(t)||(bT=!0,e.add(t),n=FE.bind(null,n,l,t),l.then(n,n))}function FE(n,l,t){var a=n.pingCache;a!==null&&a.delete(l),n.pingedLanes|=n.suspendedLanes&t,n.warmLanes&=~t,Yn===n&&(en&t)===t&&(hn===4||hn===3&&(en&62914560)===en&&300>c1()-y0?(Nn&2)===0&&dt(n,0):pT|=t,yt===en&&(yt=0)),p1(n)}function Zc(n,l){l===0&&(l=bu()),n=bl(n,l),n!==null&&(pt(n,l),p1(n))}function ME(n){var l=n.memoizedState,t=0;l!==null&&(t=l.retryLane),Zc(n,t)}function UE(n,l){var t=0;switch(n.tag){case 31:case 13:var a=n.stateNode,e=n.memoizedState;e!==null&&(t=e.retryLane);break;case 19:a=n.stateNode;break;case 22:a=n.stateNode._retryCache;break;default:throw Error(i(314))}a!==null&&a.delete(l),Zc(n,t)}function GE(n,l){return ae(n,l)}var F0=null,Lt=null,VT=!1,M0=!1,qT=!1,ol=0;function p1(n){n!==Lt&&n.next===null&&(Lt===null?F0=Lt=n:Lt=Lt.next=n),M0=!0,VT||(VT=!0,pE())}function Ca(n,l){if(!qT&&M0){qT=!0;do for(var t=!1,a=F0;a!==null;){if(n!==0){var e=a.pendingLanes;if(e===0)var T=0;else{var u=a.suspendedLanes,f=a.pingedLanes;T=(1<<31-N1(42|n)+1)-1,T&=e&~(u&~f),T=T&201326741?T&201326741|1:T?T|2:0}T!==0&&(t=!0,qc(a,T))}else T=en,T=pa(a,a===Yn?T:0,a.cancelPendingCommit!==null||a.timeoutHandle!==-1),(T&3)===0||bt(a,T)||(t=!0,qc(a,T));a=a.next}while(t);qT=!1}}function bE(){xc()}function xc(){M0=VT=!1;var n=0;ol!==0&&WE()&&(n=ol);for(var l=c1(),t=null,a=F0;a!==null;){var e=a.next,T=Qc(a,l);T===0?(a.next=null,t===null?F0=e:t.next=e,e===null&&(Lt=t)):(t=a,(n!==0||(T&3)!==0)&&(M0=!0)),a=e}bn!==0&&bn!==5||Ca(n),ol!==0&&(ol=0)}function Qc(n,l){for(var t=n.suspendedLanes,a=n.pingedLanes,e=n.expirationTimes,T=n.pendingLanes&-62914561;0<T;){var u=31-N1(T),f=1<<u,R=e[u];R===-1?((f&t)===0||(f&a)!==0)&&(e[u]=fN(f,l)):R<=l&&(n.expiredLanes|=f),T&=~f}if(l=Yn,t=en,t=pa(n,n===l?t:0,n.cancelPendingCommit!==null||n.timeoutHandle!==-1),a=n.callbackNode,t===0||n===l&&(On===2||On===9)||n.cancelPendingCommit!==null)return a!==null&&a!==null&&ee(a),n.callbackNode=null,n.callbackPriority=0;if((t&3)===0||bt(n,t)){if(l=t&-t,l===n.callbackPriority)return l;switch(a!==null&&ee(a),ie(t)){case 2:case 8:t=Uu;break;case 32:t=Ma;break;case 268435456:t=Gu;break;default:t=Ma}return a=Vc.bind(null,n),t=ae(t,a),n.callbackPriority=l,n.callbackNode=t,l}return a!==null&&a!==null&&ee(a),n.callbackPriority=2,n.callbackNode=null,2}function Vc(n,l){if(bn!==0&&bn!==5)return n.callbackNode=null,n.callbackPriority=0,null;var t=n.callbackNode;if(m0()&&n.callbackNode!==t)return null;var a=en;return a=pa(n,n===Yn?a:0,n.cancelPendingCommit!==null||n.timeoutHandle!==-1),a===0?null:(hc(n,a,l),Qc(n,c1()),n.callbackNode!=null&&n.callbackNode===t?Vc.bind(null,n):null)}function qc(n,l){if(m0())return null;hc(n,l,!0)}function pE(){jE(function(){(Nn&6)!==0?ae(Mu,bE):xc()})}function WT(){if(ol===0){var n=St;n===0&&(n=Ua,Ua<<=1,(Ua&261888)===0&&(Ua=256)),ol=n}return ol}function Wc(n){return n==null||typeof n=="symbol"||typeof n=="boolean"?null:typeof n=="function"?n:Ka(""+n)}function $c(n,l){var t=l.ownerDocument.createElement("input");return t.name=l.name,t.value=l.value,n.id&&t.setAttribute("form",n.id),l.parentNode.insertBefore(t,l),n=new FormData(n),t.parentNode.removeChild(t),n}function gE(n,l,t,a,e){if(l==="submit"&&t&&t.stateNode===e){var T=Wc((e[kn]||null).action),u=a.submitter;u&&(l=(l=u[kn]||null)?Wc(l.formAction):u.getAttribute("formAction"),l!==null&&(T=l,u=null));var f=new Va("action","action",null,a,e);n.push({event:f,listeners:[{instance:null,listener:function(){if(a.defaultPrevented){if(ol!==0){var R=u?$c(e,u):new FormData(e);AT(t,{pending:!0,data:R,method:e.method,action:T},null,R)}}else typeof T=="function"&&(f.preventDefault(),R=u?$c(e,u):new FormData(e),AT(t,{pending:!0,data:R,method:e.method,action:T},T,R))},currentTarget:e}]})}}for(var $T=0;$T<ve.length;$T++){var jT=ve[$T],zE=jT.toLowerCase(),_E=jT[0].toUpperCase()+jT.slice(1);v1(zE,"on"+_E)}v1(yi,"onAnimationEnd"),v1(hi,"onAnimationIteration"),v1(di,"onAnimationStart"),v1("dblclick","onDoubleClick"),v1("focusin","onFocus"),v1("focusout","onBlur"),v1(tE,"onTransitionRun"),v1(aE,"onTransitionStart"),v1(eE,"onTransitionCancel"),v1(Bi,"onTransitionEnd"),nt("onMouseEnter",["mouseout","mouseover"]),nt("onMouseLeave",["mouseout","mouseover"]),nt("onPointerEnter",["pointerout","pointerover"]),nt("onPointerLeave",["pointerout","pointerover"]),Fl("onChange","change click focusin focusout input keydown keyup selectionchange".split(" ")),Fl("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" ")),Fl("onBeforeInput",["compositionend","keypress","textInput","paste"]),Fl("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" ")),Fl("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" ")),Fl("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var Ya="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),KE=new Set("beforetoggle cancel close invalid load scroll scrollend toggle".split(" ").concat(Ya));function jc(n,l){l=(l&4)!==0;for(var t=0;t<n.length;t++){var a=n[t],e=a.event;a=a.listeners;n:{var T=void 0;if(l)for(var u=a.length-1;0<=u;u--){var f=a[u],R=f.instance,y=f.currentTarget;if(f=f.listener,R!==T&&e.isPropagationStopped())break n;T=f,e.currentTarget=y;try{T(e)}catch(B){$a(B)}e.currentTarget=null,T=R}else for(u=0;u<a.length;u++){if(f=a[u],R=f.instance,y=f.currentTarget,f=f.listener,R!==T&&e.isPropagationStopped())break n;T=f,e.currentTarget=y;try{T(e)}catch(B){$a(B)}e.currentTarget=null,T=R}}}}function an(n,l){var t=l[ce];t===void 0&&(t=l[ce]=new Set);var a=n+"__bubble";t.has(a)||(Jc(l,n,2,!1),t.add(a))}function JT(n,l,t){var a=0;l&&(a|=4),Jc(t,n,a,l)}var U0="_reactListening"+Math.random().toString(36).slice(2);function PT(n){if(!n[U0]){n[U0]=!0,xu.forEach(function(t){t!=="selectionchange"&&(KE.has(t)||JT(t,!1,n),JT(t,!0,n))});var l=n.nodeType===9?n:n.ownerDocument;l===null||l[U0]||(l[U0]=!0,JT("selectionchange",!1,l))}}function Jc(n,l,t,a){switch(hf(l)){case 2:var e=DO;break;case 8:e=RO;break;default:e=Ou}t=e.bind(null,l,t,n),e=void 0,!Ce||l!=="touchstart"&&l!=="touchmove"&&l!=="wheel"||(e=!0),a?e!==void 0?n.addEventListener(l,t,{capture:!0,passive:e}):n.addEventListener(l,t,!0):e!==void 0?n.addEventListener(l,t,{passive:e}):n.addEventListener(l,t,!1)}function wT(n,l,t,a,e){var T=a;if((l&1)===0&&(l&2)===0&&a!==null)n:for(;;){if(a===null)return;var u=a.tag;if(u===3||u===4){var f=a.stateNode.containerInfo;if(f===e)break;if(u===4)for(u=a.return;u!==null;){var R=u.tag;if((R===3||R===4)&&u.stateNode.containerInfo===e)return;u=u.return}for(;f!==null;){if(u=Pl(f),u===null)return;if(R=u.tag,R===5||R===6||R===26||R===27){a=T=u;continue n}f=f.parentNode}}a=a.return}li(function(){var y=T,B=De(t),F=[];n:{var h=Li.get(n);if(h!==void 0){var d=Va,_=n;switch(n){case"keypress":if(xa(t)===0)break n;case"keydown":case"keyup":d=UN;break;case"focusin":_="focus",d=oe;break;case"focusout":_="blur",d=oe;break;case"beforeblur":case"afterblur":d=oe;break;case"click":if(t.button===2)break n;case"auxclick":case"dblclick":case"mousedown":case"mousemove":case"mouseup":case"mouseout":case"mouseover":case"contextmenu":d=ei;break;case"drag":case"dragend":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"dragstart":case"drop":d=IN;break;case"touchcancel":case"touchend":case"touchmove":case"touchstart":d=pN;break;case yi:case hi:case di:d=yN;break;case Bi:d=zN;break;case"scroll":case"scrollend":d=XN;break;case"wheel":d=KN;break;case"copy":case"cut":case"paste":d=dN;break;case"gotpointercapture":case"lostpointercapture":case"pointercancel":case"pointerdown":case"pointermove":case"pointerout":case"pointerover":case"pointerup":d=ui;break;case"toggle":case"beforetoggle":d=xN}var V=(l&4)!==0,Rn=!V&&(n==="scroll"||n==="scrollend"),X=V?h!==null?h+"Capture":null:h;V=[];for(var s=y,H;s!==null;){var m=s;if(H=m.stateNode,m=m.tag,m!==5&&m!==26&&m!==27||H===null||X===null||(m=_t(s,X),m!=null&&V.push(sa(s,m,H))),Rn)break;s=s.return}0<V.length&&(h=new d(h,_,null,t,B),F.push({event:h,listeners:V}))}}if((l&7)===0){n:{if(h=n==="mouseover"||n==="pointerover",d=n==="mouseout"||n==="pointerout",h&&t!==Se&&(_=t.relatedTarget||t.fromElement)&&(Pl(_)||_[Jl]))break n;if((d||h)&&(h=B.window===B?B:(h=B.ownerDocument)?h.defaultView||h.parentWindow:window,d?(_=t.relatedTarget||t.toElement,d=y,_=_?Pl(_):null,_!==null&&(Rn=c(_),V=_.tag,_!==Rn||V!==5&&V!==27&&V!==6)&&(_=null)):(d=null,_=y),d!==_)){if(V=ei,m="onMouseLeave",X="onMouseEnter",s="mouse",(n==="pointerout"||n==="pointerover")&&(V=ui,m="onPointerLeave",X="onPointerEnter",s="pointer"),Rn=d==null?h:zt(d),H=_==null?h:zt(_),h=new V(m,s+"leave",d,t,B),h.target=Rn,h.relatedTarget=H,m=null,Pl(B)===y&&(V=new V(X,s+"enter",_,t,B),V.target=H,V.relatedTarget=Rn,m=V),Rn=m,d&&_)l:{for(V=ZE,X=d,s=_,H=0,m=X;m;m=V(m))H++;m=0;for(var Q=s;Q;Q=V(Q))m++;for(;0<H-m;)X=V(X),H--;for(;0<m-H;)s=V(s),m--;for(;H--;){if(X===s||s!==null&&X===s.alternate){V=X;break l}X=V(X),s=V(s)}V=null}else V=null;d!==null&&Pc(F,h,d,V,!1),_!==null&&Rn!==null&&Pc(F,Rn,_,V,!0)}}n:{if(h=y?zt(y):window,d=h.nodeName&&h.nodeName.toLowerCase(),d==="select"||d==="input"&&h.type==="file")var cn=Si;else if(Oi(h))if(Di)cn=kN;else{cn=PN;var Z=JN}else d=h.nodeName,!d||d.toLowerCase()!=="input"||h.type!=="checkbox"&&h.type!=="radio"?y&&Ae(y.elementType)&&(cn=Si):cn=wN;if(cn&&(cn=cn(n,y))){Ai(F,cn,t,B);break n}Z&&Z(n,h,y),n==="focusout"&&y&&h.type==="number"&&y.memoizedProps.value!=null&&Oe(h,"number",h.value)}switch(Z=y?zt(y):window,n){case"focusin":(Oi(Z)||Z.contentEditable==="true")&&(ut=Z,de=y,$t=null);break;case"focusout":$t=de=ut=null;break;case"mousedown":Be=!0;break;case"contextmenu":case"mouseup":case"dragend":Be=!1,ri(F,t,B);break;case"selectionchange":if(lE)break;case"keydown":case"keyup":ri(F,t,B)}var J;if(re)n:{switch(n){case"compositionstart":var Tn="onCompositionStart";break n;case"compositionend":Tn="onCompositionEnd";break n;case"compositionupdate":Tn="onCompositionUpdate";break n}Tn=void 0}else Tt?Ni(n,t)&&(Tn="onCompositionEnd"):n==="keydown"&&t.keyCode===229&&(Tn="onCompositionStart");Tn&&(ii&&t.locale!=="ko"&&(Tt||Tn!=="onCompositionStart"?Tn==="onCompositionEnd"&&Tt&&(J=ti()):(Tl=B,Ye="value"in Tl?Tl.value:Tl.textContent,Tt=!0)),Z=G0(y,Tn),0<Z.length&&(Tn=new Ti(Tn,n,null,t,B),F.push({event:Tn,listeners:Z}),J?Tn.data=J:(J=Ei(t),J!==null&&(Tn.data=J)))),(J=VN?qN(n,t):WN(n,t))&&(Tn=G0(y,"onBeforeInput"),0<Tn.length&&(Z=new Ti("onBeforeInput","beforeinput",null,t,B),F.push({event:Z,listeners:Tn}),Z.data=J)),gE(F,n,y,t,B)}jc(F,l)})}function sa(n,l,t){return{instance:n,listener:l,currentTarget:t}}function G0(n,l){for(var t=l+"Capture",a=[];n!==null;){var e=n,T=e.stateNode;if(e=e.tag,e!==5&&e!==26&&e!==27||T===null||(e=_t(n,t),e!=null&&a.unshift(sa(n,e,T)),e=_t(n,l),e!=null&&a.push(sa(n,e,T))),n.tag===3)return a;n=n.return}return[]}function ZE(n){if(n===null)return null;do n=n.return;while(n&&n.tag!==5&&n.tag!==27);return n||null}function Pc(n,l,t,a,e){for(var T=l._reactName,u=[];t!==null&&t!==a;){var f=t,R=f.alternate,y=f.stateNode;if(f=f.tag,R!==null&&R===a)break;f!==5&&f!==26&&f!==27||y===null||(R=y,e?(y=_t(t,T),y!=null&&u.unshift(sa(t,y,R))):e||(y=_t(t,T),y!=null&&u.push(sa(t,y,R)))),t=t.return}u.length!==0&&n.push({event:l,listeners:u})}var xE=/\r\n?/g,QE=/\u0000|\uFFFD/g;function wc(n){return(typeof n=="string"?n:""+n).replace(xE,`
`).replace(QE,"")}function kc(n,l){return l=wc(l),wc(n)===l}function Dn(n,l,t,a,e,T){switch(t){case"children":typeof a=="string"?l==="body"||l==="textarea"&&a===""||tt(n,a):(typeof a=="number"||typeof a=="bigint")&&l!=="body"&&tt(n,""+a);break;case"className":za(n,"class",a);break;case"tabIndex":za(n,"tabindex",a);break;case"dir":case"role":case"viewBox":case"width":case"height":za(n,t,a);break;case"style":ku(n,a,T);break;case"data":if(l!=="object"){za(n,"data",a);break}case"src":case"href":if(a===""&&(l!=="a"||t!=="href")){n.removeAttribute(t);break}if(a==null||typeof a=="function"||typeof a=="symbol"||typeof a=="boolean"){n.removeAttribute(t);break}a=Ka(""+a),n.setAttribute(t,a);break;case"action":case"formAction":if(typeof a=="function"){n.setAttribute(t,"javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')");break}else typeof T=="function"&&(t==="formAction"?(l!=="input"&&Dn(n,l,"name",e.name,e,null),Dn(n,l,"formEncType",e.formEncType,e,null),Dn(n,l,"formMethod",e.formMethod,e,null),Dn(n,l,"formTarget",e.formTarget,e,null)):(Dn(n,l,"encType",e.encType,e,null),Dn(n,l,"method",e.method,e,null),Dn(n,l,"target",e.target,e,null)));if(a==null||typeof a=="symbol"||typeof a=="boolean"){n.removeAttribute(t);break}a=Ka(""+a),n.setAttribute(t,a);break;case"onClick":a!=null&&(n.onclick=_1);break;case"onScroll":a!=null&&an("scroll",n);break;case"onScrollEnd":a!=null&&an("scrollend",n);break;case"dangerouslySetInnerHTML":if(a!=null){if(typeof a!="object"||!("__html"in a))throw Error(i(61));if(t=a.__html,t!=null){if(e.children!=null)throw Error(i(60));n.innerHTML=t}}break;case"multiple":n.multiple=a&&typeof a!="function"&&typeof a!="symbol";break;case"muted":n.muted=a&&typeof a!="function"&&typeof a!="symbol";break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"defaultValue":case"defaultChecked":case"innerHTML":case"ref":break;case"autoFocus":break;case"xlinkHref":if(a==null||typeof a=="function"||typeof a=="boolean"||typeof a=="symbol"){n.removeAttribute("xlink:href");break}t=Ka(""+a),n.setAttributeNS("http://www.w3.org/1999/xlink","xlink:href",t);break;case"contentEditable":case"spellCheck":case"draggable":case"value":case"autoReverse":case"externalResourcesRequired":case"focusable":case"preserveAlpha":a!=null&&typeof a!="function"&&typeof a!="symbol"?n.setAttribute(t,""+a):n.removeAttribute(t);break;case"inert":case"allowFullScreen":case"async":case"autoPlay":case"controls":case"default":case"defer":case"disabled":case"disablePictureInPicture":case"disableRemotePlayback":case"formNoValidate":case"hidden":case"loop":case"noModule":case"noValidate":case"open":case"playsInline":case"readOnly":case"required":case"reversed":case"scoped":case"seamless":case"itemScope":a&&typeof a!="function"&&typeof a!="symbol"?n.setAttribute(t,""):n.removeAttribute(t);break;case"capture":case"download":a===!0?n.setAttribute(t,""):a!==!1&&a!=null&&typeof a!="function"&&typeof a!="symbol"?n.setAttribute(t,a):n.removeAttribute(t);break;case"cols":case"rows":case"size":case"span":a!=null&&typeof a!="function"&&typeof a!="symbol"&&!isNaN(a)&&1<=a?n.setAttribute(t,a):n.removeAttribute(t);break;case"rowSpan":case"start":a==null||typeof a=="function"||typeof a=="symbol"||isNaN(a)?n.removeAttribute(t):n.setAttribute(t,a);break;case"popover":an("beforetoggle",n),an("toggle",n),ga(n,"popover",a);break;case"xlinkActuate":z1(n,"http://www.w3.org/1999/xlink","xlink:actuate",a);break;case"xlinkArcrole":z1(n,"http://www.w3.org/1999/xlink","xlink:arcrole",a);break;case"xlinkRole":z1(n,"http://www.w3.org/1999/xlink","xlink:role",a);break;case"xlinkShow":z1(n,"http://www.w3.org/1999/xlink","xlink:show",a);break;case"xlinkTitle":z1(n,"http://www.w3.org/1999/xlink","xlink:title",a);break;case"xlinkType":z1(n,"http://www.w3.org/1999/xlink","xlink:type",a);break;case"xmlBase":z1(n,"http://www.w3.org/XML/1998/namespace","xml:base",a);break;case"xmlLang":z1(n,"http://www.w3.org/XML/1998/namespace","xml:lang",a);break;case"xmlSpace":z1(n,"http://www.w3.org/XML/1998/namespace","xml:space",a);break;case"is":ga(n,"is",a);break;case"innerText":case"textContent":break;default:(!(2<t.length)||t[0]!=="o"&&t[0]!=="O"||t[1]!=="n"&&t[1]!=="N")&&(t=YN.get(t)||t,ga(n,t,a))}}function kT(n,l,t,a,e,T){switch(t){case"style":ku(n,a,T);break;case"dangerouslySetInnerHTML":if(a!=null){if(typeof a!="object"||!("__html"in a))throw Error(i(61));if(t=a.__html,t!=null){if(e.children!=null)throw Error(i(60));n.innerHTML=t}}break;case"children":typeof a=="string"?tt(n,a):(typeof a=="number"||typeof a=="bigint")&&tt(n,""+a);break;case"onScroll":a!=null&&an("scroll",n);break;case"onScrollEnd":a!=null&&an("scrollend",n);break;case"onClick":a!=null&&(n.onclick=_1);break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"innerHTML":case"ref":break;case"innerText":case"textContent":break;default:if(!Qu.hasOwnProperty(t))n:{if(t[0]==="o"&&t[1]==="n"&&(e=t.endsWith("Capture"),l=t.slice(2,e?t.length-7:void 0),T=n[kn]||null,T=T!=null?T[t]:null,typeof T=="function"&&n.removeEventListener(l,T,e),typeof a=="function")){typeof T!="function"&&T!==null&&(t in n?n[t]=null:n.hasAttribute(t)&&n.removeAttribute(t)),n.addEventListener(l,a,e);break n}t in n?n[t]=a:a===!0?n.setAttribute(t,""):ga(n,t,a)}}}function Vn(n,l,t){switch(l){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"img":an("error",n),an("load",n);var a=!1,e=!1,T;for(T in t)if(t.hasOwnProperty(T)){var u=t[T];if(u!=null)switch(T){case"src":a=!0;break;case"srcSet":e=!0;break;case"children":case"dangerouslySetInnerHTML":throw Error(i(137,l));default:Dn(n,l,T,u,t,null)}}e&&Dn(n,l,"srcSet",t.srcSet,t,null),a&&Dn(n,l,"src",t.src,t,null);return;case"input":an("invalid",n);var f=T=u=e=null,R=null,y=null;for(a in t)if(t.hasOwnProperty(a)){var B=t[a];if(B!=null)switch(a){case"name":e=B;break;case"type":u=B;break;case"checked":R=B;break;case"defaultChecked":y=B;break;case"value":T=B;break;case"defaultValue":f=B;break;case"children":case"dangerouslySetInnerHTML":if(B!=null)throw Error(i(137,l));break;default:Dn(n,l,a,B,t,null)}}ju(n,T,f,R,y,u,e,!1);return;case"select":an("invalid",n),a=u=T=null;for(e in t)if(t.hasOwnProperty(e)&&(f=t[e],f!=null))switch(e){case"value":T=f;break;case"defaultValue":u=f;break;case"multiple":a=f;default:Dn(n,l,e,f,t,null)}l=T,t=u,n.multiple=!!a,l!=null?lt(n,!!a,l,!1):t!=null&&lt(n,!!a,t,!0);return;case"textarea":an("invalid",n),T=e=a=null;for(u in t)if(t.hasOwnProperty(u)&&(f=t[u],f!=null))switch(u){case"value":a=f;break;case"defaultValue":e=f;break;case"children":T=f;break;case"dangerouslySetInnerHTML":if(f!=null)throw Error(i(91));break;default:Dn(n,l,u,f,t,null)}Pu(n,a,e,T);return;case"option":for(R in t)t.hasOwnProperty(R)&&(a=t[R],a!=null)&&(R==="selected"?n.selected=a&&typeof a!="function"&&typeof a!="symbol":Dn(n,l,R,a,t,null));return;case"dialog":an("beforetoggle",n),an("toggle",n),an("cancel",n),an("close",n);break;case"iframe":case"object":an("load",n);break;case"video":case"audio":for(a=0;a<Ya.length;a++)an(Ya[a],n);break;case"image":an("error",n),an("load",n);break;case"details":an("toggle",n);break;case"embed":case"source":case"link":an("error",n),an("load",n);case"area":case"base":case"br":case"col":case"hr":case"keygen":case"meta":case"param":case"track":case"wbr":case"menuitem":for(y in t)if(t.hasOwnProperty(y)&&(a=t[y],a!=null))switch(y){case"children":case"dangerouslySetInnerHTML":throw Error(i(137,l));default:Dn(n,l,y,a,t,null)}return;default:if(Ae(l)){for(B in t)t.hasOwnProperty(B)&&(a=t[B],a!==void 0&&kT(n,l,B,a,t,void 0));return}}for(f in t)t.hasOwnProperty(f)&&(a=t[f],a!=null&&Dn(n,l,f,a,t,null))}function VE(n,l,t,a){switch(l){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"input":var e=null,T=null,u=null,f=null,R=null,y=null,B=null;for(d in t){var F=t[d];if(t.hasOwnProperty(d)&&F!=null)switch(d){case"checked":break;case"value":break;case"defaultValue":R=F;default:a.hasOwnProperty(d)||Dn(n,l,d,null,a,F)}}for(var h in a){var d=a[h];if(F=t[h],a.hasOwnProperty(h)&&(d!=null||F!=null))switch(h){case"type":T=d;break;case"name":e=d;break;case"checked":y=d;break;case"defaultChecked":B=d;break;case"value":u=d;break;case"defaultValue":f=d;break;case"children":case"dangerouslySetInnerHTML":if(d!=null)throw Error(i(137,l));break;default:d!==F&&Dn(n,l,h,d,a,F)}}Ee(n,u,f,R,y,B,T,e);return;case"select":d=u=f=h=null;for(T in t)if(R=t[T],t.hasOwnProperty(T)&&R!=null)switch(T){case"value":break;case"multiple":d=R;default:a.hasOwnProperty(T)||Dn(n,l,T,null,a,R)}for(e in a)if(T=a[e],R=t[e],a.hasOwnProperty(e)&&(T!=null||R!=null))switch(e){case"value":h=T;break;case"defaultValue":f=T;break;case"multiple":u=T;default:T!==R&&Dn(n,l,e,T,a,R)}l=f,t=u,a=d,h!=null?lt(n,!!t,h,!1):!!a!=!!t&&(l!=null?lt(n,!!t,l,!0):lt(n,!!t,t?[]:"",!1));return;case"textarea":d=h=null;for(f in t)if(e=t[f],t.hasOwnProperty(f)&&e!=null&&!a.hasOwnProperty(f))switch(f){case"value":break;case"children":break;default:Dn(n,l,f,null,a,e)}for(u in a)if(e=a[u],T=t[u],a.hasOwnProperty(u)&&(e!=null||T!=null))switch(u){case"value":h=e;break;case"defaultValue":d=e;break;case"children":break;case"dangerouslySetInnerHTML":if(e!=null)throw Error(i(91));break;default:e!==T&&Dn(n,l,u,e,a,T)}Ju(n,h,d);return;case"option":for(var _ in t)h=t[_],t.hasOwnProperty(_)&&h!=null&&!a.hasOwnProperty(_)&&(_==="selected"?n.selected=!1:Dn(n,l,_,null,a,h));for(R in a)h=a[R],d=t[R],a.hasOwnProperty(R)&&h!==d&&(h!=null||d!=null)&&(R==="selected"?n.selected=h&&typeof h!="function"&&typeof h!="symbol":Dn(n,l,R,h,a,d));return;case"img":case"link":case"area":case"base":case"br":case"col":case"embed":case"hr":case"keygen":case"meta":case"param":case"source":case"track":case"wbr":case"menuitem":for(var V in t)h=t[V],t.hasOwnProperty(V)&&h!=null&&!a.hasOwnProperty(V)&&Dn(n,l,V,null,a,h);for(y in a)if(h=a[y],d=t[y],a.hasOwnProperty(y)&&h!==d&&(h!=null||d!=null))switch(y){case"children":case"dangerouslySetInnerHTML":if(h!=null)throw Error(i(137,l));break;default:Dn(n,l,y,h,a,d)}return;default:if(Ae(l)){for(var Rn in t)h=t[Rn],t.hasOwnProperty(Rn)&&h!==void 0&&!a.hasOwnProperty(Rn)&&kT(n,l,Rn,void 0,a,h);for(B in a)h=a[B],d=t[B],!a.hasOwnProperty(B)||h===d||h===void 0&&d===void 0||kT(n,l,B,h,a,d);return}}for(var X in t)h=t[X],t.hasOwnProperty(X)&&h!=null&&!a.hasOwnProperty(X)&&Dn(n,l,X,null,a,h);for(F in a)h=a[F],d=t[F],!a.hasOwnProperty(F)||h===d||h==null&&d==null||Dn(n,l,F,h,a,d)}function nf(n){switch(n){case"css":case"script":case"font":case"img":case"image":case"input":case"link":return!0;default:return!1}}function qE(){if(typeof performance.getEntriesByType=="function"){for(var n=0,l=0,t=performance.getEntriesByType("resource"),a=0;a<t.length;a++){var e=t[a],T=e.transferSize,u=e.initiatorType,f=e.duration;if(T&&f&&nf(u)){for(u=0,f=e.responseEnd,a+=1;a<t.length;a++){var R=t[a],y=R.startTime;if(y>f)break;var B=R.transferSize,F=R.initiatorType;B&&nf(F)&&(R=R.responseEnd,u+=B*(R<f?1:(f-y)/(R-y)))}if(--a,l+=8*(T+u)/(e.duration/1e3),n++,10<n)break}}if(0<n)return l/n/1e6}return navigator.connection&&(n=navigator.connection.downlink,typeof n=="number")?n:5}var nu=null,lu=null;function b0(n){return n.nodeType===9?n:n.ownerDocument}function lf(n){switch(n){case"http://www.w3.org/2000/svg":return 1;case"http://www.w3.org/1998/Math/MathML":return 2;default:return 0}}function tf(n,l){if(n===0)switch(l){case"svg":return 1;case"math":return 2;default:return 0}return n===1&&l==="foreignObject"?0:n}function tu(n,l){return n==="textarea"||n==="noscript"||typeof l.children=="string"||typeof l.children=="number"||typeof l.children=="bigint"||typeof l.dangerouslySetInnerHTML=="object"&&l.dangerouslySetInnerHTML!==null&&l.dangerouslySetInnerHTML.__html!=null}var au=null;function WE(){var n=window.event;return n&&n.type==="popstate"?n===au?!1:(au=n,!0):(au=null,!1)}var af=typeof setTimeout=="function"?setTimeout:void 0,$E=typeof clearTimeout=="function"?clearTimeout:void 0,ef=typeof Promise=="function"?Promise:void 0,jE=typeof queueMicrotask=="function"?queueMicrotask:typeof ef<"u"?function(n){return ef.resolve(null).then(n).catch(JE)}:af;function JE(n){setTimeout(function(){throw n})}function Il(n){return n==="head"}function Tf(n,l){var t=l,a=0;do{var e=t.nextSibling;if(n.removeChild(t),e&&e.nodeType===8)if(t=e.data,t==="/$"||t==="/&"){if(a===0){n.removeChild(e),Mt(l);return}a--}else if(t==="$"||t==="$?"||t==="$~"||t==="$!"||t==="&")a++;else if(t==="html")Xa(n.ownerDocument.documentElement);else if(t==="head"){t=n.ownerDocument.head,Xa(t);for(var T=t.firstChild;T;){var u=T.nextSibling,f=T.nodeName;T[gt]||f==="SCRIPT"||f==="STYLE"||f==="LINK"&&T.rel.toLowerCase()==="stylesheet"||t.removeChild(T),T=u}}else t==="body"&&Xa(n.ownerDocument.body);t=e}while(t);Mt(l)}function uf(n,l){var t=n;n=0;do{var a=t.nextSibling;if(t.nodeType===1?l?(t._stashedDisplay=t.style.display,t.style.display="none"):(t.style.display=t._stashedDisplay||"",t.getAttribute("style")===""&&t.removeAttribute("style")):t.nodeType===3&&(l?(t._stashedText=t.nodeValue,t.nodeValue=""):t.nodeValue=t._stashedText||""),a&&a.nodeType===8)if(t=a.data,t==="/$"){if(n===0)break;n--}else t!=="$"&&t!=="$?"&&t!=="$~"&&t!=="$!"||n++;t=a}while(t)}function eu(n){var l=n.firstChild;for(l&&l.nodeType===10&&(l=l.nextSibling);l;){var t=l;switch(l=l.nextSibling,t.nodeName){case"HTML":case"HEAD":case"BODY":eu(t),fe(t);continue;case"SCRIPT":case"STYLE":continue;case"LINK":if(t.rel.toLowerCase()==="stylesheet")continue}n.removeChild(t)}}function PE(n,l,t,a){for(;n.nodeType===1;){var e=t;if(n.nodeName.toLowerCase()!==l.toLowerCase()){if(!a&&(n.nodeName!=="INPUT"||n.type!=="hidden"))break}else if(a){if(!n[gt])switch(l){case"meta":if(!n.hasAttribute("itemprop"))break;return n;case"link":if(T=n.getAttribute("rel"),T==="stylesheet"&&n.hasAttribute("data-precedence"))break;if(T!==e.rel||n.getAttribute("href")!==(e.href==null||e.href===""?null:e.href)||n.getAttribute("crossorigin")!==(e.crossOrigin==null?null:e.crossOrigin)||n.getAttribute("title")!==(e.title==null?null:e.title))break;return n;case"style":if(n.hasAttribute("data-precedence"))break;return n;case"script":if(T=n.getAttribute("src"),(T!==(e.src==null?null:e.src)||n.getAttribute("type")!==(e.type==null?null:e.type)||n.getAttribute("crossorigin")!==(e.crossOrigin==null?null:e.crossOrigin))&&T&&n.hasAttribute("async")&&!n.hasAttribute("itemprop"))break;return n;default:return n}}else if(l==="input"&&n.type==="hidden"){var T=e.name==null?null:""+e.name;if(e.type==="hidden"&&n.getAttribute("name")===T)return n}else return n;if(n=B1(n.nextSibling),n===null)break}return null}function wE(n,l,t){if(l==="")return null;for(;n.nodeType!==3;)if((n.nodeType!==1||n.nodeName!=="INPUT"||n.type!=="hidden")&&!t||(n=B1(n.nextSibling),n===null))return null;return n}function cf(n,l){for(;n.nodeType!==8;)if((n.nodeType!==1||n.nodeName!=="INPUT"||n.type!=="hidden")&&!l||(n=B1(n.nextSibling),n===null))return null;return n}function Tu(n){return n.data==="$?"||n.data==="$~"}function uu(n){return n.data==="$!"||n.data==="$?"&&n.ownerDocument.readyState!=="loading"}function kE(n,l){var t=n.ownerDocument;if(n.data==="$~")n._reactRetry=l;else if(n.data!=="$?"||t.readyState!=="loading")l();else{var a=function(){l(),t.removeEventListener("DOMContentLoaded",a)};t.addEventListener("DOMContentLoaded",a),n._reactRetry=a}}function B1(n){for(;n!=null;n=n.nextSibling){var l=n.nodeType;if(l===1||l===3)break;if(l===8){if(l=n.data,l==="$"||l==="$!"||l==="$?"||l==="$~"||l==="&"||l==="F!"||l==="F")break;if(l==="/$"||l==="/&")return null}}return n}var iu=null;function ff(n){n=n.nextSibling;for(var l=0;n;){if(n.nodeType===8){var t=n.data;if(t==="/$"||t==="/&"){if(l===0)return B1(n.nextSibling);l--}else t!=="$"&&t!=="$!"&&t!=="$?"&&t!=="$~"&&t!=="&"||l++}n=n.nextSibling}return null}function Nf(n){n=n.previousSibling;for(var l=0;n;){if(n.nodeType===8){var t=n.data;if(t==="$"||t==="$!"||t==="$?"||t==="$~"||t==="&"){if(l===0)return n;l--}else t!=="/$"&&t!=="/&"||l++}n=n.previousSibling}return null}function Ef(n,l,t){switch(l=b0(t),n){case"html":if(n=l.documentElement,!n)throw Error(i(452));return n;case"head":if(n=l.head,!n)throw Error(i(453));return n;case"body":if(n=l.body,!n)throw Error(i(454));return n;default:throw Error(i(451))}}function Xa(n){for(var l=n.attributes;l.length;)n.removeAttributeNode(l[0]);fe(n)}var L1=new Map,Of=new Set;function p0(n){return typeof n.getRootNode=="function"?n.getRootNode():n.nodeType===9?n:n.ownerDocument}var tl=G.d;G.d={f:nO,r:lO,D:tO,C:aO,L:eO,m:TO,X:iO,S:uO,M:cO};function nO(){var n=tl.f(),l=B0();return n||l}function lO(n){var l=wl(n);l!==null&&l.tag===5&&l.type==="form"?B2(l):tl.r(n)}var vt=typeof document>"u"?null:document;function Af(n,l,t){var a=vt;if(a&&typeof l=="string"&&l){var e=o1(l);e='link[rel="'+n+'"][href="'+e+'"]',typeof t=="string"&&(e+='[crossorigin="'+t+'"]'),Of.has(e)||(Of.add(e),n={rel:n,crossOrigin:t,href:l},a.querySelector(e)===null&&(l=a.createElement("link"),Vn(l,"link",n),gn(l),a.head.appendChild(l)))}}function tO(n){tl.D(n),Af("dns-prefetch",n,null)}function aO(n,l){tl.C(n,l),Af("preconnect",n,l)}function eO(n,l,t){tl.L(n,l,t);var a=vt;if(a&&n&&l){var e='link[rel="preload"][as="'+o1(l)+'"]';l==="image"&&t&&t.imageSrcSet?(e+='[imagesrcset="'+o1(t.imageSrcSet)+'"]',typeof t.imageSizes=="string"&&(e+='[imagesizes="'+o1(t.imageSizes)+'"]')):e+='[href="'+o1(n)+'"]';var T=e;switch(l){case"style":T=mt(n);break;case"script":T=Ft(n)}L1.has(T)||(n=o({rel:"preload",href:l==="image"&&t&&t.imageSrcSet?void 0:n,as:l},t),L1.set(T,n),a.querySelector(e)!==null||l==="style"&&a.querySelector(oa(T))||l==="script"&&a.querySelector(Ia(T))||(l=a.createElement("link"),Vn(l,"link",n),gn(l),a.head.appendChild(l)))}}function TO(n,l){tl.m(n,l);var t=vt;if(t&&n){var a=l&&typeof l.as=="string"?l.as:"script",e='link[rel="modulepreload"][as="'+o1(a)+'"][href="'+o1(n)+'"]',T=e;switch(a){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":T=Ft(n)}if(!L1.has(T)&&(n=o({rel:"modulepreload",href:n},l),L1.set(T,n),t.querySelector(e)===null)){switch(a){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":if(t.querySelector(Ia(T)))return}a=t.createElement("link"),Vn(a,"link",n),gn(a),t.head.appendChild(a)}}}function uO(n,l,t){tl.S(n,l,t);var a=vt;if(a&&n){var e=kl(a).hoistableStyles,T=mt(n);l=l||"default";var u=e.get(T);if(!u){var f={loading:0,preload:null};if(u=a.querySelector(oa(T)))f.loading=5;else{n=o({rel:"stylesheet",href:n,"data-precedence":l},t),(t=L1.get(T))&&cu(n,t);var R=u=a.createElement("link");gn(R),Vn(R,"link",n),R._p=new Promise(function(y,B){R.onload=y,R.onerror=B}),R.addEventListener("load",function(){f.loading|=1}),R.addEventListener("error",function(){f.loading|=2}),f.loading|=4,g0(u,l,a)}u={type:"stylesheet",instance:u,count:1,state:f},e.set(T,u)}}}function iO(n,l){tl.X(n,l);var t=vt;if(t&&n){var a=kl(t).hoistableScripts,e=Ft(n),T=a.get(e);T||(T=t.querySelector(Ia(e)),T||(n=o({src:n,async:!0},l),(l=L1.get(e))&&fu(n,l),T=t.createElement("script"),gn(T),Vn(T,"link",n),t.head.appendChild(T)),T={type:"script",instance:T,count:1,state:null},a.set(e,T))}}function cO(n,l){tl.M(n,l);var t=vt;if(t&&n){var a=kl(t).hoistableScripts,e=Ft(n),T=a.get(e);T||(T=t.querySelector(Ia(e)),T||(n=o({src:n,async:!0,type:"module"},l),(l=L1.get(e))&&fu(n,l),T=t.createElement("script"),gn(T),Vn(T,"link",n),t.head.appendChild(T)),T={type:"script",instance:T,count:1,state:null},a.set(e,T))}}function Sf(n,l,t,a){var e=(e=ln.current)?p0(e):null;if(!e)throw Error(i(446));switch(n){case"meta":case"title":return null;case"style":return typeof t.precedence=="string"&&typeof t.href=="string"?(l=mt(t.href),t=kl(e).hoistableStyles,a=t.get(l),a||(a={type:"style",instance:null,count:0,state:null},t.set(l,a)),a):{type:"void",instance:null,count:0,state:null};case"link":if(t.rel==="stylesheet"&&typeof t.href=="string"&&typeof t.precedence=="string"){n=mt(t.href);var T=kl(e).hoistableStyles,u=T.get(n);if(u||(e=e.ownerDocument||e,u={type:"stylesheet",instance:null,count:0,state:{loading:0,preload:null}},T.set(n,u),(T=e.querySelector(oa(n)))&&!T._p&&(u.instance=T,u.state.loading=5),L1.has(n)||(t={rel:"preload",as:"style",href:t.href,crossOrigin:t.crossOrigin,integrity:t.integrity,media:t.media,hrefLang:t.hrefLang,referrerPolicy:t.referrerPolicy},L1.set(n,t),T||fO(e,n,t,u.state))),l&&a===null)throw Error(i(528,""));return u}if(l&&a!==null)throw Error(i(529,""));return null;case"script":return l=t.async,t=t.src,typeof t=="string"&&l&&typeof l!="function"&&typeof l!="symbol"?(l=Ft(t),t=kl(e).hoistableScripts,a=t.get(l),a||(a={type:"script",instance:null,count:0,state:null},t.set(l,a)),a):{type:"void",instance:null,count:0,state:null};default:throw Error(i(444,n))}}function mt(n){return'href="'+o1(n)+'"'}function oa(n){return'link[rel="stylesheet"]['+n+"]"}function Df(n){return o({},n,{"data-precedence":n.precedence,precedence:null})}function fO(n,l,t,a){n.querySelector('link[rel="preload"][as="style"]['+l+"]")?a.loading=1:(l=n.createElement("link"),a.preload=l,l.addEventListener("load",function(){return a.loading|=1}),l.addEventListener("error",function(){return a.loading|=2}),Vn(l,"link",t),gn(l),n.head.appendChild(l))}function Ft(n){return'[src="'+o1(n)+'"]'}function Ia(n){return"script[async]"+n}function Rf(n,l,t){if(l.count++,l.instance===null)switch(l.type){case"style":var a=n.querySelector('style[data-href~="'+o1(t.href)+'"]');if(a)return l.instance=a,gn(a),a;var e=o({},t,{"data-href":t.href,"data-precedence":t.precedence,href:null,precedence:null});return a=(n.ownerDocument||n).createElement("style"),gn(a),Vn(a,"style",e),g0(a,t.precedence,n),l.instance=a;case"stylesheet":e=mt(t.href);var T=n.querySelector(oa(e));if(T)return l.state.loading|=4,l.instance=T,gn(T),T;a=Df(t),(e=L1.get(e))&&cu(a,e),T=(n.ownerDocument||n).createElement("link"),gn(T);var u=T;return u._p=new Promise(function(f,R){u.onload=f,u.onerror=R}),Vn(T,"link",a),l.state.loading|=4,g0(T,t.precedence,n),l.instance=T;case"script":return T=Ft(t.src),(e=n.querySelector(Ia(T)))?(l.instance=e,gn(e),e):(a=t,(e=L1.get(T))&&(a=o({},t),fu(a,e)),n=n.ownerDocument||n,e=n.createElement("script"),gn(e),Vn(e,"link",a),n.head.appendChild(e),l.instance=e);case"void":return null;default:throw Error(i(443,l.type))}else l.type==="stylesheet"&&(l.state.loading&4)===0&&(a=l.instance,l.state.loading|=4,g0(a,t.precedence,n));return l.instance}function g0(n,l,t){for(var a=t.querySelectorAll('link[rel="stylesheet"][data-precedence],style[data-precedence]'),e=a.length?a[a.length-1]:null,T=e,u=0;u<a.length;u++){var f=a[u];if(f.dataset.precedence===l)T=f;else if(T!==e)break}T?T.parentNode.insertBefore(n,T.nextSibling):(l=t.nodeType===9?t.head:t,l.insertBefore(n,l.firstChild))}function cu(n,l){n.crossOrigin==null&&(n.crossOrigin=l.crossOrigin),n.referrerPolicy==null&&(n.referrerPolicy=l.referrerPolicy),n.title==null&&(n.title=l.title)}function fu(n,l){n.crossOrigin==null&&(n.crossOrigin=l.crossOrigin),n.referrerPolicy==null&&(n.referrerPolicy=l.referrerPolicy),n.integrity==null&&(n.integrity=l.integrity)}var z0=null;function Cf(n,l,t){if(z0===null){var a=new Map,e=z0=new Map;e.set(t,a)}else e=z0,a=e.get(t),a||(a=new Map,e.set(t,a));if(a.has(n))return a;for(a.set(n,null),t=t.getElementsByTagName(n),e=0;e<t.length;e++){var T=t[e];if(!(T[gt]||T[Kn]||n==="link"&&T.getAttribute("rel")==="stylesheet")&&T.namespaceURI!=="http://www.w3.org/2000/svg"){var u=T.getAttribute(l)||"";u=n+u;var f=a.get(u);f?f.push(T):a.set(u,[T])}}return a}function Yf(n,l,t){n=n.ownerDocument||n,n.head.insertBefore(t,l==="title"?n.querySelector("head > title"):null)}function NO(n,l,t){if(t===1||l.itemProp!=null)return!1;switch(n){case"meta":case"title":return!0;case"style":if(typeof l.precedence!="string"||typeof l.href!="string"||l.href==="")break;return!0;case"link":if(typeof l.rel!="string"||typeof l.href!="string"||l.href===""||l.onLoad||l.onError)break;return l.rel==="stylesheet"?(n=l.disabled,typeof l.precedence=="string"&&n==null):!0;case"script":if(l.async&&typeof l.async!="function"&&typeof l.async!="symbol"&&!l.onLoad&&!l.onError&&l.src&&typeof l.src=="string")return!0}return!1}function sf(n){return!(n.type==="stylesheet"&&(n.state.loading&3)===0)}function EO(n,l,t,a){if(t.type==="stylesheet"&&(typeof a.media!="string"||matchMedia(a.media).matches!==!1)&&(t.state.loading&4)===0){if(t.instance===null){var e=mt(a.href),T=l.querySelector(oa(e));if(T){l=T._p,l!==null&&typeof l=="object"&&typeof l.then=="function"&&(n.count++,n=_0.bind(n),l.then(n,n)),t.state.loading|=4,t.instance=T,gn(T);return}T=l.ownerDocument||l,a=Df(a),(e=L1.get(e))&&cu(a,e),T=T.createElement("link"),gn(T);var u=T;u._p=new Promise(function(f,R){u.onload=f,u.onerror=R}),Vn(T,"link",a),t.instance=T}n.stylesheets===null&&(n.stylesheets=new Map),n.stylesheets.set(t,l),(l=t.state.preload)&&(t.state.loading&3)===0&&(n.count++,t=_0.bind(n),l.addEventListener("load",t),l.addEventListener("error",t))}}var Nu=0;function OO(n,l){return n.stylesheets&&n.count===0&&Z0(n,n.stylesheets),0<n.count||0<n.imgCount?function(t){var a=setTimeout(function(){if(n.stylesheets&&Z0(n,n.stylesheets),n.unsuspend){var T=n.unsuspend;n.unsuspend=null,T()}},6e4+l);0<n.imgBytes&&Nu===0&&(Nu=62500*qE());var e=setTimeout(function(){if(n.waitingForImages=!1,n.count===0&&(n.stylesheets&&Z0(n,n.stylesheets),n.unsuspend)){var T=n.unsuspend;n.unsuspend=null,T()}},(n.imgBytes>Nu?50:800)+l);return n.unsuspend=t,function(){n.unsuspend=null,clearTimeout(a),clearTimeout(e)}}:null}function _0(){if(this.count--,this.count===0&&(this.imgCount===0||!this.waitingForImages)){if(this.stylesheets)Z0(this,this.stylesheets);else if(this.unsuspend){var n=this.unsuspend;this.unsuspend=null,n()}}}var K0=null;function Z0(n,l){n.stylesheets=null,n.unsuspend!==null&&(n.count++,K0=new Map,l.forEach(AO,n),K0=null,_0.call(n))}function AO(n,l){if(!(l.state.loading&4)){var t=K0.get(n);if(t)var a=t.get(null);else{t=new Map,K0.set(n,t);for(var e=n.querySelectorAll("link[data-precedence],style[data-precedence]"),T=0;T<e.length;T++){var u=e[T];(u.nodeName==="LINK"||u.getAttribute("media")!=="not all")&&(t.set(u.dataset.precedence,u),a=u)}a&&t.set(null,a)}e=l.instance,u=e.getAttribute("data-precedence"),T=t.get(u)||a,T===a&&t.set(null,e),t.set(u,e),this.count++,a=_0.bind(this),e.addEventListener("load",a),e.addEventListener("error",a),T?T.parentNode.insertBefore(e,T.nextSibling):(n=n.nodeType===9?n.head:n,n.insertBefore(e,n.firstChild)),l.state.loading|=4}}var ra={$$typeof:Cn,Provider:null,Consumer:null,_currentValue:z,_currentValue2:z,_threadCount:0};function SO(n,l,t,a,e,T,u,f,R){this.tag=1,this.containerInfo=n,this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.next=this.pendingContext=this.context=this.cancelPendingCommit=null,this.callbackPriority=0,this.expirationTimes=Te(-1),this.entangledLanes=this.shellSuspendCounter=this.errorRecoveryDisabledLanes=this.expiredLanes=this.warmLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=Te(0),this.hiddenUpdates=Te(null),this.identifierPrefix=a,this.onUncaughtError=e,this.onCaughtError=T,this.onRecoverableError=u,this.pooledCache=null,this.pooledCacheLanes=0,this.formState=R,this.incompleteTransitions=new Map}function Xf(n,l,t,a,e,T,u,f,R,y,B,F){return n=new SO(n,l,t,u,R,y,B,F,f),l=1,T===!0&&(l|=24),T=O1(3,null,null,l),n.current=T,T.stateNode=n,l=xe(),l.refCount++,n.pooledCache=l,l.refCount++,T.memoizedState={element:a,isDehydrated:t,cache:l},We(T),n}function of(n){return n?(n=ft,n):ft}function If(n,l,t,a,e,T){e=of(e),a.context===null?a.context=e:a.pendingContext=e,a=El(l),a.payload={element:t},T=T===void 0?null:T,T!==null&&(a.callback=T),t=Ol(n,a,l),t!==null&&(T1(t,n,l),la(t,n,l))}function rf(n,l){if(n=n.memoizedState,n!==null&&n.dehydrated!==null){var t=n.retryLane;n.retryLane=t!==0&&t<l?t:l}}function Eu(n,l){rf(n,l),(n=n.alternate)&&rf(n,l)}function Hf(n){if(n.tag===13||n.tag===31){var l=bl(n,67108864);l!==null&&T1(l,n,67108864),Eu(n,67108864)}}function yf(n){if(n.tag===13||n.tag===31){var l=C1();l=ue(l);var t=bl(n,l);t!==null&&T1(t,n,l),Eu(n,l)}}var x0=!0;function DO(n,l,t,a){var e=L.T;L.T=null;var T=G.p;try{G.p=2,Ou(n,l,t,a)}finally{G.p=T,L.T=e}}function RO(n,l,t,a){var e=L.T;L.T=null;var T=G.p;try{G.p=8,Ou(n,l,t,a)}finally{G.p=T,L.T=e}}function Ou(n,l,t,a){if(x0){var e=Au(a);if(e===null)wT(n,l,a,Q0,t),df(n,a);else if(YO(e,n,l,t,a))a.stopPropagation();else if(df(n,a),l&4&&-1<CO.indexOf(n)){for(;e!==null;){var T=wl(e);if(T!==null)switch(T.tag){case 3:if(T=T.stateNode,T.current.memoizedState.isDehydrated){var u=ml(T.pendingLanes);if(u!==0){var f=T;for(f.pendingLanes|=2,f.entangledLanes|=2;u;){var R=1<<31-N1(u);f.entanglements[1]|=R,u&=~R}p1(T),(Nn&6)===0&&(h0=c1()+500,Ca(0))}}break;case 31:case 13:f=bl(T,2),f!==null&&T1(f,T,2),B0(),Eu(T,2)}if(T=Au(a),T===null&&wT(n,l,a,Q0,t),T===e)break;e=T}e!==null&&a.stopPropagation()}else wT(n,l,a,null,t)}}function Au(n){return n=De(n),Su(n)}var Q0=null;function Su(n){if(Q0=null,n=Pl(n),n!==null){var l=c(n);if(l===null)n=null;else{var t=l.tag;if(t===13){if(n=I(l),n!==null)return n;n=null}else if(t===31){if(n=r(l),n!==null)return n;n=null}else if(t===3){if(l.stateNode.current.memoizedState.isDehydrated)return l.tag===3?l.stateNode.containerInfo:null;n=null}else l!==n&&(n=null)}}return Q0=n,null}function hf(n){switch(n){case"beforetoggle":case"cancel":case"click":case"close":case"contextmenu":case"copy":case"cut":case"auxclick":case"dblclick":case"dragend":case"dragstart":case"drop":case"focusin":case"focusout":case"input":case"invalid":case"keydown":case"keypress":case"keyup":case"mousedown":case"mouseup":case"paste":case"pause":case"play":case"pointercancel":case"pointerdown":case"pointerup":case"ratechange":case"reset":case"resize":case"seeked":case"submit":case"toggle":case"touchcancel":case"touchend":case"touchstart":case"volumechange":case"change":case"selectionchange":case"textInput":case"compositionstart":case"compositionend":case"compositionupdate":case"beforeblur":case"afterblur":case"beforeinput":case"blur":case"fullscreenchange":case"focus":case"hashchange":case"popstate":case"select":case"selectstart":return 2;case"drag":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"mousemove":case"mouseout":case"mouseover":case"pointermove":case"pointerout":case"pointerover":case"scroll":case"touchmove":case"wheel":case"mouseenter":case"mouseleave":case"pointerenter":case"pointerleave":return 8;case"message":switch(tN()){case Mu:return 2;case Uu:return 8;case Ma:case aN:return 32;case Gu:return 268435456;default:return 32}default:return 32}}var Du=!1,rl=null,Hl=null,yl=null,Ha=new Map,ya=new Map,hl=[],CO="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset".split(" ");function df(n,l){switch(n){case"focusin":case"focusout":rl=null;break;case"dragenter":case"dragleave":Hl=null;break;case"mouseover":case"mouseout":yl=null;break;case"pointerover":case"pointerout":Ha.delete(l.pointerId);break;case"gotpointercapture":case"lostpointercapture":ya.delete(l.pointerId)}}function ha(n,l,t,a,e,T){return n===null||n.nativeEvent!==T?(n={blockedOn:l,domEventName:t,eventSystemFlags:a,nativeEvent:T,targetContainers:[e]},l!==null&&(l=wl(l),l!==null&&Hf(l)),n):(n.eventSystemFlags|=a,l=n.targetContainers,e!==null&&l.indexOf(e)===-1&&l.push(e),n)}function YO(n,l,t,a,e){switch(l){case"focusin":return rl=ha(rl,n,l,t,a,e),!0;case"dragenter":return Hl=ha(Hl,n,l,t,a,e),!0;case"mouseover":return yl=ha(yl,n,l,t,a,e),!0;case"pointerover":var T=e.pointerId;return Ha.set(T,ha(Ha.get(T)||null,n,l,t,a,e)),!0;case"gotpointercapture":return T=e.pointerId,ya.set(T,ha(ya.get(T)||null,n,l,t,a,e)),!0}return!1}function Bf(n){var l=Pl(n.target);if(l!==null){var t=c(l);if(t!==null){if(l=t.tag,l===13){if(l=I(t),l!==null){n.blockedOn=l,Ku(n.priority,function(){yf(t)});return}}else if(l===31){if(l=r(t),l!==null){n.blockedOn=l,Ku(n.priority,function(){yf(t)});return}}else if(l===3&&t.stateNode.current.memoizedState.isDehydrated){n.blockedOn=t.tag===3?t.stateNode.containerInfo:null;return}}}n.blockedOn=null}function V0(n){if(n.blockedOn!==null)return!1;for(var l=n.targetContainers;0<l.length;){var t=Au(n.nativeEvent);if(t===null){t=n.nativeEvent;var a=new t.constructor(t.type,t);Se=a,t.target.dispatchEvent(a),Se=null}else return l=wl(t),l!==null&&Hf(l),n.blockedOn=t,!1;l.shift()}return!0}function Lf(n,l,t){V0(n)&&t.delete(l)}function sO(){Du=!1,rl!==null&&V0(rl)&&(rl=null),Hl!==null&&V0(Hl)&&(Hl=null),yl!==null&&V0(yl)&&(yl=null),Ha.forEach(Lf),ya.forEach(Lf)}function q0(n,l){n.blockedOn===l&&(n.blockedOn=null,Du||(Du=!0,A.unstable_scheduleCallback(A.unstable_NormalPriority,sO)))}var W0=null;function vf(n){W0!==n&&(W0=n,A.unstable_scheduleCallback(A.unstable_NormalPriority,function(){W0===n&&(W0=null);for(var l=0;l<n.length;l+=3){var t=n[l],a=n[l+1],e=n[l+2];if(typeof a!="function"){if(Su(a||t)===null)continue;break}var T=wl(t);T!==null&&(n.splice(l,3),l-=3,AT(T,{pending:!0,data:e,method:t.method,action:a},a,e))}}))}function Mt(n){function l(R){return q0(R,n)}rl!==null&&q0(rl,n),Hl!==null&&q0(Hl,n),yl!==null&&q0(yl,n),Ha.forEach(l),ya.forEach(l);for(var t=0;t<hl.length;t++){var a=hl[t];a.blockedOn===n&&(a.blockedOn=null)}for(;0<hl.length&&(t=hl[0],t.blockedOn===null);)Bf(t),t.blockedOn===null&&hl.shift();if(t=(n.ownerDocument||n).$$reactFormReplay,t!=null)for(a=0;a<t.length;a+=3){var e=t[a],T=t[a+1],u=e[kn]||null;if(typeof T=="function")u||vf(t);else if(u){var f=null;if(T&&T.hasAttribute("formAction")){if(e=T,u=T[kn]||null)f=u.formAction;else if(Su(e)!==null)continue}else f=u.action;typeof f=="function"?t[a+1]=f:(t.splice(a,3),a-=3),vf(t)}}}function mf(){function n(T){T.canIntercept&&T.info==="react-transition"&&T.intercept({handler:function(){return new Promise(function(u){return e=u})},focusReset:"manual",scroll:"manual"})}function l(){e!==null&&(e(),e=null),a||setTimeout(t,20)}function t(){if(!a&&!navigation.transition){var T=navigation.currentEntry;T&&T.url!=null&&navigation.navigate(T.url,{state:T.getState(),info:"react-transition",history:"replace"})}}if(typeof navigation=="object"){var a=!1,e=null;return navigation.addEventListener("navigate",n),navigation.addEventListener("navigatesuccess",l),navigation.addEventListener("navigateerror",l),setTimeout(t,100),function(){a=!0,navigation.removeEventListener("navigate",n),navigation.removeEventListener("navigatesuccess",l),navigation.removeEventListener("navigateerror",l),e!==null&&(e(),e=null)}}}function Ru(n){this._internalRoot=n}$0.prototype.render=Ru.prototype.render=function(n){var l=this._internalRoot;if(l===null)throw Error(i(409));var t=l.current,a=C1();If(t,a,n,l,null,null)},$0.prototype.unmount=Ru.prototype.unmount=function(){var n=this._internalRoot;if(n!==null){this._internalRoot=null;var l=n.containerInfo;If(n.current,2,null,n,null,null),B0(),l[Jl]=null}};function $0(n){this._internalRoot=n}$0.prototype.unstable_scheduleHydration=function(n){if(n){var l=_u();n={blockedOn:null,target:n,priority:l};for(var t=0;t<hl.length&&l!==0&&l<hl[t].priority;t++);hl.splice(t,0,n),t===0&&Bf(n)}};var Ff=O.version;if(Ff!=="19.2.6")throw Error(i(527,Ff,"19.2.6"));G.findDOMNode=function(n){var l=n._reactInternals;if(l===void 0)throw typeof n.render=="function"?Error(i(188)):(n=Object.keys(n).join(","),Error(i(268,n)));return n=N(l),n=n!==null?C(n):null,n=n===null?null:n.stateNode,n};var XO={bundleType:0,version:"19.2.6",rendererPackageName:"react-dom",currentDispatcherRef:L,reconcilerVersion:"19.2.6"};if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<"u"){var j0=__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!j0.isDisabled&&j0.supportsFiber)try{Gt=j0.inject(XO),f1=j0}catch{}}return Ba.createRoot=function(n,l){if(!S(n))throw Error(i(299));var t=!1,a="",e=g2,T=z2,u=_2;return l!=null&&(l.unstable_strictMode===!0&&(t=!0),l.identifierPrefix!==void 0&&(a=l.identifierPrefix),l.onUncaughtError!==void 0&&(e=l.onUncaughtError),l.onCaughtError!==void 0&&(T=l.onCaughtError),l.onRecoverableError!==void 0&&(u=l.onRecoverableError)),l=Xf(n,1,!1,null,null,t,a,null,e,T,u,mf),n[Jl]=l.current,PT(n),new Ru(l)},Ba.hydrateRoot=function(n,l,t){if(!S(n))throw Error(i(299));var a=!1,e="",T=g2,u=z2,f=_2,R=null;return t!=null&&(t.unstable_strictMode===!0&&(a=!0),t.identifierPrefix!==void 0&&(e=t.identifierPrefix),t.onUncaughtError!==void 0&&(T=t.onUncaughtError),t.onCaughtError!==void 0&&(u=t.onCaughtError),t.onRecoverableError!==void 0&&(f=t.onRecoverableError),t.formState!==void 0&&(R=t.formState)),l=Xf(n,1,!0,l,t??null,a,e,R,T,u,f,mf),l.context=of(null),t=l.current,a=C1(),a=ue(a),e=El(a),e.callback=null,Ol(t,e,a),t=a,l.current.lanes=t,pt(l,t),p1(l),n[Jl]=l.current,PT(n),new $0(l)},Ba.version="19.2.6",Ba}var Zf;function FO(){if(Zf)return su.exports;Zf=1;function A(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(A)}catch(O){console.error(O)}}return A(),su.exports=mO(),su.exports}var TA=FO();const MO=" 11  65  12  65  12  66  12  67  12  68  12  69  13  69  13  70  13  71  13  72  13  73  14  73  14  74  14  75  14  76  14  77  14  78  15  78  15  79  15  80  15  81  16  81  16  82  16  83  16  84  16  85  17  85  17  86  17  87  17  88  17  89  18  89  18  90  18  91  18  92  18  93  18  94  19  94  19  95  19  96  19  97  19  98  19  99  20  99  20  100  20  101  20  102  20  103  20  104  21  104  21  105  21  106  21  107  21  108  21  109  21  110  21  111  21  112  22  112  22  111  22  110  22  109  22  108  22  107  22  106  22  105  22  104  23  104  23  103  24  103  24  102  24  101  24  100  24  99  24  98  25  98  25  97  25  96  25  95  26  95  26  94  26  93  26  92  27  92  27  91  27  90  27  89  27  88  28  88  28  87  28  86  28  85  28  84  28  83  29  83  29  82  29  81  30  81  30  80  30  79  30  78  31  78  31  77  31  76  31  75  32  75  32  74  32  73  32  72  32  71  33  71  33  70  33  69  33  68  34  68  34  67  34  66  44  66  45  66  46  66  47  66  48  66  49  66  50  66  51  66  52  66  53  66  54  66  55  66  56  66  57  66  58  66  59  66  60  66  49  68  49  69  49  70  49  71  49  72  49  73  49  74  49  75  49  76  49  77  49  78  49  79  49  80  49  81  49  82  49  83  49  84  49  85  49  86  49  87  49  88  49  89  49  90  49  91  49  92  49  93  49  94  49  95  49  96  49  97  49  98  49  99  49  100  49  101  49  102  49  103  49  104  41  105  42  105  43  105  44  105  45  105  46  105  47  105  48  105  49  105  50  105  51  105  52  105  53  105  54  105  55  105  56  105  68  68  68  69  68  70  68  71  68  72  68  73  68  74  68  75  68  76  68  77  68  78  68  79  68  80  68  81  68  82  68  83  68  84  68  85  68  86  68  87  68  88  68  89  68  90  68  91  68  92  68  93  68  94  68  95  68  96  68  97  68  98  68  99  68  100  68  101  68  102  68  103  68  104  68  105  68  106  68  107  68  108  70  67  71  67  71  68  72  68  72  69  73  69  73  70  74  70  75  70  75  71  76  71  76  72  77  72  77  73  78  73  78  74  78  75  79  75  79  76  80  76  80  77  81  77  81  78  81  79  82  79  82  80  82  81  81  81  81  82  81  83  80  83  80  84  79  84  79  85  78  85  78  86  77  86  76  86  76  87  75  87  74  87  74  88  73  88  72  88  71  88  70  88  70  89  71  89  71  90  72  90  72  91  72  92  73  92  73  93  74  93  74  94  75  94  75  95  76  95  76  96  76  97  77  97  78  97  78  98  78  99  78  100  79  100  79  101  79  102  80  102  80  103  80  104  81  104  82  104  82  105  82  106  82  107  83  107  83  108  84  108  93  69  94  69  94  70  95  70  96  70  97  70  98  70  99  70  99  69  100  69  101  69  102  69  103  69  104  69  104  68  105  68  106  68  107  68  108  68  109  68  110  68  111  68  112  68  113  68  114  68  115  68  101  71  101  72  101  73  102  73  102  74  102  75  102  76  103  76  103  77  103  78  103  79  103  80  103  81  103  82  103  83  103  84  103  85  103  86  102  86  102  87  102  88  102  89  102  90  102  91  102  92  102  93  102  94  103  94  103  95  103  96  103  97  103  98  104  98  104  99  104  100  104  101  104  102  104  103  104  104  104  105  104  106  104  107  122  71  123  71  123  72  123  73  123  74  123  75  123  76  124  76  124  77  124  78  124  79  124  80  124  81  124  82  124  83  124  84  124  85  124  86  123  86  123  87  123  88  123  89  123  90  124  90  124  91  124  92  124  93  124  94  124  95  124  96  124  97  124  98  124  99  125  99  125  100  125  101  126  101  126  102  127  102  127  103  128  103  128  104  129  104  130  104  131  104  132  104  133  104  133  103  134  103  135  103  135  102  136  102  136  101  137  101  137  100  138  100  138  99  139  99  139  98  140  98  140  97  141  97  141  96  141  95  141  94  141  93  141  92  141  91  141  90  142  90  142  89  142  88  142  87  142  86  142  85  142  84  142  83  142  82  142  81  142  80  143  80  143  79  143  78  143  77  143  76  143  75  143  74  143  73  143  72  143  71  152  102  153  102  153  101  153  100  153  99  153  98  153  97  153  96  153  95  153  94  153  93  153  92  153  91  152  91  152  90  152  89  152  88  152  87  152  86  152  85  152  84  152  83  152  82  152  81  152  80  153  80  153  79  153  78  153  77  153  76  154  76  154  75  154  74  154  73  155  73  155  72  156  72  156  71  157  71  157  70  158  70  159  70  160  70  161  70  162  70  163  70  164  70  164  71  165  71  166  71  167  71  167  72  168  72  168  73  169  73  169  74  170  74  170  75  171  75  171  76  172  76  172  77  172  78  173  78  173  79  173  80  173  81  173  82  173  83  173  84  173  85  172  85  172  86  172  87  172  88  172  89  172  90  172  91  172  92  172  93  172  94  172  95  172  96  173  96  173  97  173  98  173  99  173  100  173  101  173  102  173  103  173  104  173  105  154  87  155  87  156  87  156  88  157  88  158  88  159  88  160  88  161  88  162  88  163  88  163  89  164  89  165  89  166  89  167  89  167  88  168  88  169  88  170  88  171  88  180  72  180  73  181  73  181  74  181  75  181  76  181  77  181  78  182  78  182  79  182  80  182  81  182  82  182  83  182  84  182  85  182  86  182  87  182  88  182  89  181  89  181  90  181  91  181  92  181  93  181  94  181  95  181  96  181  97  182  97  182  98  182  99  182  100  182  101  182  102  182  103  183  103  184  103  185  103  186  103  187  103  187  102  188  102  189  102  190  102  191  102  192  102  192  103  193  103  194  103  195  103  196  103  197  103  198  103  199  103  200  103  200  104  201  104  202  104  212  70  213  70  214  70  215  70  216  70  217  70  218  70  219  70  220  70  221  70  222  70  223  70  224  70  225  70  226  70  227  70  228  70  229  70  230  70  231  70  232  70  221  72  221  73  221  74  221  75  221  76  221  77  221  78  221  79  221  80  221  81  221  82  221  83  221  84  221  85  221  86  221  87  221  88  221  89  221  90  221  91  221  92  221  93  221  94  221  95  221  96  221  97  221  98  221  99  221  100  221  101  221  102  221  103  211  104  212  104  213  104  214  104  215  104  216  104  217  104  218  104  219  104  220  104  221  104  222  104  223  104  224  104  225  104  226  104  227  104  228  104  229  104  242  71  243  71  243  72  244  72  245  72  246  72  247  72  247  71  248  71  249  71  250  71  251  71  252  71  253  71  253  72  254  72  255  72  256  72  257  72  258  72  258  71  259  71  260  71  261  71  262  71  263  71  264  71  252  73  252  74  252  75  253  75  253  76  253  77  253  78  253  79  253  80  253  81  253  82  253  83  253  84  253  85  253  86  254  86  254  87  254  88  254  89  254  90  254  91  254  92  254  93  254  94  254  95  254  96  254  97  254  98  254  99  254  100  254  101  254  102  254  103  254  104  254  105  276  72  277  72  277  73  277  74  278  74  279  74  279  75  279  76  279  77  280  77  280  78  281  78  281  79  282  79  282  80  283  80  283  81  284  81  284  82  284  83  285  83  285  84  286  84  286  85  287  85  287  86  287  87  287  88  287  89  287  90  287  91  287  92  287  93  287  94  288  94  288  95  288  96  288  97  288  98  288  99  288  100  288  101  288  102  288  103  288  104  288  105  288  106  288  107  288  108  288  84  289  84  289  83  290  83  290  82  291  82  291  81  292  81  292  80  292  79  293  79  294  79  294  78  294  77  295  77  295  76  296  76  296  75  297  75  297  74  298  74  298  73  298  72  299  72  299  71  299  70  300  70  300  69  301  69  301  68  302  68  302  67 ",UO=" 113  104  113  103  113  102  113  101  113  100  113  99  113  98  113  97  113  96  113  95  113  94  113  93  113  92  113  91  113  90  113  89  113  88  114  88  114  89  115  89  115  90  116  90  116  91  116  92  117  92  117  93  118  93  118  94  119  94  119  95  120  95  120  94  121  94  121  93  122  93  122  92  123  92  123  91  124  91  124  90  125  90  125  89  126  89  126  88  127  88  127  89  127  90  127  91  127  92  127  93  127  94  127  95  127  96  127  97  127  98  127  99  127  100  127  101  127  102  127  103  127  104  147  89  146  89  145  89  144  89  143  89  142  89  141  89  140  89  139  89  138  89  137  89  136  89  135  89  135  90  135  91  135  92  135  93  135  94  135  95  135  96  135  97  135  98  135  99  135  100  135  101  135  102  135  103  135  104  136  104  137  104  138  104  139  104  140  104  141  104  142  104  143  104  144  104  145  104  146  104  147  104  148  104  144  97  143  97  142  97  141  97  140  97  139  97  138  97  137  97  136  97  135  97  156  102  156  101  156  100  156  99  156  98  156  97  156  96  156  95  156  94  156  93  156  92  156  91  156  90  156  89  157  89  157  90  158  90  158  91  158  92  159  92  159  93  159  94  160  94  160  95  160  96  161  96  161  97  162  97  162  98  162  99  163  99  163  100  163  101  164  101  164  100  164  99  164  98  164  97  164  96  164  95  164  94  164  93  164  92  164  91  164  90  164  89  164  88  164  87  171  90  171  91  171  92  171  93  171  94  171  95  171  96  171  97  172  97  172  98  172  99  173  99  173  100  174  100  174  101  175  101  176  101  177  101  178  101  178  100  179  100  179  99  180  99  180  98  181  98  181  97  181  96  181  95  181  94  181  93  181  92  181  91  181  90  181  89  181  88  181  87  181  86  181  85  181  84 ",GO=" 122  90  121  90  120  90  119  90  118  90  117  90  116  90  115  90  114  90  113  90  112  90  111  90  110  90  109  90  108  90  107  90  106  90  105  90  104  90  104  91  104  92  104  93  104  94  104  95  104  96  104  97  104  98  104  99  104  100  104  101  104  102  104  103  104  104  104  105  104  106  104  107  104  108  104  109  105  109  106  109  107  109  108  109  109  109  110  109  111  109  112  109  113  109  114  109  115  109  116  109  117  109  118  109  119  109  120  109  121  109  122  109  123  109  124  109  125  109  126  109  127  109  128  109  106  101  107  101  108  101  109  101  110  101  111  101  112  101  113  101  114  101  115  101  116  101  117  101  118  101  119  101  120  101  121  101  127  93  128  93  129  93  129  94  130  94  130  95  131  95  131  96  132  96  132  97  133  97  133  98  134  98  134  99  135  99  135  100  136  100  136  101  137  101  137  102  138  102  138  103  139  103  139  104  140  104  140  105  141  105  141  106  142  106  142  107  143  107  143  108  129  105  129  104  130  104  130  103  131  103  131  102  132  102  132  101  133  101  133  100  134  100  134  99  135  99  135  98  136  98  136  97  137  97  137  96  138  96  138  95  139  95  139  94  140  94  140  93  141  93  141  92  142  92  142  91  156  93  156  94  156  95  156  96  156  97  156  98  156  99  156  100  156  101  156  102  156  103  156  104  156  105  156  106  156  107  156  108  167  92  168  92  169  92  170  92  171  92  172  92  173  92  174  92  175  92  176  92  177  92  178  92  179  92  180  92  181  92  182  92  183  92  184  92  185  92  186  92  187  92  188  92  189  92  175  94  175  95  175  96  175  97  175  98  175  99  175  100  175  101  175  102  175  103  175  104  175  105  175  106  175  107  175  108  175  109  175  110  175  111  175  112  175  113  175  114 ",bO=" 125  85  126  85  127  85  128  85  129  85  130  85  131  85  132  85  133  85  134  85  135  85  136  85  137  85  130  87  130  88  130  89  130  90  130  91  130  92  130  93  130  94  130  95  130  96  130  97  130  98  130  99  130  100  130  101  130  102  130  103  130  104  130  105  130  106  124  107  125  107  126  107  127  107  128  107  129  107  130  107  131  107  132  107  133  107  134  107  135  107  136  107  146  106  146  105  146  104  146  103  146  102  146  101  146  100  146  99  146  98  146  97  146  96  146  95  146  94  146  93  146  92  146  91  146  90  146  89  146  88  146  87  146  86  147  86  147  87  148  87  148  88  149  88  149  89  150  89  150  90  150  91  151  91  151  92  151  93  152  93  152  94  152  95  152  96  153  96  153  97  154  97  154  98  154  99  154  100  155  100  155  101  155  102  156  102  156  103  157  103  157  104  158  104  158  105  159  105  159  104  159  103  159  102  159  101  159  100  159  99  159  98  159  97  159  96  159  95  159  94  159  93  159  92  159  91  159  90  159  89  159  88  159  87  159  86  159  85  182  85  181  85  180  85  179  85  178  85  177  85  176  85  175  85  174  85  173  85  172  85  171  85  170  85  169  85  169  86  169  87  169  88  169  89  169  90  169  91  169  92  169  93  169  94  169  95  169  96  169  97  169  98  169  99  169  100  169  101  169  102  169  103  169  104  169  105  169  106  171  97  172  97  173  97  174  97  175  97  176  97  177  97  178  97  179  97  180  97  181  97  190  96  191  96  191  95  191  94  192  94  192  93  192  92  192  91  193  91  193  90  194  90  194  89  194  88  195  88  195  87  196  87  196  86  197  86  198  86  199  86  200  86  201  86  202  86  203  86  203  87  204  87  205  87  205  88  206  88  206  89  207  89  207  90  208  90  208  91  208  92  208  93  208  94  209  94  209  95  209  96  210  96  210  97  210  98  210  99  210  100  210  101  209  101  209  102  209  103  209  104  208  104  208  105  207  105  207  106  206  106  206  107  205  107  205  108  204  108  203  108  202  108  201  108  200  108  200  107  199  107  198  107  197  107  197  106  196  106  196  105  195  105  195  104  194  104  194  103  193  103  193  102  192  102  192  101  191  101  191  100  191  99  190  99  190  98  190  97 ",pO=" 106  83  106  84  106  85  106  86  106  87  106  88  106  89  107  89  108  89  109  89  110  89  110  88  110  87  109  87  108  87  107  87  114  87  114  88  114  89  115  89  116  89  117  89  118  89  118  88  118  87  118  88  118  89  118  90  118  91  118  92  118  93  118  94  128  85  128  86  128  87  128  88  128  89  128  90  128  91  130  85  131  85  132  85  132  86  132  87  131  87  130  87  130  88  131  88  131  89  132  89  132  90  133  90  133  91  136  88  136  89  137  89  137  90  138  90  139  90  139  89  140  89  140  88  140  87  139  87  139  86  138  86  138  85  137  85  137  86  136  86  136  87  143  86  144  86  144  87  145  87  145  88  146  88  147  88  147  87  148  87  148  86  148  85  149  85  146  89  146  90  146  91  146  92  156  86  156  87  156  88  156  89  156  90  156  91  156  92  157  85  157  86  158  86  158  87  158  88  159  88  160  88  160  87  161  87  161  86  162  86  162  85  162  86  162  87  162  88  162  89  162  90  162  91  162  92  165  92  166  92  166  91  165  91 ",gO=`'$DYNAMIC
DECLARE SUB SAVER2 ()
DECLARE SUB SAVER3 ()
DECLARE SUB SAVER ()
DECLARE SUB BALL ()
DECLARE SUB COOLER ()
DECLARE SUB COOLX ()
DECLARE SUB CRAPER ()
DECLARE SUB CYBER ()
DECLARE SUB DELTA ()
DECLARE SUB DISCO ()
DECLARE SUB LASER ()
DECLARE SUB LINES ()
DECLARE SUB OMEGA ()
DECLARE SUB SHELLA ()
DECLARE SUB SPHERES ()
DECLARE SUB SPOTS ()
DECLARE SUB TUNNELS ()
DECLARE SUB TYPE1 ()
DECLARE SUB TYPE2 ()
DECLARE SUB COOL ()
DECLARE SUB SHOW (AX$, BX!, BY!)
DECLARE SUB FINISH ()
DECLARE SUB INFO ()
CLEAR
ON ERROR GOTO 669
SCREEN 13: CLS
RANDOMIZE TIMER
FOR X = 16 TO 28 STEP .007
COLOR X
LOCATE 10, 17: PRINT "R O Y"
NEXT X
FOR X = 16 TO 25 STEP .007
COLOR X
LOCATE 13, 16: PRINT "PRESENTS"
NEXT X
SLEEP 1
AX$ = "ROY MASSAAD"
SCREEN 13: CLS
FOR GTS = 1 TO 300
XS = INT(RND * 318) + 1
YS = INT(RND * 198) + 1
COLS = INT(RND * 14) + 18
PSET (XS, YS), COLS
NEXT GTS

OPEN "DATA" FOR INPUT AS #1
O = 25
AX$ = "ROY MASSAAD"
DO
INPUT #1, X: INPUT #1, Y
O = O + .1
CIRCLE (X, Y), 5, O, , , 2
LOOP UNTIL (EOF(1))
G = 20
FOR X = 30 TO 280
G = G + .04
LINE (X, 120)-(X + 5, 125), G
FOR T = 1 TO 500: NEXT T
NEXT X
FOR X = 16 TO 31 STEP .007
COLOR X
LOCATE 20, 12: PRINT "A 1997 PRODUCTION"
NEXT X

SLEEP 1

RANDOMIZE TIMER
ROY = 150
DIM A(ROY), DX(ROY), DY(ROY), XX(ROY), YY(ROY), S(ROY), G(ROY), X(ROY), Y(ROY), B(ROY), XC(ROY), YC(ROY), DD(ROY), SS(ROY)
FOR T = 1 TO ROY
M = 4.7
A(T) = 4.7
DX(T) = INT(RND * 35) + 35
DY(T) = 600
XX(T) = INT(RND * 300) + 10
YY(T) = DY(T)
S(T) = 1
G(T) = 30
X(T) = XX(T): Y(T) = -1
SS(T) = .01
DD(T) = INT(RND * 17) + 5
NEXT T
DO
FOR T = 1 TO ROY
XC(T) = X(T): YC(T) = Y(T)
IF S(T) = 1 THEN A(T) = A(T) + SS(T)
IF S(T) = 2 THEN A(T) = A(T) - SS(T)

X(T) = (COS(A(T)) * DX(T)) + XX(T)
Y(T) = (SIN(A(T)) * DY(T)) + YY(T)

'G(T) = G(T) + 1
'LINE (XC(T), YC(T))-(X(T), Y(T)), G(T)

PRESET (XC(T), YC(T))
PSET (X(T), Y(T)), G(T)

'CIRCLE (XC(T), YC(T)), DD(T), 0
'CIRCLE (X(T), Y(T)), DD(T), G(T)

IF B(T) = 1 AND Y(T) < 200 THEN B(T) = 0

IF Y(T) > 200 AND B(T) = 0 AND S(T) = 1 THEN A(T) = M - (A(T) - M): DX(T) = DX(T) + 20: XX(T) = XX(T) + (DX(T) * 1.25): DY(T) = DY(T) - 20: B(T) = 1: SS(T) = SS(T) + .00001: GOTO 11
IF Y(T) > 200 AND B(T) = 0 AND S(T) = 2 THEN A(T) = M + (M - A(T)): DX(T) = DX(T) + 20: XX(T) = XX(T) - (DX(T) * 1.25): DY(T) = DY(T) - 20: B(T) = 1: SS(T) = SS(T) + .00001: GOTO 11

IF X(T) < 0 AND B(T) = 0 AND S(T) = 2 THEN S(T) = 1: DX(T) = DX(T) + 25: B(T) = 1: SS(T) = SS(T) + .00001: GOTO 11
IF X(T) > 320 AND B(T) = 0 AND S(T) = 1 THEN S(T) = 2: DX(T) = DX(T) + 25: B(T) = 1: SS(T) = SS(T) + .00001: GOTO 11

IF Y(T) > 300 THEN GOSUB 11188
11
NEXT T
LOOP WHILE INKEY$ = ""
ERASE A, DX, DY, XX, YY, S, G, X, Y, B, XC, YC, DD, SS
GOTO 6545
11188
A(T) = 4.7
DX(T) = INT(RND * 35) + 35
DY(T) = 600
XX(T) = INT(RND * 300) + 10
YY(T) = DY(T)
S(T) = 1
X(T) = XX(T): Y(T) = -1
G(T) = G(T) + 1
RETURN






6545
FOR T = 300 TO 1 STEP -.6
CIRCLE (160, 100), T, 0, , , .5
K$ = INKEY$
IF K$ <> "" OR K$ = "" THEN K$ = "\`"
NEXT T
10 CLEAR , , 20000
DES = 2
GGG = 20
SCREEN 13: CLS
FOR GTS = 1 TO 300
XS = INT(RND * 318) + 1
YS = INT(RND * 198) + 1
COLS = INT(RND * 14) + 18
PSET (XS, YS), COLS
NEXT GTS
OPEN "DATA" FOR INPUT AS #1
O = 19
FOR G1 = T TO 465
INPUT #1, X: INPUT #1, Y
O = O + .007
LINE (160, 70)-(X, Y - 50), O
PSET (X, Y - 50), 10
NEXT G1
O = (O - 19) + O
REDIM ACE(500)
REDIM ACE2(500)
FOR G1 = 1 TO 379
INPUT #1, ACE(G1): INPUT #1, ACE2(G1)
NEXT G1
FOR G1 = 379 TO 1 STEP -1
O = O - .01
LINE (160, 70)-(ACE(G1) - 1, (ACE2(G1) + 1) - 50), O
PSET (ACE(G1), ACE2(G1) - 50), 10
NEXT G1
CLOSE #1
ERASE ACE, ACE2
OPEN "DATA" FOR INPUT AS #1
DO
INPUT #1, X: INPUT #1, Y
PSET (X, Y - 50), 10
LOOP UNTIL (EOF(1))
REDIM COL(2500)
CLOSE
OO = 30
OPEN "DATA2" FOR INPUT AS #1
DO
INPUT #1, X: INPUT #1, Y
OO = OO + .1
LINE (X + 10, Y)-((X + 10) + 3, Y + 3), OO
LOOP UNTIL (EOF(1))
CLOSE
OPEN "DATA3" FOR INPUT AS #1
DO
INPUT #1, X: INPUT #1, Y
OO = OO + .1
LINE (X + 100, Y + 50)-((X + 100) + 3, (Y + 50) + 3), OO
LOOP UNTIL (EOF(1))
CLOSE
OPEN "DATA4" FOR INPUT AS #1
DO
INPUT #1, X: INPUT #1, Y
OO = OO + .1
LINE ((X - 100), Y + 50)-((X - 100) + 3, (Y + 50) + 3), OO
LOOP UNTIL (EOF(1))
FOR H = 1 TO 2500
COL(H) = INT(RND * 10) + 16
NEXT H
CLOSE

OPEN "DATA5" FOR INPUT AS #1
O = 35
DO
INPUT #1, X: INPUT #1, Y
O = O + .1
PSET (X + 20, Y + 100), O
LOOP UNTIL (EOF(1))
CLOSE

LINE (130, 120)-(181, 171), 0, BF
LINE (131, 121)-(180, 170), 10, B
DO
'''
FOR Y = 1 TO 48 STEP 1
A = A + 1
FOR X = 1 TO 48 STEP 1
A = A + 1
GREAT = COL(A) + ROY
IF GREAT > 200 THEN ROY = 0
PSET (X + 131, Y + 121), GREAT
NEXT X
NEXT Y
KEY(1) ON
K$ = INKEY$
QAZXSW = QAZXSW + 1
IF K$ <> "" THEN QAZXSW = 0
IF QAZXSW = 400 THEN CALL SAVER: GOTO 10
IF K$ = CHR$(0) + "K" THEN GOSUB 112
IF K$ = CHR$(0) + "M" THEN GOSUB 113
ON KEY(1) GOSUB 123
IF K$ = CHR$(27) THEN DES = 3
IF UCASE$(K$) = "I" THEN DES = 1
IF UCASE$(K$) = "M" THEN DES = 2
IF UCASE$(K$) = "E" THEN DES = 3
IF UCASE$(K$) = "Q" THEN DES = 3
IF DES >= 4 THEN DES = 1
IF DES <= 0 THEN DES = 3
IF DES = 2 THEN XXX = 160: YYY = 95: CIRCLE (250, 150), 61, 0, , , -.6: CIRCLE (60, 150), 61, 0, , , -.6
IF DES = 3 THEN XXX = 250: YYY = 150:  CIRCLE (160, 95), 61, 0, , , -.6: CIRCLE (60, 150), 61, 0, , , -.6
IF DES = 1 THEN XXX = 60: YYY = 150: CIRCLE (250, 150), 61, 0, , , -.6: CIRCLE (160, 95), 61, 0, , , -.6
GGG = GGG + .5
IF GGG = 30 THEN GGG = 20
CIRCLE (XXX, YYY), 61, GGG, , , -.6
IF K$ = CHR$(32) OR K$ = CHR$(13) THEN GOTO 333
A = 0
ROY = ROY + 1
LOOP
CLOSE
112 DES = DES - 1: RETURN
113 DES = DES + 1: RETURN
333 IF DES = 1 THEN ERASE COL: CALL INFO: CLEAR : GOTO 10
IF DES = 3 THEN ERASE COL: CALL FINISH: CLEAR : GOTO 10
IF DES = 2 THEN ERASE COL: CALL COOL: CLEAR : GOTO 10
123 DES = 1: RETURN
669
CLEAR
SCREEN 0: CLS
WIDTH 80, 25
COLOR 15
PRINT "                  AN ERROR WAS DETECTED , PROGRAM ABORTED ."
BEEP
COLOR 7
SYSTEM

REM $STATIC
SUB BALL
RANDOMIZE TIMER
SCREEN 0: CLS
WIDTH 80, 25
LOCATE 3, 25: COLOR 10: PRINT "SPACE BY ROY ROY MASSAAD 1997@. "
943 LOCATE 6, 30: COLOR 15: INPUT "CHOOSE A MODE (1-8) "; DDD
IF DDD > 8 OR DDD < 1 THEN GOTO 943
IF DDD = 1 THEN GOTO 761
IF DDD = 2 THEN GOTO 762
IF DDD = 3 THEN GOTO 763
IF DDD = 4 THEN GOTO 764
IF DDD = 5 THEN GOTO 765
IF DDD = 6 THEN GOTO 767
IF DDD = 7 THEN GOTO 766
IF DDD = 8 THEN GOTO 768

761 RANDOMIZE TIMER
SCREEN 13: CLS
BAK = 0
69
ROY = 100
REDIM A(ROY), S(ROY), XB(ROY), YB(ROY), Y(ROY), X(ROY), D(ROY), C(ROY)
CCC = 160
CCC2 = 100
FOR T = 1 TO ROY
A(T) = (INT(RND * 73) + 1) / 10
S(T) = INT(RND * 95) + 5
D(T) = INT(RND * 5) + 1
Y(T) = CCC: X(T) = CCC2
C(T) = 18
NEXT T
DO
FOR T = 1 TO ROY
K$ = INKEY$
IF K$ = CHR$(27) THEN ERASE A, S, XB, YB, Y, X, D, C: GOTO 922
YB(T) = Y(T): XB(T) = X(T)
S(T) = S(T) + D(T)
X(T) = COS(A(T)) * S(T)
Y(T) = SIN(A(T)) * S(T)
COLOR C(T)
C(T) = C(T) + 2
HJU = 6 - (D(T) * 1.2)
IF HJU = 0 THEN HJU = 6
IF C(T) > 30 - HJU THEN C(T) = 30 - HJU
PSET (X(T) + CCC, Y(T) + CCC2)
PRESET (XB(T) + CCC, YB(T) + CCC2)
IF (Y(T) + CCC2) < 0 OR (Y(T) + CCC2) > 200 OR (X(T) + CCC) < 0 OR (X(T) + CCC) > 320 THEN GOSUB 60
NEXT T
LINE (0, 0)-(319, 199), 0, B
68
LOOP
60
A(T) = (INT(RND * 73) + 1) / 10
S(T) = INT(RND * 95) + 5
D(T) = INT(RND * 5) + 1
Y(T) = CCC: X(T) = CCC2
C(T) = 18
RETURN

762 SCREEN 13: CLS
RANDOMIZE TIMER
ROY = 80
REDIM A(ROY), S(ROY), XB(ROY), YB(ROY), Y(ROY), X(ROY), D(ROY), C(ROY)
CCC = 160
CCC2 = 100
FOR T = 1 TO ROY
A(T) = (INT(RND * 73) + 1) / 10
S(T) = INT(RND * 60) + 100
D(T) = INT(RND * 5) + 1
Y(T) = CCC: X(T) = CCC2
C(T) = INT(RND * 7) + 23
NEXT T
DO
FOR T = 1 TO ROY
COLOR C(T)
K$ = INKEY$
IF K$ = CHR$(27) THEN ERASE A, S, XB, YB, Y, X, D, C: GOTO 922
YB(T) = Y(T): XB(T) = X(T)
S(T) = S(T) - D(T)
X(T) = COS(A(T)) * S(T)
Y(T) = SIN(A(T)) * S(T)
DIST = SQR(((Y - 100) * (Y - 100)) + ((X - 160) * (X - 160)))
  POW = X(T) + CCC: POW2 = Y(T) + CCC2
PSET (POW, POW2)
  WOW = XB(T) + CCC: WOW2 = YB(T) + CCC2
PRESET (WOW, WOW2)
UIU = INT(RND * 20) + 1
IF S(T) < UIU THEN GOSUB 61
NEXT T
LOOP
61
YB(T) = Y(T): XB(T) = X(T): PRESET (XB(T) + CCC, YB(T) + CCC2)
A(T) = (INT(RND * 73) + 1) / 10
S(T) = INT(RND * 60) + 100
D(T) = INT(RND * 5) + 1
Y(T) = CCC: X(T) = CCC2
C(T) = INT(RND * 7) + 23
RETURN

763 SCREEN 13: CLS
ROY = 60
REDIM A(ROY), S(ROY), XB(ROY), YB(ROY), Y(ROY), X(ROY), D(ROY), C(ROY), AA3(ROY), POW(ROY), POW2(ROY), WOW(ROY), WOW2(ROY), FUF(ROY), FUF2(ROY)
CCC = 160
CCC2 = 100
FOR T = 1 TO ROY
A(T) = (INT(RND * 73) + 1) / 10
S(T) = INT(RND * 150) + 50
D(T) = INT(RND * 5) + 1
Y(T) = CCC: X(T) = CCC2
C(T) = INT(RND * 7) + 23
AA3(T) = A(T)
NEXT T
DO
FOR T = 1 TO ROY
COLOR C(T)
AA3(T) = AA3(T) + .1
IF AA3(T) = 7 THEN AA3(T) = 1
K$ = INKEY$
IF K$ = CHR$(27) THEN ERASE A, S, XB, YB, Y, X, D, C, AA3, POW, POW2, WOW, WOW2, FUF, FUF2: GOTO 922
YB(T) = Y(T): XB(T) = X(T)
S(T) = S(T) - D(T)
X(T) = COS(A(T)) * S(T)
Y(T) = SIN(A(T)) * S(T)
  POW(T) = X(T) + CCC: POW2(T) = Y(T) + CCC2
DIST = SQR(((POW2(T) - 100) * (POW2(T) - 100)) + ((POW(T) - 160) * (POW(T) - 160)))
X2 = (COS(AA3(T)) * DIST) + 160
Y2 = (SIN(AA3(T)) * DIST) + 100
PSET (X2, Y2)
  WOW(T) = XB(T) + CCC: WOW2(T) = YB(T) + CCC2
DIST = SQR(((WOW2(T) - 100) * (WOW2(T) - 100)) + ((WOW(T) - 160) * (WOW(T) - 160)))
X3 = (COS(AA3(T) - .1) * DIST) + 160
Y3 = (SIN(AA3(T) - .1) * DIST) + 100
PRESET (X3, Y3)
FUF(T) = X2: FUF2(T) = Y2
IF S(T) < 1 THEN GOSUB 52
NEXT T
LOOP
52
PRESET (FUF(T), FUF2(T))
A(T) = (INT(RND * 73) + 1) / 10
S(T) = INT(RND * 150) + 50
D(T) = INT(RND * 5) + 1
Y(T) = CCC: X(T) = CCC2
C(T) = INT(RND * 7) + 23
RETURN

764 SCREEN 13: CLS
ROY = 60
REDIM A(ROY), S(ROY), XB(ROY), YB(ROY), Y(ROY), X(ROY), D(ROY), C(ROY), AA3(ROY), POW(ROY), POW2(ROY), WOW(ROY), WOW2(ROY), FUF(ROY), FUF2(ROY)
CCC = 160
CCC2 = 100
FOR T = 1 TO ROY
A(T) = (INT(RND * 73) + 1) / 10
S(T) = INT(RND * 10) + 1
D(T) = INT(RND * 5) + 1
Y(T) = CCC: X(T) = CCC2
C(T) = INT(RND * 7) + 23
AA3(T) = A(T)
NEXT T
DO
FOR T = 1 TO ROY
COLOR C(T)
AA3(T) = AA3(T) + .1
IF AA3(T) = 7 THEN AA3(T) = 1
K$ = INKEY$
IF K$ = CHR$(27) THEN ERASE A, S, XB, YB, Y, X, D, C, AA3, POW, POW2, WOW, WOW2, FUF, FUF2: GOTO 922
YB(T) = Y(T): XB(T) = X(T)
S(T) = S(T) + D(T)
X(T) = COS(A(T)) * S(T)
Y(T) = SIN(A(T)) * S(T)
  POW(T) = X(T) + CCC: POW2(T) = Y(T) + CCC2
DIST = SQR(((POW2(T) - 100) * (POW2(T) - 100)) + ((POW(T) - 160) * (POW(T) - 160)))
X2 = (COS(AA3(T)) * DIST) + 160
Y2 = (SIN(AA3(T)) * DIST) + 100
PSET (X2, Y2)
  WOW(T) = XB(T) + CCC: WOW2(T) = YB(T) + CCC2
DIST = SQR(((WOW2(T) - 100) * (WOW2(T) - 100)) + ((WOW(T) - 160) * (WOW(T) - 160)))
X3 = (COS(AA3(T) - .1) * DIST) + 160
Y3 = (SIN(AA3(T) - .1) * DIST) + 100
PRESET (X3, Y3)
FUF(T) = X2: FUF2(T) = Y2
IF (Y(T) + CCC2) < 0 OR (Y(T) + CCC2) > 200 OR (X(T) + CCC) < 0 OR (X(T) + CCC) > 320 THEN GOSUB 56
NEXT T
LOOP
56
PRESET (FUF(T), FUF2(T))
A(T) = (INT(RND * 73) + 1) / 10
S(T) = INT(RND * 10) + 1
D(T) = INT(RND * 5) + 1
Y(T) = CCC: X(T) = CCC2
C(T) = INT(RND * 7) + 23
RETURN

765 SCREEN 13: CLS
RANDOMIZE TIMER
ROY = 50
REDIM X(ROY), Y(ROY), A(ROY), COL(ROY), XXX(ROY), YYY(ROY)
FOR T = 1 TO ROY
X(T) = INT(RND * 320) + 1
Y(T) = INT(RND * 200) + 1
A(T) = INT(RND * 4) + 1
COL(T) = INT(RND * 10) + 20
XXX(T) = INT(RND * 2) + 1
YYY(T) = INT(RND * 2) + 1
NEXT T
T = 0
PPP3 = 0
DO
K$ = INKEY$
IF K$ <> "" THEN ERASE X, Y, A, COL, XXX, YYY: GOTO 922
T = T + 1
IF T > ROY THEN T = 1
IF PPP3 = 0 THEN COL(T) = COL(T) + 1
IF PPP3 = 1 THEN COL(T) = COL(T) - 1
IF COL(T) > 30 THEN PPP3 = 1: COL(T) = 30
IF COL(T) < 20 THEN PPP3 = 0: COL(T) = 20
IF A(T) = 1 THEN X(T) = (X(T) + XXX(T)): Y(T) = (Y(T) + YYY(T))
IF A(T) = 2 THEN X(T) = (X(T) - XXX(T)): Y(T) = (Y(T) - YYY(T))
IF A(T) = 3 THEN X(T) = (X(T) + XXX(T)): Y(T) = (Y(T) - YYY(T))
IF A(T) = 4 THEN X(T) = (X(T) - XXX(T)): Y(T) = (Y(T) + YYY(T))
IF X(T) > 320 AND A(T) = 1 THEN A(T) = 4: X(T) = 320
IF X(T) > 320 AND A(T) = 3 THEN A(T) = 2: X(T) = 320
IF X(T) < 0 AND A(T) = 4 THEN A(T) = 1:  X(T) = 0
IF X(T) < 0 AND A(T) = 2 THEN A(T) = 3:  X(T) = 0
IF Y(T) > 200 AND A(T) = 1 THEN A(T) = 3:  Y(T) = 200
IF Y(T) > 200 AND A(T) = 4 THEN A(T) = 2:  Y(T) = 200
IF Y(T) < 0 AND A(T) = 3 THEN A(T) = 1:  Y(T) = 0
IF Y(T) < 0 AND A(T) = 2 THEN A(T) = 4:  Y(T) = 0
PSET (X(T), Y(T)), COL(T)
IF T <> ROY THEN PRESET (X(T + 1), Y(T + 1))
IF T = ROY THEN PRESET (X(1), Y(1))
LOOP


766
SCREEN 13: CLS
RANDOMIZE TIMER
DIM XS(100): DIM YS(100): DIM COLS(100)
FOR GTS = 1 TO 100
XS(GTS) = INT(RND * 318) + 1
YS(GTS) = INT(RND * 198) + 1
COLS(GTS) = INT(RND * 14) + 18
NEXT GTS
145 ROY = INT(RND * 90) + 10
WWW = INT(RND * 30) + 30
COL = INT(RND * 50) + 30
REDIM A(ROY), S(ROY), XB(ROY), YB(ROY), Y(ROY), X(ROY), D(ROY)
CCC = INT(RND * 320) + 1
CCC2 = INT(RND * 200) + 1
FOR T = 1 TO ROY
A(T) = (INT(RND * 73) + 1) / 10
S(T) = INT(RND * 10) + 1
D(T) = INT(RND * 5) + 1
Y(T) = CCC: X(T) = CCC2
NEXT T
DO
COL = COL + .2
COLOR COL
FOR T = 1 TO ROY
K$ = INKEY$
IF K$ = CHR$(27) THEN ERASE A, S, XB, YB, Y, X, D: GOTO 922
YB(T) = Y(T): XB(T) = X(T)
S(T) = S(T) + D(T)
X(T) = COS(A(T)) * S(T)
Y(T) = SIN(A(T)) * S(T)
PSET (X(T) + CCC, Y(T) + CCC2)
PRESET (XB(T) + CCC, YB(T) + CCC2)
NEXT T
FOR T = 1 TO 100
PSET (XS(T), YS(T)), COLS(T)
NEXT T
FOR TOT = 1 TO 100: NEXT TOT
HH = HH + 1
IF HH = WWW THEN FOR T = 1 TO ROY: YB(T) = Y(T): XB(T) = X(T): PRESET (XB(T) + CCC, YB(T) + CCC2): NEXT T: HH = 0: GOTO 145
LOOP

767
RANDOMIZE TIMER
SCREEN 13: CLS
ROY = 130
REDIM X(ROY), Y(ROY), A(ROY), S(ROY), C(ROY), R(ROY), SNS(ROY), XX(ROY), YY(ROY)
FOR T = 1 TO ROY
A(T) = (INT(RND * 73)) / 10
R(T) = INT(RND * 150) + 5
X(T) = (COS(A(T)) * R(T)) + 160
Y(T) = (SIN(A(T)) * R(T)) + 100
S(T) = INT(RND * 10) / 100
C(T) = INT(RND * 10) + 19
SNS(T) = INT(RND * 2) + 1
NEXT T

DO
FOR T = 1 TO ROY
XX(T) = X(T): YY(T) = Y(T)
IF SNS(T) = 1 THEN A(T) = A(T) + S(T)
IF SNS(T) = 2 THEN A(T) = A(T) - S(T)
X(T) = (COS(A(T)) * R(T)) + 160
Y(T) = (SIN(A(T)) * R(T)) + 100
PSET (X(T), Y(T)), C(T)
PRESET (XX(T), YY(T))
IF INKEY$ = CHR$(27) THEN ERASE X, Y, A, S, C, R, SNS, XX, YY: GOTO 922
NEXT T
LOOP

768
REM START
RANDOMIZE TIMER
SCREEN 13: CLS

REM DECALARATIONS
ROY = 150
CCC = 160
CCC2 = 100
REDIM A(ROY), S(ROY), XB(ROY), YB(ROY), Y(ROY), X(ROY), D(ROY), C(ROY), VT(ROY)




REM INITIALIZATION
FOR T = 1 TO ROY
VT(T) = 1
GOSUB 60890
NEXT T


REM RUNNING
DO

FOR T = 1 TO ROY
IF INKEY$ = CHR$(27) THEN ERASE A, S, XB, YB, Y, X, D, C, VT: GOTO 922
YB(T) = Y(T): XB(T) = X(T)
S(T) = (S(T) + D(T)) + 1
IF VT(T) = 1 THEN X(T) = COS(A(T)) * S(T)
IF VT(T) = 1 THEN Y(T) = SIN(A(T)) * S(T)

IF VT(T) = 2 THEN X(T) = TAN(A(T)) * S(T)
IF VT(T) = 2 THEN Y(T) = SIN(A(T)) * S(T)

IF VT(T) = 3 THEN X(T) = TAN(A(T)) * S(T)
IF VT(T) = 3 THEN Y(T) = COS(A(T)) * S(T)

IF VT(T) = 4 THEN X(T) = COS(A(T)) * S(T)
IF VT(T) = 4 THEN Y(T) = TAN(A(T)) * S(T)

IF VT(T) = 5 THEN X(T) = SIN(A(T)) * S(T)
IF VT(T) = 5 THEN Y(T) = TAN(A(T)) * S(T)

IF VT(T) = 6 THEN X(T) = COS(A(T)) * S(T)
IF VT(T) = 6 THEN Y(T) = SIN(A(T)) * S(T)

IF VT(T) = 7 THEN X(T) = COS(A(T)) * S(T)
IF VT(T) = 7 THEN Y(T) = SIN(A(T)) * S(T)

C(T) = C(T) + .5
IF C(T) > 50 THEN C(T) = 35
PSET (X(T) + CCC, Y(T) + CCC2), C(T)
PRESET (XB(T) + CCC, YB(T) + CCC2)
IF (Y(T) + CCC2) < -10 OR (Y(T) + CCC2) > 220 OR (X(T) + CCC) < -10 OR (X(T) + CCC) > 340 THEN GOSUB 60890
NEXT T

68890
LOOP


REM REINITIALIZATION
60890
IF CHC = 0 THEN QTX = INT(RND * 7) + 1: CHC = 1: NMB = INT(RND * 150) + 50: VX = 0: CCC = 160: VTT = INT(RND * 7) + 1
IF QTX = 1 THEN GOTO 111890
IF QTX = 2 THEN GOTO 222890
IF QTX = 7 THEN GOTO 222890
IF QTX = 3 THEN GOTO 333890
IF QTX = 4 THEN GOTO 444890
IF QTX = 5 THEN GOTO 555890
IF QTX = 6 THEN GOTO 666890

111890
Y(T) = CCC2: X(T) = CCC
S(T) = 5
D(T) = 5
VX = VX + 1
FG = FG + .1
IF FG > 7.3 THEN FG = 1
A(T) = FG
C(T) = 35
VT(T) = VTT
IF VX = NMB THEN CHC = 0
RETURN

222890
VX = VX + 1
A(T) = (INT(RND * 73) + 1) / 10
S(T) = 5
D(T) = 5
Y(T) = CCC: X(T) = CCC2
C(T) = 35
VT(T) = VTT
IF VX = NMB THEN CHC = 0
RETURN
       
333890
Y(T) = CCC2: X(T) = CCC
S(T) = 5
D(T) = 10
VX = VX + 1
FG = FG - .1
IF FG < -7.3 THEN FG = 1
A(T) = FG
C(T) = 35
VT(T) = VTT
IF VX = NMB THEN CHC = 0

RETURN


444890
Y(T) = CCC2: X(T) = CCC
S(T) = 5
D(T) = 10
VX = VX + 1
FG = ((FG * 2) / VX) + 1
A(T) = FG
C(T) = 35
VT(T) = VTT
IF VX = NMB THEN CHC = 0

RETURN

555890
Y(T) = CCC2: X(T) = CCC
S(T) = 90
D(T) = 10
VX = VX + 1
FG = FG - .1
A(T) = FG
C(T) = 35
VT(T) = VTT
IF VX = NMB THEN CHC = 0

RETURN

666890
Y(T) = CCC2: X(T) = CCC
S(T) = 20
D(T) = 5
VX = VX + 1
FG = FG + .01
A(T) = FG
C(T) = 35
VT(T) = VTT
IF VX = NMB THEN CHC = 0

RETURN




922

END SUB

SUB COOL
167 SCREEN 13: CLS
FOR GTS = 1 TO 300
XS = INT(RND * 318) + 1
YS = INT(RND * 198) + 1
COLS = INT(RND * 14) + 18
PSET (XS, YS), COLS
NEXT GTS
COLOR 33
LOCATE 2, 1: PRINT "1-OMEGA"
COLOR 34
LOCATE 5, 1: PRINT "2-LASER"
COLOR 35
LOCATE 8, 1: PRINT "3-CRAPER"
COLOR 36
LOCATE 11, 1: PRINT "4-COOLER"
COLOR 37
LOCATE 14, 1: PRINT "5-CYBER"
COLOR 38
LOCATE 17, 1: PRINT "6-DELTA"
COLOR 39
LOCATE 20, 1: PRINT "7-SPACE"
COLOR 40
LOCATE 23, 1: PRINT "8-LINES"
COLOR 43
LOCATE 2, 32: PRINT "A-GRAVITY"
COLOR 44
LOCATE 5, 32: PRINT "B-WARP"
COLOR 45
LOCATE 8, 32: PRINT "C-DOORWAY"
COLOR 46
LOCATE 11, 32: PRINT "D-BUGS"
COLOR 47
LOCATE 14, 32: PRINT "E-COOL"
COLOR 48
LOCATE 17, 32: PRINT "F-MORPH"
COLOR 49
LOCATE 20, 32: PRINT "G-SPHERES"
COLOR 50
LOCATE 23, 32: PRINT "H-SPOTS"
OPEN "DATA2" FOR INPUT AS #1
RER1 = 33
DID = INT(RND * 50) + 33
COLOR DID
DO
INPUT #1, X1: INPUT #1, Y1
T1 = 1.3
YY1 = Y1
XX1 = ((7.2 * X1) / 320) + T1
RER1 = RER1 + .1
CIRCLE (158, 100), YY1, RER1, XX1, (XX1 + .1)
LOOP UNTIL (EOF(1))
CLOSE
DO
FOR X = 1 TO 7.3 STEP .1
GHY = GHY + 1
IF GHY = 4 THEN GHY = 1
K$ = INKEY$
XX9 = COS(X - .3) * 7
YY9 = SIN(X - .3) * 7

XX = COS(X) * 7
YY = SIN(X) * 7
XX2 = COS(X + .3) * 7
YY2 = SIN(X + .3) * 7
XX3 = COS(X + .6) * 7
YY3 = SIN(X + .6) * 7
XX4 = COS(X + .9) * 7
YY4 = SIN(X + .9) * 7
XX5 = COS(X + 1.2) * 7
YY5 = SIN(X + 1.2) * 7
XX6 = COS(X + 1.5) * 7
YY6 = SIN(X + 1.5) * 7
XX7 = COS(X + 1.8) * 7
YY7 = SIN(X + 1.8) * 7
XX8 = COS(X + 2.1) * 7
IF GHY < 3 THEN GOTO 6786

LOCATE YYY + 9, XXX + 21: PRINT " "
LOCATE YYY2 + 9, XXX2 + 21: PRINT " "
LOCATE YYY3 + 9, XXX3 + 21: PRINT " "
LOCATE YYY4 + 9, XXX4 + 21: PRINT " "
LOCATE YYY5 + 9, XXX5 + 21: PRINT " "
LOCATE YYY6 + 9, XXX6 + 21: PRINT " "
LOCATE YYY7 + 9, XXX7 + 21: PRINT " "

LOCATE YY + 9, XX + 21: PRINT "V"
LOCATE YY2 + 9, XX2 + 21: PRINT "I"
LOCATE YY3 + 9, XX3 + 21: PRINT "R"
LOCATE YY4 + 9, XX4 + 21: PRINT "T"
LOCATE YY5 + 9, XX5 + 21: PRINT "U"
LOCATE YY6 + 9, XX6 + 21: PRINT "A"
LOCATE YY7 + 9, XX7 + 21: PRINT "L"

XXX = XX
XXX2 = XX2
XXX3 = XX3
XXX4 = XX2
XXX5 = XX5
XXX6 = XX6
XXX7 = XX7

YYY = YY
YYY2 = YY2
YYY3 = YY3
YYY4 = YY4
YYY5 = YY5
YYY6 = YY6
YYY7 = YY7

6786

LOCATE YY9 + 9, XX9 + 21: PRINT " "
COL = COL + 3
IF COL >= 300 THEN COL = 20
FOR XG = 1 TO 45 STEP 1
K$ = INKEY$
IF K$ = CHR$(27) THEN KTX$ = "":  GOTO 55
IF K$ = "1" THEN CALL SHOW("OMEGA BEEMS", 20, 14): KTX$ = "1"
IF K$ = "2" THEN CALL SHOW("LASER BEEMS", 20, 14): KTX$ = "2"
IF K$ = "3" THEN CALL SHOW("   CRAPER  ", 20, 14): KTX$ = "3"
IF K$ = "4" THEN CALL SHOW("   COOLER  ", 20, 14): KTX$ = "4"
IF K$ = "5" THEN CALL SHOW("CYBER STORM", 20, 14): KTX$ = "5"
IF K$ = "6" THEN CALL SHOW("   DELTA   ", 20, 14): KTX$ = "6"
IF K$ = "7" THEN CALL SHOW("   SPACE   ", 20, 14): KTX$ = "7"
IF K$ = "8" THEN CALL SHOW("   LINES   ", 20, 14): KTX$ = "8"
IF UCASE$(K$) = "A" THEN CALL SHOW("  GRAVITY  ", 20, 14): KTX$ = "A"
IF UCASE$(K$) = "B" THEN CALL SHOW("    WARP   ", 20, 14): KTX$ = "B"
IF UCASE$(K$) = "C" THEN CALL SHOW("  DOORWAYS ", 20, 14): KTX$ = "C"
IF UCASE$(K$) = "D" THEN CALL SHOW("BUGS__WORMS", 20, 14): KTX$ = "D"
IF UCASE$(K$) = "E" THEN CALL SHOW("   COOL    ", 20, 14): KTX$ = "E"
IF UCASE$(K$) = "F" THEN CALL SHOW("   MORPH   ", 20, 14): KTX$ = "F"
IF UCASE$(K$) = "G" THEN CALL SHOW("  SPHERES  ", 20, 14): KTX$ = "G"
IF UCASE$(K$) = "H" THEN CALL SHOW("   SPOTS   ", 20, 14): KTX$ = "H"
IF K$ = CHR$(32) OR K$ = CHR$(13) AND KTX$ <> "" THEN GOTO 666
321
CIRCLE (159, 60), XG, (XG + COL) / 2, , , .7
NEXT XG
NEXT X
QAZXSW = QAZXSW + 1
IF K$ <> "" THEN QAZXSW = 0
IF QAZXSW = 33 THEN CALL SAVER3: GOTO 167
LOOP
666
IF KTX$ = "1" THEN CALL OMEGA: GOTO 167
IF KTX$ = "2" THEN CALL LASER: GOTO 167
IF KTX$ = "3" THEN CALL CRAPER: GOTO 167
IF KTX$ = "4" THEN CALL COOLER: GOTO 167
IF KTX$ = "5" THEN CALL CYBER: GOTO 167
IF KTX$ = "6" THEN CALL DELTA: GOTO 167
IF KTX$ = "7" THEN CALL BALL: GOTO 167
IF KTX$ = "8" THEN CALL LINES: GOTO 167
IF KTX$ = "A" THEN CALL SHELLA: GOTO 167
IF KTX$ = "B" THEN CALL TYPE1: GOTO 167
IF KTX$ = "C" THEN CALL TYPE2: GOTO 167
IF KTX$ = "D" THEN CALL TUNNELS: GOTO 167
IF KTX$ = "E" THEN CALL COOLX: GOTO 167
IF KTX$ = "F" THEN CALL DISCO: GOTO 167
IF KTX$ = "G" THEN CALL SPHERES: GOTO 167
IF KTX$ = "H" THEN CALL SPOTS: GOTO 167:  ELSE GOTO 321
55
FOR T = 1 TO 300
CIRCLE (160, 100), T, 0, , , .5
NEXT T
END SUB

SUB COOLER
SCREEN 0: CLS
WIDTH 80, 25
LOCATE 3, 25: COLOR 10: PRINT "COOLER BY ROY MASSAAD 1997@. "
1675 LOCATE 6, 30: COLOR 15: INPUT "CHOOSE A MODE (1-2) "; DDD
IF DDD > 2 OR DDD < 1 THEN GOTO 1675
IF DDD = 1 THEN GOTO 9876
IF DDD = 2 THEN GOTO 9877
9877
SCREEN 13: CLS
RANDOMIZE TIMER
G = 16
DO
F = F + .1
IF FG = 1 THEN FF = FF + 1
IF FG = 2 THEN FF = FF - 1
IF FF < 5 THEN FG = 1
IF FF > 100 THEN FG = 2
FOR T = 2 TO 7.2 STEP 1.26
X2 = (COS(T + F) * (40 + FF)) + 160
Y2 = (SIN(T + F) * (40 + FF)) + 100
LINE (X2, Y2)-((COS((T + .62) + F) * (10 + FF)) + 160, (SIN((T + .62) + F) * (10 + FF)) + 100), G
LINE (X2, Y2)-((COS((T - .62) + F) * (10 + FF)) + 160, (SIN((T - .62) + F) * (10 + FF)) + 100), G
NEXT T
FOR Z = 1 TO 2500: NEXT Z
IF INKEY$ = CHR$(27) THEN GOTO 91
G = G + .1
LOOP

9876 SCREEN 13: CLS
RANDOMIZE TIMER
G = 150
C = INT(RND * 100) + 18
DDD = C
RTR = INT(RND * 6) + 1
QWQ = INT(RND * 25) + 5
DO
K = K + 2
G = G - 1
X = COS(K) * G
Y = SIN(K) * G
X2 = COS(K + 1) * G
Y2 = SIN(K + 1) * G
C = DDD
FOR T = 1 TO QWQ STEP RTR
C = C + .3
X = COS(K) * (G - T)
Y = SIN(K) * (G - T)
X2 = COS(K + 1) * (G - T)
Y2 = SIN(K + 1) * (G - T)
LINE (X + 150, Y + 100)-(X2 + 150, Y2 + 100), C
NEXT T
K$ = INKEY$
IF K$ = CHR$(27) THEN GOTO 91
IF G < -200 THEN GOTO 9876
FOR TOT = 1 TO 2500: NEXT TOT
LOOP
91
END SUB

SUB COOLX
SCREEN 0: CLS
WIDTH 80, 25
RANDOMIZE TIMER
COL = 25
SCREEN 0: CLS
COLOR 10
LOCATE 2, 20: PRINT "COOL STUFF BY ROY MASSAAD 1997 .tM"
7779 LOCATE 4, 20: COLOR 15: INPUT "CHOOSE A MODE (1-2)"; MD
IF MD <= 0 OR MD >= 3 THEN GOTO 7779
IF MD = 1 THEN GOTO 7778
IF MD = 2 THEN GOTO 7777
7778
COLOR 14
LOCATE 6, 28: PRINT "1-CUSTOM   2-RANDOM"
DO
K$ = INKEY$
IF K$ = "2" THEN GOTO 222
IF K$ = "1" THEN GOTO 555
LOOP
555 LOCATE 9, 26: COLOR 11: INPUT "CHOOSE A MODE (1-5) "; FEF
IF FEF <= 0 OR FEF >= 6 THEN GOTO 555
PASS = 1
GOTO 567
222 FEF = INT(RND * 5) + 1
567
SCREEN 13: CLS
DO
CLS
FOR GTS = 1 TO 150
XS = INT(RND * 318) + 1
YS = INT(RND * 198) + 1
COLS = INT(RND * 14) + 18
PSET (XS, YS), COLS
NEXT GTS
S1 = INT(RND * 10) + 1
S2 = INT(RND * 50) + 1
S3 = INT(RND * 10) + 1
S4 = INT(RND * 50) + 1
S5 = INT(RND * 50) + 1
S6 = INT(RND * 50) + 1
FOR T = 1 TO 8 STEP .007
K$ = INKEY$
IF K$ = CHR$(27) THEN GOTO 93
XX = (COS(S1 * T) * S2) + 150
YY = (SIN(S3 * T) * S4) + 100
X = (COS(T) * S5) + XX
Y = (SIN(T) * S6) + YY
COL = COL + .01
IF COL > 250 THEN COL = 25
IF FEF = 1 THEN PSET (X, Y), COL
IF FEF = 2 THEN LINE (X, Y)-(X + 5, Y + 5), COL
IF FEF = 3 THEN CIRCLE (X, Y), 5, COL
IF FEF = 4 THEN LINE (X, Y)-(150, 100), COL

IF FEF = 5 THEN ANG = (INT(RND * 63) + 1) / 10
IF FEF = 5 THEN LENG = INT(RND * 15) + 1
IF FEF = 5 THEN XP = (COS(ANG) * LENG) + X
IF FEF = 5 THEN YP = (SIN(ANG) * LENG) + Y
IF FEF = 5 THEN LINE (X, Y)-(XP, YP), COL
IF FEF = 5 THEN CIRCLE (XP, YP), 0, COL
FOR TOT = 1 TO 500: NEXT TOT
NEXT T
IF PASS = 0 THEN FEF = INT(RND * 5) + 1
LOOP

7777
SCREEN 13: CLS
RANDOMIZE TIMER
X = INT(RND * 320) + 1
Y = INT(RND * 200) + 1
A = INT(RND * 4) + 1
CCC = 20
AAC = INT(RND * 5) + 1: BBC = INT(RND * 5) + 1
HHH = INT(RND * 7) + 1
HHH2 = INT(RND * 7) + 1
ROY = INT(RND * 3) + 1
DRT = INT(RND * 15) + 1
AQAQ = INT(RND * 1000) + 1000
FRGR = 0
DO
FRGR = FRGR + 1
K$ = INKEY$
IF K$ = CHR$(27) THEN GOTO 93
IF FRGR = AQAQ THEN GOTO 7777
IF A = 1 THEN X = (X + AAC): Y = (Y + BBC)
IF A = 2 THEN X = (X - AAC): Y = (Y - BBC)
IF A = 3 THEN X = (X + AAC): Y = (Y - BBC)
IF A = 4 THEN X = (X - AAC): Y = (Y + BBC)
IF X > 320 AND A = 1 THEN A = 4: X = 320
IF X > 320 AND A = 3 THEN A = 2:  X = 320
IF X < 0 AND A = 4 THEN A = 1:  X = 0
IF X < 0 AND A = 2 THEN A = 3:  X = 0
IF Y > 200 AND A = 1 THEN A = 3: : Y = 200
IF Y > 200 AND A = 4 THEN A = 2:  Y = 200
IF Y < 0 AND A = 3 THEN A = 1:  Y = 0
IF Y < 0 AND A = 2 THEN A = 4: Y = 0
IF COL > 300 THEN COL = 20
IF COL < 20 THEN COL = 20
CCC = CCC + .05
IF CCC > 300 THEN CCC = 20
HHH = HHH + .1
IF HHH > 7 THEN HHH = 1
HHH2 = HHH2 + .1
IF HHH2 > 7 THEN HHH2 = 1
F = COS(HHH) * 3
FF = SIN(HHH2) * 3
X = X + F
Y = Y + FF
IF ROY = 1 THEN CIRCLE (X, Y), DRT, CCC
IF ROY = 2 THEN LINE (X, Y)-(X + 10, Y + 10), CCC
IF ROY = 3 THEN PSET (X, Y), CCC
FOR TOT = 1 TO 1000: NEXT TOT
LOOP
93
END SUB

SUB CRAPER
SCREEN 0: CLS
WIDTH 80, 25
LOCATE 3, 20: COLOR 10: PRINT "CRAPER BY ROY MASSAAD"
13 LOCATE 6, 20: COLOR 15: INPUT "CHOOSE A MODE (1-5)"; MD
IF MD <= 0 OR MD >= 6 THEN GOTO 13
SCREEN 13: CLS
A = 160: B = 100
RANDOMIZE TIMER
DO
K$ = INKEY$
IF K$ = CHR$(27) THEN GOTO 89
ANG = (INT(RND * 63) + 1) / 10
LENG = INT(RND * 15) + 1
'COL = INT(RND * 300) + 1
COL = COL + .01
X = COS(ANG)
Y = SIN(ANG)
IF MD = 1 THEN LINE (A, B)-((X * LENG) + A, (Y * LENG) + B), COL
IF MD = 2 THEN FOR T = 1 TO 10 STEP 1: CIRCLE (A, B), T, (T + COL) / 1: NEXT T
IF MD = 3 THEN LINE (A - 5, B - 5)-(A + 5, B + 5), COL, B
IF MD = 4 THEN PSET (A, B), COL / 10
IF MD = 5 THEN LINE (150, 100)-(A, B), FFF
BAK = A: BAK2 = B
A = (X * LENG) + A
B = (Y * LENG) + B
FFF = FFF + .01
IF FFF > 320 THEN FFF = 0
IF MD = 5 THEN LINE (BAK, BAK2)-(A, B), FFF
IF A > 320 OR A < 0 THEN A = 160
IF B > 200 OR B < 0 THEN B = 100

FOR TOT = 1 TO 250: NEXT TOT
LOOP
89
END SUB

SUB CYBER
'ON ERROR GOTO 100001
SCREEN 0: CLS
WIDTH 80, 25
LOCATE 3, 25: COLOR 14: PRINT "CYBER BY ROY MASSAAD"
LOCATE 6, 26: COLOR 15: PRINT "1-CUSTOM OR 2-RANDOM"
DO
K$ = INKEY$
IF K$ = "1" THEN GOTO 444
IF K$ = "2" THEN GOTO 789
IF K$ = CHR$(27) THEN GOTO 67
LOOP
444 LOCATE 9, 25: INPUT "CHOOSE A MODE (1-7) "; CL
IF CL <= 0 OR CL >= 8 THEN GOTO 444
HHH = 1
789 SCREEN 13: CLS
RANDOMIZE TIMER
COLOR 10
GUG = 20
U = 150
22 CLS
FOR GTS = 1 TO 150
XS = INT(RND * 318) + 1
YS = INT(RND * 198) + 1
COLS = INT(RND * 14) + 18
PSET (XS, YS), COLS
NEXT GTS
RAY = INT(RND * 2) + 1
CST = INT(RND * 4) + 1
SPR = INT(RND * 3) + 1
DUD3 = INT(RND * 30) + 1
S6 = (INT(RND * 10) + 1) / 100
U6 = (INT(RND * 10)) / 10
BIG6 = (INT(RND * 10) + 1) / 100
BIG26 = (INT(RND * 10) + 1) / 100
GUG6 = (INT(RND * 20) + 1) / 100
DUD6 = INT(RND * 20)
BIG = INT(RND * 30) + 1
BIG2 = INT(RND * 30) + 1
ON6 = INT(RND * 4) - 3
IF ON6 < 0 THEN ON6 = 1
FRT = INT(RND * 300) + 20
IF HHH = 0 THEN CL = INT(RND * 7) + 1
OP = INT(RND * 3) + 1
MOVE6 = INT(RND * 5) + 1
TUT6 = (INT(RND * 10) + 1) / 10
IF OP = 1 AND CL = 2 THEN U = 0
IF OP = 2 AND CL = 2 THEN U = 320
IF OP = 3 AND CL = 2 THEN U = 150
IF CL <> 2 THEN U = 150
DO
FOR A = 0 TO 6.3 STEP S6
IF OP = 1 THEN U = U + (U6 * ON6)
IF OP = 2 THEN U = U - (U6 * ON6)
K$ = INKEY$
FOR TOT = 1 TO 1500: NEXT TOT
IF K$ = CHR$(27) THEN GOTO 67
IF CST = 1 OR CST = 4 THEN X = COS(A): Y = SIN(A)
IF CST = 2 THEN X = TAN(A): Y = SIN(A)
IF CST = 3 THEN X = COS(A): Y = TAN(A)
BIG = BIG + (BIG6 * ON6)
BIG2 = BIG2 + (BIG26 * ON6)
GUG = GUG + GUG6
IF GUG > FRT THEN GUG = 20
IF PASS = 0 THEN DUD = DUD + 1
IF PASS = 1 THEN DUD = DUD - 1
IF DUD > DUD6 AND SPR = 1 THEN PASS = 1
IF DUD < 1 AND SPR = 1 THEN PASS = 0
IF DUD > DUD6 AND SPR = 2 THEN DUD = 0
IF DUD < 1 AND SPR = 2 THEN PASS = 0
IF SPR = 3 THEN DUD = DUD3
DUD5 = DUD5 + .01
IF RAY = 2 THEN DUD = DUD5
IF CL = 1 THEN TUT = TUT + TUT6: LINE ((X * (BIG + TUT)) + 150, (Y * (BIG2)) + 100)-((X * (BIG)) + 150, (Y * (BIG2)) + 100), GUG
IF CL = 2 THEN CIRCLE ((X * (BIG)) + U, (Y * (BIG2)) + 100), DUD, GUG
IF CL = 3 THEN LINE ((X * (BIG)) + 150, (Y * (BIG2)) + 100)-((X * (BIG) + 5) + 150, (Y * (BIG2) + 5) + 100), GUG
IF CL = 4 THEN LINE (1, 1)-((X * (BIG)) + 150, (Y * (BIG2)) + 100), GUG: LINE (1, 199)-((X * (BIG)) + 150, (Y * (BIG2)) + 100), GUG: LINE (315, 1)-((X * (BIG)) + 150, (Y * (BIG2)) + 100), GUG: LINE (315, 199)-((X * (BIG)) + 150, (Y * (BIG2)) + 100) _
, GUG
IF CL = 5 THEN LINE (150, 100)-((X * (BIG)) + 150, (Y * (BIG2)) + 100), GUG
IF CL = 6 THEN LINE ((X * (BIG - 15)) + 150, (Y * (BIG2)) + 100)-((X * (BIG + 15)) + 150, (Y * (BIG2)) + 100), GUG: LINE ((X * (BIG - 15)) + 150, (Y * (BIG2)) + 100)-((X * (BIG)) + 150, (Y * (BIG2 - 15)) + 100), GUG: LINE ((X * (BIG + 15)) + 150, (Y _
 * (BIG2)) + 100)-((X * (BIG)) + 150, (Y * (BIG2 - 15)) + 100), GUG
IF CL = 7 THEN LINE (X * BIG + 150, Y * BIG2 + 150)-(Y + DUD + BIG, X + GUG + BIG2), GUG
NEXT A
DID = DID + 1
IF DID = 10 THEN DID = 0: U = 150: DUD5 = 0: GOTO 22
LOOP
  

67
END SUB

SUB DELTA
RANDOMIZE TIMER
SCREEN 0: CLS
WIDTH 80, 25
LOCATE 3, 25: COLOR 10: PRINT "DELTA BY ROY ROY MASSAAD 1997@. "
143 LOCATE 6, 30: COLOR 15: INPUT "CHOOSE A MODE (1-6) "; DDD
IF DDD > 6 OR DDD < 1 THEN GOTO 143
IF DDD = 1 THEN GOTO 161
IF DDD = 2 THEN GOTO 162
IF DDD = 3 THEN GOTO 163
IF DDD = 4 THEN GOTO 164
IF DDD = 5 THEN GOTO 165
IF DDD = 6 THEN GOTO 166
161
SCREEN 13: CLS
DO
K$ = INKEY$
IF K$ = CHR$(27) THEN GOTO 66
COL = INT(RND * 300) + 1
X = INT(RND * 160) + 1
Y = INT(RND * 200) + 1
M = INT(RND * 200) + 1
M2 = INT(RND * 200) + 1
XP = (320 - X)
YP = Y
LINE (X, Y)-(160, M), COL
LINE (XP, YP)-(160, M), COL
LINE (X, Y)-(160, M2), COL
LINE (XP, YP)-(160, M2), COL
I = INT(RND * 200) + 1
I2 = INT(RND * 200) + 1
I3 = INT(RND * 200) + 1
I4 = INT(RND * 200) + 1
I5 = INT(RND * 200) + 1
TILE$ = CHR$(I) + CHR$(I2) + CHR$(I3) + CHR$(I4) + CHR$(I5)
PAINT (160, (M + M2) / 2), TILE$, COL
C = C + 1
FOR T = 1 TO 16000: NEXT T
IF C = 10 THEN C = 0: FOR T = 1 TO 1000: NEXT T: CLS
LOOP
162

SCREEN 13: CLS
RANDOMIZE TIMER
CCC = 30
DO
IF CCC > 100 THEN CCC = 30
F = F + .1
CCC = CCC + 1
FOR T = 2 TO 7.2 STEP 1.26
X2 = (COS(T + F) * 80) + 160
Y2 = (SIN(T + F) * 80) + 100
LINE (X2, Y2)-((COS(T + .62) * 50) + 160, (SIN(T + .62) * 50) + 100), CCC
LINE (X2, Y2)-((COS(T - .62) * 50) + 160, (SIN(T - .62) * 50) + 100), CCC
NEXT T
FOR Z = 1 TO 15000: NEXT Z
FOR T = 2 TO 7.2 STEP 1.26
X2 = (COS(T + F) * 80) + 160
Y2 = (SIN(T + F) * 80) + 100
LINE (X2, Y2)-((COS(T + .62) * 50) + 160, (SIN(T + .62) * 50) + 100), 0
LINE (X2, Y2)-((COS(T - .62) * 50) + 160, (SIN(T - .62) * 50) + 100), 0
NEXT T
IF INKEY$ = CHR$(27) THEN GOTO 66
LOOP


163
SCREEN 13: CLS
DO
FOR Y = 1 TO 200 STEP 2
FOR X = 1 TO 320 STEP 5
LINE (160, 100)-(X, Y), (X / 10) + 16 + FFF
NEXT X
IF INKEY$ = CHR$(27) THEN GOTO 66
FOR X2 = 1 TO 320 STEP 5
LINE (160, 100)-(X2, Y), 0
NEXT X2
FFF = FFF + 1
NEXT Y

FOR Y = 200 TO 1 STEP -2
FOR X = 1 TO 320 STEP 5
LINE (160, 100)-(X, Y), (X / 10) + 16 + FFF
NEXT X
IF INKEY$ = CHR$(27) THEN GOTO 66
FOR X2 = 1 TO 320 STEP 5
LINE (160, 100)-(X2, Y), 0
NEXT X2
FFF = FFF - 1
NEXT Y
LOOP

164
SCREEN 13: CLS
RANDOMIZE TIMER
CCC = 30
DO
F = F + .1
IF CCC > 100 THEN CCC = 30
CCC = CCC + 1
IF FG = 1 THEN FF = FF + 1
IF FG = 2 THEN FF = FF - 1
IF FF < 5 THEN FG = 1
IF FF > 100 THEN FG = 2
FOR T = 2 TO 7.2 STEP 1.26
X2 = (COS(T + F) * (40 + FF)) + 160
Y2 = (SIN(T + F) * (40 + FF)) + 100
LINE (X2, Y2)-((COS((T + .62) + F) * (10 + FF)) + 160, (SIN((T + .62) + F) * (10 + FF)) + 100), CCC
LINE (X2, Y2)-((COS((T - .62) + F) * (10 + FF)) + 160, (SIN((T - .62) + F) * (10 + FF)) + 100), CCC
NEXT T
FOR Z = 1 TO 15000: NEXT Z
IF INKEY$ = CHR$(27) THEN GOTO 66
FOR T = 2 TO 7.2 STEP 1.26
X2 = (COS(T + F) * (40 + FF)) + 160
Y2 = (SIN(T + F) * (40 + FF)) + 100
LINE (X2, Y2)-((COS((T + .62) + F) * (10 + FF)) + 160, (SIN((T + .62) + F) * (10 + FF)) + 100), 0
LINE (X2, Y2)-((COS((T - .62) + F) * (10 + FF)) + 160, (SIN((T - .62) + F) * (10 + FF)) + 100), 0
NEXT T

LOOP

165

SCREEN 13: CLS
RANDOMIZE TIMER
CCC = 30
DO
CCC = CCC + 1
IF CCC > 100 THEN CCC = 30
F = F + .1
FOR T = 2 TO 7.2 STEP 1.26
X2 = (COS(T) * 80) + 160
Y2 = (SIN(T) * 80) + 100
LINE (X2, Y2)-((COS((T + .62) + F) * 50) + 160, (SIN((T + .62) + F) * 50) + 100), CCC
LINE (X2, Y2)-((COS((T - .62) + F) * 50) + 160, (SIN((T - .62) + F) * 50) + 100), CCC
NEXT T
FOR Z = 1 TO 15000: NEXT Z
FOR T = 2 TO 7.2 STEP 1.26
X2 = (COS(T) * 80) + 160
Y2 = (SIN(T) * 80) + 100
LINE (X2, Y2)-((COS((T + .62) + F) * 50) + 160, (SIN((T + .62) + F) * 50) + 100), 0
LINE (X2, Y2)-((COS((T - .62) + F) * 50) + 160, (SIN((T - .62) + F) * 50) + 100), 0
NEXT T
IF INKEY$ = CHR$(27) THEN GOTO 66
LOOP
166

SCREEN 13: CLS
RANDOMIZE TIMER
AX = INT(RND * 320) + 1
AY = INT(RND * 200) + 1
BX = INT(RND * 320) + 1
BY = INT(RND * 200) + 1
AD = INT(RND * 15) + 40
BD = INT(RND * 15) + 40
A = INT(RND * 4) + 1
B = INT(RND * 4) + 1

DO
FAX = AX: FAY = AY: FBX = BX: FBY = BY
IF A = 1 THEN AX = AX + 2: AY = AY + 2
IF A = 2 THEN AX = AX - 2: AY = AY - 2
IF A = 3 THEN AX = AX + 2: AY = AY - 2
IF A = 4 THEN AX = AX - 2: AY = AY + 2
IF AX > 320 AND A = 1 THEN A = 4: AX = 320
IF AX > 320 AND A = 3 THEN A = 2: AX = 320
IF AX < 0 AND A = 4 THEN A = 1:  AX = 0
IF AX < 0 AND A = 2 THEN A = 3:  AX = 0
IF AY > 200 AND A = 1 THEN A = 3: AY = 200
IF AY > 200 AND A = 4 THEN A = 2:  AY = 200
IF AY < 0 AND A = 3 THEN A = 1:  AY = 0
IF AY < 0 AND A = 2 THEN A = 4:  AY = 0
WW = WW + .1
FOR T = 1 TO 7.3 STEP .2
AAX = (COS(T) * AD) + AX
AAY = (SIN(T) * AD) + AY
LINE (160, 100)-(AAX, AAY), 18 + T + WW
LINE (AX, AY)-(AAX, AAY), 18 + T + WW
NEXT T
FOR T = 1 TO 1000: NEXT T
FOR T = 1 TO 7.3 STEP .2
AAX = (COS(T) * AD) + AX
AAY = (SIN(T) * AD) + AY
LINE (160, 100)-(AAX, AAY), 0
LINE (AX, AY)-(AAX, AAY), 0
NEXT T
IF INKEY$ = CHR$(27) THEN GOTO 66
LOOP



66
END SUB

SUB DISCO
1323 SCREEN 13: CLS
RANDOMIZE TIMER
REDIM X1(100), Y1(100), X2(100), Y2(100), XB1(100), YB1(100)
CTY = INT(RND * 100) + 20
GOSUB 888323
GOSUB 666323

DO
FOR T = 1 TO 100
OP = ((INT(RND * 0) + 10) / 10)
Q = Q + 1

IF Q > 27500 AND H = 1 THEN : ERASE X1, Y1, X2, Y2, XB1, YB1: T99 = 0: S99 = 0: D1 = 0: D2 = 0: C88 = 0: Y88 = 0: X88 = 0: H = 0: A88 = 0: V88 = 0: CT88 = 0: VU = 0: QQ = 0: RR = 0: PO = 0: FG = 0: YU = 0: A = 0: B = 0: TT = 0: SA = 0: S1 = 0: S2 =  _
0: F = 0: CTY = 0: T = 0: OP = 0: Q = 0: H = 0: GOTO 1323: GOSUB 444323: GOSUB 999323: Q = 0: LINE (0, 0)-(320, 200), 0, BF: GOTO 7323
IF Q > 27500 AND H = 2 THEN GOSUB 444323: GOSUB 777323: Q = 0: LINE (0, 0)-(320, 200), 0, BF:  GOTO 7323
IF Q > 27500 AND H = 3 THEN GOSUB 444323: GOSUB 888323: Q = 0: LINE (0, 0)-(320, 200), 0, BF:  GOTO 7323

XB1(T) = X1(T): YB1(T) = Y1(T)

A = ABS(X1(T) - X2(T))
B = ABS(Y1(T) - Y2(T))

IF A >= B THEN GOSUB 10323: GOTO 3323
IF B >= A THEN GOSUB 20323: GOTO 3323
3323
F = F + .01
CTY = CTY + .001
CIRCLE (XB1(T), YB1(T)), 1, 0


CIRCLE (X1(T), Y1(T)), 1, CTY
7323
NEXT T
LOOP UNTIL INKEY$ = CHR$(27)
ERASE X1, Y1, X2, Y2, XB1, YB1
GOTO 1122334

10323
IF X1(T) >= X2(T) THEN GOTO 11323
IF X1(T) <= X2(T) THEN GOTO 12323

11323
TT = X1(T) - OP
IF TT = X2(T) - 1 THEN TT = X2(T)
Y1(T) = ((Y2(T) * X1(T) - Y1(T) * X2(T)) - (TT) * (Y2(T) - Y1(T))) / (X1(T) - X2(T))
X1(T) = TT
RETURN

12323
TT = X1(T) + OP
IF TT = X2(T) + 1 THEN TT = X2(T)
Y1(T) = ((Y2(T) * X1(T) - Y1(T) * X2(T)) - (TT) * (Y2(T) - Y1(T))) / (X1(T) - X2(T))
X1(T) = TT
RETURN

20323
IF Y1(T) >= Y2(T) THEN GOTO 21323
IF Y1(T) <= Y2(T) THEN GOTO 22323

21323
TT = Y1(T) - OP
IF TT = Y2(T) - 1 THEN TT = Y2(T)
X1(T) = ((TT * (X1(T) - X2(T))) - (Y2(T) * X1(T) - Y1(T) * X2(T))) / (Y1(T) - Y2(T))
Y1(T) = TT
RETURN

22323
TT = Y1(T) + OP
IF TT = Y2(T) + 1 THEN TT = Y2(T)
X1(T) = ((TT * (X1(T) - X2(T))) - (Y2(T) * X1(T) - Y1(T) * X2(T))) / (Y1(T) - Y2(T))
Y1(T) = TT
RETURN




666323
SA = 0
S1 = INT(RND * 30) + 30
S2 = INT(RND * 170) + 50
VU = INT(RND * 3) + 1
QQ = 0: RR = 0
FOR YU = 1 TO 3
FOR PO = 1 TO 33
SA = SA + 1
IF YU = 1 THEN QQ = (QQ + VU): RR = (RR + (VU / 1)): X1(SA) = QQ + S2: Y1(SA) = RR + S1
IF YU = 2 THEN QQ = (QQ - (VU * 2)): X1(SA) = QQ + S2: Y1(SA) = RR + S1
IF YU = 3 THEN QQ = (QQ + VU): RR = (RR - (VU / 1)): X1(SA) = QQ + S2: Y1(SA) = RR + S1
XB1(SA) = X1(SA): YB1(SA) = Y1(SA)
CIRCLE (X1(SA), Y1(SA)), 1, CTY
NEXT PO
NEXT YU
X1(100) = X1(1): Y1(100) = Y1(1)
XB1(100) = XB1(1): YB1(100) = YB1(1)
FOR FG = 1 TO 7000: NEXT FG
RETURN

777323
H = 1
A88 = 1
V88 = INT(RND * 4) + 3
CT88 = 0
C88 = 0
Y88 = 0
X88 = 0
S1 = INT(RND * 120) + 70
S2 = INT(RND * 25) + 25
DO
C88 = C88 + 1
IF C88 > 25 AND A88 = 4 THEN RETURN
IF C88 > 25 THEN C88 = 0: A88 = A88 + 1: GOTO 31323
IF A88 = 1 THEN X88 = X88 + V88
IF A88 = 2 THEN Y88 = Y88 + V88
IF A88 = 3 THEN X88 = X88 - V88
IF A88 = 4 THEN Y88 = Y88 - V88
X2(CT88 + 1) = X88 + S1
Y2(CT88 + 1) = Y88 + S2
IF X2(CT88 + 1) = 0 THEN X2(CT88 + 1) = 1
IF Y2(CT88 + 1) = 0 THEN Y2(CT88 + 1) = 1
CT88 = CT88 + 1
31323
LOOP

888323
H = 2
S99 = .0627
D1 = INT(RND * 50) + 40
D2 = INT(RND * 50) + 40
S1 = INT(RND * 140) + 90
S2 = INT(RND * 140) + 90
FOR T99 = 1 TO 100
S99 = S99 + .0627
X2(T99) = (COS(S99) * D1) + S1
Y2(T99) = (SIN(S99) * D2) + S2
IF X2(T99) = 0 THEN X2(T99) = 1
IF Y2(T99) = 0 THEN Y2(T99) = 1
NEXT T99
RETURN

999323
H = 3
SA = 0
S1 = INT(RND * 40) + 40
S2 = INT(RND * 150) + 50
VU = INT(RND * 3) + 1
QQ = 0: RR = 0
FOR YU = 1 TO 3
FOR PO = 1 TO 33
SA = SA + 1
IF YU = 1 THEN QQ = (QQ + VU): RR = (RR + (VU / 1)): X2(SA) = QQ + S2: Y2(SA) = RR + S1
IF YU = 2 THEN QQ = (QQ - (VU * 2)): X2(SA) = QQ + S2: Y2(SA) = RR + S1
IF YU = 3 THEN QQ = (QQ + VU): RR = (RR - (VU / 1)): X2(SA) = QQ + S2: Y2(SA) = RR + S1
'PSET (X2(SA), Y2(SA)), 15
NEXT PO
NEXT YU
X2(100) = X2(1): Y2(100) = Y2(1)
RETURN



444323
FOR U = 1 TO 100
X1(U) = X2(U)
Y1(U) = Y2(U)
XB1(U) = X1(U)
YB1(U) = Y1(U)
NEXT U
RETURN

1122334
END SUB

SUB FINISH
CALL SHOW("EXIT TO DOS (Y/N)", 23, 11)
DO
K$ = INKEY$
IF UCASE$(K$) = "Y" THEN CALL SHOW("SEE YAAAAAAAAAAAA", 23, 11): SLEEP 2:  GOSUB 9090: CLS : SCREEN 0: WIDTH 80, 25: COLOR 26: PRINT "THANK YOU FOR TAKING A MOMENT TO SEE THIS PROGRAM ...": COLOR 7: SYSTEM
IF UCASE$(K$) = "N" THEN GOTO 35
LOOP
9090
FOR T = 1 TO 5 STEP .006
T2 = T + 3
T3 = T + 6
LINE (80, 174 + T)-(221, 174 + T), 0
LINE (80, 174 + T2)-(221, 174 + T2), 0
LINE (80, 174 + T3)-(221, 174 + T3), 0
NEXT T
FOR T = 1 TO 100
LINE (1, T)-(320, 200 - T), 0, B
FOR C = 1 TO 2000: NEXT C
NEXT T
RETURN
35
END SUB

SUB INFO
CLOSE
SCREEN 13: CLS
REDIM QWE(150): REDIM ASD(150): REDIM ZXC(150): REDIM PLY(150): REDIM FGF(150)
FOR TR = 1 TO 150
QWE(TR) = INT(RND * 360) + 1
ASD(TR) = INT(RND * 200) + 1
ZXC(TR) = INT(RND * 10) + 20
PLY(TR) = 1
FGF(TR) = (INT(RND * 10) + 1) / 5
NEXT TR
T = 0
PLY = 1

OPEN "DATA" FOR INPUT AS #1
E = 20
DO
INPUT #1, X: INPUT #1, Y
X = X / 2
Y = Y / 2
O = O + .1
T = COS(O) * 2
TT = SIN(O) * 2
X = X + T + M
Y = Y + TT + MM
E = E + .1
PSET (X + 80, Y - 30), E
LOOP UNTIL (EOF(1))
CLOSE
AD = 1
COC = 18
DO
FOR COL = 1 TO 500 STEP 1
FOR X = 1 TO 35 STEP 1

TR = TR + 1
IF TR > 150 THEN TR = 1
IF PLY(TR) = 1 THEN ZXC(TR) = ZXC(TR) + FGF(TR)
IF PLY(TR) = 2 THEN ZXC(TR) = ZXC(TR) - FGF(TR)
IF ZXC(TR) > 30 THEN ZXC(TR) = 30: PLY(TR) = 2
IF ZXC(TR) < 20 THEN ZXC(TR) = 20: PLY(TR) = 1
IF QWE(TR) > 85 AND QWE(TR) < 225 THEN GOSUB 6789
PSET (QWE(TR), ASD(TR)), ZXC(TR)
9879
K$ = INKEY$
IF K$ = CHR$(27) THEN GOTO 45
LINE (85 + X, 35 + X)-(225 - X, 175 - X), X + COL, B
IF COC >= 31 THEN AD = 0
IF COC <= 17 THEN AD = 1
IF AD = 1 THEN COC = COC + .03
IF AD = 0 THEN COC = COC - .03
COLOR COC
LOCATE 11, 18: PRINT "CODED"
LOCATE 13, 20: PRINT "B"
LOCATE 14, 20: PRINT "Y"
LOCATE 16, 19: PRINT "ROY"
QAZXSW = QAZXSW + 1
IF K$ <> "" THEN QAZXSW = 0
IF QAZXSW = 10000 THEN ERASE QWE, ASD, ZXC, PLY, FGF: CALL SAVER2: GOTO 45
NEXT X
NEXT COL
LOOP
6789
IF ASD(TR) > 35 AND ASD(TR) < 175 THEN GOTO 9879
RETURN
45
DO
FGH = FGH + 1
XC = (INT(RND * 69) - 5) * 5
YC = (INT(RND * 45) - 5) * 5
LINE (XC, YC)-(XC + 5, YC + 5), 0, BF
LOOP WHILE FGH < 15000
CLS
END SUB

SUB LASER
SCREEN 0: CLS
WIDTH 80, 25
COLOR 15: LOCATE 3, 21: PRINT "* LASER BEEMS BY ROY MASSAAD (1997) *"
14 COLOR 10: LOCATE 8, 24: INPUT "ENTER MOVEMENT SPEED (0-30) "; AAA
IF AAA < 0 OR AAA > 30 THEN GOTO 14
AAA = AAA / 2
2 LOCATE 10, 26: INPUT "ENTER COLOR SPEED (0-100) "; BBB
IF BBB < 0 OR BBB > 100 THEN GOTO 2
BBB = BBB / 100
SCREEN 13: CLS
RANDOMIZE TIMER
X = INT(RND * 318) + 1
Y = INT(RND * 198) + 1
Z = INT(RND * 318) + 1
W = INT(RND * 198) + 1
M = INT(RND * 318) + 1
N = INT(RND * 198) + 1
A = INT(RND * 4) + 1
B = INT(RND * 4) + 1
C = INT(RND * 4) + 1
X1 = INT(RND * 318) + 1
Y1 = INT(RND * 198) + 1
Z1 = INT(RND * 318) + 1
W1 = INT(RND * 198) + 1
M1 = INT(RND * 318) + 1
N1 = INT(RND * 198) + 1
A1 = INT(RND * 4) + 1
B1 = INT(RND * 4) + 1
C1 = INT(RND * 4) + 1
REDIM XS(200): REDIM YS(200): REDIM COLS(200)
FOR GTS = 1 TO 200
XS(GTS) = INT(RND * 318) + 1
YS(GTS) = INT(RND * 198) + 1
COLS(GTS) = INT(RND * 14) + 18
PSET (XS(GTS), YS(GTS)), COLS(GTS)
NEXT GTS
GTS = 0
DO
GTS = GTS + 1
IF GTS = 200 THEN GTS = 1
PSET (XS(GTS), YS(GTS)), COLS(GTS)
PUSSY = PUSSY + (.06 + BBB)
IF PUSSY > 220 THEN PUSSY = 1
K$ = INKEY$
LINE (X1, Y1)-(X, Y), 25 + PUSSY: LINE (Z1, W1)-(Z, W), 26 + PUSSY: LINE (M1, N1)-(M, N), 27 + PUSSY
PSET (XS(GTS), YS(GTS)), COLS(GTS)
LINE (X1 - 5, Y1 - 5)-(X - 5, Y - 5), 25 + PUSSY: LINE (Z1 - 5, W1 - 5)-(Z - 5, W - 5), 26 + PUSSY: LINE (M1 - 5, N1 - 5)-(M - 5, N - 5), 27 + PUSSY
PSET (XS(GTS), YS(GTS)), COLS(GTS)
LINE (X1 - 9, Y1 - 9)-(X - 9, Y - 9), 25 + PUSSY: LINE (Z1 - 9, W1 - 9)-(Z - 9, W - 9), 26 + PUSSY: LINE (M1 - 9, N1 - 9)-(M - 9, N - 9), 27 + PUSSY
PSET (XS(GTS), YS(GTS)), COLS(GTS)
LINE (X, Y)-(Z, W), 18 + PUSSY: LINE (Z, W)-(M, N), 21 + PUSSY: LINE (M, N)-(X, Y), 24 + PUSSY
PSET (XS(GTS), YS(GTS)), COLS(GTS)
LINE (X - 5, Y - 5)-(Z - 5, W - 5), 19 + PUSSY: LINE (Z - 5, W - 5)-(M - 5, N - 5), 22 + PUSSY: LINE (M - 5, N - 5)-(X - 5, Y - 5), 24 + PUSSY
PSET (XS(GTS), YS(GTS)), COLS(GTS)
LINE (X - 9, Y - 9)-(Z - 9, W - 9), 20 + PUSSY: LINE (Z - 9, W - 9)-(M - 9, N - 9), 23 + PUSSY: LINE (M - 9, N - 9)-(X - 9, Y - 9), 24 + PUSSY
PSET (XS(GTS), YS(GTS)), COLS(GTS)
HEAD = Y: BUTT = X: HEAD2 = W: BUTT2 = Z: HEAD3 = N: BUTT3 = M
IF A = 1 THEN X = X + (1 + AAA): Y = Y + (1 + AAA)
IF A = 2 THEN X = X - (1 + AAA): Y = Y - (1 + AAA)
IF A = 3 THEN X = X + (1 + AAA): Y = Y - (1 + AAA)
IF A = 4 THEN X = X - (1 + AAA): Y = Y + (1 + AAA)
IF X >= 320 AND Y > HEAD AND X > BUTT THEN A = 4
IF X >= 320 AND Y < HEAD AND X > BUTT THEN A = 2
IF X <= 7 AND Y > HEAD AND X < BUTT THEN A = 1
IF X <= 7 AND Y < HEAD AND X < BUTT THEN A = 3
IF Y >= 200 AND X > BUTT AND Y > HEAD THEN A = 3
IF Y >= 200 AND X < BUTT AND Y > HEAD THEN A = 2
IF Y <= 7 AND X > BUTT AND Y < HEAD THEN A = 1
IF Y <= 7 AND X < BUTT AND Y < HEAD THEN A = 4
IF B = 1 THEN Z = Z + (.5 + AAA): W = W + (.5 + AAA)
IF B = 2 THEN Z = Z - (.5 + AAA): W = W - (.5 + AAA)
IF B = 3 THEN Z = Z + (.5 + AAA): W = W - (.5 + AAA)
IF B = 4 THEN Z = Z - (.5 + AAA): W = W + (.5 + AAA)
IF Z >= 320 AND W > HEAD2 AND Z > BUTT2 THEN B = 4
IF Z >= 320 AND W < HEAD2 AND Z > BUTT2 THEN B = 2
IF Z <= 7 AND W > HEAD2 AND Z < BUTT2 THEN B = 1
IF Z <= 7 AND W < HEAD2 AND Z < BUTT2 THEN B = 3
IF W >= 200 AND Z > BUTT2 AND W > HEAD2 THEN B = 3
IF W >= 200 AND Z < BUTT2 AND W > HEAD2 THEN B = 2
IF W <= 7 AND Z > BUTT2 AND W < HEAD2 THEN B = 1
IF W <= 7 AND Z < BUTT2 AND W < HEAD2 THEN B = 4
IF C = 1 THEN M = M + (.75 + AAA): N = N + (.75 + AAA)
IF C = 2 THEN M = M - (.75 + AAA): N = N - (.75 + AAA)
IF C = 3 THEN M = M + (.75 + AAA): N = N - (.75 + AAA)
IF C = 4 THEN M = M - (.75 + AAA): N = N + (.75 + AAA)
IF M >= 320 AND N > HEAD3 AND M > BUTT3 THEN C = 4
IF M >= 320 AND N < HEAD3 AND M > BUTT3 THEN C = 2
IF M <= 7 AND N > HEAD3 AND M < BUTT3 THEN C = 1
IF M <= 7 AND N < HEAD3 AND M < BUTT3 THEN C = 3
IF N >= 200 AND M > BUTT3 AND N > HEAD3 THEN C = 3
IF N >= 200 AND M < BUTT3 AND N > HEAD3 THEN C = 2
IF N <= 7 AND M > BUTT3 AND N < HEAD3 THEN C = 1
IF N <= 7 AND M < BUTT3 AND N < HEAD3 THEN C = 4
LINE (X1, Y1)-(Z1, W1), 28 + PUSSY: LINE (Z1, W1)-(M1, N1), 31 + PUSSY: LINE (M1, N1)-(X1, Y1), 34 + PUSSY
LINE (X1, Y1)-(Z1, W1), 28 + PUSSY: LINE (Z1, W1)-(M1, N1), 31 + PUSSY: LINE (M1, N1)-(X1, Y1), 34 + PUSSY
LINE (X1 - 5, Y1 - 5)-(Z1 - 5, W1 - 5), 29 + PUSSY: LINE (Z1 - 5, W1 - 5)-(M1 - 5, N1 - 5), 32 + PUSSY: LINE (M1 - 5, N1 - 5)-(X1 - 5, Y1 - 5), 35 + PUSSY
PSET (XS(GTS), YS(GTS)), COLS(GTS)
PSET (XS(GTS), YS(GTS)), COLS(GTS)
LINE (X1 - 5, Y1 - 5)-(Z1 - 5, W1 - 5), 29 + PUSSY: LINE (Z1 - 5, W1 - 5)-(M1 - 5, N1 - 5), 32 + PUSSY: LINE (M1 - 5, N1 - 5)-(X1 - 5, Y1 - 5), 35 + PUSSY
PSET (XS(GTS), YS(GTS)), COLS(GTS)
LINE (X1 - 9, Y1 - 9)-(Z1 - 9, W1 - 9), 30 + PUSSY: LINE (Z1 - 9, W1 - 9)-(M1 - 9, N1 - 9), 33 + PUSSY: LINE (M1 - 9, N1 - 9)-(X1 - 9, Y1 - 9), 36 + PUSSY
PSET (XS(GTS), YS(GTS)), COLS(GTS)
FOR DX = 1 TO 5000: NEXT DX
LINE (BUTT, HEAD)-(BUTT2, HEAD2), 0: LINE (BUTT2, HEAD2)-(BUTT3, HEAD3), 0: LINE (BUTT3, HEAD3)-(BUTT, HEAD), 0
PSET (XS(GTS), YS(GTS)), COLS(GTS)
LINE (BUTT - 5, HEAD - 5)-(BUTT2 - 5, HEAD2 - 5), 0: LINE (BUTT2 - 5, HEAD2 - 5)-(BUTT3 - 5, HEAD3 - 5), 0: LINE (BUTT3 - 5, HEAD3 - 5)-(BUTT - 5, HEAD - 5), 0
PSET (XS(GTS), YS(GTS)), COLS(GTS)
LINE (BUTT - 9, HEAD - 9)-(BUTT2 - 9, HEAD2 - 9), 0: LINE (BUTT2 - 9, HEAD2 - 9)-(BUTT3 - 9, HEAD3 - 9), 0: LINE (BUTT3 - 9, HEAD3 - 9)-(BUTT - 9, HEAD - 9), 0
HEAD1 = Y1: BUTT1 = X1: HEAD21 = W1: BUTT21 = Z1: HEAD31 = N1: BUTT31 = M1
IF A1 = 1 THEN X1 = X1 + (.25 + AAA): Y1 = Y1 + (.25 + AAA)
IF A1 = 2 THEN X1 = X1 - (.25 + AAA): Y1 = Y1 - (.25 + AAA)
IF A1 = 3 THEN X1 = X1 + (.25 + AAA): Y1 = Y1 - (.25 + AAA)
IF A1 = 4 THEN X1 = X1 - (.25 + AAA): Y1 = Y1 + (.25 + AAA)
IF X1 >= 320 AND Y1 > HEAD1 AND X1 > BUTT1 THEN A1 = 4
IF X1 >= 320 AND Y1 < HEAD1 AND X1 > BUTT1 THEN A1 = 2
IF X1 <= 7 AND Y1 > HEAD1 AND X1 < BUTT1 THEN A1 = 1
IF X1 <= 7 AND Y1 < HEAD1 AND X1 < BUTT1 THEN A1 = 3
IF Y1 >= 200 AND X1 > BUTT1 AND Y1 > HEAD1 THEN A1 = 3
IF Y1 >= 200 AND X1 < BUTT1 AND Y1 > HEAD1 THEN A1 = 2
IF Y1 <= 7 AND X1 > BUTT1 AND Y1 < HEAD1 THEN A1 = 1
IF Y1 <= 7 AND X1 < BUTT1 AND Y1 < HEAD1 THEN A1 = 4
IF B1 = 1 THEN Z1 = Z1 + (1.5 + AAA): W1 = W1 + (1.5 + AAA)
IF B1 = 2 THEN Z1 = Z1 - (1.5 + AAA): W1 = W1 - (1.5 + AAA)
IF B1 = 3 THEN Z1 = Z1 + (1.5 + AAA): W1 = W1 - (1.5 + AAA)
IF B1 = 4 THEN Z1 = Z1 - (1.5 + AAA): W1 = W1 + (1.5 + AAA)
IF Z1 >= 320 AND W1 > HEAD21 AND Z1 > BUTT21 THEN B1 = 4
IF Z1 >= 320 AND W1 < HEAD21 AND Z1 > BUTT21 THEN B1 = 2
IF Z1 <= 7 AND W1 > HEAD21 AND Z1 < BUTT21 THEN B1 = 1
IF Z1 <= 7 AND W1 < HEAD21 AND Z1 < BUTT21 THEN B1 = 3
IF W1 >= 200 AND Z1 > BUTT21 AND W1 > HEAD21 THEN B1 = 3
IF W1 >= 200 AND Z1 < BUTT21 AND W1 > HEAD21 THEN B1 = 2
IF W1 <= 7 AND Z1 > BUTT21 AND W1 < HEAD21 THEN B1 = 1
IF W1 <= 7 AND Z1 < BUTT21 AND W1 < HEAD21 THEN B1 = 4
IF C1 = 1 THEN M1 = M1 + (.75 + AAA): N1 = N1 + (.75 + AAA)
IF C1 = 2 THEN M1 = M1 - (.75 + AAA): N1 = N1 - (.75 + AAA)
IF C1 = 3 THEN M1 = M1 + (.75 + AAA): N1 = N1 - (.75 + AAA)
IF C1 = 4 THEN M1 = M1 - (.75 + AAA): N1 = N1 + (.75 + AAA)
IF M1 >= 320 AND N1 > HEAD31 AND M1 > BUTT31 THEN C1 = 4
IF M1 >= 320 AND N1 < HEAD31 AND M1 > BUTT31 THEN C1 = 2
IF M1 <= 7 AND N1 > HEAD31 AND M1 < BUTT31 THEN C1 = 1
IF M1 <= 7 AND N1 < HEAD31 AND M1 < BUTT31 THEN C1 = 3
IF N1 >= 200 AND M1 > BUTT31 AND N1 > HEAD31 THEN C1 = 3
IF N1 >= 200 AND M1 < BUTT31 AND N1 > HEAD31 THEN C1 = 2
IF N1 <= 7 AND M1 > BUTT31 AND N1 < HEAD31 THEN C1 = 1
IF N1 <= 7 AND M1 < BUTT31 AND N1 < HEAD31 THEN C1 = 4
FOR DX = 1 TO 100: NEXT DX
LINE (BUTT1, HEAD1)-(BUTT21, HEAD21), 0: LINE (BUTT21, HEAD21)-(BUTT31, HEAD31), 0: LINE (BUTT31, HEAD31)-(BUTT1, HEAD1), 0
PSET (XS(GTS), YS(GTS)), COLS(GTS)
LINE (BUTT1 - 5, HEAD1 - 5)-(BUTT21 - 5, HEAD21 - 5), 0: LINE (BUTT21 - 5, HEAD21 - 5)-(BUTT31 - 5, HEAD31 - 5), 0: LINE (BUTT31 - 5, HEAD31 - 5)-(BUTT1 - 5, HEAD1 - 5), 0
PSET (XS(GTS), YS(GTS)), COLS(GTS)
LINE (BUTT1 - 9, HEAD1 - 9)-(BUTT21 - 9, HEAD21 - 9), 0: LINE (BUTT21 - 9, HEAD21 - 9)-(BUTT31 - 9, HEAD31 - 9), 0: LINE (BUTT31 - 9, HEAD31 - 9)-(BUTT1 - 9, HEAD1 - 9), 0
PSET (XS(GTS), YS(GTS)), COLS(GTS)
LINE (BUTT, HEAD)-(BUTT1, HEAD1), 0: LINE (BUTT2, HEAD2)-(BUTT21, HEAD21), 0: LINE (BUTT3, HEAD3)-(BUTT31, HEAD31), 0
PSET (XS(GTS), YS(GTS)), COLS(GTS)
LINE (BUTT - 5, HEAD - 5)-(BUTT1 - 5, HEAD1 - 5), 0: LINE (BUTT2 - 5, HEAD2 - 5)-(BUTT21 - 5, HEAD21 - 5), 0: LINE (BUTT3 - 5, HEAD3 - 5)-(BUTT31 - 5, HEAD31 - 5), 0
PSET (XS(GTS), YS(GTS)), COLS(GTS)
LINE (BUTT - 9, HEAD - 9)-(BUTT1 - 9, HEAD1 - 9), 0: LINE (BUTT2 - 9, HEAD2 - 9)-(BUTT21 - 9, HEAD21 - 9), 0: LINE (BUTT3 - 9, HEAD3 - 9)-(BUTT31 - 9, HEAD31 - 9), 0
IF K$ = CHR$(27) THEN GOTO 100
PSET (XS(GTS), YS(GTS)), COLS(GTS)
LOOP
100
ERASE XS, YS, COLS

END SUB

SUB LINES
SCREEN 0: CLS
WIDTH 80, 25
LOCATE 3, 25: COLOR 10: PRINT "LINES BY ROY ROY MEGA GAMES 1997@. "
5675 LOCATE 6, 30: COLOR 15: INPUT "CHOOSE A MODE (1-6) "; DDD
IF DDD > 6 OR DDD < 1 THEN GOTO 5675
IF DDD = 1 THEN GOTO 901
IF DDD = 2 THEN GOTO 902
IF DDD = 3 THEN GOTO 903
IF DDD = 4 THEN GOTO 904
IF DDD = 5 THEN GOTO 905
IF DDD = 6 THEN GOTO 906

901 SCREEN 13: CLS
RANDOMIZE TIMER
DO
K$ = INKEY$
C = INT(RND * 300)
X = INT(RND * 315)
YY = INT(RND * 2)
Y = YY * 199
X1 = INT(RND * 315)
YY1 = INT(RND * 2)
Y1 = YY1 * 199
LINE (X, Y)-(X1, Y1), C

C2 = INT(RND * 300)
XX2 = INT(RND * 2)
Y2 = INT(RND * 199)
X2 = XX2 * 315
XX21 = INT(RND * 2)
Y21 = INT(RND * 199)
X21 = XX21 * 315
LINE (X2, Y2)-(X21, Y21), C2

IF K$ = CHR$(27) THEN GOTO 78
SHIT = SHIT + .5
IF SHIT > 200 THEN SHIT = 1
CIRCLE (150, 100), SHIT, 0, , , 1

SHIT2 = SHIT2 + 1
IF SHIT2 > 200 THEN SHIT2 = 1
CIRCLE (150, 100), SHIT2, 0
FOR T = 1 TO 100: NEXT T

LOOP

902 SCREEN 13: CLS
RANDOMIZE TIMER
X = INT(RND * 320) + 1
Y = INT(RND * 200) + 1
A = INT(RND * 4) + 1
COL = 20
AAC = 1: BBC = 1

X2 = INT(RND * 320) + 1
Y2 = INT(RND * 200) + 1
A2 = INT(RND * 4) + 1
AAC2 = 1: BBC2 = 1

DO
K$ = INKEY$
IF K$ = CHR$(27) THEN GOTO 78
IF K$ <> "" THEN GOTO 902
IF A = 1 THEN X = (X + AAC): Y = (Y + BBC)
IF A = 2 THEN X = (X - AAC): Y = (Y - BBC)
IF A = 3 THEN X = (X + AAC): Y = (Y - BBC)
IF A = 4 THEN X = (X - AAC): Y = (Y + BBC)
IF X > 320 AND A = 1 THEN A = 4: X = 320
IF X > 320 AND A = 3 THEN A = 2: X = 320
IF X < 0 AND A = 4 THEN A = 1:  X = 0
IF X < 0 AND A = 2 THEN A = 3:  X = 0
IF Y > 200 AND A = 1 THEN A = 3: Y = 200
IF Y > 200 AND A = 4 THEN A = 2:  Y = 200
IF Y < 0 AND A = 3 THEN A = 1:  Y = 0
IF Y < 0 AND A = 2 THEN A = 4:  Y = 0


IF A2 = 1 THEN X2 = (X2 + AAC2): Y2 = (Y2 + BBC2)
IF A2 = 2 THEN X2 = (X2 - AAC2): Y2 = (Y2 - BBC2)
IF A2 = 3 THEN X2 = (X2 + AAC2): Y2 = (Y2 - BBC2)
IF A2 = 4 THEN X2 = (X2 - AAC2): Y2 = (Y2 + BBC2)
IF X2 > 320 AND A2 = 1 THEN A2 = 4: X2 = 320
IF X2 > 320 AND A2 = 3 THEN A2 = 2:  X2 = 320
IF X2 < 0 AND A2 = 4 THEN A2 = 1:  X2 = 0
IF X2 < 0 AND A2 = 2 THEN A2 = 3:  X2 = 0
IF Y2 > 200 AND A2 = 1 THEN A2 = 3:  Y2 = 200
IF Y2 > 200 AND A2 = 4 THEN A2 = 2:  Y2 = 200
IF Y2 < 0 AND A2 = 3 THEN A2 = 1: Y2 = 0
IF Y2 < 0 AND A2 = 2 THEN A2 = 4: Y2 = 0


COL = COL + .05
IF COL > 300 THEN COL = 20
IF COL < 20 THEN COL = 20

LINE (X2, Y2)-(X, Y), COL
FOR TOT = 1 TO 1000: NEXT TOT
LOOP


903
SCREEN 13: CLS
Y3 = 200: Y4 = 1
COL = 30
IOI = 0
DO
FOR T = 1 TO 7.25 STEP .01
Y4 = Y4 + .05
Y3 = Y3 - .05
K$ = INKEY$
IF K$ = CHR$(27) THEN GOTO 78
X1 = (COS(T) * 30)
Y1 = (SIN(T) * 30)
T2 = (T * (-1))
X2 = (COS(T2) * 30)
Y2 = (SIN(T2) * 30)
X5 = (COS(T) * 10)
Y5 = (SIN(T) * 10)
COL = COL + .05
IOI = IOI + 1
IF IOI = 10000 THEN GOTO 903
LINE (X5 + 160, Y5 + 100)-(X2 + 50, Y2 + Y4), COL, B: LINE (X5 + 160, Y5 + 100)-(X1 + 250, Y1 + Y3), COL, B: LINE (X5 + 160, Y5 + 100)-((X2 - 20) + 50, (Y2 - 20) + Y4), COL, B: LINE (X5 + 160, Y5 + 100)-((X1 + 20) + 250, (Y1 + 20) + Y3), COL, B: _
                            LINE (X2 + 50, Y2 + Y4)-((X2 - 20) + 50, (Y2 - 20) + Y4), COL, B: LINE (X1 + 250, Y1 + Y3)-((X1 + 20) + 250, (Y1 + 20) + Y3), COL, B: LINE (X2 + 50, Y2 + Y4)-(X1 + 250, Y1 + Y3), COL, B: LINE ((X2 - 20) + 50, (Y2 - 20) +  _
Y4)-((X1 + 20) + 250, (Y1 + 20) + Y3), COL, B:

NEXT T
LOOP

904
SCREEN 13: CLS
DO
FOR T = 1 TO 7.3 STEP .1
X = (COS(T) * 70) + 160
Y = (SIN(T) * 50) + 100
CIRCLE (X, Y), 5, (T * 10)
PRINT " "
IF INKEY$ = CHR$(27) THEN GOTO 78
NEXT T
LOOP
905

SCREEN 13: CLS
RANDOMIZE TIMER
M = 4.7
A = 4.7
DX = INT(RND * 35) + 35
DY = 600
XX = INT(RND * 300) + 10
YY = DY
S = INT(RND * 2) + 1
G = 20
X = XX: Y = -1
DO
XC = X: YC = Y
IF S = 1 THEN A = A + .02
IF S = 2 THEN A = A - .02

X = (COS(A) * DX) + XX
Y = (SIN(A) * DY) + YY
G = G + .01
LINE (X, Y)-(XC, YC), G
FOR TOT = 1 TO 1000: NEXT TOT
IF B = 1 AND Y < 200 THEN B = 0

IF Y > 220 AND B = 0 AND S = 1 THEN A = M - (A - M): DX = DX + 20: XX = XX + (DX * 1.25): DY = DY - 20: B = 1:  GOTO 11789
IF Y > 220 AND B = 0 AND S = 2 THEN A = M + (M - A): DX = DX + 20: XX = XX - (DX * 1.25): DY = DY - 20: B = 1:  GOTO 11789

IF X < 0 AND B = 0 AND S = 2 THEN S = 1: DX = DX + 25: B = 1: H = 0: GOTO 11789
IF X > 330 AND B = 0 AND S = 1 THEN S = 2: DX = DX + 25: B = 1: H = 0: GOTO 11789

IF Y > 300 THEN GOTO 905
11789

LOOP UNTIL INKEY$ = CHR$(27)
GOTO 78

906
SCREEN 13: CLS
RANDOMIZE TIMER
ROY = 6
REDIM X(ROY), Y(ROY), A(ROY), XB(ROY), YB(ROY)
S = 1
C = 20
FOR T = 1 TO ROY
X(T) = INT(RND * 320) + 1
Y(T) = INT(RND * 200) + 1
A(T) = INT(RND * 4) + 1
NEXT T
DO
FOR T = 1 TO ROY

YB(T) = Y(T): XB(T) = X(T)

IF A(T) = 1 THEN X(T) = X(T) - S: Y(T) = Y(T) - S
IF A(T) = 2 THEN X(T) = X(T) - S: Y(T) = Y(T) + S
IF A(T) = 3 THEN X(T) = X(T) + S: Y(T) = Y(T) + S
IF A(T) = 4 THEN X(T) = X(T) + S: Y(T) = Y(T) - S

IF X(T) < 0 AND A(T) = 1 THEN A(T) = 4
IF X(T) < 0 AND A(T) = 2 THEN A(T) = 3
IF X(T) > 320 AND A(T) = 4 THEN A(T) = 1
IF X(T) > 320 AND A(T) = 3 THEN A(T) = 2

IF Y(T) < 0 AND A(T) = 1 THEN A(T) = 2
IF Y(T) < 0 AND A(T) = 4 THEN A(T) = 3
IF Y(T) > 200 AND A(T) = 2 THEN A(T) = 1
IF Y(T) > 200 AND A(T) = 3 THEN A(T) = 4

FOR TT = 1 TO ROY - 1

XX = 160 - X(TT)
YY = Y(TT)
XX2 = 160 - X(TT + 1)
YY2 = Y(TT + 1)

ZZ = 160 - XB(TT)
WW = YB(TT)
ZZ2 = 160 - XB(TT + 1)
WW2 = YB(TT + 1)

LINE (160 + ZZ, WW)-(160 + ZZ2, WW2), 0
LINE (XB(TT), YB(TT))-(XB(TT + 1), YB(TT + 1)), 0

C = C + .01
IF C > 200 THEN C = 20

LINE (X(TT), Y(TT))-(X(TT + 1), Y(TT + 1)), 10 + C
LINE (160 + XX, YY)-(160 + XX2, YY2), 15 + C


NEXT TT

NEXT T
LOOP UNTIL INKEY$ = CHR$(27)
ERASE X, Y, A, XB, YB

78
END SUB

SUB OMEGA
SCREEN 0: CLS
WIDTH 80, 25
COLOR 15: LOCATE 3, 21: PRINT "* OMEGA BEEMS BY ROY MASSAAD (1997) *"
COLOR 10
255
3 LOCATE 8, 22: INPUT "ENTER LENGTH LEVEL (-150 150) "; CCC1
IF CCC1 < -150 OR CCC1 > 150 THEN GOTO 3
4 LOCATE 10, 22: INPUT "ENTER DENSITY LEVEL (1-95) "; DENS
IF DENS < 0 OR DENS > 95 THEN GOTO 4
IF DENS = 0 THEN DENS = 85
DENS = 100 - DENS
SCREEN 13: CLS
RANDOMIZE TIMER
X = INT(RND * 318) + 1
Y = INT(RND * 198) + 1
Z = INT(RND * 318) + 1
W = INT(RND * 198) + 1
M = INT(RND * 318) + 1
N = INT(RND * 198) + 1
A = INT(RND * 4) + 1
B = INT(RND * 4) + 1
C = INT(RND * 4) + 1
REDIM BX(1000)
REDIM BY(1000)
REDIM BZ(1000)
REDIM BW(1000)
REDIM BM(1000)
REDIM BN(1000)
BUTT = 15
DO
BUTT = BUTT + .001
IF BUTT >= 320 THEN BUTT = 16
SHIT = SHIT + 1
IF SHIT = (201 + CCC1) THEN SHIT = 1
BX(SHIT) = X
BY(SHIT) = Y
BZ(SHIT) = Z
BW(SHIT) = W
BM(SHIT) = M
BN(SHIT) = N
LINE (X, Y)-(Z, W), 11 + BUTT: LINE (Z, W)-(M, N), 12 + BUTT: LINE (M, N)-(X, Y), 13 + BUTT
FOR AAA = 1 TO (200 + CCC1) STEP DENS
BUTT = BUTT + .001
HEAD = HEAD + 1
IF HEAD = 11 THEN HEAD = 1
ABC = SHIT - AAA
IF ABC < 0 THEN ABC = ABC + (200 + CCC1)
LINE (BX(ABC), BY(ABC))-(BZ(ABC), BW(ABC)), BUTT + 4: LINE (BZ(ABC), BW(ABC))-(BM(ABC), BN(ABC)), BUTT + 4: LINE (BM(ABC), BN(ABC))-(BX(ABC), BY(ABC)), BUTT + 4
NEXT AAA
HEAD1 = Y: BUTT1 = X: HEAD2 = W: BUTT2 = Z: HEAD3 = N: BUTT3 = M
K$ = INKEY$
IF K$ = CHR$(27) THEN GOTO 1001
IF A = 1 THEN X = X + .25: Y = Y + .25
IF A = 2 THEN X = X - .25: Y = Y - .25
IF A = 3 THEN X = X + .25: Y = Y - .25
IF A = 4 THEN X = X - .25: Y = Y + .25
IF X >= 320 AND Y > HEAD1 AND X > BUTT1 THEN A = 4
IF X >= 320 AND Y < HEAD1 AND X > BUTT1 THEN A = 2
IF X <= 0 AND Y > HEAD1 AND X < BUTT1 THEN A = 1
IF X <= 0 AND Y < HEAD1 AND X < BUTT1 THEN A = 3
IF Y >= 200 AND X > BUTT1 AND Y > HEAD1 THEN A = 3
IF Y >= 200 AND X < BUTT1 AND Y > HEAD1 THEN A = 2
IF Y <= 0 AND X > BUTT1 AND Y < HEAD1 THEN A = 1
IF Y <= 0 AND X < BUTT1 AND Y < HEAD1 THEN A = 4
IF B = 1 THEN Z = Z + .55: W = W + .55
IF B = 2 THEN Z = Z - .55: W = W - .55
IF B = 3 THEN Z = Z + .55: W = W - .55
IF B = 4 THEN Z = Z - .55: W = W + .55
IF Z >= 320 AND W > HEAD2 AND Z > BUTT2 THEN B = 4
IF Z >= 320 AND W < HEAD2 AND Z > BUTT2 THEN B = 2
IF Z <= 0 AND W > HEAD2 AND Z < BUTT2 THEN B = 1
IF Z <= 0 AND W < HEAD2 AND Z < BUTT2 THEN B = 3
IF W >= 200 AND Z > BUTT2 AND W > HEAD2 THEN B = 3
IF W >= 200 AND Z < BUTT2 AND W > HEAD2 THEN B = 2
IF W <= 0 AND Z > BUTT2 AND W < HEAD2 THEN B = 1
IF W <= 0 AND Z < BUTT2 AND W < HEAD2 THEN B = 4
IF C = 1 THEN M = M + .74: N = N + .74
IF C = 2 THEN M = M - .74: N = N - .74
IF C = 3 THEN M = M + .74: N = N - .74
IF C = 4 THEN M = M - .74: N = N + .74
IF M >= 320 AND N > HEAD3 AND M > BUTT3 THEN C = 4
IF M >= 320 AND N < HEAD3 AND M > BUTT3 THEN C = 2
IF M <= 0 AND N > HEAD3 AND M < BUTT3 THEN C = 1
IF M <= 0 AND N < HEAD3 AND M < BUTT3 THEN C = 3
IF N >= 200 AND M > BUTT3 AND N > HEAD3 THEN C = 3
IF N >= 200 AND M < BUTT3 AND N > HEAD3 THEN C = 2
IF N <= 0 AND M > BUTT3 AND N < HEAD3 THEN C = 1
IF N <= 0 AND M < BUTT3 AND N < HEAD3 THEN C = 4
FOR TOT = 1 TO 500: NEXT TOT
LINE (BUTT1, HEAD1)-(BUTT2, HEAD2), 0: LINE (BUTT2, HEAD2)-(BUTT3, HEAD3), 0: LINE (BUTT3, HEAD3)-(BUTT1, HEAD1), 0
FOR AAA = 1 TO (200 + CCC1) STEP DENS
BUTT = BUTT + .001
ABC = SHIT - AAA
IF ABC < 0 THEN ABC = ABC + (200 + CCC1)
LINE (BX(ABC), BY(ABC))-(BZ(ABC), BW(ABC)), 0: LINE (BZ(ABC), BW(ABC))-(BM(ABC), BN(ABC)), 0: LINE (BM(ABC), BN(ABC))-(BX(ABC), BY(ABC)), 0
NEXT AAA
LOOP
1001
ERASE BX, BY, BZ, BW, BM, BN

END SUB

SUB SAVER
SCREEN 13: CLS
RANDOMIZE TIMER
ROY = 50
REDIM X(ROY), Y(ROY), A(ROY), COL(ROY), XXX(ROY), YYY(ROY)
FOR T = 1 TO ROY
X(T) = INT(RND * 320) + 1
Y(T) = INT(RND * 200) + 1
A(T) = INT(RND * 4) + 1
COL(T) = INT(RND * 10) + 20
XXX(T) = INT(RND * 4) + 3
YYY(T) = INT(RND * 4) + 3
NEXT T
T = 0
PPP3 = 0
DO
K$ = INKEY$
IF K$ <> "" THEN ERASE X, Y, A, COL, XXX, YYY: GOTO 11113
T = T + 1
IF T > ROY THEN T = 1
IF PPP3 = 0 THEN COL(T) = COL(T) + 1
IF PPP3 = 1 THEN COL(T) = COL(T) - 1
IF COL(T) > 30 THEN PPP3 = 1: COL(T) = 30
IF COL(T) < 20 THEN PPP3 = 0: COL(T) = 20
IF A(T) = 1 THEN X(T) = (X(T) + XXX(T)): Y(T) = (Y(T) + YYY(T))
IF A(T) = 2 THEN X(T) = (X(T) - XXX(T)): Y(T) = (Y(T) - YYY(T))
IF A(T) = 3 THEN X(T) = (X(T) + XXX(T)): Y(T) = (Y(T) - YYY(T))
IF A(T) = 4 THEN X(T) = (X(T) - XXX(T)): Y(T) = (Y(T) + YYY(T))
IF X(T) > 320 AND A(T) = 1 THEN A(T) = 4: X(T) = 320
IF X(T) > 320 AND A(T) = 3 THEN A(T) = 2: X(T) = 320
IF X(T) < 0 AND A(T) = 4 THEN A(T) = 1:  X(T) = 0
IF X(T) < 0 AND A(T) = 2 THEN A(T) = 3:  X(T) = 0
IF Y(T) > 200 AND A(T) = 1 THEN A(T) = 3:  Y(T) = 200
IF Y(T) > 200 AND A(T) = 4 THEN A(T) = 2:  Y(T) = 200
IF Y(T) < 0 AND A(T) = 3 THEN A(T) = 1:  Y(T) = 0
IF Y(T) < 0 AND A(T) = 2 THEN A(T) = 4:  Y(T) = 0
PSET (X(T), Y(T)), COL(T)
IF T <> ROY THEN PRESET (X(T + 1), Y(T + 1))
IF T = ROY THEN PRESET (X(1), Y(1))

LOOP
11113
END SUB

SUB SAVER2
'SCREEN 13: CLS
RANDOMIZE TIMER
ROY = 10
REDIM X(ROY), Y(ROY), A(ROY), COL(ROY), XXX(ROY), YYY(ROY), R1(ROY), R2(ROY), F(ROY), BACK(ROY), BACK2(ROY)
FOR T = 1 TO ROY
X(T) = INT(RND * 320) + 1
Y(T) = INT(RND * 200) + 1
A(T) = INT(RND * 4) + 1
COL(T) = INT(RND * 60) + 40
XXX(T) = INT(RND * 5) + 1
YYY(T) = INT(RND * 5) + 1
BACK(T) = X(T) + R1(T)
BACK2(T) = Y(T) + R2(T)
NEXT T
T = 0
DO
K$ = INKEY$
IF K$ <> "" THEN ERASE X, Y, A, COL, XXX, YYY, R1, R2, F, BACK, BACK2: GOTO 6767
T = T + 1
IF T > ROY THEN T = 1
IF PPP3 = 0 THEN COL(T) = COL(T) + 1
IF PPP3 = 1 THEN COL(T) = COL(T) - 1
IF COL(T) > 60 THEN PPP3 = 1: COL(T) = 60
IF COL(T) < 40 THEN PPP3 = 0: COL(T) = 40
IF A(T) = 1 THEN X(T) = (X(T) + XXX(T)): Y(T) = (Y(T) + YYY(T))
IF A(T) = 2 THEN X(T) = (X(T) - XXX(T)): Y(T) = (Y(T) - YYY(T))
IF A(T) = 3 THEN X(T) = (X(T) + XXX(T)): Y(T) = (Y(T) - YYY(T))
IF A(T) = 4 THEN X(T) = (X(T) - XXX(T)): Y(T) = (Y(T) + YYY(T))
IF X(T) > 320 AND A(T) = 1 THEN A(T) = 4: X(T) = 320
IF X(T) > 320 AND A(T) = 3 THEN A(T) = 2: X(T) = 320
IF X(T) < 0 AND A(T) = 4 THEN A(T) = 1:  X(T) = 0
IF X(T) < 0 AND A(T) = 2 THEN A(T) = 3:  X(T) = 0
IF Y(T) > 200 AND A(T) = 1 THEN A(T) = 3:  Y(T) = 200
IF Y(T) > 200 AND A(T) = 4 THEN A(T) = 2:  Y(T) = 200
IF Y(T) < 0 AND A(T) = 3 THEN A(T) = 1:  Y(T) = 0
IF Y(T) < 0 AND A(T) = 2 THEN A(T) = 4:  Y(T) = 0
F(T) = F(T) + .1
IF F(T) > 7.2 THEN F(T) = 1
R1(T) = COS(F(T)) * 15
R2(T) = SIN(F(T)) * 15
LINE (X(T) + R1(T), Y(T) + R2(T))-(BACK(T), BACK2(T)), COL(T)
BACK(T) = X(T) + R1(T)
BACK2(T) = Y(T) + R2(T)
FOR TRT = 1 TO 200: NEXT TRT
LOOP

6767
END SUB

SUB SAVER3
SCREEN 13: CLS
RANDOMIZE TIMER
ROY = 6
REDIM X(ROY), Y(ROY), A(ROY), COL(ROY), XXX(ROY), YYY(ROY), R1(ROY), R2(ROY), F(ROY), BACK(ROY), BACK2(ROY)
FOR T = 1 TO ROY
X(T) = INT(RND * 320) + 1
Y(T) = INT(RND * 200) + 1
A(T) = INT(RND * 4) + 1
COL(T) = INT(RND * 20) + 40
XXX(T) = INT(RND * 5) + 1
YYY(T) = INT(RND * 5) + 1
BACK(T) = X(T - 1) + R1(T - 1)
BACK2(T) = Y(T - 1) + R2(T - 1)
IF T = 1 THEN BACK(T) = X(ROY) + R1(ROY): BACK2(T) = Y(ROY) + R2(ROY)
NEXT T
T = 0
DO
K$ = INKEY$
IF K$ <> "" THEN ERASE X, Y, A, COL, XXX, YYY, R1, R2, F, BACK, BACK2: GOTO 77777
T = T + 1
IF T > ROY THEN T = 1
IF PPP3 = 0 THEN COL(T) = COL(T) + .1
IF PPP3 = 1 THEN COL(T) = COL(T) - .1
IF COL(T) < 40 THEN PPP3 = 0: COL(T) = 40
IF COL(T) > 60 THEN PPP3 = 1: COL(T) = 60
IF A(T) = 1 THEN X(T) = (X(T) + XXX(T)): Y(T) = (Y(T) + YYY(T))
IF A(T) = 2 THEN X(T) = (X(T) - XXX(T)): Y(T) = (Y(T) - YYY(T))
IF A(T) = 3 THEN X(T) = (X(T) + XXX(T)): Y(T) = (Y(T) - YYY(T))
IF A(T) = 4 THEN X(T) = (X(T) - XXX(T)): Y(T) = (Y(T) + YYY(T))
IF X(T) > 320 AND A(T) = 1 THEN A(T) = 4: X(T) = 320
IF X(T) > 320 AND A(T) = 3 THEN A(T) = 2: X(T) = 320
IF X(T) < 0 AND A(T) = 4 THEN A(T) = 1:  X(T) = 0
IF X(T) < 0 AND A(T) = 2 THEN A(T) = 3:  X(T) = 0
IF Y(T) > 200 AND A(T) = 1 THEN A(T) = 3:  Y(T) = 200
IF Y(T) > 200 AND A(T) = 4 THEN A(T) = 2:  Y(T) = 200
IF Y(T) < 0 AND A(T) = 3 THEN A(T) = 1:  Y(T) = 0
IF Y(T) < 0 AND A(T) = 2 THEN A(T) = 4:  Y(T) = 0
F(T) = F(T) + .1
IF F(T) > 7.2 THEN F(T) = 1
R1(T) = COS(F(T)) * 15
R2(T) = SIN(F(T)) * 15
LINE (X(T) + R1(T), Y(T) + R2(T))-(160, 100), COL(T)
FOR TOT = 1 TO 1000: NEXT TOT
LINE (160, 100)-(BACK(T), BACK2(T)), 0
BACK(T) = X(T - 1) + R1(T - 1)
BACK2(T) = Y(T - 1) + R2(T - 1)
IF T = 1 THEN BACK(T) = X(ROY) + R1(ROY): BACK2(T) = Y(ROY) + R2(ROY)
LOOP
77777
END SUB

SUB SHELLA
SCREEN 0: CLS
WIDTH 80, 25
LOCATE 3, 20: COLOR 10: PRINT "GRAVITY BY ROY MEGA GAMES"
1113 LOCATE 6, 20: COLOR 15: INPUT "CHOOSE A MODE (1-3)"; MD
IF MD <= 0 OR MD >= 4 THEN GOTO 1113
IF MD = 1 THEN GOTO 1010
IF MD = 2 THEN GOTO 1020
IF MD = 3 THEN GOTO 1030

1010 SCREEN 13: CLS
RANDOMIZE TIMER
REDIM QWE(100): REDIM ASD(100): REDIM ZXC(100)
D1 = INT(RND * 80) + 1
D2 = INT(RND * 80) + 1
D3 = INT(RND * 80) + 1
D4 = INT(RND * 80) + 1
DD1 = (INT(RND * 50) + 1) / 10
DD2 = (INT(RND * 50) + 1) / 10

AD1 = INT(RND * 80) + 1
AD2 = INT(RND * 80) + 1
AD3 = INT(RND * 80) + 1
AD4 = INT(RND * 80) + 1
ADD1 = (INT(RND * 50) + 1) / 10
ADD2 = (INT(RND * 50) + 1) / 10

BD1 = INT(RND * 80) + 1
BD2 = INT(RND * 80) + 1
BD3 = INT(RND * 80) + 1
BD4 = INT(RND * 80) + 1
BDD1 = (INT(RND * 50) + 1) / 10
BDD2 = (INT(RND * 50) + 1) / 10

FOR T = 1 TO 100
QWE(T) = INT(RND * 360) + 1
ASD(T) = INT(RND * 200) + 1
ZXC(T) = INT(RND * 10) + 20
NEXT T

DO
FOR X = 1 TO 7.25 STEP .01
K$ = INKEY$
IF K$ = CHR$(27) THEN ERASE QWE, ASD, ZXC: GOTO 23
IF K$ <> "" THEN ERASE QWE, ASD, ZXC: GOTO 1010
XX = COS(X) * D1
YY = SIN(X) * D2
XX2 = COS(X + DD1) * D3
YY2 = SIN(X + DD2) * D4

AXX = COS(X) * AD1
AYY = SIN(X) * AD2
AXX2 = COS(X + ADD1) * AD3
AYY2 = SIN(X + ADD2) * AD4

BXX = COS(X) * BD1
BYY = SIN(X) * BD2
BXX2 = COS(X + BDD1) * BD3
BYY2 = SIN(X + BDD2) * BD4

LINE (BXX + 160, BYY + 100)-(BXX2 + 160, BYY2 + 100), 13
LINE (AXX + 160, AYY + 100)-(AXX2 + 160, AYY2 + 100), 14
LINE (XX + 160, YY + 100)-(XX2 + 160, YY2 + 100), 10
FOR T = 1 TO 100
PSET (QWE(T), ASD(T)), ZXC(T)
NEXT T
FOR TOT = 1 TO 1000: NEXT TOT
LINE (XX + 160, YY + 100)-(XX2 + 160, YY2 + 100), 0
LINE (AXX + 160, AYY + 100)-(AXX2 + 160, AYY2 + 100), 0
LINE (BXX + 160, BYY + 100)-(BXX2 + 160, BYY2 + 100), 0

NEXT X
LOOP

1020 SCREEN 13: CLS
RANDOMIZE TIMER
DO
D1 = INT(RND * 80) + 1
D2 = INT(RND * 80) + 1
D3 = INT(RND * 80) + 1
D4 = INT(RND * 80) + 1
DD1 = (INT(RND * 50) + 1) / 10
DD2 = (INT(RND * 50) + 1) / 10

AD1 = INT(RND * 80) + 1
AD2 = INT(RND * 80) + 1
AD3 = INT(RND * 80) + 1
AD4 = INT(RND * 80) + 1
ADD1 = (INT(RND * 50) + 1) / 10
ADD2 = (INT(RND * 50) + 1) / 10

BD1 = INT(RND * 80) + 1
BD2 = INT(RND * 80) + 1
BD3 = INT(RND * 80) + 1
BD4 = INT(RND * 80) + 1
BDD1 = (INT(RND * 50) + 1) / 10
BDD2 = (INT(RND * 50) + 1) / 10

FOR X = 1 TO 30 STEP .01
K$ = INKEY$
IF K$ = CHR$(27) THEN GOTO 23
IF K$ <> "" THEN GOTO 1020
XX = COS(X) * D1
YY = SIN(X) * D2
XX2 = COS(X + DD1) * D3
YY2 = SIN(X + DD2) * D4

AXX = COS(X) * AD1
AYY = SIN(X) * AD2
AXX2 = COS(X + ADD1) * AD3
AYY2 = SIN(X + ADD2) * AD4

BXX = COS(X) * BD1
BYY = SIN(X) * BD2
BXX2 = COS(X + BDD1) * BD3
BYY2 = SIN(X + BDD2) * BD4
COC = COC + .1
LINE (BXX + 160, BYY + 100)-(BXX2 + 160, BYY2 + 100), 20 + COC
LINE (AXX + 160, AYY + 100)-(AXX2 + 160, AYY2 + 100), 30 + COC
LINE (XX + 160, YY + 100)-(XX2 + 160, YY2 + 100), 40 + COC
FOR T = 1 TO 1000: NEXT T
NEXT X
LOOP

1030 SCREEN 13: CLS
RANDOMIZE TIMER
DO
D1 = INT(RND * 80) + 1
D2 = INT(RND * 80) + 1
D3 = INT(RND * 80) + 1
D4 = INT(RND * 80) + 1
DD1 = (INT(RND * 50) + 1) / 10
DD2 = (INT(RND * 50) + 1) / 10

AD1 = INT(RND * 80) + 1
AD2 = INT(RND * 80) + 1
AD3 = INT(RND * 80) + 1
AD4 = INT(RND * 80) + 1
ADD1 = (INT(RND * 50) + 1) / 10
ADD2 = (INT(RND * 50) + 1) / 10

BD1 = INT(RND * 80) + 1
BD2 = INT(RND * 80) + 1
BD3 = INT(RND * 80) + 1
BD4 = INT(RND * 80) + 1
BDD1 = (INT(RND * 50) + 1) / 10
BDD2 = (INT(RND * 50) + 1) / 10

FOR X = 1 TO 300 STEP .01
K$ = INKEY$
IF K$ = CHR$(27) THEN GOTO 23
IF K$ <> "" THEN GOTO 1030
XX = COS(X) * D1
YY = SIN(X) * D2
XX2 = COS(X + DD1) * D3
YY2 = SIN(X + DD2) * D4

AXX = COS(X) * AD1
AYY = SIN(X) * AD2
AXX2 = COS(X + ADD1) * AD3
AYY2 = SIN(X + ADD2) * AD4

BXX = COS(X) * BD1
BYY = SIN(X) * BD2
BXX2 = COS(X + BDD1) * BD3
BYY2 = SIN(X + BDD2) * BD4

COC = COC + .1
LINE (BXX + 160, BYY + 100)-(BXX2 + 160, BYY2 + 100), 18 + COC
LINE (AXX + 160, AYY + 100)-(AXX2 + 160, AYY2 + 100), 19 + COC
LINE (XX + 160, YY + 100)-(XX2 + 160, YY2 + 100), 20 + COC
LINE (XX + 160, YY + 100)-(AXX2 + 160, AYY2 + 100), 21 + COC
LINE (XX + 160, YY + 100)-(BXX2 + 160, BYY2 + 100), 22 + COC
LINE (AXX + 160, AYY + 100)-(BXX2 + 160, BYY2 + 100), 23 + COC
LINE (BXX + 160, BYY + 100)-(AXX2 + 160, AYY2 + 100), 24 + COC
LINE (AXX + 160, AYY + 100)-(XX2 + 160, YY2 + 100), 25 + COC
LINE (BXX + 160, BYY + 100)-(XX2 + 160, YY2 + 100), 26 + COC

FOR T = 1 TO 1500: NEXT T
LINE (XX + 160, YY + 100)-(XX2 + 160, YY2 + 100), 0
LINE (AXX + 160, AYY + 100)-(AXX2 + 160, AYY2 + 100), 0
LINE (BXX + 160, BYY + 100)-(BXX2 + 160, BYY2 + 100), 0
LINE (BXX + 160, BYY + 100)-(AXX2 + 160, AYY2 + 100), 0
LINE (AXX + 160, AYY + 100)-(BXX2 + 160, BYY2 + 100), 0
LINE (XX + 160, YY + 100)-(BXX2 + 160, BYY2 + 100), 0
LINE (XX + 160, YY + 100)-(AXX2 + 160, AYY2 + 100), 0
LINE (AXX + 160, AYY + 100)-(XX2 + 160, YY2 + 100), 0
LINE (BXX + 160, BYY + 100)-(XX2 + 160, YY2 + 100), 0
NEXT X
LOOP

23
END SUB

SUB SHOW (AX$, BX, BY)
RANDOMIZE TIMER
REDIM B$(LEN(AX$))
REDIM F(1000)
FOR X = 1 TO LEN(AX$)
B$(X) = MID$(AX$, X, 1)
NEXT X
FOR X = 1 TO LEN(AX$)
K$ = INKEY$
IF K$ = CHR$(27) THEN SYSTEM
O = O + 1
111 C = INT(RND * LEN(AX$)) + 1
F(O) = C
FOR TC = 0 TO (O - 1)
IF F(TC) = F(O) THEN GOTO 111
NEXT TC
ROY$ = MID$(AX$, C, 1)
FOR G = 18 TO 30 STEP .03
LOCATE BX, BY + C
COLOR G
PRINT ROY$;
NEXT G
FOR T = 1 TO 1000: NEXT T
NEXT X
ERASE F, B$
END SUB

SUB SPHERES
SCREEN 13: CLS
RANDOMIZE TIMER
FOR GTS = 1 TO 150
XS = INT(RND * 318) + 1
YS = INT(RND * 198) + 1
COLS = INT(RND * 14) + 18
PSET (XS, YS), COLS
NEXT GTS
X = 150
Y = 100
Q1 = 1: Q2 = 2
WWW = 1
WIDE = 1
DO
K$ = INKEY$
IF K$ = CHR$(27) THEN GOTO 88
CHOOSE = INT(RND * 2)
IF CHOOSE = 0 THEN GOTO 1011
IF CHOOSE = 1 THEN GOTO 20
1011 Z = INT(RND * 311)
W = INT(RND * 2)
W = W * 260
GOTO 30
20 Z = INT(RND * 2)
W = INT(RND * 260)
Z = Z * 310
GOTO 30
30 IF X > Z THEN AF = -1
IF X < Z THEN AF = 1
SHIT = (W - Y)
SHIT2 = (Z - X)
IF SHIT2 = 0 THEN SHIT2 = .00000001#
M = SHIT / SHIT2
P = Y - (M * X)
FOR XX = X TO Z STEP AF
K$ = INKEY$
YY = (M * XX) + P
COL = COL + 1
IF COL > 300 THEN COL = 0
IF ACS = 0 THEN BUTT = BUTT + 1
IF ACS = 1 THEN BUTT = BUTT - 1
IF BUTT = 50 THEN ACS = 1
IF BUTT = 1 THEN ACS = 0
Q1 = Q1 + .5
IF Q1 > 6 THEN Q1 = 0
Q2 = Q2 + .5
IF Q2 > 6 THEN Q2 = 0
CIRCLE (XX, YY), BUTT, COL, Q1, Q2, WWW: PSET (XX, YY), 10
FOR HH = 1 TO 2500: NEXT HH
IF K$ = CHR$(27) THEN GOTO 88
NEXT XX
WWW = INT(RND * 30) + 1
WWW = (WWW / 10)
DUD = DUD + 1
IF DUD = 5 THEN DUD = 0: Q1 = INT(RND * 5) + 1: Q2 = INT(RND * 5) + 1: GOSUB 999
LOOP
999 CLS
FOR GTS = 1 TO 150
XS = INT(RND * 318) + 1
YS = INT(RND * 198) + 1
COLS = INT(RND * 14) + 18
PSET (XS, YS), COLS
NEXT GTS
RETURN
88
END SUB

SUB SPOTS
SCREEN 0: CLS
WIDTH 80, 25
LOCATE 3, 25: COLOR 10: PRINT "SPOTS BY ROY ROY MEGA GAMES 1997@. "
15675 LOCATE 6, 30: COLOR 15: INPUT "CHOOSE A MODE (1-9) "; DDD
IF DDD > 9 OR DDD < 1 THEN GOTO 15675
IF DDD = 1 THEN GOTO 1778
IF DDD = 2 THEN GOTO 2778
IF DDD = 3 THEN GOTO 3778
IF DDD = 4 THEN GOTO 1255
IF DDD = 5 THEN GOTO 4778
IF DDD = 6 THEN GOTO 5778
IF DDD = 7 THEN GOTO 6778
IF DDD = 8 THEN GOTO 8778
IF DDD = 9 THEN GOTO 9778

1778
SCREEN 13: CLS
RANDOMIZE TIMER
DO
K$ = INKEY$
IF K$ = CHR$(27) THEN GOTO 677
X = INT(RND * 320) + 1
Y = INT(RND * 200) + 1
Z = INT(RND * 50) + 1
C = INT(RND * 300) + 1
S = INT(RND * 6.2) + .1
S2 = INT(RND * 6.2) + .1
A = INT(RND * 20) - 10
FOR T = 1 TO Z
CIRCLE (X, Y), T, C + (T / 10), S, S2, A
NEXT T
LOOP
2778
SCREEN 13: CLS
RANDOMIZE TIMER
DO
K$ = INKEY$
IF K$ = CHR$(27) THEN GOTO 677
X = INT(RND * 320)
Y = INT(RND * 200)
C = INT(RND * 30) + 30
PSET (X, Y)
FOR T = 1 TO 30
C = C + .5
CIRCLE (X, Y), T, C
LINE (X, Y - T)-(X - T, Y), C
LINE (X, Y + T)-(X - T, Y), C
LINE (X, Y + T)-(X + T, Y), C
LINE (X, Y - T)-(X + T, Y), C
NEXT T
LOOP

3778
SCREEN 13: CLS
RANDOMIZE TIMER
DO
K$ = INKEY$
IF K$ = CHR$(27) THEN GOTO 677
X = INT(RND * 320)
Y = INT(RND * 200)
C = INT(RND * 30) + 30
PSET (X, Y)
FOR T = 1 TO 30
C = C + .5
CIRCLE (X, Y), T, C
LINE (X, Y - T)-(X - T, Y), C, B
LINE (X, Y + T)-(X - T, Y), C, B
LINE (X, Y + T)-(X + T, Y), C, B
LINE (X, Y - T)-(X + T, Y), C, B
NEXT T
LOOP

1255 E = 0
RANDOMIZE TIMER
C = INT(RND * 100) + 1
SCREEN 13: CLS
REDIM BOX%(1 TO 200)
X1% = 0: X2% = 10: Y1% = 0: Y2% = 10
LINE (X1%, Y1%)-(X2%, Y2%), C, BF
GET (X1%, Y1%)-(X2%, Y2%), BOX%
DO
K$ = INKEY$
E = E + 1
PUT (X1%, Y1%), BOX%, XOR
X1% = RND * 300
Y1% = RND * 180
IF E = 1500 THEN EXIT DO
IF K$ = CHR$(27) THEN GOTO 677
FOR T = 1 TO 10: NEXT T
LOOP
ERASE BOX%
GOTO 1255

4778
SCREEN 13: CLS
RANDOMIZE TIMER
DO
K$ = INKEY$
IF K$ = CHR$(27) THEN GOTO 677
X1 = INT(RND * 300) + 1
Y1 = INT(RND * 200) + 1
Y2 = INT(RND * (200 - Y1)) + Y1
FOR T = Y1 TO Y2 STEP .05
C = C + .01
PSET (X1, T), C
NEXT T
D = INT(RND * 40) + 1
FOR T = 1 TO D STEP .05
C = C + .01
CIRCLE (X1, Y2), T, C, 1.8, 1.3, .3
NEXT T
LOOP

5778
SCREEN 13: CLS
RANDOMIZE TIMER
REDIM X(100): REDIM Y(100): REDIM A(100): : REDIM TTT(100)
FFF = INT(RND * 3) + 1
FOR T = 1 TO 50
X(T) = INT(RND * 360) + 1
Y(T) = INT(RND * 200) + 1
NEXT T
DO
K$ = INKEY$
IF K$ = CHR$(27) THEN ERASE X, Y, A, TTT: GOTO 677
IF K$ <> "" THEN ERASE X, Y, A, TTT: GOTO 5778
TT = TT + 1
IF TT > 50 THEN TT = 1
XX = X(TT)
YY = Y(TT)
A(TT) = A(TT) + 1

IF FFF = 1 THEN TTT(TT) = TTT(TT) + 1
IF FFF = 1 THEN CIRCLE (X(TT), Y(TT)), A(TT), TTT(TT)

IF FFF = 2 THEN TTTT = TTTT + 1
IF FFF = 2 THEN CIRCLE (X(TT), Y(TT)), A(TT), TTTT

IF FFF = 3 THEN CIRCLE (X(TT), Y(TT)), A(TT), TT

QQQQ = QQQQ + 1
IF QQQQ > 20000 THEN ERASE X, Y, A, TTT: GOTO 5778
LOOP

6778
SCREEN 13: CLS
RANDOMIZE TIMER
AX = INT(RND * 320) + 1
AY = INT(RND * 200) + 1
BX = INT(RND * 320) + 1
BY = INT(RND * 200) + 1
AD = INT(RND * 15) + 40
BD = INT(RND * 15) + 40
A = INT(RND * 4) + 1
B = INT(RND * 4) + 1

DO
FAX = AX: FAY = AY: FBX = BX: FBY = BY
FD = FD + .05
IF A = 1 THEN AX = AX + 3: AY = AY + 3
IF A = 2 THEN AX = AX - 3: AY = AY - 3
IF A = 3 THEN AX = AX + 3: AY = AY - 3
IF A = 4 THEN AX = AX - 3: AY = AY + 3
IF AX > 320 AND A = 1 THEN A = 4: AX = 320
IF AX > 320 AND A = 3 THEN A = 2: AX = 320
IF AX < 0 AND A = 4 THEN A = 1:  AX = 0
IF AX < 0 AND A = 2 THEN A = 3:  AX = 0
IF AY > 200 AND A = 1 THEN A = 3: AY = 200
IF AY > 200 AND A = 4 THEN A = 2:  AY = 200
IF AY < 0 AND A = 3 THEN A = 1:  AY = 0
IF AY < 0 AND A = 2 THEN A = 4:  AY = 0

IF B = 1 THEN BX = BX + 3: BY = BY + 3
IF B = 2 THEN BX = BX - 3: BY = BY - 3
IF B = 3 THEN BX = BX + 3: BY = BY - 3
IF B = 4 THEN BX = BX - 3: BY = BY + 3
IF BX > 320 AND B = 1 THEN B = 4: BX = 320
IF BX > 320 AND B = 3 THEN B = 2: BX = 320
IF BX < 0 AND B = 4 THEN B = 1: BX = 0
IF BX < 0 AND B = 2 THEN B = 3: BX = 0
IF BY > 200 AND B = 1 THEN B = 3: BY = 200
IF BY > 200 AND B = 4 THEN B = 2:  BY = 200
IF BY < 0 AND B = 3 THEN B = 1: BY = 0
IF BY < 0 AND B = 2 THEN B = 4: BY = 0
IF INKEY$ = CHR$(27) THEN GOTO 677
CLS 1
FOR T = 1 TO 7.3 STEP .05
AAX = (COS(T) * AD) + AX
AAY = (SIN(T) * AD) + AY
D1 = INT(SQR(((BX - AAX) * (BX - AAX)) + ((BY - AAY) * (BY - AAY))))
IF D1 < BD THEN GOTO 1
PSET (AAX, AAY), 14 + FD
1
BBY = (SIN(T) * BD) + BY
BBX = (COS(T) * BD) + BX
D2 = INT(SQR(((AX - BBX) * (AX - BBX)) + ((AY - BBY) * (AY - BBY))))
IF D2 < AD THEN GOTO 24
PSET (BBX, BBY), 14 + FD
24
NEXT T

LOOP


8778
SCREEN 13: CLS
RANDOMIZE TIMER
ROY = 15
REDIM A(ROY), S(ROY), XB(ROY), YB(ROY), Y(ROY), X(ROY), D(ROY), C(ROY), DES(ROY), CC(ROY)
CCC = 160
CCC2 = 100
FOR T = 1 TO ROY
A(T) = (INT(RND * 73) + 1) / 10
S(T) = INT(RND * 95) + 5
D(T) = INT(RND * 5) + 1
Y(T) = CCC: X(T) = CCC2
C(T) = INT(RND * 100) + 15
DES(T) = INT(RND * 50) + 1
CC(T) = C(T)
NEXT T
DO
FOR T = 1 TO ROY
K$ = INKEY$
IF K$ = CHR$(27) THEN ERASE A, S, XB, YB, Y, X, D, C, DES, CC: GOTO 677
YB(T) = Y(T): XB(T) = X(T)
S(T) = S(T) + D(T)
X(T) = COS(A(T)) * S(T)
Y(T) = SIN(A(T)) * S(T)
COLOR C(T)
C(T) = C(T) + .5
IF C(T) > CC(T) + 30 THEN C(T) = CC(T) + 30
CIRCLE (X(T) + CCC, Y(T) + CCC2), DES(T)
CIRCLE (XB(T) + CCC, YB(T) + CCC2), DES(T), 0
IF (Y(T) + CCC2) < -50 OR (Y(T) + CCC2) > 250 OR (X(T) + CCC) < -50 OR (X(T) + CCC) > 370 THEN GOSUB 1078
NEXT T
LINE (0, 0)-(319, 199), 0, B

LOOP
1078
A(T) = (INT(RND * 73) + 1) / 10
S(T) = INT(RND * 95) + 5
D(T) = INT(RND * 5) + 1
Y(T) = CCC: X(T) = CCC2
C(T) = INT(RND * 100) + 15
DES(T) = INT(RND * 50) + 1
CC(T) = C(T)
RETURN


9778
SCREEN 13: CLS
RANDOMIZE TIMER
ROY = 20
REDIM A(ROY), DX(ROY), DY(ROY), XX(ROY), YY(ROY), S(ROY), G(ROY), X(ROY), Y(ROY), B(ROY), XC(ROY), YC(ROY), DD(ROY), SS(ROY)
FOR T = 1 TO ROY
M = 4.7
A(T) = 4.7
DX(T) = INT(RND * 35) + 35
DY(T) = 600
XX(T) = INT(RND * 300) + 10
YY(T) = DY(T)
S(T) = INT(RND * 2) + 1
G(T) = 30
X(T) = XX(T): Y(T) = -1
SS(T) = (INT(RND * 10) / 650) + .01
DD(T) = INT(RND * 17) + 5
NEXT T
DO
FOR T = 1 TO ROY
XC(T) = X(T): YC(T) = Y(T)
IF S(T) = 1 THEN A(T) = A(T) + SS(T)
IF S(T) = 2 THEN A(T) = A(T) - SS(T)

X(T) = (COS(A(T)) * DX(T)) + XX(T)
Y(T) = (SIN(A(T)) * DY(T)) + YY(T)

CIRCLE (XC(T), YC(T)), DD(T), 0
CIRCLE (X(T), Y(T)), DD(T), G(T)

FOR TOT = 1 TO 200: NEXT TOT

IF B(T) = 1 AND Y(T) < 200 THEN B(T) = 0

IF Y(T) > 200 AND B(T) = 0 AND S(T) = 1 THEN A(T) = M - (A(T) - M): DX(T) = DX(T) + 20: XX(T) = XX(T) + (DX(T) * 1.25): DY(T) = DY(T) - 20: B(T) = 1: SS(T) = SS(T) + .00001: GOTO 1167
IF Y(T) > 200 AND B(T) = 0 AND S(T) = 2 THEN A(T) = M + (M - A(T)): DX(T) = DX(T) + 20: XX(T) = XX(T) - (DX(T) * 1.25): DY(T) = DY(T) - 20: B(T) = 1: SS(T) = SS(T) + .00001: GOTO 1167

IF X(T) < 0 AND B(T) = 0 AND S(T) = 2 THEN S(T) = 1: DX(T) = DX(T) + 25: B(T) = 1: SS(T) = SS(T) + .00001: GOTO 1167
IF X(T) > 320 AND B(T) = 0 AND S(T) = 1 THEN S(T) = 2: DX(T) = DX(T) + 25: B(T) = 1: SS(T) = SS(T) + .00001: GOTO 1167

IF Y(T) > 300 THEN GOSUB 11166
1167
NEXT T
LOOP UNTIL INKEY$ = CHR$(27)
ERASE A, DX, DY, XX, YY, S, G, X, Y, B, XC, YC, DD, SS: GOTO 677
11166
A(T) = 4.7
DX(T) = INT(RND * 35) + 35
DY(T) = 600
XX(T) = INT(RND * 300) + 10
YY(T) = DY(T)
S(T) = INT(RND * 2) + 1
X(T) = XX(T): Y(T) = -1
G(T) = G(T) + 1
RETURN



677
END SUB

SUB TUNNELS
SCREEN 0: CLS
WIDTH 80, 25
LOCATE 3, 20: COLOR 10: PRINT "BUGS & WORMS BY ROY MEGA GAMES"
2223 LOCATE 6, 20: COLOR 15: INPUT "CHOOSE A MODE (1-3)"; MD
IF MD <= 0 OR MD >= 4 THEN GOTO 2223
IF MD = 1 THEN GOTO 2210
IF MD = 2 THEN GOTO 2220
IF MD = 3 THEN GOTO 2230

2210 SCREEN 13: CLS
RANDOMIZE TIMER
REDIM X(100): REDIM Y(100): REDIM A(100)
FOR T = 1 TO 100
X(T) = INT(RND * 360) + 1
Y(T) = INT(RND * 200) + 1
NEXT T
DO
K$ = INKEY$
IF K$ = CHR$(27) THEN ERASE X, Y, A: GOTO 34
TT = TT + 1
IF TT > 100 THEN TT = 1
XX = X(TT)
YY = Y(TT)
A(TT) = INT(RND * 4) + 1
IF A(TT) = 1 THEN X(TT) = X(TT) - 10
IF A(TT) = 2 THEN X(TT) = X(TT) + 10
IF A(TT) = 3 THEN Y(TT) = Y(TT) - 10
IF A(TT) = 4 THEN Y(TT) = Y(TT) + 10
LINE (XX, YY)-(X(TT), Y(TT)), TT
LOOP

2220 SCREEN 13: CLS
RANDOMIZE TIMER
REDIM X(100): REDIM Y(100): REDIM A(100): REDIM CCC(100)
RRR = INT(RND * 30) + 1
RRR2 = INT(RND * 50) + 33
RRR3 = INT(RND * 9) + 1
RRR4 = INT(RND * 9) + 1
FOR T = 1 TO 100
X(T) = 160
Y(T) = 100
CCC(T) = INT(RND * RRR) + RRR2
NEXT T
DO
K$ = INKEY$
IF K$ = CHR$(27) THEN ERASE X, Y, A, CCC: GOTO 34
IF K$ <> "" THEN ERASE X, Y, A, CCC: : GOTO 2220
TT = TT + 1
IF TT > 100 THEN TT = 1
XX = X(TT)
YY = Y(TT)
CCC(TT) = CCC(TT) + 1
IF CCC(TT) > (RRR + RRR2) THEN CCC(TT) = RRR2
A(TT) = INT(RND * 4) + 1
IF A(TT) = 1 THEN X(TT) = X(TT) - RRR3
IF A(TT) = 2 THEN X(TT) = X(TT) + RRR3
IF A(TT) = 3 THEN Y(TT) = Y(TT) - RRR3
IF A(TT) = 4 THEN Y(TT) = Y(TT) + RRR3
LINE (XX, YY)-(X(TT), Y(TT)), CCC(TT)

LOOP

2230
SCREEN 13: CLS
RANDOMIZE TIMER
REDIM X(100): REDIM Y(100): REDIM A(100): REDIM CCC(100)
RRR3 = 1
19999
DDDD = INT(RND * 10) + 1
X2 = INT(RND * 360) + 1
Y2 = INT(RND * 200) + 1
CCC2 = INT(RND * 60) + 20
FOR T = 1 TO DDDD
X(T) = X2
Y(T) = Y2
CCC(T) = INT(RND * 5) + CCC2
NEXT T
FFFF = INT(RND * 10000) + 1
DO
GGGG = GGGG + 1
K$ = INKEY$
IF K$ = CHR$(27) THEN ERASE X, Y, A, CCC: GOTO 34
IF GGGG = FFFF THEN GGGG = 0: GOTO 19999
TT = TT + 1
IF TT > DDDD THEN TT = 1
XX = X(TT)
YY = Y(TT)
CCC(TT) = CCC(TT) + 1
IF CCC(TT) > (CCC2 + 5) THEN CCC(TT) = CCC2
A(TT) = INT(RND * 8) + 1
IF A(TT) = 1 THEN X(TT) = X(TT) - RRR3
IF A(TT) = 2 THEN X(TT) = X(TT) + RRR3
IF A(TT) = 3 THEN Y(TT) = Y(TT) - RRR3
IF A(TT) = 4 THEN Y(TT) = Y(TT) + RRR3
IF A(TT) = 5 THEN X(TT) = X(TT) - RRR3: Y(TT) = Y(TT) - RRR3
IF A(TT) = 6 THEN X(TT) = X(TT) + RRR3: Y(TT) = Y(TT) + RRR3
IF A(TT) = 7 THEN Y(TT) = Y(TT) - RRR3: X(TT) = X(TT) + RRR3
IF A(TT) = 8 THEN Y(TT) = Y(TT) + RRR3: X(TT) = X(TT) - RRR3

LINE (XX, YY)-(X(TT), Y(TT)), CCC(TT)

LOOP



34
END SUB

SUB TYPE1
SCREEN 13: CLS
DO
FOR X = 5 TO 100
K$ = INKEY$
IF K$ = CHR$(27) THEN GOTO 114
FOR S = 1 TO 100 STEP 20
D = D + .1
CIRCLE (150, 100), (X + S) - 1, 0, , , .5
CIRCLE (150, 100), (X + S), D, , , .9
NEXT S
FOR T = 1 TO 100: NEXT T
NEXT X
LOOP
114
END SUB

SUB TYPE2
1234 SCREEN 13: CLS
R = INT(RND * 100) + 1
R2 = INT(RND * 100) + 1
R1 = INT(RND * 100) + 1
R21 = INT(RND * 100) + 1
C = 18
DO
K = (INT(RND * 700) + 1) / 10
C = C + .01
IF C > 300 THEN C = 18
X = COS(K) * R
Y = SIN(K) * R2
G = G + .01
X2 = COS(K + G) * R1
Y2 = SIN(K + G) * R21
LINE (X + 150, Y + 100)-(X2 + 150, Y2 + 100), C
K$ = INKEY$
IF K$ = CHR$(27) THEN GOTO 31
IF K$ <> "" THEN GOTO 1234
FOR TOT = 1 TO 500: NEXT TOT
LOOP
31
END SUB

`,Bl={DATA:La(MO),DATA2:La(UO),DATA3:La(GO),DATA4:La(bO),DATA5:La(pO)},uA=gO.split(/\r?\n/);function La(A){const O=A.trim().split(/\s+/).map(i=>Number(i)).filter(i=>Number.isFinite(i)),E=[];for(let i=0;i<O.length-1;i+=2)E.push({x:O[i],y:O[i+1]});return E}const yu=["#000000","#0000aa","#00aa00","#00aaaa","#aa0000","#aa00aa","#aa5500","#aaaaaa","#555555","#5555ff","#55ff55","#55ffff","#ff5555","#ff55ff","#ffff55","#ffffff"];function xf(A,O=1){const i=(Number.isFinite(A)?Math.max(0,Math.round(A)):0)%256;return i<yu.length?zO(yu[i],O):i<J0.length?`rgba(${J0[i][0]}, ${J0[i][1]}, ${J0[i][2]}, ${O})`:`rgba(255, 255, 255, ${O})`}function zO(A,O){const E=A.replace("#",""),i=parseInt(E.slice(0,2),16),S=parseInt(E.slice(2,4),16),c=parseInt(E.slice(4,6),16);return`rgba(${i}, ${S}, ${c}, ${O})`}const J0=_O();function _O(){const A=yu.map(i=>{const S=i.replace("#","");return[parseInt(S.slice(0,2),16),parseInt(S.slice(2,4),16),parseInt(S.slice(4,6),16)]});[0,5,8,11,14,17,20,24,28,32,36,40,45,50,56,63].forEach(i=>A.push(hu(i,i,i)));const E=Jf(63,[0,16,31,47,63]).map(([i,S,c])=>hu(i,S,c));for(A.push(...E),A.push(...E.map(i=>Qf(i,[255,255,255],.24))),A.push(...E.map(i=>Qf(i,[255,255,255],.46))),jl(A,31,[0,8,16,24,31]),jl(A,47,[0,12,24,35,47]),jl(A,39,[0,10,19,29,39]),jl(A,55,[0,14,27,41,55]),jl(A,23,[0,6,11,17,23]),jl(A,63,[16,27,39,51,63]),jl(A,45,[8,17,26,35,45]);A.length<256;)A.push([0,0,0]);return A.slice(0,256)}function jl(A,O,E){Jf(O,E).forEach(([i,S,c])=>A.push(hu(i,S,c)))}function Jf(A,O){const[E,i,S,c]=O;return[[E,E,A],[i,E,A],[S,E,A],[c,E,A],[A,E,A],[A,E,c],[A,E,S],[A,E,i],[A,E,E],[A,i,E],[A,S,E],[A,c,E],[A,A,E],[c,A,E],[S,A,E],[i,A,E],[E,A,E],[E,A,i],[E,A,S],[E,A,c],[E,A,A],[E,c,A],[E,S,A],[E,i,A]]}function hu(A,O,E){return[Math.round(A/63*255),Math.round(O/63*255),Math.round(E/63*255)]}function Qf(A,O,E){return[Math.round(A[0]+(O[0]-A[0])*E),Math.round(A[1]+(O[1]-A[1])*E),Math.round(A[2]+(O[2]-A[2])*E)]}function du(A,O,E,i,S=i==="modern",c=1){const I=i==="modern"||S,r=i==="modern"?c:1;A.imageSmoothingEnabled=I,A.lineCap=i==="modern"?"round":"butt",A.lineJoin=i==="modern"?"round":"miter";const D=(N=15,C=1)=>typeof N=="number"?xf(N,C):N;return{width:O,height:E,ctx:A,mode:i,antialias:I,lineScale:r,color:(N,C=1)=>xf(N,C),cls:(N=0,C=1)=>{A.save(),A.globalAlpha=C,A.fillStyle=D(N),A.fillRect(0,0,O,E),A.restore()},pset:(N,C,o=15,U=i==="classic"?1:2)=>{A.fillStyle=D(o);const M=i==="classic"?Math.round(N):Math.floor(N),b=i==="classic"?Math.round(C):Math.floor(C),p=i==="classic"?U:Math.max(1,Math.ceil(U));A.fillRect(M,b,p,p)},line:(N,C,o,U,M=15,b=1,p=1)=>{if(!I){va(A,Math.round(N),Math.round(C),Math.round(o),Math.round(U),D(M),b,p);return}A.save(),A.globalAlpha=p,A.strokeStyle=D(M),A.lineWidth=b*r,A.beginPath(),A.moveTo(N,C),A.lineTo(o,U),A.stroke(),A.restore()},circle:(N,C,o,U=15,M=!1,b=1)=>{if(!I){KO(A,Math.round(N),Math.round(C),Math.round(o),D(U),M,b);return}A.save(),A.globalAlpha=b,A.beginPath(),A.arc(N,C,Math.max(0,o),0,Math.PI*2),M?(A.fillStyle=D(U),A.fill()):(A.strokeStyle=D(U),A.lineWidth=(i==="modern"?1.5:1)*r,A.stroke()),A.restore()},box:(N,C,o,U,M=15,b=!1,p=1)=>{if(!I){if(A.save(),A.globalAlpha=p,A.fillStyle=D(M),b)A.fillRect(Math.round(N),Math.round(C),Math.round(o),Math.round(U));else{const q=Math.round(N),w=Math.round(C),In=Math.round(N+o),Cn=Math.round(C+U);va(A,q,w,In,w,D(M),1,p),va(A,In,w,In,Cn,D(M),1,p),va(A,In,Cn,q,Cn,D(M),1,p),va(A,q,Cn,q,w,D(M),1,p)}A.restore();return}A.save(),A.globalAlpha=p,b?(A.fillStyle=D(M),A.fillRect(N,C,o,U)):(A.strokeStyle=D(M),A.lineWidth=r,A.strokeRect(N,C,o,U)),A.restore()},locateText:(N,C,o,U=15,M=1)=>{const b=8*M,p=8*M;A.fillStyle=D(U),xO(A,o,(C-1)*b,(N-1)*p,M)}}}function va(A,O,E,i,S,c,I,r){A.save(),A.globalAlpha=r,A.fillStyle=c;const D=Math.max(1,Math.round(I));let N=O,C=E;const o=Math.abs(i-N),U=N<i?1:-1,M=-Math.abs(S-C),b=C<S?1:-1;let p=o+M;for(;A.fillRect(N,C,D,D),!(N===i&&C===S);){const q=p*2;q>=M&&(p+=M,N+=U),q<=o&&(p+=o,C+=b)}A.restore()}function KO(A,O,E,i,S,c,I){if(A.save(),A.globalAlpha=I,A.fillStyle=S,c){for(let C=-i;C<=i;C+=1){const o=Math.floor(Math.sqrt(i*i-C*C));A.fillRect(O-o,E+C,o*2+1,1)}A.restore();return}let r=i,D=0,N=0;for(;r>=D;)ZO(A,O,E,r,D),D+=1,N<=0&&(N+=2*D+1),N>0&&(r-=1,N-=2*r+1);A.restore()}function ZO(A,O,E,i,S){A.fillRect(O+i,E+S,1,1),A.fillRect(O+S,E+i,1,1),A.fillRect(O-S,E+i,1,1),A.fillRect(O-i,E+S,1,1),A.fillRect(O-i,E-S,1,1),A.fillRect(O-S,E-i,1,1),A.fillRect(O+S,E-i,1,1),A.fillRect(O+i,E-S,1,1)}const Vf={" ":["00000000","00000000","00000000","00000000","00000000","00000000","00000000","00000000"],B:["11111100","01100110","01100110","01111100","01100110","01100110","01100110","11111100"],C:["00111100","01100110","11000000","11000000","11000000","11000000","01100110","00111100"],D:["11111000","01101100","01100110","01100110","01100110","01100110","01101100","11111000"],E:["11111110","01100010","01101000","01111000","01101000","01100000","01100010","11111110"],O:["00111000","01101100","11000110","11000110","11000110","11000110","01101100","00111000"],R:["11111100","01100110","01100110","01111100","01101100","01100110","01100110","11100110"],Y:["11000110","11000110","01101100","00111000","00010000","00010000","00010000","00111000"]};function xO(A,O,E,i,S){const c=Math.max(1,Math.round(S));[...O.toUpperCase()].forEach((I,r)=>{(Vf[I]??Vf[" "]).forEach((N,C)=>{[...N].forEach((o,U)=>{o==="1"&&A.fillRect(Math.round(E+r*8*S+U*S),Math.round(i+C*S),c,c)})})})}const Lu=[{kind:"range",id:"speed",label:"Speed",description:"Animation timing multiplier. Classic defaults to the original pacing target.",min:.25,max:3,step:.05,defaultValue:1},{kind:"range",id:"density",label:"Density",description:"How many particles, beams, or repeated elements the scene draws where the routine allows it.",min:.35,max:2,step:.05,defaultValue:1},{kind:"range",id:"trail",label:"Trail",description:"Persistence amount for demos with afterimages. Set to 0 for no trail where supported.",min:0,max:1,step:.05,defaultValue:.35}],vu=[{kind:"toggle",id:"antialias",label:"Classic anti-aliasing",description:"Smoothing for Classic mode. On by default for a softer browser presentation.",defaultValue:!0},{kind:"range",id:"modernLineWidth",label:"Modern line width",description:"Stroke multiplier for high-resolution rendering, where one-pixel DOS lines become too thin.",min:1,max:8,step:.1,defaultValue:4}],Pf=[...Lu,...vu];function qf(A={}){return[...Lu.map(O=>O.kind==="range"&&O.id==="trail"&&A.trail!==void 0?{...O,defaultValue:A.trail}:O),...vu.map(O=>O.kind==="range"&&O.id==="modernLineWidth"&&A.modernLineWidth!==void 0?{...O,defaultValue:A.modernLineWidth}:O)]}function M1(A,O="original",E={}){return[...Lu.map(i=>i.kind==="range"&&i.id==="trail"&&E.trail!==void 0?{...i,defaultValue:E.trail}:i),{kind:"select",id:"variant",label:"Variant",description:"Original branches from this specific routine.",options:A,defaultValue:O},...vu.map(i=>i.kind==="range"&&i.id==="modernLineWidth"&&E.modernLineWidth!==void 0?{...i,defaultValue:E.modernLineWidth}:i)]}function iA(A=Pf){return Object.fromEntries(A.map(O=>[O.id,O.defaultValue]))}function ru(A,O,E){const i=A[O];return typeof i=="number"?i:E}function QO(A,O,E){const i=A[O];return typeof i=="string"?i:E}const Pn=320,Wn=200;class VO{constructor(O){this.kind=O}kind;stars=WO(300);movers=$O(120);dots=jO(180);infoParticles=JO(150);craperWalker={x:160,y:100,color:20,tick:0};wormPoints=Wf(100);doorway=$f();coolBuffer=null;coolBufferVariant="";menuNoise=kO();lastMode="";lastKind="";noiseTick=0;render(O,E){const i=ru(E.settings,"speed",1),S=ru(E.settings,"density",1),c=ru(E.settings,"trail",.35),I=QO(E.settings,"variant","original"),r=E.mode==="modern",D=E.time*i,N=this.kind==="intro"||this.kind==="info"?Math.floor(D*30)/30:D,C=Hu(O),o=this.lastMode!==E.mode||this.lastKind!==this.kind;if(this.lastMode=E.mode,this.lastKind=this.kind,this.kind==="intro"){O.cls(0),this.drawMainMenu(O,E,N,r,C);return}switch(o?(this.resetSceneState(),O.cls(0)):O.cls(0,qO(this.kind,c,r)),this.kind){case"info":this.drawInfo(O,N,r,C);break;case"saver":this.drawSaver(O,N,S,r,C);break;case"omega":this.drawOmega(O,N,S,r,C);break;case"laser":this.drawLaser(O,N,S,r,C);break;case"craper":this.drawCraper(O,N,S,r,C,I);break;case"cooler":this.drawCooler(O,N,S,r,C,I);break;case"cyber":this.drawCyber(O,N,S,r,C,I);break;case"delta":this.drawDelta(O,N,S,r,C,I);break;case"ball":this.drawBall(O,N,S,r,C,I);break;case"lines":this.drawLines(O,N,S,r,C,I);break;case"shella":this.drawShella(O,N,S,r,C,I);break;case"type1":this.drawType1(O,N,S,r,C);break;case"type2":this.drawType2(O,N,E.delta*i,S,r,C,I);break;case"tunnels":this.drawTunnels(O,N,S,r,C,I);break;case"coolx":this.drawCoolX(O,N,S,c,r,C,I);break;case"disco":this.drawDisco(O,N,S,r,C);break;case"spheres":this.drawSpheres(O,N,S,r,C);break;case"spots":this.drawSpots(O,N,S,r,C,I);break}}resetSceneState(){this.craperWalker={x:160,y:100,color:20,tick:0},this.wormPoints=Wf(140),this.doorway=$f(),this.coolBuffer=null,this.coolBufferVariant=""}update(O,E){if(this.kind!=="intro"||!E.input.pointer.justPressed)return;const i=Hu(O),S=E.input.pointer.x/i.sx,c=E.input.pointer.y/i.sy;ma({x:S,y:c},24,134,92,30)&&E.action?.("open-info"),ma({x:S,y:c},98,72,124,54)&&E.action?.("open-gallery"),ma({x:S,y:c},204,136,88,32)&&E.action?.("open-gallery")}drawMainMenu(O,E,i,S,c){const I={x:E.input.pointer.x/c.sx,y:E.input.pointer.y/c.sy},r=ma(I,24,134,92,30),D=ma(I,204,136,88,32);this.drawStars(O,c,300,!1);const N=Bl.DATA.slice(0,465),C=Bl.DATA.slice(465,844).reverse();N.forEach((b,p)=>this.drawTitleShadowLine(O,c,b,p,!1,S)),C.forEach((b,p)=>this.drawTitleShadowLine(O,c,b,p,!0,S)),this.drawPointText(O,Bl.DATA,c,0,-50,10,S?2:1,!1);let o=30;o=this.drawMenuWord(O,Bl.DATA2,c,10,0,o,S),o=this.drawMenuWord(O,Bl.DATA3,c,100,50,o,S),this.drawMenuWord(O,Bl.DATA4,c,-100,50,o,S),this.drawByline(O,c,S),this.drawNoiseBox(O,i,c,S);const U=r?{x:60,y:150}:D?{x:250,y:150}:{x:160,y:95},M=20+i*18%10;this.ellipse(O,c.x(U.x),c.y(U.y),c.w(61),c.h(36.6),M,S?2:1,1)}drawStars(O,E,i,S){for(let c=0;c<i;c+=1){const I=this.stars[c%this.stars.length],r=E.pixel(1);O.pset(E.x(I.x*Pn),E.y(I.y*Wn),S?18+c*.03:7,r)}}drawTitleShadowLine(O,E,i,S,c,I){const r=c?25.51-(S+1)*.01:19+(S+1)*.007,D=c?i.x-1:i.x,N=c?i.y+1:i.y;this.pixelLine(O,E.x(160),E.y(70),E.x(D),E.y(N-50),r,I?1.6:1,I)}drawMenuWord(O,E,i,S,c,I,r){let D=I;for(const N of E)D+=.1,this.pixelLine(O,i.x(N.x+S),i.y(N.y+c),i.x(N.x+S+3),i.y(N.y+c+3),D,r?2.2:1,r);return D}drawByline(O,E,i){let S=35;for(const c of Bl.DATA5)S+=.1,O.pset(E.x(c.x+20),E.y(c.y+100),S,i?E.pixel(1.4):1)}drawPointText(O,E,i,S,c,I,r,D){E.forEach((N,C)=>{O.pset(i.x(N.x+S),i.y(N.y+c),D?I+C*.08:I,i.pixel(r))})}drawNoiseBox(O,E,i,S){O.box(i.x(130),i.y(120),i.w(52),i.h(52),0,!0),O.box(i.x(131),i.y(121),i.w(49),i.h(49),10,!1);const c=Math.floor(E*30);c!==this.noiseTick&&(this.noiseTick=c);const I=c%16;for(let r=1;r<=48;r+=1)for(let D=1;D<=48;D+=1){const N=16+(this.menuNoise[r*48+D]+I)%16;O.pset(i.x(131+D),i.y(121+r),N,S?i.pixel(1.15):1)}}drawInfo(O,E,i,S){this.drawInfoTitle(O,S,i),this.drawInfoParticles(O,E,S,i);const c=Math.floor(E*70)%500;for(let r=1;r<=35;r+=1)this.pixelBox(O,S.x(85+r),S.y(35+r),S.x(225-r),S.y(175-r),r+c,i);const I=24+Math.sin(E*3.6)*7;this.drawInfoCredits(O,S,I,i)}drawInfoCredits(O,E,i,S){S&&(O.ctx.save(),O.ctx.scale(E.sx,E.sy)),O.locateText(11,18,"CODED",i,1),O.locateText(13,20,"B",i,1),O.locateText(14,20,"Y",i,1),O.locateText(16,19,"ROY",i,1),S&&O.ctx.restore()}drawInfoTitle(O,E,i){let S=0,c=20;for(const I of Bl.DATA){S+=.1,c+=.1;const r=I.x/2+Math.cos(S)*2+80,D=I.y/2+Math.sin(S)*2-30;O.pset(E.x(r),E.y(D),c,i?E.pixel(1.7):1)}}drawInfoParticles(O,E,i,S){this.infoParticles.forEach(c=>{if(c.x>85&&c.x<225&&c.y>35&&c.y<175)return;const I=25+Math.sin(E*c.speed+c.phase)*5;O.pset(i.x(c.x),i.y(c.y),I,i.pixel(1))})}drawSaver(O,E,i,S,c){const I=Math.floor(50*i);for(let r=0;r<I;r+=1){const D=this.movers[r],N=g1(D.x+E*25*D.dx,Pn),C=g1(D.y+E*18*D.dy,Wn),o=Math.cos(E*4+r)*15,U=Math.sin(E*4+r)*15;r%3===0?O.line(c.x(N+o),c.y(C+U),c.x(Pn/2),c.y(Wn/2),40+r,S?1.4:1,S?.7:1):O.pset(c.x(N),c.y(C),20+r,c.pixel(S?2:1))}}drawOmega(O,E,i,S,c){const r=Math.max(5,Math.floor(24/i)),D=P0(E,.25,.55,.74);for(let N=0;N<200;N+=r){const C=P0(E-N*.02,.25,.55,.74);O.line(c.x(C[0].x),c.y(C[0].y),c.x(C[1].x),c.y(C[1].y),18+N*.12,S?1.2:1,S?.35:.75),O.line(c.x(C[1].x),c.y(C[1].y),c.x(C[2].x),c.y(C[2].y),19+N*.12,S?1.2:1,S?.35:.75),O.line(c.x(C[2].x),c.y(C[2].y),c.x(C[0].x),c.y(C[0].y),20+N*.12,S?1.2:1,S?.35:.75)}O.line(c.x(D[0].x),c.y(D[0].y),c.x(D[1].x),c.y(D[1].y),30,S?2:1),O.line(c.x(D[1].x),c.y(D[1].y),c.x(D[2].x),c.y(D[2].y),33,S?2:1),O.line(c.x(D[2].x),c.y(D[2].y),c.x(D[0].x),c.y(D[0].y),36,S?2:1)}drawLaser(O,E,i,S,c){this.drawStars(O,c,200,!0);const I=P0(E*1.5,1.2,.8,1.7),r=P0(E*.9+80,.5,1.7,1.1);[0,-5,-9].forEach((N,C)=>{O.line(c.x(I[0].x+N),c.y(I[0].y+N),c.x(r[0].x+N),c.y(r[0].y+N),25+E*12+C,S?1.6:1),O.line(c.x(I[1].x+N),c.y(I[1].y+N),c.x(r[1].x+N),c.y(r[1].y+N),28+E*12+C,S?1.6:1),O.line(c.x(I[2].x+N),c.y(I[2].y+N),c.x(r[2].x+N),c.y(r[2].y+N),31+E*12+C,S?1.6:1),O.line(c.x(I[0].x+N),c.y(I[0].y+N),c.x(I[1].x+N),c.y(I[1].y+N),18+E*12+C,S?1.3:1),O.line(c.x(I[1].x+N),c.y(I[1].y+N),c.x(I[2].x+N),c.y(I[2].y+N),21+E*12+C,S?1.3:1),O.line(c.x(I[2].x+N),c.y(I[2].y+N),c.x(I[0].x+N),c.y(I[0].y+N),24+E*12+C,S?1.3:1)})}drawCraper(O,E,i,S,c,I){const r=Math.max(4,Math.floor(14*i));for(let D=0;D<r;D+=1){const N=this.craperWalker.tick*7+D,C=(Math.floor(x(N)*63)+1)/10,o=Math.floor(x(N+3)*15)+1,U=this.craperWalker.x+Math.cos(C)*o,M=this.craperWalker.y+Math.sin(C)*o,b=this.craperWalker.color;if(I==="dense")for(let p=1;p<=10;p+=1)O.circle(c.x(this.craperWalker.x),c.y(this.craperWalker.y),c.w(p),b+p,!1,S?.35:.75);else I==="wide"?O.box(c.x(this.craperWalker.x-5),c.y(this.craperWalker.y-5),c.w(10),c.h(10),b,!1,S?.55:1):O.line(c.x(this.craperWalker.x),c.y(this.craperWalker.y),c.x(U),c.y(M),b,S?1.2:1,S?.75:1);this.craperWalker.x=U<0||U>Pn?160:U,this.craperWalker.y=M<0||M>Wn?100:M,this.craperWalker.color=this.craperWalker.color>300?20:this.craperWalker.color+.01,this.craperWalker.tick+=1}}drawCooler(O,E,i,S,c,I){if(I==="wide"){let N=150-E*45%350;for(let C=0;C<38*i;C+=1){const o=E*4+C*2;N-=1.2,O.line(c.x(150+Math.cos(o)*N),c.y(100+Math.sin(o)*N),c.x(150+Math.cos(o+1)*N),c.y(100+Math.sin(o+1)*N),18+C,S?1.4:1)}return}const D=52+Math.sin(E)*48;for(let N=2;N<=7.2;N+=1.26){const C=Math.cos(N+E)*(40+D)+160,o=Math.sin(N+E)*(40+D)+100;O.line(c.x(C),c.y(o),c.x(Math.cos(N+.62+E)*(10+D)+160),c.y(Math.sin(N+.62+E)*(10+D)+100),30+E*8,S?2:1),O.line(c.x(C),c.y(o),c.x(Math.cos(N-.62+E)*(10+D)+160),c.y(Math.sin(N-.62+E)*(10+D)+100),30+E*8,S?2:1)}}drawCyber(O,E,i,S,c,I){this.drawStars(O,c,150,!0);const r=Math.floor(180*i),D=I==="wide"?4:I==="dense"?6:1;for(let N=0;N<r;N+=1){const C=N*.08+E,o=Math.cos(C),U=Math.sin(C),M=12+N*.7+Math.sin(E)*8,b=10+N*.45+Math.cos(E*.7)*8,p=o*M+150,q=U*b+100,w=20+N*.25+E*8;D===4?(O.line(c.x(1),c.y(1),c.x(p),c.y(q),w,S?1.1:1,S?.28:.55),O.line(c.x(315),c.y(199),c.x(p),c.y(q),w,S?1.1:1,S?.28:.55)):D===6?(O.line(c.x(p-15),c.y(q),c.x(p+15),c.y(q),w),O.line(c.x(p-15),c.y(q),c.x(p),c.y(q-15),w),O.line(c.x(p+15),c.y(q),c.x(p),c.y(q-15),w)):O.line(c.x(p+Math.sin(E)*20),c.y(q),c.x(o*(M+18)+150),c.y(U*b+100),w,S?1.5:1,S?.55:1)}}drawDelta(O,E,i,S,c,I){if(I==="dense"){for(let D=1;D<Wn;D+=4)for(let N=1;N<Pn;N+=12)O.line(c.x(160),c.y(100),c.x(N),c.y(D),16+N/10+E*20,S?.8:1,S?.22:.45);return}const r=I==="wide"?50+Math.sin(E)*50:50;for(let D=2;D<=7.2;D+=1.26){const N=I==="orbit"?E:0,C=Math.cos(D+N)*80+160,o=Math.sin(D+N)*80+100;O.line(c.x(C),c.y(o),c.x(Math.cos(D+.62+E)*r+160),c.y(Math.sin(D+.62+E)*r+100),30+E*10,S?2:1),O.line(c.x(C),c.y(o),c.x(Math.cos(D-.62+E)*r+160),c.y(Math.sin(D-.62+E)*r+100),30+E*10,S?2:1)}}drawBall(O,E,i,S,c,I){if(S&&I!=="orbit"){this.drawModernSpaceDepth(O,E,i,c,I);return}const r=Math.floor((I==="dense"?150:100)*i);for(let D=0;D<r;D+=1){const N=x(D)*7.3,C=5+x(D*2)*5,o=(x(D*3)*95+E*C*18)%180,U=Math.cos(N)*o+160,M=Math.sin(N)*o+100,b=Math.cos(N)*(o-C)+160,p=Math.sin(N)*(o-C)+100;I==="orbit"?O.pset(c.x(Math.cos(E+D)*(20+x(D)*130)+160),c.y(Math.sin(E+D)*(20+x(D+4)*80)+100),19+D,c.pixel(S?2:1)):O.line(c.x(b),c.y(p),c.x(U),c.y(M),18+D*.1,S?1.2:1,S?.7:1)}O.box(c.x(0),c.y(0),c.w(319),c.h(199),0,!1)}drawModernSpaceDepth(O,E,i,S,c){const I=Math.floor((c==="dense"?260:190)*i),r=160+Math.sin(E*.18)*8,D=100+Math.cos(E*.14)*5;for(let N=0;N<I;N+=1){const C=c==="dense"?3.5:3.1,o=(x(N*17+3)-.5)*C,U=(x(N*19+7)-.5)*C*.72,M=.22+x(N*23+11)*.6,b=(x(N*29+13)+E*M)%1,p=Math.max(0,b-(.018+x(N*31+17)*.026)),q=1-b*.96,w=1-p*.96,In=22/Math.max(.08,q),Cn=22/Math.max(.08,w),rn=r+o*In,vn=D+U*In,Hn=r+o*Cn,P=D+U*Cn;if(rn<-20||rn>Pn+20||vn<-20||vn>Wn+20)continue;const mn=c==="original"?7+b*3:18+b*16+N*.02,$n=.25+b*.65,u1=.35+b*1.5;O.line(S.x(Hn),S.y(P),S.x(rn),S.y(vn),mn,u1,$n),O.pset(S.x(rn),S.y(vn),mn+2,S.pixel(.6+b*.7))}O.box(S.x(0),S.y(0),S.w(319),S.h(199),0,!1)}drawLines(O,E,i,S,c,I){if(I==="wide"){const D=jf(E*.35,1,1),N=jf(E*.35+90,1,-1);O.line(c.x(D.x),c.y(D.y),c.x(N.x),c.y(N.y),20+E*4,S?2:1);return}if(I==="orbit"){for(let D=0;D<6;D+=1){const N=E*.45+D,C=E*.6+D*.7;O.line(c.x(160+Math.cos(N)*70),c.y(100+Math.sin(N)*50),c.x(160+Math.cos(C)*70),c.y(100+Math.sin(C)*50),20+D*4+E*6)}return}const r=Math.floor(32*i);for(let D=0;D<r;D+=1){const N=Math.floor(E*12),C=x(D+N)*315,o=x(D*3+N)*315,U=x(D*4)>.5?199:0,M=x(D*5)>.5?199:0;O.line(c.x(C),c.y(U),c.x(o),c.y(M),x(D)*300,S?1.1:1,S?.28:.55)}}drawShella(O,E,i,S,c,I){const r=I==="dense"?9:3;for(let D=0;D<r;D+=1){const N=30+D*11,C=D*1.7;for(let o=1;o<=7.25*i;o+=.14){const U=Math.cos(o+E+C)*N+160,M=Math.sin(o+E*.7+C)*(N*.8)+100,b=Math.cos(o+2.1+C)*(N+15)+160,p=Math.sin(o+1.6+C)*(N+10)+100;O.line(c.x(U),c.y(M),c.x(b),c.y(p),10+D*5+o*2,S?1.3:1,S?.35:.75)}}}drawType1(O,E,i,S,c){const I=Math.floor(70*i);for(let r=5;r<I;r+=8)for(let D=1;D<=100;D+=20){const N=(r+D+E*12)%130+4;O.circle(c.x(150),c.y(100),c.w(N),20+N*.2,!1,S?.5:.8)}}drawType2(O,E,i,S,c,I,r){if(r==="trail"){O.cls(0,c?.065:.1);const N=Math.floor(420*S);for(let C=0;C<N;C+=1){const o=x(C*11+5)*70+E*.18,U=35+x(C*13+7)*70,M=35+x(C*17+11)*70,b=35+x(C*19+13)*70,p=35+x(C*23+17)*70,q=E*(.8+x(C*29)*.35)+C*.0025;O.line(I.x(Math.cos(o)*U+150),I.y(Math.sin(o)*M+100),I.x(Math.cos(o+q)*b+150),I.y(Math.sin(o+q)*p+100),18+C*.05+E*2,c?1.1:1,c?.35:.7)}return}this.doorway.lineDebt+=Math.max(0,i)*520*S;const D=Math.min(32,Math.floor(this.doorway.lineDebt));this.doorway.lineDebt-=D;for(let N=0;N<D;N+=1){const C=(Math.floor(x(this.doorway.tick*17+3)*700)+1)/10;this.doorway.color+=.01,this.doorway.color>300&&(this.doorway.color=18),this.doorway.g+=.01;const o=Math.cos(C)*this.doorway.r,U=Math.sin(C)*this.doorway.r2,M=Math.cos(C+this.doorway.g)*this.doorway.r1,b=Math.sin(C+this.doorway.g)*this.doorway.r21;O.line(I.x(o+150),I.y(U+100),I.x(M+150),I.y(b+100),this.doorway.color,c?1.1:1,c?.55:1),this.doorway.tick+=1}}drawTunnels(O,E,i,S,c,I){const r=Math.max(6,Math.floor(16*i));for(let D=0;D<r;D+=1){const N=Math.floor(E*60)+D,C=N%this.wormPoints.length,o=this.wormPoints[C],U={x:o.x,y:o.y},M=I==="orbit",b=I==="original"?10:I==="wide"?2:1,p=M?[[-b,0],[b,0],[0,-b],[0,b],[-b,-b],[b,b],[b,-b],[-b,b]]:[[-b,0],[b,0],[0,-b],[0,b]],q=p[Math.floor(x(N*11)*p.length)];o.x+=q[0],o.y+=q[1],o.color=I==="original"?C+1:o.color+1,o.color>95&&(o.color=33),O.line(c.x(U.x),c.y(U.y),c.x(o.x),c.y(o.y),o.color,S?1.2:1,S?.65:1)}}drawCoolX(O,E,i,S,c,I,r){this.drawStars(O,I,150,!0);const D=this.getCoolBufferDraw(O,r),N=Hu(D);PO(D.ctx,wO(S,c),O.width,O.height);const C=r==="wide"?2:r==="dense"?3:1;let o=null;for(let U=1;U<=8*i;U+=.01){const M=Math.cos((2+C)*U+E)*42+150,b=Math.sin((4+C)*U)*42+100,p=Math.cos(U)*42+M,q=Math.sin(U)*42+b,w=25+U*8+E*5;C===1&&(c&&o?D.line(N.x(o.x),N.y(o.y),N.x(p),N.y(q),w,1.1,.75):D.pset(N.x(p),N.y(q),w,1),o={x:p,y:q}),C===2&&D.line(N.x(p),N.y(q),N.x(p+5),N.y(q+5),w,c?1.3:1),C===3&&D.circle(N.x(p),N.y(q),N.w(5),w,!1,c?.45:.8)}this.coolBuffer&&O.ctx.drawImage(this.coolBuffer,0,0)}getCoolBufferDraw(O,E){(!this.coolBuffer||this.coolBuffer.width!==O.width||this.coolBuffer.height!==O.height||this.coolBufferVariant!==E)&&(this.coolBuffer=document.createElement("canvas"),this.coolBuffer.width=O.width,this.coolBuffer.height=O.height,this.coolBufferVariant=E);const S=this.coolBuffer;if(!S)throw new Error("Could not create Cool scene buffer");const c=S.getContext("2d");if(!c)throw new Error("Could not create Cool scene buffer");return du(c,O.width,O.height,O.mode,O.antialias,O.lineScale)}drawDisco(O,E,i,S,c){const I=Math.floor(100*i);for(let r=0;r<I;r+=1){const D=r*.0627,N=lA(r),C={x:Math.cos(D)*55+160,y:Math.sin(D)*45+100},o=(Math.sin(E*.4)+1)/2,U=N.x+(C.x-N.x)*o,M=N.y+(C.y-N.y)*o;O.circle(c.x(U),c.y(M),c.w(S?1.1:1),20+r*.1+E*3,!0,S?.7:1)}}drawSpheres(O,E,i,S,c){this.drawStars(O,c,150,!0);const I=Math.floor(90*i);for(let r=0;r<I;r+=1){const N=r%2?310:0,C=(r*17+E*35)%260,o=(r/I+E*.04)%1,U=150+(N-150)*o,M=100+(C-100)*o,b=1+(r+E*10)%50;O.circle(c.x(U),c.y(M),c.w(b),18+r+E*3,!1,S?.32:.65),O.pset(c.x(U),c.y(M),10,c.pixel(S?2:1))}}drawSpots(O,E,i,S,c,I){if(I==="wide"){for(let D=0;D<40*i;D+=1){const N=x(D+Math.floor(E*6))*Pn,C=x(D*5+Math.floor(E*8))*Wn;for(let o=1;o<30;o+=2)O.circle(c.x(N),c.y(C),c.w(o),30+o+D,!1,S?.18:.35),O.line(c.x(N),c.y(C-o),c.x(N-o),c.y(C),30+o+D,S?1.1:1,S?.18:.35),O.line(c.x(N),c.y(C+o),c.x(N+o),c.y(C),30+o+D,S?1.1:1,S?.18:.35)}return}if(I==="dense"){for(let D=0;D<50;D+=1){const N=x(D)*7.3,C=(E*30+D*8)%180;O.circle(c.x(Math.cos(N)*C+160),c.y(Math.sin(N)*C+100),c.w(4+x(D)*24),20+D,!1,S?.5:1)}O.box(c.x(0),c.y(0),c.w(319),c.h(199),0,!1);return}const r=Math.floor(36*i);for(let D=0;D<r;D+=1){const N=Math.floor(E*12),C=x(D+N)*Pn,o=x(D*2)*Wn,U=o+x(D*3)*(Wn-o);O.line(c.x(C),c.y(o),c.x(C),c.y(U),20+D*.1,S?1.2:1,S?.35:.75),O.circle(c.x(C),c.y(U),c.w(1+x(D)*25),25+D,!1,S?.32:.65)}}ellipse(O,E,i,S,c,I,r,D){if(!O.antialias){const N=Math.max(48,Math.round(Math.max(S,c)*3));let C={x:E+S,y:i};for(let o=1;o<=N;o+=1){const U=o/N*Math.PI*2,M={x:E+Math.cos(U)*S,y:i+Math.sin(U)*c};O.line(C.x,C.y,M.x,M.y,I,r,D),C=M}return}O.ctx.save(),O.ctx.globalAlpha=D,O.ctx.strokeStyle=O.color(I),O.ctx.lineWidth=r*O.lineScale,O.ctx.beginPath(),O.ctx.ellipse(E,i,S,c,0,0,Math.PI*2),O.ctx.stroke(),O.ctx.restore()}pixelLine(O,E,i,S,c,I,r,D){if(D){O.line(E,i,S,c,I,r);return}let N=Math.round(E),C=Math.round(i);const o=Math.round(S),U=Math.round(c),M=Math.abs(o-N),b=N<o?1:-1,p=-Math.abs(U-C),q=C<U?1:-1;let w=M+p;for(;O.pset(N,C,I,1),!(N===o&&C===U);){const In=w*2;In>=p&&(w+=p,N+=b),In<=M&&(w+=M,C+=q)}}pixelBox(O,E,i,S,c,I,r){this.pixelLine(O,E,i,S,i,I,r?1.4:1,r),this.pixelLine(O,S,i,S,c,I,r?1.4:1,r),this.pixelLine(O,S,c,E,c,I,r?1.4:1,r),this.pixelLine(O,E,c,E,i,I,r?1.4:1,r)}}function Hu(A){const O=A.width/Pn,E=A.height/Wn;return{sx:O,sy:E,x:i=>i*O,y:i=>i*E,w:i=>i*O,h:i=>i*E,pixel:i=>Math.max(1,Math.round(i*Math.min(O,E)))}}function qO(A,O,E){return O<=0?1:A==="craper"?E?.018:.012:A==="lines"?E?.065:.04:A==="type1"?E?.045:.03:A==="type2"?0:A==="tunnels"?E?.045:.03:A==="coolx"?1:A==="spots"?E?.08:.055:E?Math.max(.04,.18-O*.12):Math.max(.1,.35-O*.2)}function WO(A){return Array.from({length:A},(O,E)=>({x:x(E*2),y:x(E*3),speed:.2+x(E*5)*1.6,size:1+Math.floor(x(E*7)*2)}))}function $O(A){return Array.from({length:A},(O,E)=>({x:x(E)*Pn,y:x(E*2)*Wn,dx:(x(E*3)>.5?1:-1)*(.5+x(E*4)*2),dy:(x(E*5)>.5?1:-1)*(.5+x(E*6)*2),color:20+x(E*7)*60}))}function jO(A){return Array.from({length:A},(O,E)=>({x:x(E*11)*Pn,y:x(E*13)*Wn}))}function JO(A){return Array.from({length:A},(O,E)=>({x:Math.floor(x(E*19)*360)+1,y:Math.floor(x(E*23)*200)+1,phase:x(E*29)*Math.PI*2,speed:(Math.floor(x(E*31)*10)+1)/5}))}function Wf(A){return Array.from({length:A},(O,E)=>({x:Math.floor(x(E*41)*360)+1,y:Math.floor(x(E*43)*200)+1,color:33+Math.floor(x(E*47)*30)}))}function $f(){return{r:Math.floor(x(103)*100)+1,r2:Math.floor(x(107)*100)+1,r1:Math.floor(x(109)*100)+1,r21:Math.floor(x(113)*100)+1,g:0,color:18,tick:0,lineDebt:0}}function PO(A,O,E,i){A.save(),A.globalCompositeOperation="destination-out",A.globalAlpha=O,A.fillStyle="#000",A.fillRect(0,0,E,i),A.restore()}function wO(A,O){return A<=0?1:O?Math.max(.04,.18-A*.12):Math.max(.1,.35-A*.2)}function kO(){return Array.from({length:2353},(A,O)=>Math.floor(x(O*17)*10))}function x(A){return nA(Math.sin(A*12.9898+78.233)*43758.5453)}function nA(A){return A-Math.floor(A)}function g1(A,O){const E=O*2,i=(A%E+E)%E;return i>O?E-i:i}function jf(A,O,E){return{x:g1(40+A*45*O,Pn),y:g1(30+A*31*E,Wn)}}function P0(A,O,E,i){return[{x:g1(20+A*45*O,Pn),y:g1(40+A*35*O,Wn)},{x:g1(160+A*45*E,Pn),y:g1(20+A*35*E,Wn)},{x:g1(300+A*45*i,Pn),y:g1(160+A*35*i,Wn)}]}function lA(A){const O=Math.floor(A/33),E=A%33,i=1+x(A)*2;return O===0?{x:80+E*i,y:60+E*i}:O===1?{x:80+33*i-E*i*2,y:60+33*i}:{x:80-33*i+E*i,y:60+33*i-E*i}}function ma(A,O,E,i,S){return A.x>=O&&A.x<=O+i&&A.y>=E&&A.y<=E+S}function pn(A,O,E,i,S,c,I,r,D=Pf){return{id:A,title:O,key:E,originalName:i,note:S,settings:D,annotation:{file:"VIRT.BAS",subroutine:i,startLine:c,endLine:I},create:()=>new VO(r)}}const tA=[pn("intro","Intro and Title","I","program start","The opening star field, title data art, and menu identity remade for canvas.",27,258,"intro"),pn("info","Info","N","INFO","The old credits chamber, now with readable archive notes beside it.",1588,1661,"info"),pn("saver","Screen Savers","S","SAVER/SAVER2/SAVER3","Idle animations from the menus, preserved as standalone scenes.",2172,2316,"saver")],wf=[pn("omega","Omega Beams","1","OMEGA","Radial beam geometry with density and length controls.",2069,2170,"omega",qf({trail:.05})),pn("laser","Laser Beams","2","LASER","Triangular laser traces driven by speed and color motion.",1663,1827,"laser",qf({trail:.05})),pn("craper","Random Walker","3","CRAPER","Slow random-walk line drawing from the original mode selector.",1070,1105,"craper",M1([{label:"Original",value:"original",description:"Colorful random-walk line drawing."},{label:"Variant 1",value:"dense",description:"Circle traces around the walker."},{label:"Variant 2",value:"wide",description:"Box traces around the walker."}])),pn("cooler","Cooler","4","COOLER","Orbiting line structures with two classic motion modes.",893,951,"cooler",M1([{label:"Original",value:"original",description:"Orbiting line structure."},{label:"Variant 1",value:"wide",description:"Contracting spiral line mode."}])),pn("cyber","Cyber Storm","5","CYBER","Tunnel and storm forms pulled from the old custom/random selector.",1107,1196,"cyber",M1([{label:"Original",value:"original",description:"Central storm tunnel."},{label:"Variant 1",value:"wide",description:"Corner-to-center beam traces."},{label:"Variant 2",value:"dense",description:"Triangular storm traces."}])),pn("delta","Delta","6","DELTA","Rotating triangular forms and mirrored line fields.",1198,1390,"delta",M1([{label:"Original",value:"original",description:"Rotating triangular arms."},{label:"Variant 1",value:"wide",description:"Wider radius arm motion."},{label:"Variant 2",value:"dense",description:"Dense radial line field."},{label:"Variant 3",value:"orbit",description:"Orbiting anchor points."}])),pn("ball","Space","7","BALL","The bouncing/orbiting space particle routines grouped under SPACE.",267,725,"ball",M1([{label:"Original",value:"original",description:"Radiating space particle trails."},{label:"Variant 1",value:"dense",description:"More particle trails."},{label:"Variant 2",value:"orbit",description:"Orbital point field."}])),pn("lines","Lines","8","LINES","The line experiments, boxes, bounces, and perspective traces.",1829,2067,"lines",M1([{label:"Original",value:"wide",description:"Single bouncing line mode."},{label:"Variant 1",value:"original",description:"Random edge-to-edge line traces."},{label:"Variant 2",value:"orbit",description:"Orbital line mode."}],"wide")),pn("shella","Gravity","A","SHELLA","Gravity-style orbiting strokes and multi-arm motion.",2318,2510,"shella",M1([{label:"Original",value:"original",description:"Three-arm gravity trace."},{label:"Variant 1",value:"dense",description:"Nine-arm gravity trace."}])),pn("type1","Warp","B","TYPE1","Concentric warp rings from the original WARP routine.",3027,3042,"type1"),pn("type2","Doorway","C","TYPE2","Doorway rectangles that pull the eye into the center.",3044,3067,"type2",M1([{label:"Original",value:"original",description:"Faithful accumulating TYPE2 line loop."},{label:"Variant 1",value:"trail",description:"Smooth fading doorway cloud."}])),pn("tunnels","Bugs and Worms","D","TUNNELS","Tunnel crawlers and worm-like line motion.",2918,3025,"tunnels",M1([{label:"Original",value:"original",description:"Large-step worm motion."},{label:"Variant 1",value:"wide",description:"Small-step worm motion."},{label:"Variant 2",value:"dense",description:"Small-step color-cycling motion."},{label:"Variant 3",value:"orbit",description:"Diagonal worm motion."}])),pn("coolx","Cool","E","COOLX","Random custom cool-stuff generator remade from the original lissajous and bounce modes.",953,1068,"coolx",M1([{label:"Original",value:"original",description:"Lissajous point field."},{label:"Variant 1",value:"wide",description:"Offset line field."},{label:"Variant 2",value:"dense",description:"Circle field."}],"original",{trail:0,modernLineWidth:8})),pn("disco","Morph","F","DISCO","Morphing disco blobs and shifting colorful trails.",1392,1563,"disco"),pn("spheres","Spheres","G","SPHERES","Sphere arcs, center points, and orbital shell motion.",2539,2605,"spheres"),pn("spots","Spots","H","SPOTS","Spot, box, circle, and floating particle variants.",2607,2916,"spots",M1([{label:"Original",value:"dense",description:"Expanding spot circles from the original routine."},{label:"Variant 1",value:"wide",description:"Circle-and-cross spot field."},{label:"Variant 2",value:"original",description:"Vertical spot streaks."}],"dense"))],w0=[...tA,...wf],aA=w0.filter(A=>A.id!=="intro"&&A.id!=="info");function cA(A){return w0.find(O=>O.id===A)??w0[0]}function fA(A){return aA.find(O=>O.id===A)??wf[0]}function NA(A){return w0.find(O=>O.key.toLowerCase()===A.toLowerCase())}function EA({scene:A,mode:O,settings:E,onExit:i,onSceneAction:S,nativeHost:c=!1,nativeFrameBridge:I=!1}){const r=Ll.useRef(null),D=Ll.useMemo(()=>A.create(),[A]),N=Ll.useRef(E),C=Ll.useRef(O),o=Ll.useRef(S),U=Ll.useRef({pointer:{x:160,y:100,down:!1,justPressed:!1,active:!1},keys:new Set,lastKey:""});return N.current=E,C.current=O,o.current=S,Ll.useLayoutEffect(()=>{const M=r.current;if(!M)return;let b=0,p=0,q=0,w=performance.now(),In=C.current,Cn=0,rn=!1;const vn=M.getContext("2d");if(!vn)return;const Hn=()=>{const G=M.getBoundingClientRect(),z=C.current==="classic",k=c||I?1:window.devicePixelRatio||1;let nn=z?320:Math.max(640,Math.floor(G.width*k)),Y=z?200:Math.max(400,Math.floor(G.height*k));(M.width!==nn||M.height!==Y)&&(M.width=nn,M.height=Y),M.style.imageRendering=z?"pixelated":"auto"},P=G=>{const z=M.getBoundingClientRect(),k=C.current==="classic",nn=k?320:M.width,Y=k?200:M.height;return{x:(G.clientX-z.left)/z.width*nn,y:(G.clientY-z.top)/z.height*Y}},mn=G=>{const z=P(G);U.current.pointer={...U.current.pointer,...z,active:!0}},$n=G=>{const z=P(G);U.current.pointer={...z,down:!0,justPressed:!0,active:!0},M.setPointerCapture(G.pointerId)},u1=()=>{U.current.pointer={...U.current.pointer,down:!1}},i1=G=>{if(G.key==="Escape"){G.preventDefault(),i();return}U.current.keys.add(G.key),U.current.lastKey=G.key},_n=G=>{U.current.keys.delete(G.key)};Hn(),window.addEventListener("resize",Hn),window.addEventListener("keydown",i1),window.addEventListener("keyup",_n),M.addEventListener("pointermove",mn),M.addEventListener("pointerdown",$n),M.addEventListener("pointerup",u1),M.addEventListener("pointerleave",u1);const Y1=G=>{if(rn)return;In!==C.current&&(Hn(),In=C.current);const z=(G-w)/1e3,k=Number.isFinite(z)&&z>0?Math.min(.05,z):1/30;w=G;const nn=du(vn,M.width,M.height,C.current,!!N.current.antialias,Number(N.current.modernLineWidth)||1),Y={mode:C.current,time:G/1e3,delta:k,frame:b,settings:N.current,input:U.current,action:o.current};try{D.update?.(nn,Y),D.render(nn,Y),window.__VIRTUALITY_STATUS__={frame:b,height:M.height,mode:C.current,sceneId:A.id,width:M.width}}catch(v){throw window.__VIRTUALITY_STATUS__={error:v instanceof Error?v.message:String(v),frame:b,height:M.height,mode:C.current,sceneId:A.id,width:M.width},v}U.current.pointer.justPressed=!1,b+=1,Cn=performance.now()},s1=G=>{rn||(Y1(G),p=requestAnimationFrame(s1))},wn=()=>{Hn(),Y1(performance.now());const G=M.getBoundingClientRect(),z=vn.getImageData(0,0,M.width,M.height),k=Math.max(4,Math.floor(M.width*M.height/1200)*4);let nn=0,Y=0;for(let v=0;v<z.data.length;v+=k)Y+=1,(z.data[v]||z.data[v+1]||z.data[v+2])&&(nn+=1);return{ok:!0,width:M.width,height:M.height,cssWidth:Math.round(G.width),cssHeight:Math.round(G.height),pixelRatio:c||I?1:window.devicePixelRatio||1,frame:b,sampleNonBlack:nn,sampleTotal:Y,dataURL:M.toDataURL("image/png")}},L=()=>{rn=!0,cancelAnimationFrame(p),window.clearInterval(q)};return D.init?.(du(vn,M.width,M.height,C.current,!!N.current.antialias,Number(N.current.modernLineWidth)||1),{mode:C.current,time:0,delta:0,frame:0,settings:N.current,input:U.current,action:o.current}),window.__VIRTUALITY_STOP__=L,I&&(window.__VIRTUALITY_RENDER_FRAME__=wn),Y1(performance.now()),I||(p=requestAnimationFrame(s1),q=window.setInterval(()=>{performance.now()-Cn>120&&Y1(performance.now())},100)),()=>{rn=!0,cancelAnimationFrame(p),window.clearInterval(q),I&&window.__VIRTUALITY_RENDER_FRAME__===wn&&delete window.__VIRTUALITY_RENDER_FRAME__,window.__VIRTUALITY_STOP__===L&&delete window.__VIRTUALITY_STOP__,D.dispose?.(),window.removeEventListener("resize",Hn),window.removeEventListener("keydown",i1),window.removeEventListener("keyup",_n),M.removeEventListener("pointermove",mn),M.removeEventListener("pointerdown",$n),M.removeEventListener("pointerup",u1),M.removeEventListener("pointerleave",u1)}},[D,i,c,I]),yO.jsx("canvas",{ref:r,className:`stage-canvas ${O}`,"aria-label":`${A.title} canvas`})}export{EA as C,eA as R,NA as a,fA as b,TA as c,iA as d,aA as e,cA as f,yO as j,uA as o,Ll as r,w0 as s};
